# 06 – MockMvc REST API testing
(Revision: tests stay in package `com.example.demo` and import `com.example.demo.model.Employee` and `com.example.demo.repository.EmployeeRepository`. If you change your package or entity, fix these two imports.)
The 7 topic folders each hold one runnable test class for the **Employee** API (01 project). The same 7 files already sit in the project's `src/test/java`, so `mvn test` runs all 32 tests. Two more test classes for the two-collection project are in `02_FullStack_Two_Collections/.../src/test`.

## Template (what every class contains)
```java
@SpringBootTest            // starts the whole application context
@AutoConfigureMockMvc      // gives you a MockMvc object (no real HTTP port is opened)
class XTests {
    @Autowired MockMvc mockMvc;
    mockMvc.perform(post("/api/employees").contentType("application/json").content("{...}"))
           .andExpect(status().isCreated())              // 201
           .andExpect(jsonPath("$.name").value("Meena")) // particular value
           .andExpect(jsonPath("$.id").exists())         // field exists
           .andExpect(jsonPath("$._id").doesNotExist()); // unexpected field absent
}
```
Static imports: `MockMvcRequestBuilders.*`, `MockMvcResultMatchers.*`. **Spring Boot 4:** `@AutoConfigureMockMvc` is `org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc` and needs `spring-boot-starter-webmvc-test` (both in the pom). On Boot 3 it is `org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc`.

## Accuracy notes
* 201 is returned only because the controller has `@ResponseStatus(HttpStatus.CREATED)`; 204 for delete likewise.
* 400 for missing fields, malformed JSON, wrong types and bad parameters is guaranteed here because the service validates and `ApiExceptionHandler` maps the exceptions. Without such code, Spring's default behaviour applies and you must not assume a code.
* Record counts match `setUp()` (3 records). Change the data → change the expected number.
* In MockMvc an error response has **no `/error` page body**; our `{"error": "..."}` body exists only because of `ApiExceptionHandler`.
* Trailing slash (`/api/employees/`) and unmatched-path behaviour depend on the Spring version/routing configuration – try it with `status().is...()` in a scratch test before relying on it; no template asserts it.
* The two reference documents (`Spring-Boot-Test-API (2).docx`, `TestAPI (2).docx`) were **not in the upload**, so I could not read them or audit their assertions. Upload them and I will compare.
* `jsonPath("$.length()")` is used for counts; the Hamcrest form `jsonPath("$", hasSize(3))` is equivalent (used in the schema test).
