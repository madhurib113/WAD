# JSON content type, record count, particular value, JSON types, calculation result
File: `EmployeeJsonResponseTests.java` (copy of the test inside `01_FullStack_One_Collection/Complete_Project/backend/src/test/java/com/example/demo/`).
**Use:** paste into `src/test/java/<your package>/` of the project, change the package line, endpoint URLs, JSON keys and expected values; click the green arrow beside the class in IntelliJ.
**Needs:** MongoDB running; the test uses database `employee_db_test` (`src/test/resources/application.properties`).
**What each test checks:** read the comment above each `@Test` method.
**If an assertion fails:** IntelliJ shows *Status expected:<201> but was:<200>* (controller returns a different status), or *No value at JSON path "$.x"* (field name/path wrong), or *JSON path "$.length()" expected:<3> but was:<4>* (data in `setUp()` differs from the number you expect).
