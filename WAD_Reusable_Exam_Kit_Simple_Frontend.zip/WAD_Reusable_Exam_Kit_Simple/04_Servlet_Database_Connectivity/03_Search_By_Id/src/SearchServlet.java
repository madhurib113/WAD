import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** Search one record by primary key.  Table: employees(empid, name, department, salary). Every query uses PreparedStatement. */
public class SearchServlet extends HttpServlet {

    // ===== CHANGE HERE: placeholders, use your own values =====
    private static final String URL  = "jdbc:mysql://localhost:3306/wad_db";
    private static final String USER = "YOUR_DB_USER";
    private static final String PASS = "YOUR_DB_PASSWORD";
    // ==========================================================

    // New connection per request, closed automatically by try-with-resources.
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    @Override
    public void init() throws ServletException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }          // Connector/J must be in WEB-INF/lib
        catch (ClassNotFoundException e) { throw new ServletException("MySQL driver jar missing in WEB-INF/lib", e); }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { doPost(req, res); }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        String action = req.getParameter("action");
        out.println("<html><body>");
        try (Connection con = connect()) {
            if ("search".equals(action)) {
                try (PreparedStatement ps = con.prepareStatement("SELECT * FROM employees WHERE empid = ?")) {
                    ps.setInt(1, Integer.parseInt(req.getParameter("empid").trim()));
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next())
                            out.println("<p>Name: " + esc(rs.getString("name")) + "<br>Department: " + esc(rs.getString("department"))
                                    + "<br>Salary: " + rs.getDouble("salary") + "</p>");
                        else out.println("<p>Employee not found.</p>");
                    }
                }
            }
            else out.println("<p>Choose an operation from the form.</p>");
        } catch (NumberFormatException e) {
            out.println("<p style='color:red'>Enter valid numbers.</p>");
        } catch (SQLIntegrityConstraintViolationException e) {
            out.println("<p style='color:red'>Duplicate employee id.</p>");
        } catch (SQLException e) {
            e.printStackTrace();                                      // full error goes to Tomcat logs
            out.println("<p style='color:red'>Database error: " + esc(e.getMessage()) + "</p>");
        }
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
