# 04 – Servlet + JDBC (MySQL)
Five folders, same table `employees(empid, name, department, salary)`; each is a deployable webapp (URL `/db`). `05_Complete_CRUD` contains everything; 01–04 are subsets.

## Setup
1. MySQL running. Run `schema.sql` (MySQL Workbench or `mysql -u root -p < schema.sql`).
2. Edit `URL`, `USER`, `PASS` at the top of the servlet (placeholders `YOUR_DB_USER` / `YOUR_DB_PASSWORD`; schema `wad_db`).
3. Copy **mysql-connector-j-8.x.jar** into `WEB-INF/lib/` of the webapp (your repo's version used `WEB-INF/lib/mysql-connector-j.jar`). Driver class `com.mysql.cj.jdbc.Driver`; URL form `jdbc:mysql://host:3306/schema`.
4. `export CATALINA_HOME=...` → `./compile.sh` → copy the folder to `$CATALINA_HOME/webapps/<Name>` → start Tomcat → `http://localhost:8080/<Name>/`.
(javax / Tomcat 8.5–9; for Tomcat 10+ use `../03_Servlet_Basics/convert_to_jakarta.sh <folder>`.)

## Sample
Add 3 / Asha / IT / 45000 → "Employee added successfully."; View → table of 3 rows; Search 3 → name/department/salary; Update 3 → "Employee updated."; Delete 99 → "Employee not found."; duplicate id → "Duplicate employee id."
## Notes
`PreparedStatement` with `?` placeholders everywhere (prevents SQL injection); connection opened per request with try-with-resources (your original kept one shared `Connection` in a field, which is not thread-safe); `executeUpdate()` returns the affected-row count, used for "not found". **To change scenario:** edit table/column names in the SQL strings, the `req.getParameter` names, and the HTML inputs.
