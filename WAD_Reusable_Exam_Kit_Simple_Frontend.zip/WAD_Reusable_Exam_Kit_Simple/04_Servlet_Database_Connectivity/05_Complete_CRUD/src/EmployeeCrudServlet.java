import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** Complete CRUD.  Table: employees(empid, name, department, salary). Every query uses PreparedStatement. */
public class EmployeeCrudServlet extends HttpServlet {

    // ===== CHANGE HERE: placeholders, use your own values =====
    private static final String URL  = "jdbc:mysql://localhost:3306/wad_db";
    private static final String USER = "YOUR_DB_USER";
    private static final String PASS = "YOUR_DB_PASSWORD";
    // ==========================================================

    // New connection per request, closed automatically by try-with-resources.
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    @Override
    public void init() throws ServletException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }          // Connector/J must be in WEB-INF/lib
        catch (ClassNotFoundException e) { throw new ServletException("MySQL driver jar missing in WEB-INF/lib", e); }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { doPost(req, res); }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        String action = req.getParameter("action");
        out.println("<html><body>");
        try (Connection con = connect()) {
            if ("add".equals(action)) {
                try (PreparedStatement ps = con.prepareStatement("INSERT INTO employees (empid, name, department, salary) VALUES (?, ?, ?, ?)")) {
                    ps.setInt(1, Integer.parseInt(req.getParameter("empid").trim()));
                    ps.setString(2, req.getParameter("name"));
                    ps.setString(3, req.getParameter("department"));
                    ps.setDouble(4, Double.parseDouble(req.getParameter("salary")));
                    ps.executeUpdate();
                    out.println("<p>Employee added successfully.</p>");
                }
            }
            else if ("view".equals(action)) {
                try (PreparedStatement ps = con.prepareStatement("SELECT empid, name, department, salary FROM employees ORDER BY empid");
                     ResultSet rs = ps.executeQuery()) {
                    out.println("<h2>All Employees</h2><table border='1'><tr><th>ID</th><th>Name</th><th>Department</th><th>Salary</th></tr>");
                    while (rs.next())
                        out.println("<tr><td>" + rs.getInt("empid") + "</td><td>" + esc(rs.getString("name")) + "</td><td>"
                                + esc(rs.getString("department")) + "</td><td>" + rs.getDouble("salary") + "</td></tr>");
                    out.println("</table>");
                }
            }
            else if ("search".equals(action)) {
                try (PreparedStatement ps = con.prepareStatement("SELECT * FROM employees WHERE empid = ?")) {
                    ps.setInt(1, Integer.parseInt(req.getParameter("empid").trim()));
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next())
                            out.println("<p>Name: " + esc(rs.getString("name")) + "<br>Department: " + esc(rs.getString("department"))
                                    + "<br>Salary: " + rs.getDouble("salary") + "</p>");
                        else out.println("<p>Employee not found.</p>");
                    }
                }
            }
            else if ("update".equals(action)) {
                try (PreparedStatement ps = con.prepareStatement("UPDATE employees SET name = ?, department = ?, salary = ? WHERE empid = ?")) {
                    ps.setString(1, req.getParameter("name"));
                    ps.setString(2, req.getParameter("department"));
                    ps.setDouble(3, Double.parseDouble(req.getParameter("salary")));
                    ps.setInt(4, Integer.parseInt(req.getParameter("empid").trim()));
                    out.println(ps.executeUpdate() > 0 ? "<p>Employee updated.</p>" : "<p>Employee not found.</p>");   // rows affected
                }
            }
            else if ("delete".equals(action)) {
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM employees WHERE empid = ?")) {
                    ps.setInt(1, Integer.parseInt(req.getParameter("empid").trim()));
                    out.println(ps.executeUpdate() > 0 ? "<p>Employee deleted.</p>" : "<p>Employee not found.</p>");
                }
            }
            else out.println("<p>Choose an operation from the form.</p>");
        } catch (NumberFormatException e) {
            out.println("<p style='color:red'>Enter valid numbers.</p>");
        } catch (SQLIntegrityConstraintViolationException e) {
            out.println("<p style='color:red'>Duplicate employee id.</p>");
        } catch (SQLException e) {
            e.printStackTrace();                                      // full error goes to Tomcat logs
            out.println("<p style='color:red'>Database error: " + esc(e.getMessage()) + "</p>");
        }
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
