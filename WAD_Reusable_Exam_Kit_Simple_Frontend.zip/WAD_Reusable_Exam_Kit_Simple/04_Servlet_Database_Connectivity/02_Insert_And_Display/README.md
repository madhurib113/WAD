# Servlet + JDBC insert + display all
**API: `javax.servlet.*` (Servlet 3.1) → Tomcat 8.5 or 9.** For Tomcat 10+ run `../convert_to_jakarta.sh <this folder>` (or replace `javax.servlet` by `jakarta.servlet` in `src/*.java` and use the Jakarta namespace in `WEB-INF/web.xml`), then recompile.
| Tomcat | Servlet | Package |
|---|---|---|
| 8.5 | 3.1 | `javax.servlet` |
| 9.0 | 4.0 | `javax.servlet` |
| 10.1 | 6.0 | `jakarta.servlet` |
| 11 | 6.1 | `jakarta.servlet` |

**Needs:** a running MySQL, `schema.sql` executed, edit `URL/USER/PASS` (placeholders) in the servlet, and `mysql-connector-j-8.x.jar` copied into `WEB-INF/lib/` (download: dev.mysql.com/downloads/connector/j). Without the jar you get *MySQL driver jar missing*.

**Files:** `index.html` (form) · `src/*.java` · `WEB-INF/web.xml` (URL → servlet) · `compile.bat` / `compile.sh` · `schema.sql`
**URLs:** `/db` (POST with hidden field `action`)
**Sample:** Add 3/Asha/IT/45000 → added; View → table
**Deploy (Windows):** `set CATALINA_HOME=C:\apache-tomcat-9.0.xx` → `compile.bat` → copy this folder to `%CATALINA_HOME%\webapps\<Name>` → `%CATALINA_HOME%\bin\startup.bat` → http://localhost:8080/<Name>/ . (Linux/Mac: `compile.sh`, `startup.sh`.)
**Verified in this kit:** compiles with `javac` against servlet-api 4.0.1 (javax) and, after conversion, Tomcat 10 servlet-api (jakarta). **Not run** inside Tomcat and not run against MySQL.
**Change for another question:** field names in the HTML ⇄ `request.getParameter("...")`; formula/SQL lines; `<url-pattern>` ⇄ form `action`.
