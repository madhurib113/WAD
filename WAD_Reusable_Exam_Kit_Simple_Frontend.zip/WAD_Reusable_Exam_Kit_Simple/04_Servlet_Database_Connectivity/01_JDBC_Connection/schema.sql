CREATE DATABASE IF NOT EXISTS wad_db;
USE wad_db;
CREATE TABLE IF NOT EXISTS employees (
    empid      INT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    department VARCHAR(50),
    salary     DOUBLE
);
INSERT INTO employees VALUES (1, 'Ravi Kumar', 'IT', 50000), (2, 'Priya Sharma', 'HR', 60000);
-- Verify:  SELECT * FROM employees;
