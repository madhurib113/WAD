@echo off
if not exist WEB-INF\classes mkdir WEB-INF\classes
javac -cp "%CATALINA_HOME%\lib\servlet-api.jar" -d WEB-INF\classes src\*.java
