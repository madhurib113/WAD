#!/bin/sh
# export CATALINA_HOME=/path/to/tomcat first
set -e
mkdir -p WEB-INF/classes
javac -cp "${SERVLET_API:-$CATALINA_HOME/lib/servlet-api.jar}" -d WEB-INF/classes src/*.java
echo Compiled
