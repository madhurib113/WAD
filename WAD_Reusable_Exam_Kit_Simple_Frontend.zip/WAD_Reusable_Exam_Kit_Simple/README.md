# WAD Reusable Exam Kit
Start here. Your original repository is **not** modified; everything new is in this folder.

| Folder | What | Status |
|---|---|---|
| `01_FullStack_One_Collection` | Employee Directory: Spring Boot 4.1.1 + MongoDB + Vue/Axios, 7 MockMvc test classes, `HOW_TO_CHANGE_SCENARIO.md` | written, partly verified (below) |
| `02_FullStack_Two_Collections` | Event ⇄ Participant, relationship rules, `HOW_TO_CHANGE_TWO_COLLECTION_SCENARIO.md` | written, partly verified |
| `03_Servlet_Basics` | form input, total/discount, marks/grade, 5 other calculators | compiled |
| `04_Servlet_Database_Connectivity` | JDBC connection, insert/display, search, update/delete, full CRUD (MySQL) | compiled, **not run against a DB** |
| `05_MVC_Programs` | folder structure only | **PENDING – needs your syllabus** |
| `06_MockMvc_REST_API_Testing` | one folder per topic, with test class + README | compiled against stubs only |
| `07_Exam_Reference`, `08_Practice_Questions` | commands, selection guide, setup, errors, viva, questions | written |
Also read `Repository_Analysis.md`.

## Quick start (project 1)
MongoDB running → `cd 01_FullStack_One_Collection/Complete_Project/backend && mvn spring-boot:run` → new terminal `cd ../frontend && npm install && npm run dev` → http://localhost:5173.

## Test report (revised kit) – honest status
| Check | Status |
|---|---|
| Package declarations / imports / file paths of all Java files | **Static inspection + javac against homemade stubs** (rc 0, both projects, main + tests). Stubs prove names and types of my code only – this is **not** a real Maven build |
| Service logic on in-memory repositories (after restructure) | **Passed** – 34 (project 1) and 32 (project 2) checks executed |
| Vue (new simple `App.vue`): `npm ci` + production build, both frontends | **Passed** (re-run after this revision) |
| Simple Vue pages in a browser against the live backend | **Not run** – URLs, params and field names cross-checked against the controllers by reading (static inspection) |
| Servlets (javax, 13 classes + 5 JDBC) compile; Jakarta conversion compiles | **Passed** (javac only) |
| Maven build (`mvn package`), `mvn test`, MockMvc tests, Spring Boot start-up | **Not run** – Maven Central unreachable from my sandbox |
| MongoDB behaviour, API ⇄ database, Vue ⇄ live backend | **Not run** – no MongoDB / no Maven |
| Tomcat deployment, JDBC against MySQL | **Not run** |
| `check_environment.ps1` / `.bat` | **Not run** (no Windows/PowerShell here) – written carefully, report any error |
| Feature-removal tables (§J) | **Static inspection only** |
| Spring Boot 4.1.1 compatibility | unchanged from your own generated `demo/pom.xml`; unverified by me |
See `CHANGES_REVISION.md`.
