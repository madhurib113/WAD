# API requests (Postman or curl)

Base URL: `http://localhost:8080/api/employees`   (Postman: set header `Content-Type: application/json` for POST/PUT)

| # | Purpose | Method + URL | Body | Success status |
|---|---------|--------------|------|----------------|
| 1 | Create | `POST /api/employees` | `{"name":"Meena","email":"m@x.com","phone":"900","department":"Finance","designation":"Analyst","salary":45000}` | 201 |
| 2 | All | `GET /api/employees` | – | 200 |
| 3 | All, sorted | `GET /api/employees?sortBy=salary&dir=desc` | – | 200 |
| 4 | By id | `GET /api/employees/{id}` | – | 200 / 404 |
| 5 | Update | `PUT /api/employees/{id}` | same shape as #1 | 200 / 404 / 400 |
| 6 | Delete | `DELETE /api/employees/{id}` | – | 204 / 404 |
| 7 | Search | `GET /api/employees/search?name=ra` | – | 200 |
| 8 | Filter | `GET /api/employees/filter?department=IT&min=40000&max=90000` | – | 200 |
| 9 | Count | `GET /api/employees/count` or `?department=IT` | – | 200 `{"count":n}` |
| 10 | Salary statistics | `GET /api/employees/stats` | – | 200 |
| 11 | Salary +10 % | `POST /api/employees/{id}/adjust?percent=10` (negative = decrease) | – | 200 / 404 / 400 |

curl examples:
```bash
curl -i -X POST http://localhost:8080/api/employees -H "Content-Type: application/json" \
     -d '{"name":"Meena","email":"m@x.com","salary":45000}'
curl -i http://localhost:8080/api/employees
curl -i "http://localhost:8080/api/employees/filter?department=IT&min=40000"
curl -i -X DELETE http://localhost:8080/api/employees/PASTE_ID_HERE
```
Error body (400/404): `{"error":"name is required"}`.
