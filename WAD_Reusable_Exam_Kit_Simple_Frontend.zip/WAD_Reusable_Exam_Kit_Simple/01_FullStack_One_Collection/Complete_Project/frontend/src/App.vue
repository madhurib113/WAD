<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const API = 'http://localhost:8080/api/employees'

const employees = ref([])
const form = ref({ name: '', email: '', phone: '', department: '', designation: '', salary: '' })
const editingId = ref('')
const lookupId = ref('')
const searchText = ref('')
const filterValue = ref('')
const minValue = ref('')
const maxValue = ref('')
const sortBy = ref('')
const sortDir = ref('asc')
const adjustId = ref('')
const percent = ref('')
const result = ref('')
const error = ref('')

function showError(e) {
  error.value = e.response?.data?.error || e.message
}

// Display all (with optional sorting)
async function loadAll() {
  error.value = ''
  try {
    const res = await axios.get(API, { params: { sortBy: sortBy.value, dir: sortDir.value } })
    employees.value = res.data
  } catch (e) { showError(e) }
}

// Add (when editingId is empty) or Update (when editingId has an id)
async function save() {
  error.value = ''
  const body = { ...form.value, salary: form.value.salary === '' ? null : Number(form.value.salary) }
  try {
    if (editingId.value === '') {
      await axios.post(API, body)
    } else {
      await axios.put(API + '/' + editingId.value, body)
    }
    form.value = { name: '', email: '', phone: '', department: '', designation: '', salary: '' }
    editingId.value = ''
    loadAll()
  } catch (e) { showError(e) }
}

// Copy a row into the form
function edit(emp) {
  form.value = { name: emp.name, email: emp.email, phone: emp.phone, department: emp.department, designation: emp.designation, salary: emp.salary }
  editingId.value = emp.id
}

async function remove(id) {
  error.value = ''
  try {
    await axios.delete(API + '/' + id)
    loadAll()
  } catch (e) { showError(e) }
}

// Get one by id
async function getOne() {
  error.value = ''
  try {
    const res = await axios.get(API + '/' + lookupId.value)
    result.value = JSON.stringify(res.data, null, 2)
  } catch (e) { showError(e) }
}

async function search() {
  error.value = ''
  try {
    const res = await axios.get(API + '/search', { params: { name: searchText.value } })
    employees.value = res.data
  } catch (e) { showError(e) }
}

async function filter() {
  error.value = ''
  try {
    const res = await axios.get(API + '/filter', { params: { department: filterValue.value, min: minValue.value, max: maxValue.value } })
    employees.value = res.data
  } catch (e) { showError(e) }
}

async function count() {
  error.value = ''
  try {
    const res = await axios.get(API + '/count', { params: { department: filterValue.value } })
    result.value = 'Count: ' + res.data.count
  } catch (e) { showError(e) }
}

async function stats() {
  error.value = ''
  try {
    const res = await axios.get(API + '/stats')
    result.value = JSON.stringify(res.data, null, 2)
  } catch (e) { showError(e) }
}

async function adjust() {
  error.value = ''
  try {
    const res = await axios.post(API + '/' + adjustId.value + '/adjust', null, { params: { percent: percent.value } })
    result.value = JSON.stringify(res.data, null, 2)
    loadAll()
  } catch (e) { showError(e) }
}

onMounted(loadAll)
</script>

<template>
  <h1>Employee Directory</h1>
  <p v-if="error">Error: {{ error }}</p>

  <h2>Add / Update Employee</h2>
  <p>Name: <input v-model="form.name" /></p>
  <p>Email: <input v-model="form.email" /></p>
  <p>Phone: <input v-model="form.phone" /></p>
  <p>Department: <input v-model="form.department" /></p>
  <p>Designation: <input v-model="form.designation" /></p>
  <p>Salary: <input v-model="form.salary" type="number" /></p>
  <button @click="save">{{ editingId === '' ? 'Add' : 'Update' }}</button>

  <h2>Get by ID</h2>
  <input v-model="lookupId" placeholder="id" />
  <button @click="getOne">Get</button>

  <h2>Search / Filter / Sort</h2>
  <p>
    <input v-model="searchText" placeholder="name" />
    <button @click="search">Search</button>
  </p>
  <p>
    <input v-model="filterValue" placeholder="department" />
    <input v-model="minValue" type="number" placeholder="min salary" />
    <input v-model="maxValue" type="number" placeholder="max salary" />
    <button @click="filter">Filter</button>
    <button @click="count">Count</button>
  </p>
  <p>
    Sort by:
    <select v-model="sortBy">
      <option value="">none</option>
      <option value="name">name</option>
      <option value="department">department</option>
      <option value="salary">salary</option>
    </select>
    <select v-model="sortDir">
      <option value="asc">ascending</option>
      <option value="desc">descending</option>
    </select>
    <button @click="loadAll">Show all</button>
  </p>

  <h2>Calculations</h2>
  <p><button @click="stats">Total / average / max / min salary</button></p>
  <p>
    <input v-model="adjustId" placeholder="id" />
    <input v-model="percent" type="number" placeholder="percent (negative = decrease)" />
    <button @click="adjust">Change salary by %</button>
  </p>

  <h2>Result</h2>
  <pre>{{ result }}</pre>

  <h2>All Employees ({{ employees.length }})</h2>
  <table>
    <tr>
      <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Department</th><th>Designation</th><th>Salary</th><th>Actions</th>
    </tr>
    <tr v-for="e in employees" :key="e.id">
      <td>{{ e.id }}</td>
      <td>{{ e.name }}</td>
      <td>{{ e.email }}</td>
      <td>{{ e.phone }}</td>
      <td>{{ e.department }}</td>
      <td>{{ e.designation }}</td>
      <td>{{ e.salary }}</td>
      <td>
        <button @click="edit(e)">Edit</button>
        <button @click="remove(e.id)">Delete</button>
      </td>
    </tr>
  </table>
</template>

<style>
table, th, td { border: 1px solid gray; border-collapse: collapse; padding: 4px; }
</style>
