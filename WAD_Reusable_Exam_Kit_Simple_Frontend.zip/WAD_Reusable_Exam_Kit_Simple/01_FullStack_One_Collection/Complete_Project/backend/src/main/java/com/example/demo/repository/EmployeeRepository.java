package com.example.demo.repository;

import com.example.demo.model.Employee;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

// REPOSITORY = database access. Spring writes the queries from the method NAMES.
public interface EmployeeRepository extends MongoRepository<Employee, String> {

    List<Employee> findByNameContainingIgnoreCase(String name);   // search

    long countByDepartmentIgnoreCase(String department);          // count with a condition
}
