package com.example.demo.controller;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

// CONTROLLER = URLs. Each method = one endpoint (HTTP method + path).
@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})   // lets the Vue dev server call this API
public class EmployeeController {

    private final EmployeeService service;

    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    // POST   /api/employees              -> 201 Created + saved employee
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Employee create(@RequestBody Employee e) {
        return service.create(e);
    }

    // GET    /api/employees              -> all   (optional ?sortBy=salary&dir=desc)
    @GetMapping
    public List<Employee> getAll(@RequestParam(required = false) String sortBy,
                                 @RequestParam(required = false) String dir) {
        return service.getAll(sortBy, dir);
    }

    // GET    /api/employees/{id}         -> one, or 404
    @GetMapping("/{id}")
    public Employee getById(@PathVariable String id) {
        return service.getById(id);
    }

    // PUT    /api/employees/{id}         -> updated employee, or 404
    @PutMapping("/{id}")
    public Employee update(@PathVariable String id, @RequestBody Employee e) {
        return service.update(id, e);
    }

    // DELETE /api/employees/{id}         -> 204 No Content, or 404
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) {
        service.delete(id);
    }

    // GET    /api/employees/search?name=ra
    @GetMapping("/search")
    public List<Employee> search(@RequestParam String name) {
        return service.search(name);
    }

    // GET    /api/employees/filter?department=IT&min=40000&max=90000   (all optional; min/max apply to salary)
    @GetMapping("/filter")
    public List<Employee> filter(@RequestParam(required = false) String department,
                                 @RequestParam(required = false) Double min,
                                 @RequestParam(required = false) Double max) {
        return service.filter(department, min, max);
    }

    // GET    /api/employees/count   or   /count?department=IT      -> {"count": 3}
    @GetMapping("/count")
    public Map<String, Long> count(@RequestParam(required = false) String department) {
        return Map.of("count", service.count(department));
    }

    // GET    /api/employees/stats -> {"count":..,"total":..,"average":..,"max":..,"min":..} of salary
    @GetMapping("/stats")
    public Map<String, Object> salaryStats() {
        return service.salaryStats();
    }

    // POST   /api/employees/{id}/adjust?percent=10   (negative = decrease)  -> employee with the new salary
    @PostMapping("/{id}/adjust")
    public Employee adjust(@PathVariable String id, @RequestParam double percent) {
        return service.adjustSalary(id, percent);
    }
}
