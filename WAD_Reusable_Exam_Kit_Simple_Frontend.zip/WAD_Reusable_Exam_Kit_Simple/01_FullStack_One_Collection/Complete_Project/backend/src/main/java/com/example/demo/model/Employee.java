package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// MODEL = one document in the MongoDB collection "employees".
// The Java field "id" is stored in MongoDB as "_id" (an ObjectId); Spring converts it to/from a String.
@Document(collection = "employees")
public class Employee {

    @Id
    private String id;          // <-- never typed by the user; MongoDB generates it

    private String name;        // required
    private String email;       // required
    private String phone;
    private String department;
    private String designation;
    private Double salary;      // required, >= 0 (Double, not double, so "missing" can be detected as null)

    public Employee() { }       // required by Jackson / Spring Data

    public Employee(String name, String email, String phone, String department, String designation, Double salary) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.designation = designation;
        this.salary = salary;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
    public Double getSalary() { return salary; }
    public void setSalary(Double salary) { this.salary = salary; }
}
