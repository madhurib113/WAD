package com.example.demo.service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.DoubleSummaryStatistics;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

// SERVICE = business rules (validation, calculations). The controller only forwards requests here.
@Service
public class EmployeeService {

    // Fields the client may sort by. Anything else -> 400 instead of a database error.
    private static final Set<String> SORT_FIELDS = Set.of("name", "email", "department", "designation", "salary");

    private final EmployeeRepository repo;

    public EmployeeService(EmployeeRepository repo) {
        this.repo = repo;
    }

    // ---------- validation ----------
    private void validate(Employee e) {
        if (e.getName() == null || e.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (e.getEmail() == null || e.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (e.getSalary() == null || e.getSalary() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "salary is required and must be >= 0");
    }

    private ResponseStatusException notFound(String id) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, "Employee not found with id " + id);
    }

    // ---------- CRUD ----------
    public Employee create(Employee e) {
        validate(e);
        e.setId(null);                 // ignore any id sent by the client; MongoDB generates a new one
        return repo.save(e);
    }

    public List<Employee> getAll(String sortBy, String dir) {
        if (sortBy == null || sortBy.isBlank()) return repo.findAll();
        if (!SORT_FIELDS.contains(sortBy))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "cannot sort by " + sortBy);
        Sort.Direction d = "desc".equalsIgnoreCase(dir) ? Sort.Direction.DESC : Sort.Direction.ASC;
        return repo.findAll(Sort.by(d, sortBy));
    }

    public Employee getById(String id) {
        return repo.findById(id).orElseThrow(() -> notFound(id));
    }

    public Employee update(String id, Employee incoming) {
        Employee existing = getById(id);          // 404 if missing (so PUT never silently creates)
        validate(incoming);
        existing.setName(incoming.getName());
        existing.setEmail(incoming.getEmail());
        existing.setPhone(incoming.getPhone());
        existing.setDepartment(incoming.getDepartment());
        existing.setDesignation(incoming.getDesignation());
        existing.setSalary(incoming.getSalary());
        return repo.save(existing);
    }

    public void delete(String id) {
        if (!repo.existsById(id)) throw notFound(id);
        repo.deleteById(id);
    }

    // ---------- search / filter / count ----------
    public List<Employee> search(String name) {
        return repo.findByNameContainingIgnoreCase(name);
    }

    // Any combination of the three optional filters. Missing filter = ignored.
    public List<Employee> filter(String department, Double min, Double max) {
        return repo.findAll().stream()
                .filter(e -> department == null || department.isBlank()
                        || (e.getDepartment() != null && e.getDepartment().equalsIgnoreCase(department)))
                .filter(e -> min == null || (e.getSalary() != null && e.getSalary() >= min))
                .filter(e -> max == null || (e.getSalary() != null && e.getSalary() <= max))
                .toList();
    }

    public long count(String department) {
        if (department == null || department.isBlank()) return repo.count();
        return repo.countByDepartmentIgnoreCase(department);
    }

    // ---------- calculations ----------
    // Total / average / max / min salary of every employee.
    public Map<String, Object> salaryStats() {
        DoubleSummaryStatistics s = repo.findAll().stream()
                .filter(e -> e.getSalary() != null)
                .mapToDouble(Employee::getSalary)
                .summaryStatistics();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("count", s.getCount());
        m.put("total", s.getSum());
        m.put("average", s.getCount() == 0 ? 0.0 : Math.round(s.getAverage() * 100.0) / 100.0);
        m.put("max", s.getCount() == 0 ? 0.0 : s.getMax());
        m.put("min", s.getCount() == 0 ? 0.0 : s.getMin());
        return m;
    }

    // SPECIAL OPERATION: change the salary by N percent and save it.
    //   percent = 10  -> 10% raise      percent = -20 -> 20% cut (e.g. a discount when the field is "price")
    // (Replace this method for another question: total price, grade, bonus ...)
    public Employee adjustSalary(String id, double percent) {
        if (percent == 0 || percent <= -100)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "percent must not be 0 and must be greater than -100");
        Employee e = getById(id);
        double newSalary = e.getSalary() + e.getSalary() * percent / 100.0;
        e.setSalary(Math.round(newSalary * 100.0) / 100.0);
        return repo.save(e);
    }
}
