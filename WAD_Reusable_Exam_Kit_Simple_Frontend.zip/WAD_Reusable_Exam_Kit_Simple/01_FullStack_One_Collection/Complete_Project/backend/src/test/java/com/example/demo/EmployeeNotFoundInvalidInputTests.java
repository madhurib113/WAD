package com.example.demo;

import com.example.demo.exception.ApiExceptionHandler;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;   // Boot 4 package (Boot 3: org.springframework.boot.test.autoconfigure.web.servlet)
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Missing records and invalid requests. */
@SpringBootTest
@AutoConfigureMockMvc
class EmployeeNotFoundInvalidInputTests {

    @Autowired MockMvc mockMvc;
    @Autowired EmployeeRepository repo;
    String firstId;   // id of "Ravi Kumar"

    // Runs before EVERY test: empty the TEST database (employee_db_test) and insert 3 known records.
    @BeforeEach
    void setUp() {
        repo.deleteAll();
        firstId = repo.save(new Employee("Ravi Kumar", "ravi@example.com", "9876543210", "IT", "Developer", 50000.0)).getId();
        repo.save(new Employee("Priya Sharma", "priya@example.com", "9876500001", "HR", "Manager", 60000.0));
        repo.save(new Employee("Arun Raj", "arun@example.com", "9876500002", "IT", "Tester", 40000.0));
    }

    static final String MISSING_ID = "000000000000000000000000";

    // Checks: 404 and the JSON error message produced by ApiExceptionHandler.
    @Test
    void missingId_returns404_withMessage() throws Exception {
        mockMvc.perform(get("/api/employees/" + MISSING_ID))
               .andExpect(status().isNotFound())
               .andExpect(jsonPath("$.error").value("Employee not found with id " + MISSING_ID));
    }

    // Checks: an id that is not even ObjectId-shaped is simply "not found".
    @Test
    void garbageId_returns404() throws Exception {
        mockMvc.perform(get("/api/employees/abc"))
               .andExpect(status().isNotFound());
    }

    // Checks: required query parameter missing -> 400.
    @Test
    void search_withoutName_returns400() throws Exception {
        mockMvc.perform(get("/api/employees/search"))
               .andExpect(status().isBadRequest());
    }

    // Checks: sorting by a field that does not exist -> 400.
    @Test
    void sort_unknownField_returns400() throws Exception {
        mockMvc.perform(get("/api/employees").param("sortBy", "banana"))
               .andExpect(status().isBadRequest());
    }

    // Checks: wrong parameter type (?percent=abc) -> 400.
    @Test
    void adjust_nonNumericPercent_returns400() throws Exception {
        mockMvc.perform(post("/api/employees/" + firstId + "/adjust").param("percent", "abc"))
               .andExpect(status().isBadRequest());
    }

    // Checks: filter that matches nothing is NOT an error: 200 with an empty array.
    @Test
    void filter_noMatch_returnsEmptyArray() throws Exception {
        mockMvc.perform(get("/api/employees/filter").param("department", "Nowhere"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(0));
    }
}
