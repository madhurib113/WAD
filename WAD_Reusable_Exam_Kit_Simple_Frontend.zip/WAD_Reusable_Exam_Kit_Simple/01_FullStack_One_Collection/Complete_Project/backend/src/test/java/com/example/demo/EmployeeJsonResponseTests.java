package com.example.demo;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;   // Boot 4 package (Boot 3: org.springframework.boot.test.autoconfigure.web.servlet)
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** Content type, number of records, particular values, JSON types. */
@SpringBootTest
@AutoConfigureMockMvc
class EmployeeJsonResponseTests {

    @Autowired MockMvc mockMvc;
    @Autowired EmployeeRepository repo;
    String firstId;   // id of "Ravi Kumar"

    // Runs before EVERY test: empty the TEST database (employee_db_test) and insert 3 known records.
    @BeforeEach
    void setUp() {
        repo.deleteAll();
        firstId = repo.save(new Employee("Ravi Kumar", "ravi@example.com", "9876543210", "IT", "Developer", 50000.0)).getId();
        repo.save(new Employee("Priya Sharma", "priya@example.com", "9876500001", "HR", "Manager", 60000.0));
        repo.save(new Employee("Arun Raj", "arun@example.com", "9876500002", "IT", "Tester", 40000.0));
    }

    // Checks: the response Content-Type is JSON.
    // contentTypeCompatibleWith ignores an optional ";charset=UTF-8" suffix, so it is the safer choice.
    @Test
    void response_isJson() throws Exception {
        mockMvc.perform(get("/api/employees"))
               .andExpect(status().isOk())
               .andExpect(content().contentTypeCompatibleWith("application/json"));
    }

    // Checks: the top level is an array containing 3 records.
    @Test
    void response_isArrayOfThree() throws Exception {
        mockMvc.perform(get("/api/employees"))
               .andExpect(jsonPath("$").isArray())
               .andExpect(jsonPath("$.length()").value(3));
    }

    // Checks: a particular value. Sorting by name makes the first record predictable.
    @Test
    void response_particularValue() throws Exception {
        mockMvc.perform(get("/api/employees").param("sortBy", "name"))
               .andExpect(jsonPath("$[0].name").value("Arun Raj"))
               .andExpect(jsonPath("$[0].salary").value(40000.0));
    }

    // Checks: JSON types of single-record fields.
    @Test
    void response_fieldTypes() throws Exception {
        mockMvc.perform(get("/api/employees/" + firstId))
               .andExpect(jsonPath("$.id").isString())
               .andExpect(jsonPath("$.name").isString())
               .andExpect(jsonPath("$.salary").isNumber());
    }

    // Checks: the calculation endpoint. Total = 50000+60000+40000, average = 50000.
    @Test
    void response_salaryStats() throws Exception {
        mockMvc.perform(get("/api/employees/stats"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.count").value(3))
               .andExpect(jsonPath("$.total").value(150000.0))
               .andExpect(jsonPath("$.average").value(50000.0))
               .andExpect(jsonPath("$.max").value(60000.0))
               .andExpect(jsonPath("$.min").value(40000.0));
    }
}
