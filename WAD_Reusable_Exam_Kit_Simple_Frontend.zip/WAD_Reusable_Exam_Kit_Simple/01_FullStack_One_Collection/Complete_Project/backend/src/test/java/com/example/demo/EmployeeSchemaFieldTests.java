package com.example.demo;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;   // Boot 4 package (Boot 3: org.springframework.boot.test.autoconfigure.web.servlet)
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Required fields exist; unexpected fields do not; exact field count. */
@SpringBootTest
@AutoConfigureMockMvc
class EmployeeSchemaFieldTests {

    @Autowired MockMvc mockMvc;
    @Autowired EmployeeRepository repo;
    String firstId;   // id of "Ravi Kumar"

    // Runs before EVERY test: empty the TEST database (employee_db_test) and insert 3 known records.
    @BeforeEach
    void setUp() {
        repo.deleteAll();
        firstId = repo.save(new Employee("Ravi Kumar", "ravi@example.com", "9876543210", "IT", "Developer", 50000.0)).getId();
        repo.save(new Employee("Priya Sharma", "priya@example.com", "9876500001", "HR", "Manager", 60000.0));
        repo.save(new Employee("Arun Raj", "arun@example.com", "9876500002", "IT", "Tester", 40000.0));
    }

    // Checks: every REQUIRED field is present in one record.
    @Test
    void requiredFieldsExist() throws Exception {
        mockMvc.perform(get("/api/employees/" + firstId))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.id").exists())
               .andExpect(jsonPath("$.name").exists())
               .andExpect(jsonPath("$.email").exists())
               .andExpect(jsonPath("$.salary").exists());
    }

    // Checks: fields that must NOT be exposed / do not belong to this entity.
    //  - "_id"      : Java exposes "id", never MongoDB's raw "_id"
    //  - "password" : something that must never leak
    //  - "rollNo"   : a field from a different scenario (catches copy/paste mistakes)
    @Test
    void unexpectedFieldsDoNotExist() throws Exception {
        mockMvc.perform(get("/api/employees/" + firstId))
               .andExpect(jsonPath("$._id").doesNotExist())
               .andExpect(jsonPath("$.password").doesNotExist())
               .andExpect(jsonPath("$.rollNo").doesNotExist());
    }

    // Checks: required fields exist in EVERY element of the list ([*] means "each element").
    @Test
    void everyListItemHasRequiredFields() throws Exception {
        mockMvc.perform(get("/api/employees"))
               .andExpect(jsonPath("$[*].id", hasSize(3)))
               .andExpect(jsonPath("$[*].name", hasSize(3)))
               .andExpect(jsonPath("$[*].salary", hasSize(3)));
    }

    // Checks: the object has EXACTLY these 7 properties (any extra/missing one fails).
    // "$.*" returns every value of the object. Update the 7 if you add/remove a field in Employee.java.
    @Test
    void exactFieldCount() throws Exception {
        mockMvc.perform(get("/api/employees/" + firstId))
               .andExpect(jsonPath("$.*", hasSize(7)));
    }
}
