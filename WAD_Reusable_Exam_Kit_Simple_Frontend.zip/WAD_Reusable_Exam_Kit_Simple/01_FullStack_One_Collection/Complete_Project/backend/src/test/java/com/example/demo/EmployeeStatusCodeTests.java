package com.example.demo;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;   // Boot 4 package (Boot 3: org.springframework.boot.test.autoconfigure.web.servlet)
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** One test per HTTP status code the API returns: 200, 201, 204, 400, 404, 405. */
@SpringBootTest
@AutoConfigureMockMvc
class EmployeeStatusCodeTests {

    @Autowired MockMvc mockMvc;
    @Autowired EmployeeRepository repo;
    String firstId;   // id of "Ravi Kumar"

    // Runs before EVERY test: empty the TEST database (employee_db_test) and insert 3 known records.
    @BeforeEach
    void setUp() {
        repo.deleteAll();
        firstId = repo.save(new Employee("Ravi Kumar", "ravi@example.com", "9876543210", "IT", "Developer", 50000.0)).getId();
        repo.save(new Employee("Priya Sharma", "priya@example.com", "9876500001", "HR", "Manager", 60000.0));
        repo.save(new Employee("Arun Raj", "arun@example.com", "9876500002", "IT", "Tester", 40000.0));
    }

    static final String MISSING_ID = "000000000000000000000000";   // valid ObjectId format, but no such document

    @Test void status200_getAll() throws Exception {
        mockMvc.perform(get("/api/employees")).andExpect(status().isOk());                     // 200
    }

    @Test void status200_put() throws Exception {
        mockMvc.perform(put("/api/employees/" + firstId).contentType("application/json")
                .content("{\"name\":\"Meena\",\"email\":\"meena@example.com\",\"phone\":\"9000000000\",\"department\":\"Finance\",\"designation\":\"Analyst\",\"salary\":45000}")).andExpect(status().isOk());                               // 200
    }

    @Test void status201_post() throws Exception {
        mockMvc.perform(post("/api/employees").contentType("application/json")
                .content("{\"name\":\"Meena\",\"email\":\"meena@example.com\",\"phone\":\"9000000000\",\"department\":\"Finance\",\"designation\":\"Analyst\",\"salary\":45000}")).andExpect(status().isCreated());                          // 201
    }

    @Test void status204_delete() throws Exception {
        mockMvc.perform(delete("/api/employees/" + firstId)).andExpect(status().isNoContent()); // 204
    }

    @Test void status400_missingField() throws Exception {
        mockMvc.perform(post("/api/employees").contentType("application/json")
                .content("{}")).andExpect(status().isBadRequest());                            // 400
    }

    @Test void status404_getMissing() throws Exception {
        mockMvc.perform(get("/api/employees/" + MISSING_ID)).andExpect(status().isNotFound()); // 404
    }

    @Test void status404_deleteMissing() throws Exception {
        mockMvc.perform(delete("/api/employees/" + MISSING_ID)).andExpect(status().isNotFound());
    }

    @Test void status404_putMissing() throws Exception {
        mockMvc.perform(put("/api/employees/" + MISSING_ID).contentType("application/json")
                .content("{\"name\":\"Meena\",\"email\":\"meena@example.com\",\"phone\":\"9000000000\",\"department\":\"Finance\",\"designation\":\"Analyst\",\"salary\":45000}")).andExpect(status().isNotFound());
    }

    // PATCH is not mapped on /{id}, so Spring answers 405 Method Not Allowed.
    @Test void status405_wrongMethod() throws Exception {
        mockMvc.perform(patch("/api/employees/" + firstId)).andExpect(status().isMethodNotAllowed());
    }
}
