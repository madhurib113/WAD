package com.example.demo;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;   // Boot 4 package (Boot 3: org.springframework.boot.test.autoconfigure.web.servlet)
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** PUT, DELETE and the special "adjust salary by percent" operation. */
@SpringBootTest
@AutoConfigureMockMvc
class EmployeeUpdateDeleteTests {

    @Autowired MockMvc mockMvc;
    @Autowired EmployeeRepository repo;
    String firstId;   // id of "Ravi Kumar"

    // Runs before EVERY test: empty the TEST database (employee_db_test) and insert 3 known records.
    @BeforeEach
    void setUp() {
        repo.deleteAll();
        firstId = repo.save(new Employee("Ravi Kumar", "ravi@example.com", "9876543210", "IT", "Developer", 50000.0)).getId();
        repo.save(new Employee("Priya Sharma", "priya@example.com", "9876500001", "HR", "Manager", 60000.0));
        repo.save(new Employee("Arun Raj", "arun@example.com", "9876500002", "IT", "Tester", 40000.0));
    }

    // Checks: PUT replaces the fields and the new values are returned.
    @Test
    void put_updatesEmployee() throws Exception {
        mockMvc.perform(put("/api/employees/" + firstId)
                    .contentType("application/json")
                    .content("{\"name\":\"Ravi K\",\"email\":\"ravi@example.com\",\"department\":\"HR\",\"salary\":55000}"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.id").value(firstId))
               .andExpect(jsonPath("$.name").value("Ravi K"))
               .andExpect(jsonPath("$.salary").value(55000.0));
        assertEquals("Ravi K", repo.findById(firstId).get().getName());   // also verify the database
    }

    // Checks: PUT with invalid data -> 400 and the old value stays.
    @Test
    void put_invalid_returns400() throws Exception {
        mockMvc.perform(put("/api/employees/" + firstId)
                    .contentType("application/json")
                    .content("{\"name\":\"\",\"email\":\"a@b.c\",\"salary\":10}"))
               .andExpect(status().isBadRequest());
        assertEquals("Ravi Kumar", repo.findById(firstId).get().getName());
    }

    // Checks: DELETE -> 204, the record is gone from the database, and GET afterwards is 404.
    @Test
    void delete_removesEmployee() throws Exception {
        mockMvc.perform(delete("/api/employees/" + firstId))
               .andExpect(status().isNoContent());
        assertFalse(repo.existsById(firstId));
        mockMvc.perform(get("/api/employees/" + firstId))
               .andExpect(status().isNotFound());
    }

    // Checks: special operation. 50000 + 10% = 55000.
    @Test
    void adjust_plusTenPercent() throws Exception {
        mockMvc.perform(post("/api/employees/" + firstId + "/adjust").param("percent", "10"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.salary").value(55000.0));
        assertEquals(55000.0, repo.findById(firstId).get().getSalary());
    }

    // Checks: a negative percent is a decrease. 50000 - 20% = 40000.
    @Test
    void adjust_minusTwentyPercent() throws Exception {
        mockMvc.perform(post("/api/employees/" + firstId + "/adjust").param("percent", "-20"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.salary").value(40000.0));
    }

    // Checks: 0 percent is rejected.
    @Test
    void adjust_zeroPercent_returns400() throws Exception {
        mockMvc.perform(post("/api/employees/" + firstId + "/adjust").param("percent", "0"))
               .andExpect(status().isBadRequest());
    }
}
