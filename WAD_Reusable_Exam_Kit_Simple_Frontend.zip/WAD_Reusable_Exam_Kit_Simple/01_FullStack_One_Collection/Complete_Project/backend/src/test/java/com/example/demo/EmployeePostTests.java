package com.example.demo;

import com.example.demo.exception.ApiExceptionHandler;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;   // Boot 4 package (Boot 3: org.springframework.boot.test.autoconfigure.web.servlet)
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** POST tests: valid insert, missing/invalid fields, broken JSON. */
@SpringBootTest
@AutoConfigureMockMvc
class EmployeePostTests {

    @Autowired MockMvc mockMvc;
    @Autowired EmployeeRepository repo;
    String firstId;   // id of "Ravi Kumar"

    // Runs before EVERY test: empty the TEST database (employee_db_test) and insert 3 known records.
    @BeforeEach
    void setUp() {
        repo.deleteAll();
        firstId = repo.save(new Employee("Ravi Kumar", "ravi@example.com", "9876543210", "IT", "Developer", 50000.0)).getId();
        repo.save(new Employee("Priya Sharma", "priya@example.com", "9876500001", "HR", "Manager", 60000.0));
        repo.save(new Employee("Arun Raj", "arun@example.com", "9876500002", "IT", "Tester", 40000.0));
    }

    // Checks: valid JSON -> 201 CREATED, response has a generated id and the sent values.
    @Test
    void post_validEmployee_returns201() throws Exception {
        mockMvc.perform(post("/api/employees")
                    .contentType("application/json")
                    .content("{\"name\":\"Meena\",\"email\":\"meena@example.com\",\"phone\":\"9000000000\",\"department\":\"Finance\",\"designation\":\"Analyst\",\"salary\":45000}"))
               .andExpect(status().isCreated())
               .andExpect(jsonPath("$.id").exists())
               .andExpect(jsonPath("$.name").value("Meena"))
               .andExpect(jsonPath("$.salary").value(45000.0));
    }

    // Checks: the record really reached the database (3 old + 1 new).
    @Test
    void post_validEmployee_isSavedInDatabase() throws Exception {
        mockMvc.perform(post("/api/employees")
                    .contentType("application/json")
                    .content("{\"name\":\"Meena\",\"email\":\"meena@example.com\",\"phone\":\"9000000000\",\"department\":\"Finance\",\"designation\":\"Analyst\",\"salary\":45000}"))
               .andExpect(status().isCreated());
        assertEquals(4, repo.count());
    }

    // Checks: name missing -> 400 and an error message; nothing is saved.
    @Test
    void post_missingName_returns400() throws Exception {
        mockMvc.perform(post("/api/employees")
                    .contentType("application/json")
                    .content("{\"email\":\"x@example.com\",\"salary\":1000}"))
               .andExpect(status().isBadRequest())
               .andExpect(jsonPath("$.error").value("name is required"));
        assertEquals(3, repo.count());
    }

    // Checks: salary missing -> 400.
    @Test
    void post_missingSalary_returns400() throws Exception {
        mockMvc.perform(post("/api/employees")
                    .contentType("application/json")
                    .content("{\"name\":\"X\",\"email\":\"x@example.com\"}"))
               .andExpect(status().isBadRequest());
    }

    // Checks: negative salary -> 400.
    @Test
    void post_negativeSalary_returns400() throws Exception {
        mockMvc.perform(post("/api/employees")
                    .contentType("application/json")
                    .content("{\"name\":\"X\",\"email\":\"x@example.com\",\"salary\":-5}"))
               .andExpect(status().isBadRequest());
    }

    // Checks: wrong type ("salary":"abc") -> 400 (handled in ApiExceptionHandler).
    @Test
    void post_wrongType_returns400() throws Exception {
        mockMvc.perform(post("/api/employees")
                    .contentType("application/json")
                    .content("{\"name\":\"X\",\"email\":\"x@example.com\",\"salary\":\"abc\"}"))
               .andExpect(status().isBadRequest());
    }

    // Checks: syntactically broken JSON -> 400 (handled in ApiExceptionHandler).
    @Test
    void post_malformedJson_returns400() throws Exception {
        mockMvc.perform(post("/api/employees")
                    .contentType("application/json")
                    .content("{ this is not json"))
               .andExpect(status().isBadRequest());
    }
}
