package com.example.demo;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;   // Boot 4 package (Boot 3: org.springframework.boot.test.autoconfigure.web.servlet)
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** GET tests: success, wrong path, by id, search, filter, sort, count. */
@SpringBootTest
@AutoConfigureMockMvc
class EmployeeGetTests {

    @Autowired MockMvc mockMvc;
    @Autowired EmployeeRepository repo;
    String firstId;   // id of "Ravi Kumar"

    // Runs before EVERY test: empty the TEST database (employee_db_test) and insert 3 known records.
    @BeforeEach
    void setUp() {
        repo.deleteAll();
        firstId = repo.save(new Employee("Ravi Kumar", "ravi@example.com", "9876543210", "IT", "Developer", 50000.0)).getId();
        repo.save(new Employee("Priya Sharma", "priya@example.com", "9876500001", "HR", "Manager", 60000.0));
        repo.save(new Employee("Arun Raj", "arun@example.com", "9876500002", "IT", "Tester", 40000.0));
    }

    // Checks: GET /api/employees answers 200 OK.
    @Test
    void getAll_returns200() throws Exception {
        mockMvc.perform(get("/api/employees"))
               .andExpect(status().isOk());
    }

    // Checks: exactly 3 records come back (setUp inserted 3).
    @Test
    void getAll_returnsThreeRecords() throws Exception {
        mockMvc.perform(get("/api/employees"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(3));
    }

    // Checks: a path that does not exist answers 404.
    @Test
    void incorrectEndpoint_returns404() throws Exception {
        mockMvc.perform(get("/api/employeez"))
               .andExpect(status().isNotFound());
    }

    // Checks: GET by id returns that employee.
    @Test
    void getById_returnsEmployee() throws Exception {
        mockMvc.perform(get("/api/employees/" + firstId))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.name").value("Ravi Kumar"))
               .andExpect(jsonPath("$.department").value("IT"));
    }

    // Checks: "ra" is contained in "Ravi Kumar" and "Arun Raj" (case-insensitive) -> 2 results.
    @Test
    void search_returnsMatchingNames() throws Exception {
        mockMvc.perform(get("/api/employees/search").param("name", "ra"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(2));
    }

    // Checks: filter by department -> 2 IT employees.
    @Test
    void filter_byDepartment() throws Exception {
        mockMvc.perform(get("/api/employees/filter").param("department", "IT"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(2));
    }

    // Checks: condition salary >= 50000 -> Ravi (50000) and Priya (60000).
    @Test
    void filter_byMinSalary() throws Exception {
        mockMvc.perform(get("/api/employees/filter").param("min", "50000"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(2));
    }

    // Checks: sorting by salary descending puts the highest salary first.
    @Test
    void sort_bySalaryDescending() throws Exception {
        mockMvc.perform(get("/api/employees").param("sortBy", "salary").param("dir", "desc"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$[0].name").value("Priya Sharma"))
               .andExpect(jsonPath("$[2].name").value("Arun Raj"));
    }

    // Checks: count endpoints.
    @Test
    void count_all_and_byDepartment() throws Exception {
        mockMvc.perform(get("/api/employees/count"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.count").value(3));
        mockMvc.perform(get("/api/employees/count").param("department", "IT"))
               .andExpect(jsonPath("$.count").value(2));
    }
}
