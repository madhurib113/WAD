# HOW TO CHANGE THE SCENARIO (one-collection template)

The template is **Employee** (`name, email, phone, department, designation, salary`) on `/api/employees`, collection `employees`, database `employee_db`.
Everything below is a **file-by-file checklist**. Work top to bottom. A worked before/after example is in section H.

> **Golden rule.** Four names must stay identical everywhere:
> **Java field name = JSON key = Vue `form.xxx` name = (what you look at in Compass).**
> If you type `price` in Java, it must be `price` in the Vue `form` object and `v-model`, in request JSON and in test JSON.


## Package layout (read first)
```
com/example/demo/  DemoApplication.java          <- root package: Spring scans everything below it
  model/       Employee.java
  repository/  EmployeeRepository.java
  service/     EmployeeService.java
  controller/  EmployeeController.java
  exception/   ApiExceptionHandler.java
src/test/java/com/example/demo/  7 test classes (import model.* and repository.*)
```
Each file starts with its own `package com.example.demo.<sub>;` and **imports the classes it uses from the other sub-packages** (e.g. the service imports `com.example.demo.model.Employee` and `com.example.demo.repository.EmployeeRepository`).
**When you rename a class with IntelliJ Shift+F6, imports and package lines update automatically.** If you edit by hand, update the file name, the `class` name and every `import` that mentions it.
Which imports each file needs: model → none of ours · repository → model · service → model + repository · controller → model + service · exception → none of ours · tests → model + repository.
Scenario-specific names written below as `Employee.java` etc. live in the sub-package above.

---

## 0. Fast path in IntelliJ (saves minutes)
1. Open `model/Employee.java` → put the cursor on the class name → **Shift+F6** → type `Product` → tick *"Search in comments and strings"* → OK.
   IntelliJ renames the file, the class and every reference (repository, service, controller, tests).
2. Do the same with `EmployeeRepository` → `ProductRepository`, `EmployeeService` → `ProductService`, `EmployeeController` → `ProductController`.
3. Rename the test classes the same way (optional but tidy).
4. Then edit the *contents* described in sections A–E. Rename of fields: put the cursor on a field → **Shift+F6** → renames the field **and** its getter/setter.

---

## A. Changing the entity name (`Employee` → `Product`)

| # | File (under `backend/src/main/java/com/example/demo/`, in the sub-package shown) | What to change |
|---|---|---|
| 1 | `model/Employee.java` → **rename file + class** to `model/Product.java` | `public class Product`, both constructors (`public Product()` and the field constructor) |
| 2 | `repository/EmployeeRepository.java` → `repository/ProductRepository.java` | interface name; `MongoRepository<Product, String>`; `List<Product>` return types |
| 3 | `service/EmployeeService.java` → `service/ProductService.java` | class name; constructor name; field type `ProductRepository`; every `Employee` type; the text `"Employee not found with id "` |
| 4 | `controller/EmployeeController.java` → `controller/ProductController.java` | class name; constructor; `EmployeeService` → `ProductService`; every `Employee` type |
| 5 | `exception/ApiExceptionHandler.java` | **nothing** (does not mention the entity) |
| 6 | `DemoApplication.java` | **nothing** |

Tests (`backend/src/test/java/com/example/demo/`, 7 files): replace `Employee` → `Product` and `EmployeeRepository` → `ProductRepository` (Ctrl+Shift+R *Replace in Files*, scope = that folder). Also fix the error-message text asserted in `EmployeeNotFoundInvalidInputTests` (`"Employee not found with id "`).

Frontend: no entity name exists in Vue code. Only `title` and the URL (section D).

## B. Changing the fields (`name, email, salary` → `name, price, quantity`)

| # | File | What to change |
|---|---|---|
| 1 | `model/Product.java` | Replace the field declarations, the field constructor, and the getters/setters (right-click → *Generate → Getter and Setter*). Remove `@Id` **never**. Use `Double`/`Integer` (wrapper types) for numbers so "missing" = `null`. |
| 2 | `repository/ProductRepository.java` | Rename derived queries to existing fields: `findByNameContainingIgnoreCase` (needs a field `name`), `findByDepartmentIgnoreCase` → `findByCategoryIgnoreCase`, `findBySalaryGreaterThanEqual` → `findByPriceGreaterThanEqual`, `countByDepartmentIgnoreCase` → `countByCategoryIgnoreCase`. **A method name that mentions a field that does not exist makes the application fail at start-up.** Delete a method you do not need *and* the service line that calls it. |
| 3 | `service/ProductService.java` | (a) `validate(...)`: one `if` per required field. (b) `SORT_FIELDS`: list the field names the user may sort by. (c) `update(...)`: one `existing.setX(incoming.getX())` per field. (d) `filter(...)`: the `department` line uses `getDepartment()`; the min/max lines use `getSalary()`. (e) `count(...)`: repository method name from step 2. (f) `salaryStats()` / `adjustSalary()`: see section E. |
| 4 | `controller/ProductController.java` | Only if a *request parameter name* mentions a field: `@RequestParam String department` in `filter` and `count` → rename to `category` (the `department:` key in `filter()` and `count()` in App.vue must equal it). |
| 5 | `frontend/src/App.vue` | Every field appears in **5 places**: (a) the object `form = ref({...})`, (b) the same object again inside `save()` after a successful save and (c) inside `edit()`, (d) one `<input v-model="form.xxx">` in the form, (e) one `<th>` + one `<td>{{ e.xxx }}</td>` in the table. Number fields: `Number(...)` in `save()`. Then change the labels/placeholders (`department`, `min salary`), the sort `<option>` list, and the `department:` key in `filter()`/`count()` params (must equal the Java `@RequestParam` name). Use Ctrl+F for the old field name and fix every hit. |
| 6 | `sample_data/employees.json` | New documents with the same keys. |
| 7 | Request JSON (Postman / `api_requests.md`) | Same keys. |
| 8 | Tests (7 files) | `setUp()` objects and constructor arguments; JSON strings in `.content("...")`; `jsonPath("$.salary")` → `$.price`; expected totals/counts; in `EmployeeSchemaFieldTests.exactFieldCount` the number `7` = number of fields **including `id`**. |

The Vue page is plain HTML: nothing is generated, so search `App.vue` for the old field name (Ctrl+F) until there are no hits.

## C. Changing the collection name (and database name)

* **Collection:** `model/Product.java` → `@Document(collection = "products")`. This is the only place. In Compass it is the collection under the database in the left sidebar. If the name does not match, the app starts but shows an empty list (it is reading a different, empty collection).
* **Database:** `application.properties` → last part of `spring.mongodb.uri=mongodb://localhost:27017/product_db`; also `src/test/resources/application.properties` (`product_db_test`).
* Omitting `collection = "..."` makes Spring use the lower-camel class name (`product`) – always write it explicitly.

## D. Changing routes (endpoints) without breaking Axios

1. `controller/ProductController.java` → `@RequestMapping("/api/products")`.
2. `frontend/src/App.vue` → `const API = 'http://localhost:8080/api/products'`.
3. Tests: Find/Replace `/api/employees` → `/api/products` (7 files).
4. `api_requests.md`.

Every other URL in Vue is built from `API` (`${API}/search`, `${API}/filter`, `${API}/count`, `${API}/stats`, `${API}/{id}/adjust`). If you rename a *sub*-route (e.g. `/search` → `/find`), change the `@GetMapping("/search")` **and** the single `axios.get(API + '/search', ...)` line in `App.vue` **and** the tests.
If the question gives the exact URLs (e.g. `/students/all`, `/students/add`): change `@GetMapping` → `@GetMapping("/all")` and `@PostMapping` → `@PostMapping("/add")`, `@RequestMapping("/students")`, then update `axios.get(API + '/all')` / `axios.post(API + '/add', ...)` in `loadAll()` and `save()`.
Remember: `@GetMapping("/{id}")` must not collide with a literal like `/all` — Spring picks the literal first, so it is safe.
CORS: if Vue runs on a different port, change the two origins in `@CrossOrigin`.

## E. Changing the special operation (replace the salary calculation)

Only two methods hold business calculations: `salaryStats()` and `adjustSalary()` in the service, and one endpoint each in the controller. Vue calls them through the **Calculations** buttons.

**1. Total price = price × quantity (per record and for the whole stock)**
```java
// ProductService.java  – replaces salaryStats()
public Map<String, Object> stockStats() {
    List<Product> all = repo.findAll();
    double totalValue = all.stream().mapToDouble(p -> p.getPrice() * p.getQuantity()).sum();
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("count", all.size());
    m.put("totalStockValue", totalValue);
    m.put("averagePrice", all.stream().mapToDouble(Product::getPrice).average().orElse(0));
    return m;
}
```
Controller (`/stats` unchanged): `return service.stockStats();`
Test: update `response_salaryStats` expected keys. Vue: no change – the result area prints whatever JSON arrives.

**2. Bill for one product (quantity × price − discount)**
```java
// ProductService.java
public Map<String, Object> bill(String id, int qty, double discountPercent) {
    Product p = getById(id);
    double gross = p.getPrice() * qty;
    double discount = gross * discountPercent / 100.0;
    Map<String, Object> m = new LinkedHashMap<>();
    m.put("gross", gross); m.put("discount", discount); m.put("net", gross - discount);
    return m;
}
// ProductController.java
@GetMapping("/{id}/bill")
public Map<String, Object> bill(@PathVariable String id, @RequestParam int qty, @RequestParam(defaultValue = "0") double discount) {
    return service.bill(id, qty, discount);
}
```
In `App.vue` copy the `adjust` function: `axios.get(API + '/' + id + '/bill', { params: { qty: ..., discount: ... } })`, and add a button.

**3. Discount** – no code at all: call `POST /api/products/{id}/adjust?percent=-10` (negative = decrease). Rename `adjustSalary` → `adjustPrice` and `getSalary/setSalary` → `getPrice/setPrice`.

**4. Another condition** (e.g. "products with quantity < 10"): add `List<Product> findByQuantityLessThan(Integer q);` to the repository, a service method returning it, a `@GetMapping("/low-stock")` in the controller, and a Vue button copying `search()`.

## F. Removing files / features you do not need

### F1. Question needs only *create + display*
**Must remain (for compilation):** `pom.xml`, `application.properties`, `DemoApplication.java`, model, repository, controller.
**Can delete:** `service/EmployeeService.java`, `exception/ApiExceptionHandler.java` (only if no code still throws `ResponseStatusException`), all test files, the Vue list/section blocks you do not need.
Minimal controller (service removed):
```java
@RestController @RequestMapping("/api/products") @CrossOrigin(origins = "http://localhost:5173")
public class ProductController {
    private final ProductRepository repo;
    public ProductController(ProductRepository repo) { this.repo = repo; }
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public Product create(@RequestBody Product p) { p.setId(null); return repo.save(p); }
    @GetMapping public List<Product> all() { return repo.findAll(); }
}
```
**Important:** `mvn spring-boot:run` also *compiles the tests*. If you delete a class or method the tests use, either delete those test files or the run fails with a compile error. In an exam where tests are not asked, delete `src/test/java/com/example/demo/*` (keep nothing) – the app still runs.

### F2. Which file can I drop for which feature?
| Not needed | Remove |
|---|---|
| Update | `update()` in service + `@PutMapping` in controller + Vue `edit`/`editingId` use |
| Delete | `delete()` + `@DeleteMapping` + Vue `remove` + Delete button |
| Search/Filter/Sort/Count | the matching service + controller methods and repository `findBy…`/`countBy…` + Vue boxes |
| Validation / error JSON | `validate()` call(s); `ApiExceptionHandler` |
| Calculation | `salaryStats`/`adjustSalary` + endpoints + Vue "Calculations" section |
| Frontend | the whole `frontend/` folder (use Postman) |

Unused leftovers are harmless; **missing references** are what break the build. After deleting, press *Build → Rebuild Project* and fix red lines.

## G. Changing the package name (`com.example.demo` → `com.college.app`)
1. IntelliJ: *Project view* → `src/main/java` → right-click package `com.example.demo` → **Refactor → Rename…** → *Rename package* (not directory) → `com.college.app`. IntelliJ updates folder names and every `package` line, and offers to rename the test package too – say **yes**.
2. Check: every `.java` file starts with `package com.college.app;` in **both** `src/main/java` and `src/test/java`, and the folders are `com/college/app`.
3. `pom.xml` `<groupId>` / `<artifactId>` are independent – changing them is optional.
4. Rule: `DemoApplication` must be in the **same or a parent package** of every controller/service/repository, otherwise Spring does not find them (404 on every URL). Tests must also live in the same package tree, or `@SpringBootTest` cannot find the `@SpringBootApplication`.
5. Manual method: rename the three folders, then Find/Replace `com.example.demo` → `com.college.app` in the project.

## H. Worked example: Employee → Product

**Question:** *"Create a Spring Boot REST API with MongoDB for Product (name, category, price, quantity). Support add, view all, search by name, filter by category, update, delete, and show total stock value."*

| Item | Before | After |
|---|---|---|
| Model | `Employee` | `Product` |
| Fields | name, email, phone, department, designation, salary | name, category, price, quantity |
| Collection / DB | `employees` / `employee_db` | `products` / `product_db` |
| Route | `/api/employees` | `/api/products` |
| Filter param | `department` | `category` |
| Calculation | `salaryStats` (total/average salary) | `stockStats` (Σ price × quantity) |

**Product.java**
```java
@Document(collection = "products")
public class Product {
    @Id private String id;
    private String name;       // required
    private String category;
    private Double price;      // required, >= 0
    private Integer quantity;  // required, >= 0
    public Product() {}
    // + getters and setters for id, name, category, price, quantity
}
```
**ProductRepository.java**
```java
public interface ProductRepository extends MongoRepository<Product, String> {
    List<Product> findByNameContainingIgnoreCase(String name);
    List<Product> findByCategoryIgnoreCase(String category);
    long countByCategoryIgnoreCase(String category);
}
```
**ProductService.java** – changed parts
```java
private static final Set<String> SORT_FIELDS = Set.of("name", "category", "price", "quantity");

private void validate(Product p) {
    if (p.getName() == null || p.getName().isBlank())
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
    if (p.getPrice() == null || p.getPrice() < 0)
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "price is required and must be >= 0");
    if (p.getQuantity() == null || p.getQuantity() < 0)
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "quantity is required and must be >= 0");
}
// update(): existing.setName(..); setCategory(..); setPrice(..); setQuantity(..)
// filter(String category, Double min, Double max): compare getCategory() and getPrice()
// stats: stockStats() from section E.1
```
**ProductController.java** – `@RequestMapping("/api/products")`, `@RequestParam(required = false) String category` in `filter` and `count`.

**App.vue edits for this example**
1. `const API = 'http://localhost:8080/api/products'`
2. Replace the field lists: `{ name: '', category: '', price: '', quantity: '' }` (3 places: `form`, `save()`, `edit()` – in `edit()` it is `name: p.name, category: p.category, ...`).
3. Form: four `<p>Label: <input v-model="form.xxx" /></p>` lines (`name`, `category`, `price`, `quantity`; number type for the last two). In `save()` use `Number(...)` for `price` and `quantity`.
4. Table: header `<th>`s and `<td>{{ e.category }}</td>`, `{{ e.price }}`, `{{ e.quantity }}` (rename the loop variable `e`/`emp` consistently).
5. Filter inputs: `department` → `category` in the placeholder, in `filter()`/`count()` params, and `min/max salary` → `min/max price`.
6. Sort `<option>`s: `name`, `category`, `price`.

**application.properties** – `spring.mongodb.uri=mongodb://localhost:27017/product_db`
**Sample document**
```json
{ "name": "Pen", "category": "Stationery", "price": 10.0, "quantity": 100 }
```
**Checks:** `POST /api/products` (201) → `GET /api/products/filter?category=Stationery&min=5` → `GET /api/products/stats` → Compass collection `products` shows the document.


## J. Feature-to-file mapping (how to remove what the question does not ask for)
Names: **C** = `controller/EmployeeController`, **S** = `service/EmployeeService`, **R** = `repository/EmployeeRepository`, **V** = `frontend/src/App.vue`, tests in `src/test/java/com/example/demo/`.
After removing, delete the **imports that become unused** in that file (IntelliJ: Ctrl+Alt+O) and press *Build → Rebuild Project*.

| Feature | Backend (remove) | Frontend `App.vue` (remove) | Tests (remove) |
|---|---|---|---|
| **Create** | C `create`; S `create` (keep `validate` if Update stays) | `save()` – the `else` (POST) branch; form section | `EmployeePostTests` (whole), `status201_post`, `status400_missingField`, `ApiExceptionHandler` tests for bad JSON |
| **Display all** | C `getAll`; S `getAll`; R: nothing (inherited `findAll`) | `loadAll()` + `onMounted(loadAll)` + the table section – but other features call `loadAll()` after changes; replace those calls | `EmployeeGetTests.getAll_*`, `status200_getAll`, `response_isJson`, `response_isArrayOfThree`, `response_particularValue` |
| **Get by id** | C `getById`; S `getById` **is also used by update and adjust – keep it if either stays** | `getOne()` + "Get by ID" section + `lookupId` | `getById_returnsEmployee`, `missingId_*`, `garbageId_*` |
| **Search** | C `search`; S `search`; R `findByNameContainingIgnoreCase` (used only by `search` → safe to delete) | `search()`, `searchText`, search input/button | `search_returnsMatchingNames`, `search_withoutName_returns400` |
| **Filter** | C `filter`; S `filter` (uses streams, **no repository method**) | `filter()`, `filterValue/minValue/maxValue`, the three inputs + Filter button (`count()` also uses `filterValue`) | `filter_byDepartment`, `filter_byMinSalary`, `filter_noMatch_returnsEmptyArray` |
| **Sort** | S `getAll`: replace body with `return repo.findAll();` and delete `SORT_FIELDS`, the `Sort`/`Set` imports; C `getAll`: delete the two `@RequestParam` and call `service.getAll()` | `sortBy`, `sortDir`, the two `<select>`; in `loadAll` use `params = {}` | `sort_bySalaryDescending`, `sort_unknownField_returns400`; `response_particularValue` (uses `sortBy=name`) |
| **Count** | C `count`; S `count`; R `countByDepartmentIgnoreCase` (only used by `count`) | `count()` + Count button | `count_all_and_byDepartment` |
| **Update** | C `update`; S `update` | `edit()`, `editingId`, the Cancel/Update logic in `save()` (keep POST only), Edit button | `EmployeeUpdateDeleteTests.put_*`, `status200_put`, `status404_putMissing` |
| **Delete** | C `delete`; S `delete` | `remove()` + Delete button | `delete_removesEmployee`, `status204_delete`, `status404_deleteMissing` |
| **Calculation (statistics)** | C `salaryStats`; S `salaryStats` (+ imports `LinkedHashMap`, `Map`, `DoubleSummaryStatistics`) | `stats()` + button | `response_salaryStats` |
| **Special operation (% change)** | C `adjust`; S `adjustSalary` | `adjust()`, `adjustId`, `percent`, its inputs | `adjust_*` tests |
| **Validation / error JSON** | S `validate` (+ its calls), `notFound`; `exception/ApiExceptionHandler` | `error` paragraph + `showError()` (harmless to keep) | every `isBadRequest` / `$.error` assertion |

Removal order that never breaks compilation: tests first → frontend → controller method → service method → repository method. Afterwards search the project (Ctrl+Shift+F) for the removed method name; zero hits means nothing dangling.
Always keep: `pom.xml`, `application.properties`, `DemoApplication`, the model, the repository interface (can be empty), and either the controller or an equivalent.
**If a repository method is used elsewhere:** only `getById` (S) is shared; the `findBy…`/`countBy…` repository methods each serve exactly one service method (the earlier unused `findByDepartmentIgnoreCase` and `findBySalaryGreaterThanEqual` were deleted in this revision).
