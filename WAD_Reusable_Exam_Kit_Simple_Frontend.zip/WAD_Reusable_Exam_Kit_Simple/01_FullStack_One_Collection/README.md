# 01 – Full-stack template, ONE collection (Employee Directory)

Vue 3 + Axios  →  Spring Boot 4.1.1 (Java 17)  →  MongoDB (`employee_db`, collection `employees`).
The scenario is deliberately generic so it can be re-skinned (Product, Student, Book, Patient ...).
It does **not** repeat any scenario already in your repository (Student, Product CRUD, Library, Room Booking, Shopping Cart, Course Registration, Food Ordering).

```
Complete_Project/
  backend/    pom.xml, src/main (6 Java files), src/test (7 MockMvc test classes), application.properties
  frontend/   package.json, vite.config.js, index.html, src/main.js, src/App.vue
  sample_data/employees.json     <- import into MongoDB Compass
  api_requests.md                <- every endpoint for Postman / curl
```

## What it covers
| Pattern | Endpoint | Where the code is |
|---|---|---|
| Create (201) | `POST /api/employees` | Controller `create` → Service `create` |
| Get all / sort | `GET /api/employees[?sortBy=&dir=]` | Service `getAll` |
| Get by id (404 if missing) | `GET /api/employees/{id}` | Service `getById` |
| Update (404 if missing) | `PUT /api/employees/{id}` | Service `update` |
| Delete (204 / 404) | `DELETE /api/employees/{id}` | Service `delete` |
| Search by name | `GET /api/employees/search?name=` | Repository `findByNameContainingIgnoreCase` |
| Filter by value / condition | `GET /api/employees/filter?department=&min=&max=` | Service `filter` |
| Count (all / by value) | `GET /api/employees/count[?department=]` | Repository `countBy...` |
| Total / average / max / min | `GET /api/employees/stats` | Service `salaryStats` |
| Special operation (% change) | `POST /api/employees/{id}/adjust?percent=` | Service `adjustSalary` |
| Validation → 400 · Missing → 404 · Bad JSON/param → 400 | – | Service `validate`, `ApiExceptionHandler` |

## Run order
1. **Start MongoDB** (Windows: service "MongoDB Server" is normally already running; check with Compass → connect to `mongodb://localhost:27017`).
2. **Backend** – in `backend/`:
   ```bash
   mvn spring-boot:run
   ```
   (or IntelliJ: open `backend/pom.xml` as a project → *Maven → Reload* → run `DemoApplication`). Runs on **http://localhost:8080**.
3. **Frontend** – in `frontend/`:
   ```bash
   npm install
   npm run dev
   ```
   Runs on **http://localhost:5173** (CORS in `EmployeeController` allows exactly this origin).
4. Open http://localhost:5173.
5. Optional: test the API in Postman using `api_requests.md`.

Ports: Spring Boot **8080**, Vue (Vite) **5173**, MongoDB **27017**.

## MongoDB
* `application.properties`: `spring.mongodb.uri=mongodb://localhost:27017/employee_db` (Boot 4.x name, same as your working `Full-Stack-CRUD/demo`; on Boot 3.x it is `spring.data.mongodb.uri`).
* Database `employee_db` and collection `employees` are **created automatically** on the first insert – you need not create them.
* `_id` mapping: the Java field `@Id private String id` ⇄ MongoDB `_id` (an `ObjectId` such as `66f1c0a2b3d4e5f6a7b8c9d0`). Spring converts it to a 24-character hex string in JSON (`"id":"66f1..."`). Never send an id when creating; the service ignores it anyway.

### Insert sample data with Compass
1. Compass → connect `mongodb://localhost:27017`.
2. *Create Database*: name `employee_db`, collection `employees`.
3. Open `employees` → **ADD DATA → Import JSON or CSV file** → choose `sample_data/employees.json` → *Import*.
4. Or *ADD DATA → Insert document* and paste one object from the file.

### Check the database after each operation
Compass → `employee_db` → `employees` → click the **refresh** icon (or *Find*). After Create a new document appears; after Update its fields change but `_id` stays; after Delete it disappears. Filter box example: `{ "department": "IT" }`.

## Tests (MockMvc)
`mvn test` – needs MongoDB running. Tests use database **`employee_db_test`** (`src/test/resources/application.properties`), so your real data is never touched. Details: `../06_MockMvc_REST_API_Testing/README.md`.

## Changing the scenario
Read **HOW_TO_CHANGE_SCENARIO.md** (file-by-file checklist).
