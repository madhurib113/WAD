# MVC practice questions (PENDING)

1. Waiting for your MVC syllabus – no questions invented.
