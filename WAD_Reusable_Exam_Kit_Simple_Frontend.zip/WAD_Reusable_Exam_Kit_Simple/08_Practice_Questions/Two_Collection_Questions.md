# Two-collection practice questions

1. Department–Employee: employees of a department, total salary per department.

2. Category–Product: refuse a product whose category does not exist; count products per category.

3. Author–Book: delete an author and cascade the books.

4. Course–Student registration with seat limit (409 when full).
