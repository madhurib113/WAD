# One-collection practice questions

1. Build a Student API (roll, name, dept, marks): add, list, search by name, filter by dept, update, delete. Vue page included.

2. Product manager: add products, show total stock value (price × quantity), list products below a price.

3. Book store: add books, sort by price, count books per author.

4. Patient records: add, find by id (404 if missing), filter age > 60.

5. Employee: give all IT employees a 10% raise (new endpoint).

6. Remove update/delete and keep only create + display.
