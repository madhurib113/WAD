# Servlet + JDBC practice questions

1. Create table Student(regno, name, dept); insert and display all rows.

2. Search a book by id and show 'not found' otherwise.

3. Update a product price; delete by id; report rows affected.

4. Show employees earning more than a given salary.
