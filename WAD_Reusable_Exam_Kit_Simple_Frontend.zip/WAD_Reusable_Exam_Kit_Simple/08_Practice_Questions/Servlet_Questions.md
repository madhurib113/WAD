# Servlet practice questions

1. Form with name/age/course; show a summary.

2. Bill: price × quantity with 5% GST.

3. Marks of 3 subjects: total, average, class (First ≥60, Second ≥50, else Fail).

4. Leap-year checker.

5. Salary slip: HRA 20%, DA 10%, net pay.
