# MockMvc practice questions

1. GET /api/employees returns 200 and 3 records.

2. GET to a wrong URL returns 404.

3. POST a valid employee returns 201 and has an id.

4. POST without name returns 400.

5. Assert the field password does not exist.

6. Assert content type is JSON.

7. Update salary then assert the new value.

8. Delete then GET returns 404.
