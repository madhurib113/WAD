# Revision record (from WAD_Reusable_Exam_Kit.zip → WAD_Reusable_Exam_Kit_Revised)
| Change | Files | Why |
|---|---|---|
| Conventional packages: `model/ repository/ service/ controller/ exception/` under `com.example.demo` (root class stays in the root) | 6 main classes of project 1, 10 of project 2: moved, `package` lines rewritten, imports added | requested structure |
| Test imports for `model`/`repository` | 7 tests (project 1), 2 tests (project 2), 7 copies in `06_MockMvc_REST_API_Testing/*` | tests stay in `com.example.demo`, need explicit imports |
| Removed 2 dead repository methods (`findByDepartmentIgnoreCase`, `findBySalaryGreaterThanEqual`) | `EmployeeRepository` | unused; filter uses streams |
| Maven Wrapper added (`mvnw`, `mvnw.cmd`, `.mvn/wrapper/maven-wrapper.properties`) | both `backend/` | copied from your own `Full-Stack-CRUD/demo`; no Maven install needed |
| Package/path updates, feature-to-file tables (§J), import guidance | both `HOW_TO_CHANGE_*.md`, READMEs | accuracy |
| Windows environment check + run guide | `07_Exam_Reference/check_environment.ps1`, `.bat`, `Environment_Check_And_Run_Guide.md` | requested |
| README with javax/jakarta table, Tomcat versions, deployment and JDBC jar requirement | one per Servlet folder (9 new files) | previously missing |
| Unchanged: Spring Boot 4.1.1, `spring.mongodb.uri`, no Lombok, Vue code, servlets, practice questions, MVC (still PENDING) | – | no evidence requiring change |

# Revision 2 – simple frontend
| Change | Files |
|---|---|
| Both `App.vue` rewritten as plain, beginner-level pages: white page, black text, plain HTML forms and tables, one CSS line (gray table borders); no config array, no helper wrapper, no component, no colours. Same function names as before, so the removal tables still apply | `01…/frontend/src/App.vue`, `02…/frontend/src/App.vue` |
| Guide text about the old `fields` array replaced by the 5-place checklist and a new Product example | `HOW_TO_CHANGE_SCENARIO.md` §B, §H, §J; two-collection guide §B |
| New 30-minute writing order | `07_Exam_Reference/Frontend_30_Minute_Guide.md` |
| Backend, tests, servlets, Maven setup: unchanged |  |
