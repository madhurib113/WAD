# 02 – Full-stack template, TWO collections (Event ⇄ Participant)

Vue 3 + Axios → Spring Boot 4.1.1 (Java 17) → MongoDB database `event_db` with collections **`events`** (the "one" side) and **`participants`** (the "many" side).
Not present in your repository (which has Student/Course, Library, Room/Booking, Product/Order).

```
Complete_Project/
  backend/   pom.xml · src/main: Event, Participant, 2 repositories, 2 services, 2 controllers, ApiExceptionHandler, DemoApplication
             src/test: EventApiTests, ParticipantApiTests (MockMvc)
  frontend/  package.json · vite.config.js · index.html · src/main.js · src/App.vue
  sample_data/events.json, participants.json
```

## How the relationship works in MongoDB (important for viva)
* A `participants` document stores `"eventId": "64b000000000000000000001"` – the `_id` of an event written as **text**.
* **MongoDB has no foreign keys.** It will happily store an `eventId` that points to nothing, and it will let you delete an event that still has participants.
* So *our Java code* enforces the rules that SQL would enforce:
  | Rule | Where | Result |
  |---|---|---|
  | `eventId` must exist when creating/updating a participant | `ParticipantService.checkEvent` | 400 |
  | Event must have a free seat | `ParticipantService.checkEvent` | 409 |
  | Capacity cannot be lowered below the number registered | `EventService.update` | 409 |
  | Deleting an event that has participants | `EventService.delete` | 409, or with `?cascade=true` participants are deleted first |
* Lookups are two queries: `participants.findByEventId(id)` and `events.findById(id)` (MongoDB has `$lookup` joins, but they are not needed here).

## Endpoints
| Purpose | Request | Status |
|---|---|---|
| CRUD events | `POST/GET /api/events`, `GET/PUT/DELETE /api/events/{id}` | 201/200/204, 404, 400, 409 |
| Search events | `GET /api/events/search?name=` | 200 |
| Related records | `GET /api/events/{id}/participants` | 200 / 404 |
| Count + calculations for one event | `GET /api/events/{id}/summary` → participantCount, seatsLeft, totalRevenue | 200 / 404 |
| Totals across all events | `GET /api/events/stats` | 200 |
| Delete with children | `DELETE /api/events/{id}?cascade=true` | 204 |
| CRUD participants | `POST/GET /api/participants`, `GET/PUT/DELETE /api/participants/{id}` | 201/200/204, 400 (bad event), 404, 409 (full) |
| Filter by related record | `GET /api/participants?eventId=` | 200 |
| Count (all / per event) | `GET /api/participants/count[?eventId=]` | 200 |
| Search participants | `GET /api/participants/search?name=` | 200 |

## Run order
1. Start MongoDB.
2. `cd backend` → `mvn spring-boot:run` (port **8080**).
3. `cd frontend` → `npm install` → `npm run dev` (port **5173**) → open http://localhost:5173.
4. Optional: Postman against `http://localhost:8080/api/events` and `/api/participants`.

## Sample data in Compass
1. Create database `event_db`, collection `events` → *ADD DATA → Import JSON* → `sample_data/events.json` (it carries fixed `_id` values so participants can point at them).
2. Create collection `participants` → import `sample_data/participants.json`.
3. Refresh the Vue page: 2 events, 3 participants; "Tech Fest" (capacity 2) is already full → registering a 3rd person gives the message *event is full* (409).
Without sample data: create events in the page first, then register participants using the drop-down (it fills `eventId` for you).

Check in Compass after operations: delete a participant → seat count in *Summary* goes up; delete an event with *Delete + participants* → both the event and its participants vanish from the two collections.

## Tests
`mvn test` (needs MongoDB; uses database `event_db_test`). the service logic was also run in-memory (32 checks, see root README).

## Converting to another scenario
`HOW_TO_CHANGE_TWO_COLLECTION_SCENARIO.md`
