# HOW TO CHANGE THE TWO-COLLECTION SCENARIO

Template: **Event** (one) ⇄ **Participant** (many, field `eventId`).
Generic names used below: **Parent** = Event, **Child** = Participant, **link field** = `eventId`.
Golden rule: *Java field = JSON key = Vue form key.* The link field name (`eventId`) appears in **7 places** – change it everywhere or the relationship silently breaks (see section C).

## 0. Package layout
`com/example/demo/`: `DemoApplication.java` (root) · `model/` Event, Participant · `repository/` EventRepository, ParticipantRepository · `service/` EventService, ParticipantService · `controller/` EventController, ParticipantController · `exception/` ApiExceptionHandler.
Imports: repository → model · service → model + repository (EventService also imports `ParticipantRepository`, ParticipantService imports `EventRepository`) · controller → model + service · tests → model + repository. IntelliJ Shift+F6 keeps package lines and imports correct.

## A. Rename the two entities (`Event/Participant` → `Department/Staff`)
Use IntelliJ **Shift+F6** on each class name (it renames files and all references). Rename: `Event`→`Department`, `Participant`→`Staff`, `EventRepository`, `ParticipantRepository`, `EventService`, `ParticipantService`, `EventController`, `ParticipantController`.
Then fix by hand (strings are not refactored automatically):

| File | Edit |
|---|---|
| `model/Department.java` | `@Document(collection = "departments")` |
| `model/Staff.java` | `@Document(collection = "staff")` |
| `controller/DepartmentController.java` | `@RequestMapping("/api/departments")` |
| `controller/StaffController.java` | `@RequestMapping("/api/staff")` |
| `service/DepartmentService.java` | message `"Event not found with id "` → `"Department not found with id "`; messages containing "event"/"participants" |
| `service/StaffService.java` | messages `"Participant not found…"`, `"eventId does not exist: "`, `"event is full"` |
| `application.properties` (main + test) | `…/department_db` and `…/department_db_test` |
| `frontend/src/App.vue` | `EVENTS`/`PARTICIPANTS` URLs; headings/labels |
| 2 test files + `ApiExceptionHandler` | tests: class names, URLs, JSON; handler: nothing |
| `sample_data/*.json` | new documents; child documents carry the parent's `_id` text |

## B. Change the fields
Parent `Event(name, date, venue, capacity, ticketPrice)` → `Department(name, location, budget)`
Child `Participant(name, email, eventId)` → `Staff(name, email, salary, departmentId)`

1. **Model classes** – fields, constructors, getters/setters.
2. **`…Service.validate`** (both services) – one `if` per required field.
3. **`…Service.update`** – one `setX(in.getX())` per field.
4. **Repositories** – derived names must match fields: `findByEventId` → `findByDepartmentId`, `countByEventId` → `countByDepartmentId`, `deleteByEventId` → `deleteByDepartmentId`. A name that mentions a non-existing field prevents start-up.
5. **`App.vue`** – the two form objects (`eventForm`, `partForm`) – defined at the top, reset inside `saveEvent`/`savePart`, copied in `editEvent`/`editPart`, the two `body` objects in `saveEvent`/`savePart`, `editEvent`/`editPart`, `resetEvent`/`resetPart`, the `<label>` inputs and table columns.
6. **Tests and sample JSON** – same keys.

## C. The link field (`eventId` → `departmentId`) – 7 places
1. `model/Participant.java`/`model/Staff.java`: field + getter + setter + constructor argument.
2. `ParticipantRepository`: `findByEventId`, `countByEventId`, `deleteByEventId`.
3. `ParticipantService`: `getEventId()`/`setEventId()` in `validate`, `create`, `update`, `getAll` parameter name.
4. `EventService`: calls `participants.countByEventId(...)`, `findByEventId`, `deleteByEventId`.
5. `ParticipantController`: `@RequestParam String eventId` in `getAll` and `count`.
6. `App.vue`: `partForm.eventId`, `filterEventId` param key `{ eventId: ... }`, `p.eventId`.
7. Tests + `sample_data/participants.json`.

## D. Collection names
Only in `@Document(collection = "...")` of each model. Compass shows these under the database named in `spring.mongodb.uri`. Mismatch ⇒ empty lists, no error.

## E. Routes
`@RequestMapping` in each controller ⇄ `EVENTS` / `PARTICIPANTS` constants at the top of `App.vue` ⇄ tests. Sub-routes (`/{id}/participants`, `/{id}/summary`, `/stats`) are used in `App.vue` as `${EVENTS}/${id}/summary` etc. – edit both sides together.

## F. Replace the calculations
Calculations live in `EventService.summary` and `EventService.stats` (parent side, because they look at the children).
* Event: `participantCount × ticketPrice` → **Department**: total salary of staff
  ```java
  double totalSalary = staffRepo.findByDepartmentId(id).stream().mapToDouble(Staff::getSalary).sum();
  m.put("staffCount", count); m.put("totalSalary", totalSalary); m.put("budgetLeft", d.getBudget() - totalSalary);
  ```
* Category–Product: count of products + average price: `findByCategoryId(id).stream().mapToDouble(Product::getPrice).average().orElse(0)`.
* Author–Book: number of books and total price of the author's books.
* Seat/capacity rule (`checkEvent(..., true)`): delete it if the question has no capacity; keep only the existence check.

## G. Remove features
| Question needs only… | Keep | Delete |
|---|---|---|
| Parent + child CRUD, no rules | models, repos, controllers | both services' `checkEvent`, `cascade` code, `summary`, `stats`; controllers call repos directly |
| Child creation with parent check | + `ParticipantService.checkEvent` (without the seat test) | the capacity branch |
| No frontend | – | `frontend/` (use Postman) |
`mvn spring-boot:run` also compiles `src/test`; delete or fix tests that reference removed code.

## H. Package change
Same as the one-collection guide: IntelliJ *Refactor → Rename package* in `src/main/java` **and** `src/test/java`; `DemoApplication` must stay in the root package of all classes.

## I. Worked example: Event/Participant → Author/Book
*"Author(name, country) and Book(title, price, authorId). Add authors and books, list books of an author, count them, and show the total price."*
| Item | Value |
|---|---|
| Collections | `authors`, `books` · DB `library_db` |
| Link | `Book.authorId` (text of `authors._id`) |
| Repo methods | `BookRepository`: `findByAuthorId`, `countByAuthorId`, `deleteByAuthorId` |
| Service | `BookService.create`: validate → `authors.findById(authorId)` else 400 |
| Calc | `AuthorService.summary`: `{bookCount, totalPrice}` from `books.findByAuthorId(id)` |
| Routes | `/api/authors`, `/api/books[?authorId=]`, `/api/authors/{id}/books`, `/api/authors/{id}/summary` |
| Vue | change the two forms/tables; the dropdown `partForm.eventId` becomes `bookForm.authorId` |
| Delete rule | author with books → 409 unless `?cascade=true` |


## J. Feature-to-file mapping
| Feature | Remove (backend) | Remove (Vue `App.vue`) | Tests |
|---|---|---|---|
| Child → parent check (`checkEvent`, 400) | `ParticipantService.checkEvent` calls in `create`/`update` | – | `post_unknownEvent_returns400`, `put_unknownEvent_returns400` |
| Capacity / "full" rule (409) | second half of `checkEvent`; capacity check in `EventService.update` | – | `post_fullEvent_returns409`, `put_capacityBelowRegistered_returns409` |
| Delete rule + cascade | `EventService.delete` (cascade branch), `ParticipantRepository.deleteByEventId`, `@RequestParam cascade` in `EventController.delete` | `deleteEvent(id, cascade)` second button | `delete_eventWithParticipants_*`, `delete_cascade_*` |
| Related records | `EventService.participantsOf`, `EventController.participants` | `eventParticipants()` + button | `participantsOfEvent_*` |
| Summary / stats (counts + calculation) | `EventService.summary`/`stats`, controller methods | `eventSummary()`, `eventStats()`, buttons | `summary_*`, `stats_*` |
| Filter by related record | `ParticipantService.getAll(eventId)` branch, `ParticipantRepository.findByEventId` (**also used by `participantsOf`**), `@RequestParam eventId` | `filterEventId`, filter select/button | `filterByEvent_*` |
| Count | `ParticipantService.count`, `countByEventId` (**also used by checkEvent, summary, stats, delete rules – keep it if any of those stay**) | `countPart()` | `count_byEvent` |
| Search | `search` in both services/controllers, both `findByNameContainingIgnoreCase` | `searchPart()` + input | `search_*` |
After removal: delete unused imports, rebuild, search the project for the removed names. Must remain: both models, both repositories (may be empty), controllers, `DemoApplication`, `pom.xml`, `application.properties`.
