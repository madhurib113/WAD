package com.example.demo.repository;

import com.example.demo.model.Participant;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ParticipantRepository extends MongoRepository<Participant, String> {
    List<Participant> findByEventId(String eventId);                   // filter by the related record
    long countByEventId(String eventId);                               // count related records
    long deleteByEventId(String eventId);                              // cascade delete
    List<Participant> findByNameContainingIgnoreCase(String name);     // search
}
