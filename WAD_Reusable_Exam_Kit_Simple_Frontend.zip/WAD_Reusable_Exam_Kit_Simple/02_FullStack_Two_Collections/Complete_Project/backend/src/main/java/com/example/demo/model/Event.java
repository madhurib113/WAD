package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side of the relationship. Collection: events
@Document(collection = "events")
public class Event {

    @Id
    private String id;            // MongoDB _id (ObjectId) <-> hex String

    private String name;          // required
    private String date;          // required, text "YYYY-MM-DD"
    private String venue;
    private Integer capacity;     // required, > 0   (maximum participants)
    private Double ticketPrice;   // required, >= 0

    public Event() { }

    public Event(String name, String date, String venue, Integer capacity, Double ticketPrice) {
        this.name = name;
        this.date = date;
        this.venue = venue;
        this.capacity = capacity;
        this.ticketPrice = ticketPrice;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    public Double getTicketPrice() { return ticketPrice; }
    public void setTicketPrice(Double ticketPrice) { this.ticketPrice = ticketPrice; }
}
