package com.example.demo.controller;

import com.example.demo.model.Event;
import com.example.demo.model.Participant;
import com.example.demo.service.EventService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class EventController {

    private final EventService service;

    public EventController(EventService service) {
        this.service = service;
    }

    @PostMapping                                   // POST   /api/events                 -> 201
    @ResponseStatus(HttpStatus.CREATED)
    public Event create(@RequestBody Event e) { return service.create(e); }

    @GetMapping                                    // GET    /api/events
    public List<Event> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/events/{id}            -> 200 / 404
    public Event getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/events/{id}            -> 200 / 400 / 404 / 409
    public Event update(@PathVariable String id, @RequestBody Event e) { return service.update(id, e); }

    @DeleteMapping("/{id}")                        // DELETE /api/events/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/events/search?name=tech
    public List<Event> search(@RequestParam String name) { return service.search(name); }

    @GetMapping("/{id}/participants")              // GET    /api/events/{id}/participants  (related records)
    public List<Participant> participants(@PathVariable String id) { return service.participantsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/events/{id}/summary   (count, seats left, revenue)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/events/stats          (totals over all events)
    public Map<String, Object> stats() { return service.stats(); }
}
