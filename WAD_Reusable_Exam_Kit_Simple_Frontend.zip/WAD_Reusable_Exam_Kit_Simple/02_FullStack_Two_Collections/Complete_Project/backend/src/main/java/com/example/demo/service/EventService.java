package com.example.demo.service;

import com.example.demo.model.Event;
import com.example.demo.model.Participant;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.ParticipantRepository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class EventService {

    private final EventRepository events;
    private final ParticipantRepository participants;

    public EventService(EventRepository events, ParticipantRepository participants) {
        this.events = events;
        this.participants = participants;
    }

    private void validate(Event e) {
        if (e.getName() == null || e.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (e.getDate() == null || e.getDate().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "date is required");
        if (e.getCapacity() == null || e.getCapacity() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "capacity is required and must be > 0");
        if (e.getTicketPrice() == null || e.getTicketPrice() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "ticketPrice is required and must be >= 0");
    }

    public Event getById(String id) {
        return events.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Event not found with id " + id));
    }

    // ---------- CRUD ----------
    public Event create(Event e) {
        validate(e);
        e.setId(null);
        return events.save(e);
    }

    public List<Event> getAll() {
        return events.findAll();
    }

    public List<Event> search(String name) {
        return events.findByNameContainingIgnoreCase(name);
    }

    public Event update(String id, Event in) {
        Event existing = getById(id);
        validate(in);
        // consistency rule: capacity cannot drop below the number of people already registered
        long registered = participants.countByEventId(id);
        if (in.getCapacity() < registered)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "capacity cannot be less than the " + registered + " registered participants");
        existing.setName(in.getName());
        existing.setDate(in.getDate());
        existing.setVenue(in.getVenue());
        existing.setCapacity(in.getCapacity());
        existing.setTicketPrice(in.getTicketPrice());
        return events.save(existing);
    }

    // consistency rule: an event that still has participants is NOT deleted unless cascade=true,
    // in which case its participants are deleted first (MongoDB would otherwise leave orphans).
    public void delete(String id, boolean cascade) {
        getById(id);
        long registered = participants.countByEventId(id);
        if (registered > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "event has " + registered + " participants; delete them first or use cascade=true");
        participants.deleteByEventId(id);
        events.deleteById(id);
    }

    // ---------- related records ----------
    public List<Participant> participantsOf(String eventId) {
        getById(eventId);                       // 404 if the event is missing
        return participants.findByEventId(eventId);
    }

    // count + calculations across the two collections for ONE event
    public Map<String, Object> summary(String eventId) {
        Event e = getById(eventId);
        long count = participants.countByEventId(eventId);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("eventId", e.getId());
        m.put("eventName", e.getName());
        m.put("capacity", e.getCapacity());
        m.put("participantCount", count);
        m.put("seatsLeft", e.getCapacity() - count);
        m.put("ticketPrice", e.getTicketPrice());
        m.put("totalRevenue", count * e.getTicketPrice());
        return m;
    }

    // totals across ALL events
    public Map<String, Object> stats() {
        long totalParticipants = 0;
        double totalRevenue = 0;
        List<Event> all = events.findAll();
        for (Event e : all) {
            long c = participants.countByEventId(e.getId());
            totalParticipants += c;
            totalRevenue += c * e.getTicketPrice();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalEvents", all.size());
        m.put("totalParticipants", totalParticipants);
        m.put("totalRevenue", totalRevenue);
        return m;
    }
}
