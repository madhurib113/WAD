package com.example.demo.repository;

import com.example.demo.model.Event;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface EventRepository extends MongoRepository<Event, String> {
    List<Event> findByNameContainingIgnoreCase(String name);
}
