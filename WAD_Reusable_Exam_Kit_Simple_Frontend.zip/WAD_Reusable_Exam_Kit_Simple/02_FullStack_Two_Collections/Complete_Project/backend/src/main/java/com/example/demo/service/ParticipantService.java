package com.example.demo.service;

import com.example.demo.model.Event;
import com.example.demo.model.Participant;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.ParticipantRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ParticipantService {

    private final ParticipantRepository participants;
    private final EventRepository events;

    public ParticipantService(ParticipantRepository participants, EventRepository events) {
        this.participants = participants;
        this.events = events;
    }

    private void validate(Participant p) {
        if (p.getName() == null || p.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (p.getEmail() == null || p.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (p.getEventId() == null || p.getEventId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "eventId is required");
    }

    // The referenced event must exist (this replaces the SQL foreign-key check) and must have a free seat.
    private void checkEvent(String eventId, boolean checkSeat) {
        Event e = events.findById(eventId).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "eventId does not exist: " + eventId));
        if (checkSeat && participants.countByEventId(eventId) >= e.getCapacity())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "event is full");
    }

    public Participant getById(String id) {
        return participants.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Participant not found with id " + id));
    }

    public Participant create(Participant p) {
        validate(p);
        checkEvent(p.getEventId(), true);
        p.setId(null);
        return participants.save(p);
    }

    // optional filter by related record: ?eventId=...
    public List<Participant> getAll(String eventId) {
        if (eventId == null || eventId.isBlank()) return participants.findAll();
        return participants.findByEventId(eventId);
    }

    public List<Participant> search(String name) {
        return participants.findByNameContainingIgnoreCase(name);
    }

    public Participant update(String id, Participant in) {
        Participant existing = getById(id);
        validate(in);
        boolean moving = !in.getEventId().equals(existing.getEventId());
        checkEvent(in.getEventId(), moving);        // only check for a free seat when moving to another event
        existing.setName(in.getName());
        existing.setEmail(in.getEmail());
        existing.setEventId(in.getEventId());
        return participants.save(existing);
    }

    public void delete(String id) {
        getById(id);
        participants.deleteById(id);
    }

    public long count(String eventId) {
        if (eventId == null || eventId.isBlank()) return participants.count();
        return participants.countByEventId(eventId);
    }
}
