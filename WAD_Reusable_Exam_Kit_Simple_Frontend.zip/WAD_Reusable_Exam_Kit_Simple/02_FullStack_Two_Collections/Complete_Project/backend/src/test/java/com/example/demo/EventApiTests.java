package com.example.demo;

import com.example.demo.model.Event;
import com.example.demo.model.Participant;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.ParticipantRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** Tests for /api/events and the calculations that span both collections. */
@SpringBootTest
@AutoConfigureMockMvc
class EventApiTests {

    @Autowired MockMvc mockMvc;
    @Autowired EventRepository events;
    @Autowired ParticipantRepository participants;

    String techId;       // "Tech Fest": capacity 2, price 100, 2 participants (FULL)
    String workshopId;   // "Coding Workshop": capacity 50, price 250, 1 participant

    static final String MISSING_ID = "000000000000000000000000";

    @BeforeEach
    void setUp() {
        participants.deleteAll();
        events.deleteAll();
        techId = events.save(new Event("Tech Fest", "2026-11-15", "Main Hall", 2, 100.0)).getId();
        workshopId = events.save(new Event("Coding Workshop", "2026-12-01", "Lab 3", 50, 250.0)).getId();
        participants.save(new Participant("Anu", "anu@example.com", techId));
        participants.save(new Participant("Bala", "bala@example.com", techId));
        participants.save(new Participant("Charu", "charu@example.com", workshopId));
    }

    // ---- basic CRUD ----
    @Test
    void getAll_returnsTwoEvents() throws Exception {
        mockMvc.perform(get("/api/events"))
               .andExpect(status().isOk())
               .andExpect(content().contentTypeCompatibleWith("application/json"))
               .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    void getById_returnsEvent() throws Exception {
        mockMvc.perform(get("/api/events/" + techId))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.name").value("Tech Fest"))
               .andExpect(jsonPath("$.capacity").value(2));
    }

    @Test
    void getById_missing_returns404() throws Exception {
        mockMvc.perform(get("/api/events/" + MISSING_ID))
               .andExpect(status().isNotFound());
    }

    @Test
    void post_valid_returns201() throws Exception {
        mockMvc.perform(post("/api/events").contentType("application/json")
                .content("{\"name\":\"Quiz\",\"date\":\"2027-01-10\",\"venue\":\"Hall\",\"capacity\":30,\"ticketPrice\":50}"))
               .andExpect(status().isCreated())
               .andExpect(jsonPath("$.id").exists());
        assertEquals(3, events.count());
    }

    @Test
    void post_missingName_returns400() throws Exception {
        mockMvc.perform(post("/api/events").contentType("application/json")
                .content("{\"date\":\"2027-01-10\",\"capacity\":30,\"ticketPrice\":50}"))
               .andExpect(status().isBadRequest());
    }

    @Test
    void post_zeroCapacity_returns400() throws Exception {
        mockMvc.perform(post("/api/events").contentType("application/json")
                .content("{\"name\":\"Quiz\",\"date\":\"2027-01-10\",\"capacity\":0,\"ticketPrice\":50}"))
               .andExpect(status().isBadRequest());
    }

    @Test
    void put_updatesEvent() throws Exception {
        mockMvc.perform(put("/api/events/" + workshopId).contentType("application/json")
                .content("{\"name\":\"Coding Workshop 2\",\"date\":\"2026-12-02\",\"venue\":\"Lab 4\",\"capacity\":60,\"ticketPrice\":300}"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.name").value("Coding Workshop 2"))
               .andExpect(jsonPath("$.ticketPrice").value(300.0));
    }

    // consistency: capacity 1 < 2 registered participants
    @Test
    void put_capacityBelowRegistered_returns409() throws Exception {
        mockMvc.perform(put("/api/events/" + techId).contentType("application/json")
                .content("{\"name\":\"Tech Fest\",\"date\":\"2026-11-15\",\"capacity\":1,\"ticketPrice\":100}"))
               .andExpect(status().isConflict());
    }

    @Test
    void search_findsByName() throws Exception {
        mockMvc.perform(get("/api/events/search").param("name", "tech"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(1))
               .andExpect(jsonPath("$[0].name").value("Tech Fest"));
    }

    // ---- delete + consistency ----
    @Test
    void delete_eventWithoutParticipants_returns204() throws Exception {
        participants.deleteAll();
        mockMvc.perform(delete("/api/events/" + techId)).andExpect(status().isNoContent());
        assertEquals(1, events.count());
    }

    // MongoDB has no foreign keys: our service refuses to leave orphan participants.
    @Test
    void delete_eventWithParticipants_returns409_andKeepsData() throws Exception {
        mockMvc.perform(delete("/api/events/" + techId)).andExpect(status().isConflict());
        assertEquals(2, events.count());
        assertEquals(2, participants.countByEventId(techId));
    }

    @Test
    void delete_cascade_removesEventAndItsParticipants() throws Exception {
        mockMvc.perform(delete("/api/events/" + techId).param("cascade", "true"))
               .andExpect(status().isNoContent());
        assertEquals(1, events.count());
        assertEquals(0, participants.countByEventId(techId));
        assertEquals(1, participants.count());                 // Charu (other event) is untouched
    }

    @Test
    void delete_missing_returns404() throws Exception {
        mockMvc.perform(delete("/api/events/" + MISSING_ID)).andExpect(status().isNotFound());
    }

    // ---- related records + calculations ----
    @Test
    void participantsOfEvent_returnsRelatedRecords() throws Exception {
        mockMvc.perform(get("/api/events/" + techId + "/participants"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    void participantsOfMissingEvent_returns404() throws Exception {
        mockMvc.perform(get("/api/events/" + MISSING_ID + "/participants"))
               .andExpect(status().isNotFound());
    }

    // 2 participants x price 100 = 200; capacity 2 -> 0 seats left
    @Test
    void summary_countsSeatsAndRevenue() throws Exception {
        mockMvc.perform(get("/api/events/" + techId + "/summary"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.participantCount").value(2))
               .andExpect(jsonPath("$.seatsLeft").value(0))
               .andExpect(jsonPath("$.totalRevenue").value(200.0));
    }

    // events: 2, participants: 3, revenue: 2*100 + 1*250 = 450
    @Test
    void stats_acrossAllEvents() throws Exception {
        mockMvc.perform(get("/api/events/stats"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.totalEvents").value(2))
               .andExpect(jsonPath("$.totalParticipants").value(3))
               .andExpect(jsonPath("$.totalRevenue").value(450.0));
    }
}
