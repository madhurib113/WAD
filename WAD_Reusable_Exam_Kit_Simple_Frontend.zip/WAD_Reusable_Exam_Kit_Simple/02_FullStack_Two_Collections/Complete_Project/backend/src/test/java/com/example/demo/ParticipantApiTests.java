package com.example.demo;

import com.example.demo.model.Event;
import com.example.demo.model.Participant;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.ParticipantRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** Tests for /api/participants: references to an event, missing reference, full event. */
@SpringBootTest
@AutoConfigureMockMvc
class ParticipantApiTests {

    @Autowired MockMvc mockMvc;
    @Autowired EventRepository events;
    @Autowired ParticipantRepository participants;

    String techId;        // FULL event (capacity 2, 2 participants)
    String workshopId;    // capacity 50, 1 participant
    String anuId;

    static final String MISSING_ID = "000000000000000000000000";

    @BeforeEach
    void setUp() {
        participants.deleteAll();
        events.deleteAll();
        techId = events.save(new Event("Tech Fest", "2026-11-15", "Main Hall", 2, 100.0)).getId();
        workshopId = events.save(new Event("Coding Workshop", "2026-12-01", "Lab 3", 50, 250.0)).getId();
        anuId = participants.save(new Participant("Anu", "anu@example.com", techId)).getId();
        participants.save(new Participant("Bala", "bala@example.com", techId));
        participants.save(new Participant("Charu", "charu@example.com", workshopId));
    }

    private String body(String name, String email, String eventId) {
        return "{\"name\":\"" + name + "\",\"email\":\"" + email + "\",\"eventId\":\"" + eventId + "\"}";
    }

    @Test
    void getAll_returnsThree() throws Exception {
        mockMvc.perform(get("/api/participants"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(3));
    }

    // filter by the related record
    @Test
    void filterByEvent_returnsOnlyThatEventsParticipants() throws Exception {
        mockMvc.perform(get("/api/participants").param("eventId", techId))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    void count_byEvent() throws Exception {
        mockMvc.perform(get("/api/participants/count").param("eventId", workshopId))
               .andExpect(jsonPath("$.count").value(1));
        mockMvc.perform(get("/api/participants/count"))
               .andExpect(jsonPath("$.count").value(3));
    }

    @Test
    void post_validReference_returns201() throws Exception {
        mockMvc.perform(post("/api/participants").contentType("application/json")
                .content(body("Dev", "dev@example.com", workshopId)))
               .andExpect(status().isCreated())
               .andExpect(jsonPath("$.id").exists())
               .andExpect(jsonPath("$.eventId").value(workshopId));
        assertEquals(4, participants.count());
    }

    // referenced event does not exist -> 400, nothing saved (we enforce what SQL foreign keys would)
    @Test
    void post_unknownEvent_returns400() throws Exception {
        mockMvc.perform(post("/api/participants").contentType("application/json")
                .content(body("Dev", "dev@example.com", MISSING_ID)))
               .andExpect(status().isBadRequest());
        assertEquals(3, participants.count());
    }

    @Test
    void post_missingEventId_returns400() throws Exception {
        mockMvc.perform(post("/api/participants").contentType("application/json")
                .content("{\"name\":\"Dev\",\"email\":\"dev@example.com\"}"))
               .andExpect(status().isBadRequest());
    }

    // Tech Fest is full (2/2) -> 409
    @Test
    void post_fullEvent_returns409() throws Exception {
        mockMvc.perform(post("/api/participants").contentType("application/json")
                .content(body("Dev", "dev@example.com", techId)))
               .andExpect(status().isConflict());
        assertEquals(3, participants.count());
    }

    @Test
    void getById_andMissing() throws Exception {
        mockMvc.perform(get("/api/participants/" + anuId))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.name").value("Anu"));
        mockMvc.perform(get("/api/participants/" + MISSING_ID))
               .andExpect(status().isNotFound());
    }

    // move Anu to the Workshop: allowed (seat free there)
    @Test
    void put_moveToAnotherEvent() throws Exception {
        mockMvc.perform(put("/api/participants/" + anuId).contentType("application/json")
                .content(body("Anu", "anu@example.com", workshopId)))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.eventId").value(workshopId));
        assertEquals(1, participants.countByEventId(techId));
    }

    // same event, only the email changes: allowed even though the event is full
    @Test
    void put_sameEvent_changesEmail() throws Exception {
        mockMvc.perform(put("/api/participants/" + anuId).contentType("application/json")
                .content(body("Anu", "anu.new@example.com", techId)))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.email").value("anu.new@example.com"));
    }

    @Test
    void put_unknownEvent_returns400() throws Exception {
        mockMvc.perform(put("/api/participants/" + anuId).contentType("application/json")
                .content(body("Anu", "anu@example.com", MISSING_ID)))
               .andExpect(status().isBadRequest());
    }

    @Test
    void delete_returns204_thenFreesSeat() throws Exception {
        mockMvc.perform(delete("/api/participants/" + anuId)).andExpect(status().isNoContent());
        mockMvc.perform(get("/api/events/" + techId + "/summary"))
               .andExpect(jsonPath("$.seatsLeft").value(1));
    }

    @Test
    void delete_missing_returns404() throws Exception {
        mockMvc.perform(delete("/api/participants/" + MISSING_ID)).andExpect(status().isNotFound());
    }

    @Test
    void search_byName() throws Exception {
        mockMvc.perform(get("/api/participants/search").param("name", "ch"))
               .andExpect(jsonPath("$.length()").value(1))
               .andExpect(jsonPath("$[0].name").value("Charu"));
    }

    // schema: required fields exist, unexpected ones do not
    @Test
    void schema_fields() throws Exception {
        mockMvc.perform(get("/api/participants/" + anuId))
               .andExpect(jsonPath("$.id").exists())
               .andExpect(jsonPath("$.name").exists())
               .andExpect(jsonPath("$.email").exists())
               .andExpect(jsonPath("$.eventId").exists())
               .andExpect(jsonPath("$._id").doesNotExist())
               .andExpect(jsonPath("$.event").doesNotExist());
    }
}
