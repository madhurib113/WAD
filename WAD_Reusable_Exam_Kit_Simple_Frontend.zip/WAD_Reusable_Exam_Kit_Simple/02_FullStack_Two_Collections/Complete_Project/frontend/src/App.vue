<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const EVENTS = 'http://localhost:8080/api/events'
const PARTICIPANTS = 'http://localhost:8080/api/participants'

const events = ref([])
const participants = ref([])
const eventForm = ref({ name: '', date: '', venue: '', capacity: '', ticketPrice: '' })
const editingEventId = ref('')
const partForm = ref({ name: '', email: '', eventId: '' })
const editingPartId = ref('')
const filterEventId = ref('')
const searchName = ref('')
const result = ref('')
const error = ref('')

function showError(e) {
  error.value = e.response?.data?.error || e.message
}
const num = (v) => (v === '' ? null : Number(v))

// ---------- Events ----------
async function loadEvents() {
  try {
    const res = await axios.get(EVENTS)
    events.value = res.data
  } catch (e) { showError(e) }
}

async function saveEvent() {
  error.value = ''
  const body = { ...eventForm.value, capacity: num(eventForm.value.capacity), ticketPrice: num(eventForm.value.ticketPrice) }
  try {
    if (editingEventId.value === '') {
      await axios.post(EVENTS, body)
    } else {
      await axios.put(EVENTS + '/' + editingEventId.value, body)
    }
    eventForm.value = { name: '', date: '', venue: '', capacity: '', ticketPrice: '' }
    editingEventId.value = ''
    loadEvents()
  } catch (e) { showError(e) }
}

function editEvent(e) {
  eventForm.value = { name: e.name, date: e.date, venue: e.venue, capacity: e.capacity, ticketPrice: e.ticketPrice }
  editingEventId.value = e.id
}

// cascade = true also deletes the event's participants; false -> error 409 if it has participants
async function deleteEvent(id, cascade) {
  error.value = ''
  try {
    await axios.delete(EVENTS + '/' + id, { params: { cascade: cascade } })
    loadEvents()
    loadParticipants()
  } catch (e) { showError(e) }
}

async function eventParticipants(id) {
  error.value = ''
  try {
    const res = await axios.get(EVENTS + '/' + id + '/participants')
    result.value = JSON.stringify(res.data, null, 2)
  } catch (e) { showError(e) }
}

async function eventSummary(id) {
  error.value = ''
  try {
    const res = await axios.get(EVENTS + '/' + id + '/summary')
    result.value = JSON.stringify(res.data, null, 2)
  } catch (e) { showError(e) }
}

async function eventStats() {
  error.value = ''
  try {
    const res = await axios.get(EVENTS + '/stats')
    result.value = JSON.stringify(res.data, null, 2)
  } catch (e) { showError(e) }
}

// ---------- Participants ----------
async function loadParticipants() {
  try {
    const res = await axios.get(PARTICIPANTS, { params: { eventId: filterEventId.value } })
    participants.value = res.data
  } catch (e) { showError(e) }
}

async function savePart() {
  error.value = ''
  try {
    if (editingPartId.value === '') {
      await axios.post(PARTICIPANTS, partForm.value)
    } else {
      await axios.put(PARTICIPANTS + '/' + editingPartId.value, partForm.value)
    }
    partForm.value = { name: '', email: '', eventId: '' }
    editingPartId.value = ''
    loadParticipants()
  } catch (e) { showError(e) }
}

function editPart(p) {
  partForm.value = { name: p.name, email: p.email, eventId: p.eventId }
  editingPartId.value = p.id
}

async function deletePart(id) {
  error.value = ''
  try {
    await axios.delete(PARTICIPANTS + '/' + id)
    loadParticipants()
  } catch (e) { showError(e) }
}

async function searchPart() {
  error.value = ''
  try {
    const res = await axios.get(PARTICIPANTS + '/search', { params: { name: searchName.value } })
    participants.value = res.data
  } catch (e) { showError(e) }
}

async function countPart() {
  error.value = ''
  try {
    const res = await axios.get(PARTICIPANTS + '/count', { params: { eventId: filterEventId.value } })
    result.value = 'Count: ' + res.data.count
  } catch (e) { showError(e) }
}

function eventName(id) {
  const found = events.value.find((e) => e.id === id)
  return found ? found.name : id
}

onMounted(() => {
  loadEvents()
  loadParticipants()
})
</script>

<template>
  <h1>Event Manager</h1>
  <p v-if="error">Error: {{ error }}</p>

  <h2>Add / Update Event</h2>
  <p>Name: <input v-model="eventForm.name" /></p>
  <p>Date: <input v-model="eventForm.date" type="date" /></p>
  <p>Venue: <input v-model="eventForm.venue" /></p>
  <p>Capacity: <input v-model="eventForm.capacity" type="number" /></p>
  <p>Ticket price: <input v-model="eventForm.ticketPrice" type="number" /></p>
  <button @click="saveEvent">{{ editingEventId === '' ? 'Add Event' : 'Update Event' }}</button>
  <button @click="eventStats">Totals of all events</button>

  <h2>Events ({{ events.length }})</h2>
  <table>
    <tr><th>ID</th><th>Name</th><th>Date</th><th>Venue</th><th>Capacity</th><th>Price</th><th>Actions</th></tr>
    <tr v-for="e in events" :key="e.id">
      <td>{{ e.id }}</td>
      <td>{{ e.name }}</td>
      <td>{{ e.date }}</td>
      <td>{{ e.venue }}</td>
      <td>{{ e.capacity }}</td>
      <td>{{ e.ticketPrice }}</td>
      <td>
        <button @click="editEvent(e)">Edit</button>
        <button @click="deleteEvent(e.id, false)">Delete</button>
        <button @click="deleteEvent(e.id, true)">Delete with participants</button>
        <button @click="eventParticipants(e.id)">Participants</button>
        <button @click="eventSummary(e.id)">Summary</button>
      </td>
    </tr>
  </table>

  <h2>Add / Update Participant</h2>
  <p>Name: <input v-model="partForm.name" /></p>
  <p>Email: <input v-model="partForm.email" /></p>
  <p>
    Event:
    <select v-model="partForm.eventId">
      <option value="">choose</option>
      <option v-for="e in events" :key="e.id" :value="e.id">{{ e.name }}</option>
    </select>
  </p>
  <button @click="savePart">{{ editingPartId === '' ? 'Add Participant' : 'Update Participant' }}</button>

  <h2>Participants ({{ participants.length }})</h2>
  <p>
    Filter by event:
    <select v-model="filterEventId">
      <option value="">all</option>
      <option v-for="e in events" :key="e.id" :value="e.id">{{ e.name }}</option>
    </select>
    <button @click="loadParticipants">Filter</button>
    <button @click="countPart">Count</button>
  </p>
  <p>
    <input v-model="searchName" placeholder="name" />
    <button @click="searchPart">Search</button>
  </p>
  <table>
    <tr><th>ID</th><th>Name</th><th>Email</th><th>Event</th><th>Actions</th></tr>
    <tr v-for="p in participants" :key="p.id">
      <td>{{ p.id }}</td>
      <td>{{ p.name }}</td>
      <td>{{ p.email }}</td>
      <td>{{ eventName(p.eventId) }}</td>
      <td>
        <button @click="editPart(p)">Edit</button>
        <button @click="deletePart(p.id)">Delete</button>
      </td>
    </tr>
  </table>

  <h2>Result</h2>
  <pre>{{ result }}</pre>
</template>

<style>
table, th, td { border: 1px solid gray; border-collapse: collapse; padding: 4px; }
</style>
