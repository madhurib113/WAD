# 03 – Servlet basics (no database)
Four independent webapps. Servlet API: **javax.servlet** (Tomcat 8.5/9 – your `steps.txt` uses 8.5.50). Tomcat 10+ uses **jakarta.servlet**: run `./convert_to_jakarta.sh <folder>` (changes imports and web.xml namespace) then recompile with that Tomcat's `servlet-api.jar`. Mixing them gives `ClassNotFoundException`/`NoSuchMethodError` or "servlet is not a javax.servlet.Servlet".

| Folder | Servlets / URLs | Sample input → output |
|---|---|---|
| 01_Form_Input | `/form` | name Ravi, age 20, Male, hobbies Music+Sports → all values listed, "Age: 20 (adult)" |
| 02_Total_And_Discount | `/total` (index.html), `/discount` (discount.html) | price 250, qty 4 → Total 1000.00 · price 2500, qty 3, blank % → total 7500, 10% slab, **final 6750.00** |
| 03_Marks_And_Grade | `/marks` | 80,90,70,60,100 → total 400, avg 80.00, grade A, PASS · any mark <35 → FAIL |
| 04_Other_Calculations | `/interest /bmi /bill /temperature /login` | 10000,5%,2y → interest 1000.00, amount 11000.00 · 250 units → 600.00 · 100°C → 212.00°F · admin/1234 → Welcome |

## Deploy (each folder is a ready webapp)
```bash
export CATALINA_HOME=/path/to/apache-tomcat-9.x      # Windows: set CATALINA_HOME=C:\apache-tomcat-9.0.xx
cd 03_Marks_And_Grade
./compile.sh                                          # Windows: compile.bat  -> creates WEB-INF/classes/*.class
cp -r ../03_Marks_And_Grade $CATALINA_HOME/webapps/Marks     # folder name = URL context
$CATALINA_HOME/bin/startup.sh                         # Windows: bin\startup.bat
# open http://localhost:8080/Marks/
```
Required layout inside the webapp: `index.html`, `WEB-INF/web.xml`, `WEB-INF/classes/*.class` (`src/` is only source and may stay).
**How it works:** form `action="marks"` ⇄ `<url-pattern>/marks</url-pattern>` ⇄ servlet; each `<input name="m1">` is read by `request.getParameter("m1")` (always a String → parse). Edit the calculation lines marked `<-- the calculation`.
**Adapting:** change input `name`s in the HTML and the same strings in `getParameter(...)`; change formula; change URL pattern in both web.xml and the form action. Recompile after every Java edit and restart/reload the app.
Each servlet also accepts GET, so `http://localhost:8080/Marks/marks?name=A&m1=80&m2=90&m3=70&m4=60&m5=100` works for quick checks.
