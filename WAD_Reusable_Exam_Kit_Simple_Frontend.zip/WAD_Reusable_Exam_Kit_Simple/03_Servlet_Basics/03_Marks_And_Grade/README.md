# Servlet: total, average, grade
**API: `javax.servlet.*` (Servlet 3.1) → Tomcat 8.5 or 9.** For Tomcat 10+ run `../convert_to_jakarta.sh <this folder>` (or replace `javax.servlet` by `jakarta.servlet` in `src/*.java` and use the Jakarta namespace in `WEB-INF/web.xml`), then recompile.
| Tomcat | Servlet | Package |
|---|---|---|
| 8.5 | 3.1 | `javax.servlet` |
| 9.0 | 4.0 | `javax.servlet` |
| 10.1 | 6.0 | `jakarta.servlet` |
| 11 | 6.1 | `jakarta.servlet` |

No database needed.

**Files:** `index.html` (form) · `src/*.java` · `WEB-INF/web.xml` (URL → servlet) · `compile.bat` / `compile.sh`
**URLs:** `/marks`
**Sample:** 80,90,70,60,100 → total 400, average 80.00, grade A, PASS
**Deploy (Windows):** `set CATALINA_HOME=C:\apache-tomcat-9.0.xx` → `compile.bat` → copy this folder to `%CATALINA_HOME%\webapps\<Name>` → `%CATALINA_HOME%\bin\startup.bat` → http://localhost:8080/<Name>/ . (Linux/Mac: `compile.sh`, `startup.sh`.)
**Verified in this kit:** compiles with `javac` against servlet-api 4.0.1 (javax) and, after conversion, Tomcat 10 servlet-api (jakarta). **Not run** inside Tomcat.
**Change for another question:** field names in the HTML ⇄ `request.getParameter("...")`; formula/SQL lines; `<url-pattern>` ⇄ form `action`.
