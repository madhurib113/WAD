import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Five subject marks (0-100) -> total, average, grade, result.
 * Result = FAIL if ANY subject is below 35, otherwise PASS.
 * Grade (average): >=90 A+, >=80 A, >=70 B, >=60 C, >=50 D, else F
 */
public class MarksServlet extends HttpServlet {

    private static final int PASS_MARK = 35;
    private static final String[] SUBJECTS = {"m1", "m2", "m3", "m4", "m5"};   // names of the input boxes

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        out.println("<html><body><h2>Student Result</h2>");
        try {
            String name = req.getParameter("name");
            int total = 0;
            boolean anyFail = false;
            out.println("<p>Name: " + esc(name) + "</p>");
            for (int i = 0; i < SUBJECTS.length; i++) {
                int mark = Integer.parseInt(req.getParameter(SUBJECTS[i]).trim());
                if (mark < 0 || mark > 100) throw new NumberFormatException("range");
                total += mark;
                if (mark < PASS_MARK) anyFail = true;
                out.println("<p>Subject " + (i + 1) + ": " + mark + "</p>");
            }
            double average = total / (double) SUBJECTS.length;     // <-- calculations
            String grade;
            if (average >= 90) grade = "A+";
            else if (average >= 80) grade = "A";
            else if (average >= 70) grade = "B";
            else if (average >= 60) grade = "C";
            else if (average >= 50) grade = "D";
            else grade = "F";

            out.println("<p><b>Total: " + total + " / " + (SUBJECTS.length * 100) + "</b></p>");
            out.println("<p><b>Average: " + String.format("%.2f", average) + "</b></p>");
            out.println("<p><b>Grade: " + (anyFail ? "F" : grade) + "</b></p>");
            out.println("<p><b>Result: " + (anyFail ? "FAIL" : "PASS") + "</b></p>");
        } catch (NumberFormatException | NullPointerException e) {
            out.println("<p style='color:red'>Enter whole-number marks between 0 and 100 for all subjects.</p>");
        }
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }

    // Escapes < > & " so text typed by the user cannot break (or inject into) the page.
    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
