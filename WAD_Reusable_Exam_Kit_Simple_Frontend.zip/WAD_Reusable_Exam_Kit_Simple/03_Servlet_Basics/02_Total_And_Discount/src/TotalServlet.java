import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** total = price x quantity */
public class TotalServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        String item = req.getParameter("item");
        out.println("<html><body><h2>Bill</h2>");
        try {
            double price = Double.parseDouble(req.getParameter("price"));
            int quantity = Integer.parseInt(req.getParameter("quantity"));
            if (price < 0 || quantity < 0) throw new NumberFormatException();
            double total = price * quantity;                          // <-- the calculation
            out.println("<p>Item: " + esc(item) + "</p>");
            out.println("<p>Price: " + String.format("%.2f", price) + "</p>");
            out.println("<p>Quantity: " + quantity + "</p>");
            out.println("<p><b>Total = " + String.format("%.2f", total) + "</b></p>");
        } catch (NumberFormatException | NullPointerException e) {
            out.println("<p style='color:red'>Enter a valid non-negative price and quantity.</p>");
        }
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }

    // Escapes < > & " so text typed by the user cannot break (or inject into) the page.
    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
