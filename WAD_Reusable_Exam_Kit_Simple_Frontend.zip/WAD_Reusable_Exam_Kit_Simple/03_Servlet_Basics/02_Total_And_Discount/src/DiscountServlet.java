import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * total = price x quantity
 * discount: the percent typed by the user; if the box is empty a SLAB rule is used
 *           (total >= 5000 -> 10%,  total >= 2000 -> 5%,  otherwise 0%)
 * final = total - discount
 */
public class DiscountServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        out.println("<html><body><h2>Bill with Discount</h2>");
        try {
            String item = req.getParameter("item");
            double price = Double.parseDouble(req.getParameter("price"));
            int quantity = Integer.parseInt(req.getParameter("quantity"));
            String pct = req.getParameter("discountPercent");
            if (price < 0 || quantity < 0) throw new NumberFormatException();

            double total = price * quantity;
            double percent;
            String rule;
            if (pct != null && !pct.trim().isEmpty()) {
                percent = Double.parseDouble(pct);                 // percent given by the user
                if (percent < 0 || percent > 100) throw new NumberFormatException();
                rule = "entered by user";
            } else if (total >= 5000) { percent = 10; rule = "slab: total >= 5000"; }
            else if (total >= 2000)   { percent = 5;  rule = "slab: total >= 2000"; }
            else                      { percent = 0;  rule = "slab: no discount"; }

            double discount = total * percent / 100.0;
            double finalAmount = total - discount;                  // <-- the calculation

            out.println("<p>Item: " + esc(item) + "</p>");
            out.println("<p>Total: " + String.format("%.2f", total) + "</p>");
            out.println("<p>Discount (" + percent + "%, " + rule + "): " + String.format("%.2f", discount) + "</p>");
            out.println("<p><b>Final amount = " + String.format("%.2f", finalAmount) + "</b></p>");
        } catch (NumberFormatException | NullPointerException e) {
            out.println("<p style='color:red'>Enter valid numbers (discount 0 to 100).</p>");
        }
        out.println("<p><a href='discount.html'>Back</a></p></body></html>");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }

    // Escapes < > & " so text typed by the user cannot break (or inject into) the page.
    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
