import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** SI = P x R x T / 100 ; amount = P + SI */
public class SimpleInterestServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        out.println("<html><body><h2>Simple Interest</h2>");
        try {
            double p = Double.parseDouble(req.getParameter("principal"));
            double r = Double.parseDouble(req.getParameter("rate"));
            double t = Double.parseDouble(req.getParameter("years"));
            if (p < 0 || r < 0 || t < 0) throw new NumberFormatException();
            double si = p * r * t / 100.0;
            out.println("<p>Interest = " + String.format("%.2f", si) + "</p>");
            out.println("<p><b>Total amount = " + String.format("%.2f", p + si) + "</b></p>");
        } catch (NumberFormatException | NullPointerException e) {
            out.println("<p style='color:red'>Enter valid non-negative numbers.</p>");
        }
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { doPost(req, res); }
}
