import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** C -> F : c*9/5+32      F -> C : (f-32)*5/9 */
public class TemperatureServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        out.println("<html><body><h2>Temperature Converter</h2>");
        try {
            double value = Double.parseDouble(req.getParameter("value"));
            String mode = req.getParameter("mode");
            if ("C2F".equals(mode))
                out.println("<p><b>" + value + " &deg;C = " + String.format("%.2f", value * 9 / 5 + 32) + " &deg;F</b></p>");
            else if ("F2C".equals(mode))
                out.println("<p><b>" + value + " &deg;F = " + String.format("%.2f", (value - 32) * 5 / 9) + " &deg;C</b></p>");
            else
                out.println("<p style='color:red'>Choose a conversion.</p>");
        } catch (NumberFormatException | NullPointerException e) {
            out.println("<p style='color:red'>Enter a valid number.</p>");
        }
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { doPost(req, res); }
}
