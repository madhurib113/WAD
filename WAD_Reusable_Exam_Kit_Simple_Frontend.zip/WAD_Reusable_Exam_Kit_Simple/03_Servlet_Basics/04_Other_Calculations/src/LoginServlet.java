import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** Conditional processing: compares the typed values with fixed credentials (admin / 1234). */
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        String user = req.getParameter("username");
        String pass = req.getParameter("password");
        out.println("<html><body>");
        if (user == null || user.trim().isEmpty() || pass == null || pass.isEmpty())
            out.println("<p style='color:red'>Username and password are required.</p>");
        else if ("admin".equals(user) && "1234".equals(pass))
            out.println("<h2>Welcome, " + esc(user) + "!</h2>");
        else
            out.println("<p style='color:red'>Invalid username or password.</p>");
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { doPost(req, res); }

    // Escapes < > & " so text typed by the user cannot break (or inject into) the page.
    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
