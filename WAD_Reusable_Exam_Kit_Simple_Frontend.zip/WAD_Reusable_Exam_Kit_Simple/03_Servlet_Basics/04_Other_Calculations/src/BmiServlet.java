import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** BMI = weight(kg) / (height(m))^2  ->  category */
public class BmiServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        out.println("<html><body><h2>BMI</h2>");
        try {
            double kg = Double.parseDouble(req.getParameter("weight"));
            double m = Double.parseDouble(req.getParameter("height")) / 100.0;   // cm -> m
            if (kg <= 0 || m <= 0) throw new NumberFormatException();
            double bmi = kg / (m * m);
            String category = bmi < 18.5 ? "Underweight" : bmi < 25 ? "Normal" : bmi < 30 ? "Overweight" : "Obese";
            out.println("<p><b>BMI = " + String.format("%.2f", bmi) + " (" + category + ")</b></p>");
        } catch (NumberFormatException | NullPointerException e) {
            out.println("<p style='color:red'>Enter positive weight and height.</p>");
        }
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { doPost(req, res); }
}
