import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Slab tariff:  first 100 units @ 1.5,  next 100 @ 2.5,  next 100 @ 4.0,  above 300 @ 6.0
 * Example: 250 units = 100*1.5 + 100*2.5 + 50*4.0 = 600.00
 */
public class ElectricityBillServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        out.println("<html><body><h2>Electricity Bill</h2>");
        try {
            int units = Integer.parseInt(req.getParameter("units").trim());
            if (units < 0) throw new NumberFormatException();
            double bill;
            if (units <= 100)      bill = units * 1.5;
            else if (units <= 200) bill = 100 * 1.5 + (units - 100) * 2.5;
            else if (units <= 300) bill = 100 * 1.5 + 100 * 2.5 + (units - 200) * 4.0;
            else                   bill = 100 * 1.5 + 100 * 2.5 + 100 * 4.0 + (units - 300) * 6.0;
            out.println("<p>Units: " + units + "</p>");
            out.println("<p><b>Bill amount = " + String.format("%.2f", bill) + "</b></p>");
        } catch (NumberFormatException | NullPointerException e) {
            out.println("<p style='color:red'>Enter a valid number of units.</p>");
        }
        out.println("<p><a href='index.html'>Back</a></p></body></html>");
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { doPost(req, res); }
}
