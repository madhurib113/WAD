#!/bin/sh
# Usage:  export CATALINA_HOME=/path/to/apache-tomcat-9.x   (once)   then   ./compile.sh
# Compiles every .java in src/ into WEB-INF/classes using Tomcat's servlet-api.jar
set -e
API="${SERVLET_API:-$CATALINA_HOME/lib/servlet-api.jar}"
mkdir -p WEB-INF/classes
javac -cp "$API" -d WEB-INF/classes src/*.java
echo "Compiled into WEB-INF/classes"
