@echo off
REM Usage: set CATALINA_HOME=C:\apache-tomcat-9.0.xx   then   compile.bat
if not exist WEB-INF\classes mkdir WEB-INF\classes
javac -cp "%CATALINA_HOME%\lib\servlet-api.jar" -d WEB-INF\classes src\*.java
echo Compiled into WEB-INF\classes
