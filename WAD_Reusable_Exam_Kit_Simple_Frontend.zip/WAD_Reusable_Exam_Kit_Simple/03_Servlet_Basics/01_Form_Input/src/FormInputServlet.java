import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** Reads every kind of form control and displays the values. */
public class FormInputServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");                    // must be called BEFORE reading parameters
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();

        String name    = req.getParameter("name");            // <input type=text name="name">
        String email   = req.getParameter("email");
        String ageText = req.getParameter("age");             // always a String - convert if you need a number
        String gender  = req.getParameter("gender");          // radio: null when nothing selected
        String course  = req.getParameter("course");          // <select>
        String[] hobbies = req.getParameterValues("hobbies"); // checkboxes: String[] or null when none ticked
        String message = req.getParameter("message");         // <textarea>

        out.println("<html><body>");
        out.println("<h2>Submitted Details</h2>");
        out.println("<p>Name: " + esc(name) + "</p>");
        out.println("<p>Email: " + esc(email) + "</p>");
        try {
            int age = Integer.parseInt(ageText.trim());
            out.println("<p>Age: " + age + (age >= 18 ? " (adult)" : " (minor)") + "</p>");
        } catch (Exception e) {                               // null or not a number
            out.println("<p>Age: invalid</p>");
        }
        out.println("<p>Gender: " + (gender == null ? "not selected" : esc(gender)) + "</p>");
        out.println("<p>Course: " + esc(course) + "</p>");
        out.print("<p>Hobbies: ");
        if (hobbies == null) out.print("none");
        else out.print(esc(String.join(", ", hobbies)));
        out.println("</p>");
        out.println("<p>Message: " + esc(message) + "</p>");
        out.println("<p><a href='index.html'>Back</a></p>");
        out.println("</body></html>");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);                                     // lets the URL also work when typed in the browser
    }

    // Escapes < > & " so text typed by the user cannot break (or inject into) the page.
    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
