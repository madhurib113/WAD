#!/bin/sh
# Converts ONE servlet project folder from javax.servlet (Tomcat 8.5 / 9) to jakarta.servlet (Tomcat 10+).
# Usage:  ./convert_to_jakarta.sh 01_Form_Input      (edits the folder IN PLACE - copy it first if you want to keep both)
set -e
d="$1"; [ -d "$d" ] || { echo "usage: $0 <project-folder>"; exit 1; }
for f in "$d"/src/*.java; do sed -i 's/javax\.servlet/jakarta.servlet/g' "$f"; done
sed -i -e 's#http://xmlns.jcp.org/xml/ns/javaee#https://jakarta.ee/xml/ns/jakartaee#' -e 's/version="3.1"/version="5.0"/' "$d/WEB-INF/web.xml"
echo "Converted $d to jakarta.servlet (Servlet 5.0). Recompile with ./compile.sh using Tomcat 10+'s servlet-api.jar."
