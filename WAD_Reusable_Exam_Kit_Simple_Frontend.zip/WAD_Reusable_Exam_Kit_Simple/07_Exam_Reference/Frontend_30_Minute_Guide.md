# Writing the frontend from memory (about 30 minutes)
The page is plain HTML (white, black text, gray table borders). Only 1 CSS line. Write in this order:
1. `npm create vite@latest frontend -- --template vue` (or copy `frontend/`), then `npm install axios`.
2. `App.vue` = `<script setup>` (imports `ref`, `onMounted`, `axios`) + `<template>` + the one-line `<style>`.
3. Script: `API` constant → `ref` for the list and the form → `loadAll()` (GET) → `save()` (POST; PUT when `editingId` is set) → `remove(id)` (DELETE) → `edit(row)` → `onMounted(loadAll)`.
4. Template: `<h2>`, `<p>Label: <input v-model="form.name" /></p>` lines, one `<button @click="save">`, then `<table>` with a `<tr v-for="e in list" :key="e.id">`.
5. Extras only if the question asks: `search()`, `filter()`, `count()`, `stats()`, `adjust()`; each is the same 6 lines (`try { const res = await axios.get(...) ; list.value = res.data } catch (e) { showError(e) }`).
Pattern for any call: `axios.get(url, { params: {...} })`, `axios.post(url, body)`, `axios.put(url + '/' + id, body)`, `axios.delete(url + '/' + id)`; result is in `res.data`; errors in `e.response?.data?.error`.
Run: `npm install`, `npm run dev` → http://localhost:5173 (backend on 8080 must be running and `@CrossOrigin` allows 5173).
