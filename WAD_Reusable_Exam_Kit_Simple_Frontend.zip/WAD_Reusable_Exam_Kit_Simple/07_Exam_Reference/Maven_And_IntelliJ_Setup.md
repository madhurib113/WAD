# Maven & IntelliJ setup
**Chosen versions:** Spring Boot **4.1.1**, Java **17**, Maven. This is exactly the parent/starters of your own working `Full-Stack-CRUD/demo/pom.xml`. I could **not** download from Maven Central in my sandbox, so the combination was **not built by me** – it is copied from your project that you generated with start.spring.io. Boot 4 requires Java 17+ (you have 17).
Boot 4 specifics: starters are `spring-boot-starter-webmvc` (not `-web`), `spring-boot-starter-webmvc-test`, `spring-boot-starter-data-mongodb-test`; Mongo URI property is `spring.mongodb.uri` (on Boot 3.x: `spring.data.mongodb.uri` – the master prompt's claim is correct only for 3.x); `@AutoConfigureMockMvc` package changed. Lombok is **not** used (plain getters/setters) so no annotation-processor problems.
**New project (IntelliJ):** File → New → Project → Spring Boot (start.spring.io), Maven, Java 17, JAR, Group `com.example`, Artifact `demo`, deps *Spring Web, Spring Data MongoDB*. Or *File → Open →* the `backend/pom.xml` of this kit → *Open as Project*.
**Fix list**
1. File → Project Structure → SDK = 17 (or newer) and Language level 17. Settings → Build → Maven → Runner JRE = same.
2. Maven tool window → 🔄 *Reload All Maven Projects* (or right-click pom.xml → Maven → Reload).
3. "Cannot resolve symbol / package does not exist" → reload Maven, then *File → Invalidate Caches*.
4. Dependency download fails → check internet/proxy (Settings → Maven), delete the folder `~/.m2/repository/<failed artifact>` and reload.
5. "Source option 17 is not supported" → JDK older than 17.
6. "Port 8080 already in use" → stop the other app or `server.port=8081` (then update `API` in App.vue and `@CrossOrigin` stays the same).
7. Class not found at start → `DemoApplication` must be in the root package of all classes.
8. `mvn spring-boot:run` fails at *testCompile* → fix/delete tests that reference removed code.
9. Mongo "Timed out while waiting for a server" → MongoDB not running.
Run: `mvn spring-boot:run`, or the green arrow on `DemoApplication`.
