# Which file/template for which question
| Question says | Use | Keep | Skip |
|---|---|---|---|
| "Spring Boot + MongoDB REST API, one entity, CRUD" | 01 | model, repo, controller (+service) | Vue if not asked, tests |
| "Vue form that adds/lists/updates/deletes" | 01 (whole) | all + `App.vue` `fields` | – |
| "Search / filter / sort / count / total" | 01 | service + controller methods | – |
| "Two collections / relationship / reference" | 02 | all | – |
| "Servlet: display form values" | 03/01 | – | – |
| "price × quantity / discount / bill" | 03/02 | – | – |
| "marks, total, average, grade" | 03/03 | – | – |
| "interest, BMI, bill slabs, converter, login" | 03/04 | – | – |
| "Servlet + database insert/view/search/update/delete" | 04/05 (or the matching subset 01–04) | + MySQL jar | – |
| "Test GET/POST/status/JSON/fields with MockMvc" | 06 | matching test class | – |
| "Spring MVC (views)" | 05 – **pending syllabus** | – | – |
