# Environment check and run guide (Windows)
## 1. Check what you have
PowerShell (recommended): `powershell -ExecutionPolicy Bypass -File 07_Exam_Reference\check_environment.ps1`
Command Prompt: `07_Exam_Reference\check_environment.bat`
| Check | Success looks like | If missing |
|---|---|---|
| Java | `openjdk version "17..."` (17 or newer; the project is compiled for 17) | In IntelliJ use *File → Project Structure → SDK → Add JDK → Download JDK 17*; no system install needed |
| javac | `javac 17...` | You only have a JRE; use IntelliJ's downloaded JDK |
| Maven | `Apache Maven 3.9...` | **Not required**: use `mvnw.cmd` inside `backend/` (downloads Maven itself on first run, needs internet) or IntelliJ's bundled Maven |
| Node / npm | node ≥ 22.18, npm 10+ | Only needed for the Vue part; install Node LTS |
| MongoDB service | `MongoDB: Running` | Start it: `net start MongoDB` (admin prompt). Not installed → install MongoDB Community Server |
| Compass | path found | optional; `mongosh` can replace it |
| Tomcat | `Server number: 9.0.x` | needed only for Servlet questions; choose 9 for `javax`, 10.1 for `jakarta` |
| MySQL + Connector/J | service Running, `mysql-connector-j-8.x.jar` found | needed only for 04_Servlet_Database_Connectivity; jar from dev.mysql.com/downloads/connector/j (Platform Independent) |
| Ports | 8080, 5173 free; 27017 (Mongo), 3306 (MySQL) in use when those services run | stop the other program using the port |
**Lombok:** the kit's code does not use Lombok (plain getters/setters), so it works whether or not the wizard added it. Leave Lombok out of `pom.xml`; if you keep it you must also enable *Settings → Build → Compiler → Annotation Processors*.
**Mongo URI property:** the kit uses Boot 4.1.1 → `spring.mongodb.uri` (Boot 3.x → `spring.data.mongodb.uri`).

## 2. Run a full-stack project (steps 1–10)
1. **Open backend:** IntelliJ → *File → Open* → select `…\Complete_Project\backend\pom.xml` → *Open as Project* → *Trust*.
2. **Reload Maven:** right-hand *Maven* panel → 🔄 *Reload All Maven Projects* (wait for the progress bar).
3. **JDK:** *File → Project Structure → Project → SDK = 17+*, language level 17; *Settings → Build Tools → Maven → Runner → JRE = Project JDK*.
4. **Start Spring Boot:** green arrow on `DemoApplication`, or terminal in `backend`: `.\mvnw.cmd spring-boot:run` (or `mvn spring-boot:run`). Success: log line *Started DemoApplication* and port 8080.
5. **Frontend dependencies:** terminal in `frontend`: `npm ci` (uses package-lock.json; `npm install` also works).
6. **Start Vue:** `npm run dev` → open http://localhost:5173.
7. **MongoDB connectivity:** Compass → connect `mongodb://localhost:27017` shows databases; or `mongosh --eval "db.runCommand({ping:1})"` → `ok: 1`. Backend log shows no *MongoTimeoutException*; `GET http://localhost:8080/api/employees` (or `/api/events`) returns `[]` or data.
8. **Postman:** use `api_requests.md` (one-collection) – body *raw → JSON*, header `Content-Type: application/json`.
9. **MockMvc tests:** MongoDB running → IntelliJ: right-click `src/test/java` → *Run 'All Tests'*, or `.\mvnw.cmd test`. They use the databases `employee_db_test` / `event_db_test`, never your normal ones.
10. **Common errors:** see `Common_Errors.md`. Most likely: JDK < 17 (*release version 17 not supported*); Maven not reloaded (red imports); MongoDB not running (timeout); port 8080 busy; Vue started before backend (empty list, console CORS/Network error); wrong `API` URL in `App.vue`.
