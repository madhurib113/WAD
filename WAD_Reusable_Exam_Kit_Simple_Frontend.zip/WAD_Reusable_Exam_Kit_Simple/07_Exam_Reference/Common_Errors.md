# Common errors
| Symptom | Cause | Fix |
|---|---|---|
| Browser console "CORS policy" | origin not allowed | Vue must run on 5173 or edit `@CrossOrigin` |
| 404 on every URL | wrong path / controller outside main package | match `@RequestMapping` and Axios URL |
| 405 | wrong HTTP method | check `@PostMapping` vs `axios.post` |
| 400 | validation failed / bad JSON | read `{"error": ...}` in the response |
| 415 Unsupported Media Type | missing `Content-Type: application/json` | Postman header / `.contentType("application/json")` |
| Empty list, no error | collection or db name mismatch | `@Document(collection)`, `spring.mongodb.uri` |
| Field is `null` in DB | JSON key ≠ Java field name | align names |
| `No property xyz found for type` at start | repository method names a missing field | fix the method name |
| Servlet 404 | url-pattern ≠ form action, or class not compiled | check web.xml + `WEB-INF/classes` |
| `javax.servlet` not found / "not a javax.servlet.Servlet" | Tomcat 10+ vs javax code | convert to jakarta |
| JSON path `$.x` not found in test | field name wrong or error response | print with `.andDo(print())` (import `MockMvcResultHandlers.print`) |
