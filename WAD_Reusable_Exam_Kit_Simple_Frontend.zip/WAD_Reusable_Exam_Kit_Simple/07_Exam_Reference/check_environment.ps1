# WAD environment check (Windows PowerShell). Run:  powershell -ExecutionPolicy Bypass -File .\check_environment.ps1
function Show($name,$ok,$info){ if($ok){Write-Host ("[ OK ] {0,-22} {1}" -f $name,$info) -ForegroundColor Green} else {Write-Host ("[MISSING] {0,-18} {1}" -f $name,$info) -ForegroundColor Yellow} }
function Ver($cmd,$args){ try { $o = & $cmd $args 2>&1 | Select-Object -First 1; return "$o" } catch { return $null } }

$j = Ver "java" "-version";   Show "Java (need 17+)"   ($j -ne $null) $j
$jc = Ver "javac" "-version"; Show "javac (JDK)"       ($jc -ne $null) $jc
Show "JAVA_HOME" ([bool]$env:JAVA_HOME) $env:JAVA_HOME
$m = Ver "mvn" "-v";          Show "Maven (optional)"  ($m -ne $null) $m
Show "Maven wrapper mvnw.cmd" ((Test-Path ".\mvnw.cmd") -or (Test-Path "..\..\01_FullStack_One_Collection\Complete_Project\backend\mvnw.cmd")) "(run it from the backend folder: .\mvnw.cmd spring-boot:run)"
$n = Ver "node" "-v";         Show "Node.js (need 22.18+)" ($n -ne $null) $n
$np = Ver "npm" "-v";         Show "npm"               ($np -ne $null) $np
$mg = Get-Service -Name "MongoDB*" -ErrorAction SilentlyContinue
Show "MongoDB service" ([bool]$mg) (($mg | ForEach-Object { "$($_.Name): $($_.Status)" }) -join ", ")
$ms = Ver "mongosh" "--version"; Show "mongosh (optional)" ($ms -ne $null) $ms
$compass = Get-ChildItem "$env:LOCALAPPDATA\MongoDBCompass","$env:ProgramFiles\MongoDB Compass" -ErrorAction SilentlyContinue | Select-Object -First 1
Show "MongoDB Compass" ([bool]$compass) "(GUI only; optional)"
Show "CATALINA_HOME (Tomcat)" ([bool]$env:CATALINA_HOME) $env:CATALINA_HOME
if ($env:CATALINA_HOME) {
  $ver = & "$env:CATALINA_HOME\bin\version.bat" 2>&1 | Select-String "Server number|Server version"
  Write-Host "       Tomcat: $ver   (8.5/9 -> javax.servlet   |   10.1/11 -> jakarta.servlet)"
  Show "servlet-api.jar" (Test-Path "$env:CATALINA_HOME\lib\servlet-api.jar") "$env:CATALINA_HOME\lib\servlet-api.jar"
}
$my = Ver "mysql" "--version"; Show "MySQL client" ($my -ne $null) $my
$mys = Get-Service -Name "MySQL*" -ErrorAction SilentlyContinue
Show "MySQL service" ([bool]$mys) (($mys | ForEach-Object { "$($_.Name): $($_.Status)" }) -join ", ")
$jar = Get-ChildItem -Path "$env:USERPROFILE\Downloads","$env:USERPROFILE\.m2" -Recurse -Filter "mysql-connector-j*.jar" -ErrorAction SilentlyContinue | Select-Object -First 1
Show "MySQL Connector/J jar" ([bool]$jar) $jar.FullName
Write-Host "`nPorts (Listen = something is already using it):"
foreach($p in 8080,5173,27017,3306){ $c = Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue
  if($c){Write-Host ("  {0,-6} IN USE by PID {1}" -f $p,$c[0].OwningProcess) -ForegroundColor Cyan} else {Write-Host ("  {0,-6} free" -f $p)} }
Write-Host "  (27017 and 3306 SHOULD be in use once MongoDB / MySQL run; 8080 and 5173 should be free before you start Spring Boot / Vue.)"
