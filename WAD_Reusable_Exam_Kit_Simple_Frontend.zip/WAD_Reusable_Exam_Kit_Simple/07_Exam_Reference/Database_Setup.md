# Database setup
## MongoDB (Compass)
Connect `mongodb://localhost:27017`. Database/collection appear after the first insert, or create them with *Create Database*. Import: collection → ADD DATA → Import JSON. Verify with the refresh button. `_id` = ObjectId; Java `id` is its hex string. If the list is empty, check the db name in `spring.mongodb.uri` and `@Document(collection=...)`.
## MySQL (servlets)
`mysql -u root -p < schema.sql` ; check `SHOW TABLES; SELECT * FROM employees;`. URL `jdbc:mysql://localhost:3306/wad_db`. Connector/J jar in `WEB-INF/lib`. Error "Access denied" = wrong user/password; "Communications link failure" = MySQL not running/wrong port; "Unknown database" = schema.sql not run; `ClassNotFoundException: com.mysql.cj.jdbc.Driver` = jar missing.
