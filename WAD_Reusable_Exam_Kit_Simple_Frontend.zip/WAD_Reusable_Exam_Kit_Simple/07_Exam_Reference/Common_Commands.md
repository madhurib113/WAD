# Common commands
```bash
java -version ; mvn -version ; node -v ; npm -v        # Java must be 17+
mvn spring-boot:run                                    # backend (in backend/)
mvn test                                               # all MockMvc tests (MongoDB must run)
mvn -Dtest=EmployeeGetTests test                       # one test class
mvn clean compile                                      # rebuild from scratch
npm install ; npm run dev ; npm run build              # frontend (in frontend/)
mongosh  →  use employee_db ; db.employees.find() ; db.employees.deleteMany({})
curl -i http://localhost:8080/api/employees
# Tomcat
$CATALINA_HOME/bin/startup.sh   |  shutdown.sh          # Windows: startup.bat / shutdown.bat
javac -cp "$CATALINA_HOME/lib/servlet-api.jar" -d WEB-INF/classes src/*.java
```
Ports: Spring 8080 · Vue 5173 · MongoDB 27017 · Tomcat 8080 (stop Spring before starting Tomcat, or change one port with `server.port=8081`).
