@echo off
REM Command Prompt version. Double-click or run: check_environment.bat
echo --- Java ---        & java -version 2>&1 | findstr /i "version" 
echo --- javac ---       & javac -version 2>&1
echo --- JAVA_HOME ---   & echo %JAVA_HOME%
echo --- Maven ---       & mvn -v 2>&1 | findstr /i "Apache Maven Java"
echo --- Node / npm ---  & node -v & npm -v
echo --- MongoDB service --- & sc query MongoDB | findstr /i "STATE"
echo --- mongosh ---     & mongosh --version
echo --- Tomcat (CATALINA_HOME=%CATALINA_HOME%) --- & if defined CATALINA_HOME "%CATALINA_HOME%\bin\version.bat" | findstr /i "Server number"
echo --- MySQL ---       & mysql --version
echo --- Ports in use (8080 5173 27017 3306) --- & netstat -ano | findstr LISTENING | findstr ":8080 :5173 :27017 :3306"
echo.
echo OK = a version line is shown. "not recognized" = not installed / not on PATH. See Environment_Check_And_Run_Guide.md
