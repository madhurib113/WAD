# Repository analysis (WAD-main.zip, 153 files)
| Project | Purpose / operations | DB | Notes |
|---|---|---|---|
| Full-Stack-CRUD/demo + CRUD | Student CRUD, search by name; Vue uses `fetch` | Mongo `models` | **Boot 4.1.1**, `spring-boot-starter-webmvc`, `spring.mongodb.uri`, Lombok; 1 collection (`students`) |
| Course-FullStack | course registration | Mongo `courseRegistrationDB` | Boot 3.4.3, `/api/courses`, 1 collection |
| ShoppingCart-FullStack | products + orders | Mongo `shoppingCartDB` | Boot 3.4.3, 2 collections, order total calc |
| Room_Booking_FullStack | rooms + bookings (DTOs) | Mongo `hotel_db` | Boot 3.5.6, 2 collections |
| Servlet-CRUD | Servlet + JDBC CRUD on `students(regno,name,course)` | MySQL | javax, Tomcat 8/9, Connector/J |
| Servlet/Hello-Servlet | Hello form (GET) | – | javax; steps.txt for Tomcat 8.5.50 |
| Pinia/Props/routing food-ordering | Vue front-end only (Pinia, router, props/emits) | – | no backend |
| Html,CSS,JS | 11 games | – | front-end only |
| Nested ZIPs | FS.zip (Library: Book/Member/Borrow/User, with `target/` classes), Student/Course (2 versions, one with Lombok + Pinia), Assignment8 CRUD (Student, Product, Pinia/router), Room_Booking, Servlet_Marks_Project (grade servlet), WAD_Assignments (6 HTML/JS assignments) | Mongo | **Scenarios to avoid:** Student, Course, Product/Order, Library, Room Booking, Shopping Cart, Food ordering |
**Existing operations:** CRUD, search by name, order total, booking save into two collections, grade calculation. **Not present:** Axios, filter/sort/count/stats endpoints, validation/exception handling, MockMvc tests (only `contextLoads`), Spring MVC views, MongoDB-relationship rules.
## Detected problems (confirmed by reading the code)
1. Mixed Spring Boot versions (3.4.3, 3.5.6, 4.1.1) and properties: only the 4.1.1 project uses `spring.mongodb.uri`; the others use `spring.data.mongodb.uri` (correct for their Boot 3). The master prompt's rule is version-dependent.
2. `demo/pom.xml`: the project name element is written `<n>demo</n>` instead of `<name>demo</name>` – Maven normally reports *Unrecognised tag* for this and may refuse to build (I could not run Maven to confirm); it also leaves empty `<license/>`, `<developer/>`, `<scm>` stubs.
3. `StudentController`: PUT does not check existence (acts as upsert); `search` returns one `Student` via `findByName` – throws if two students share a name, returns an empty 200 when none; DELETE has no 404 handling.
4. `Servlet-CRUD`: web.xml maps `/hello` for a database servlet; the `sql` file mixes SQL with shell commands and has no extension; the compile command points to `src/DatabaseServlet.java` but the source is in `WEB-INF/classes/`; one shared `Connection` field (not thread-safe); credentials hard-coded; user text echoed without escaping; `index.html` redirect link only.
5. `HelloServlet`: prints the request parameter unescaped (XSS); `web.xml` has no version/namespace.
6. `Servlet_Marks_Project`: `Integer.parseInt` unguarded → HTTP 500 on empty/non-numeric input; same unescaped name.
7. Vue apps use `fetch`, no Axios (your exam brief asks for Axios).
8. `FS.zip` contains compiled `target/` output; generated files should not be committed. Several `.zip` archives duplicate folders already unpacked.
9. Not detected/verified: whether each project builds (Maven Central unreachable from my sandbox).
