<script setup>
// Table of Room records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'roomType', label: 'Room Type', type: 'text' },
  { key: 'facility', label: 'Facility', type: 'text' },
  { key: 'floor', label: 'Floor', type: 'text' },
  { key: 'maxGuests', label: 'Max Guests', type: 'number' },
  { key: 'pricePerNight', label: 'Price Per Night', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Guests</button>
          <button @click="$emit('related', x.id)">Guests</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
