<script setup>
// Form for the "ONE" side (Room). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'roomType', label: 'Room Type', type: 'text' },
  { key: 'facility', label: 'Facility', type: 'text' },
  { key: 'floor', label: 'Floor', type: 'text' },
  { key: 'maxGuests', label: 'Max Guests', type: 'number' },
  { key: 'pricePerNight', label: 'Price Per Night', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Room</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
