<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import RoomForm from './components/RoomForm.vue'
import RoomList from './components/RoomList.vue'
import GuestForm from './components/GuestForm.vue'
import GuestList from './components/GuestList.vue'
import ResultBox from './components/ResultBox.vue'

const ROOMS = 'http://localhost:8080/api/rooms'
const GUESTS = 'http://localhost:8080/api/guests'

const rooms = ref([])
const guests = ref([])
const roomForm = ref({ roomType: '', facility: '', floor: '', maxGuests: '', pricePerNight: '' })
const editingRoomId = ref('')
const guestForm = ref({ name: '', phone: '', roomId: '' })
const editingGuestId = ref('')
const filterRoomId = ref('')
const keyword = ref('')
const minpricePerNight = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Room ----------
async function loadRooms() {
  try { rooms.value = (await axios.get(ROOMS)).data } catch (e) { showError(e) }
}

async function saveRoom() {
  error.value = ''
  const body = { ...roomForm.value, maxGuests: num(roomForm.value.maxGuests), pricePerNight: num(roomForm.value.pricePerNight) }
  try {
    if (editingRoomId.value === '') await axios.post(ROOMS, body)
    else await axios.put(ROOMS + '/' + editingRoomId.value, body)
    cancelRoom()
    loadRooms()
  } catch (e) { showError(e) }
}

function editRoom(x) {
  roomForm.value = { ...x }
  editingRoomId.value = x.id
}

function cancelRoom() {
  roomForm.value = { roomType: '', facility: '', floor: '', maxGuests: '', pricePerNight: '' }
  editingRoomId.value = ''
}

// cascade = true also deletes the guests; false -> error 409 if there are guests
async function deleteRoom(id, cascade) {
  error.value = ''
  try {
    await axios.delete(ROOMS + '/' + id, { params: { cascade } })
    loadRooms()
    loadGuests()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Guest ----------
async function loadGuests() {
  try { guests.value = (await axios.get(GUESTS, { params: { roomId: filterRoomId.value } })).data } catch (e) { showError(e) }
}

async function saveGuest() {
  error.value = ''
  try {
    if (editingGuestId.value === '') await axios.post(GUESTS, guestForm.value)
    else await axios.put(GUESTS + '/' + editingGuestId.value, guestForm.value)
    cancelGuest()
    loadGuests()
  } catch (e) { showError(e) }
}

function editGuest(x) {
  guestForm.value = { name: x.name, phone: x.phone, roomId: x.roomId }
  editingGuestId.value = x.id
}

function cancelGuest() {
  guestForm.value = { name: '', phone: '', roomId: '' }
  editingGuestId.value = ''
}

async function deleteGuest(id) {
  error.value = ''
  try {
    await axios.delete(GUESTS + '/' + id)
    loadGuests()
  } catch (e) { showError(e) }
}

onMounted(() => { loadRooms(); loadGuests() })
</script>

<template>
  <h1>Room - Guest Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Rooms</h2>
  <RoomForm :form="roomForm" :editing="editingRoomId !== ''" @save="saveRoom" @cancel="cancelRoom" />
  <div class="box">
    <input v-model="keyword" placeholder="search roomType" />
    <button @click="showGet(ROOMS + '/search', { keyword })">Search</button>
    <input v-model="minpricePerNight" type="number" placeholder="min pricePerNight" />
    <button @click="showGet(ROOMS + '/filter', { minpricePerNight })">Filter</button>
    <button @click="showGet(ROOMS + '/sorted')">Sort by pricePerNight</button>
    <button @click="showGet(ROOMS + '/available')">Available</button>
    <button @click="showGet(ROOMS + '/stats')">Stats</button>
  </div>
  <RoomList :items="rooms" @edit="editRoom" @remove="deleteRoom"
    @related="(id) => showGet(ROOMS + '/' + id + '/guests')" @summary="(id) => showGet(ROOMS + '/' + id + '/summary')" />

  <h2>Guests</h2>
  <GuestForm :form="guestForm" :editing="editingGuestId !== ''" :parents="rooms" @save="saveGuest" @cancel="cancelGuest" />
  <div class="box">
    <select v-model="filterRoomId" @change="loadGuests">
      <option value="">All rooms</option>
      <option v-for="p in rooms" :key="p.id" :value="p.id">{{ p.roomType }}</option>
    </select>
    <button @click="showGet(GUESTS + '/count', { roomId: filterRoomId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(GUESTS + '/search', { keyword })">Search</button>
  </div>
  <GuestList :items="guests" :parents="rooms" @edit="editGuest" @remove="deleteGuest" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
