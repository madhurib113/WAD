package com.example.demo.service;

import com.example.demo.model.Room;
import com.example.demo.model.Guest;
import com.example.demo.repository.RoomRepository;
import com.example.demo.repository.GuestRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class RoomService {

    private final RoomRepository rooms;
    private final GuestRepository guests;

    public RoomService(RoomRepository rooms, GuestRepository guests) {
        this.rooms = rooms;
        this.guests = guests;
    }

    private void validate(Room x) {
        if (x.getRoomType() == null || x.getRoomType().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "roomType is required");
        if (x.getFacility() == null || x.getFacility().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "facility is required");
        if (x.getmaxGuests() == null || x.getmaxGuests() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "maxGuests is required and must be > 0");
        if (x.getpricePerNight() == null || x.getpricePerNight() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "pricePerNight is required and must be >= 0");
    }

    public Room getById(String id) {
        return rooms.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Room not found with id " + id));
    }

    // ---------- CRUD ----------
    public Room create(Room x) {
        validate(x);
        x.setId(null);
        return rooms.save(x);
    }

    public List<Room> getAll() { return rooms.findAll(); }

    public Room update(String id, Room in) {
        Room existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of guests already added
        long used = guests.countByRoomId(id);
        if (in.getmaxGuests() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "maxGuests cannot be less than the " + used + " existing guests");
        existing.setRoomType(in.getRoomType());
        existing.setFacility(in.getFacility());
        existing.setFloor(in.getFloor());
        existing.setMaxGuests(in.getMaxGuests());
        existing.setPricePerNight(in.getPricePerNight());
        return rooms.save(existing);
    }

    // a room that still has guests is NOT deleted unless cascade=true (then its guests are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = guests.countByRoomId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "room has " + used + " guests; delete them first or use cascade=true");
        guests.deleteByRoomId(id);
        rooms.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Room> search(String keyword) { return rooms.findByRoomTypeContainingIgnoreCase(keyword); }

    public List<Room> filterBypricePerNight(Double min) { return rooms.findBypricePerNightGreaterThanEqual(min); }

    public List<Room> sortedBypricePerNight() { return rooms.findAll(Sort.by(Sort.Direction.DESC, "pricePerNight")); }

    // only the rooms that still have a free place
    public List<Room> available() {
        List<Room> result = new ArrayList<>();
        for (Room x : rooms.findAll())
            if (guests.countByRoomId(x.getId()) < x.getmaxGuests()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Guest> guestsOf(String id) {
        getById(id);                              // 404 if the room is missing
        return guests.findByRoomId(id);
    }

    // count + calculations across the two collections for ONE room
    public Map<String, Object> summary(String id) {
        Room x = getById(id);
        long count = guests.countByRoomId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("roomId", x.getId());
        m.put("name", x.getRoomType());
        m.put("maxGuests", x.getmaxGuests());
        m.put("guestCount", count);
        m.put("placesLeft", x.getmaxGuests() - count);
        m.put("pricePerNight", x.getpricePerNight());
        m.put("totalAmount", count * x.getpricePerNight());
        return m;
    }

    // totals across ALL rooms
    public Map<String, Object> stats() {
        long totalGuest = 0;
        double totalAmount = 0;
        List<Room> all = rooms.findAll();
        for (Room x : all) {
            long c = guests.countByRoomId(x.getId());
            totalGuest += c;
            totalAmount += c * x.getpricePerNight();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalRooms", all.size());
        m.put("totalGuests", totalGuest);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
