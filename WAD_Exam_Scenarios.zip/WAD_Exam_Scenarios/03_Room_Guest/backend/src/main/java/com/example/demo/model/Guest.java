package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: guests
// roomId stores the _id of a Room as plain text. MongoDB has NO foreign keys,
// so GuestService checks that the room exists before saving.
@Document(collection = "guests")
public class Guest {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String roomId;    // required: reference to rooms._id

    public Guest() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getRoomId() { return roomId; }
    public void setRoomId(String roomId) { this.roomId = roomId; }
}
