package com.example.demo.repository;

import com.example.demo.model.Room;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RoomRepository extends MongoRepository<Room, String> {
    List<Room> findByRoomTypeContainingIgnoreCase(String keyword);        // search
    List<Room> findBypricePerNightGreaterThanEqual(Double min);                  // filter by number
}
