package com.example.demo.controller;

import com.example.demo.model.Room;
import com.example.demo.model.Guest;
import com.example.demo.service.RoomService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rooms")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class RoomController {

    private final RoomService service;

    public RoomController(RoomService service) { this.service = service; }

    @PostMapping                                   // POST   /api/rooms                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Room create(@RequestBody Room x) { return service.create(x); }

    @GetMapping                                    // GET    /api/rooms
    public List<Room> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/rooms/{id}            -> 200 / 404
    public Room getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/rooms/{id}            -> 200 / 400 / 404 / 409
    public Room update(@PathVariable String id, @RequestBody Room x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/rooms/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/rooms/search?keyword=ab
    public List<Room> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/rooms/filter?minpricePerNight=500
    public List<Room> filter(@RequestParam Double minpricePerNight) { return service.filterBypricePerNight(minpricePerNight); }

    @GetMapping("/sorted")                         // GET    /api/rooms/sorted          (pricePerNight high -> low)
    public List<Room> sorted() { return service.sortedBypricePerNight(); }

    @GetMapping("/available")                      // GET    /api/rooms/available       (still have free places)
    public List<Room> available() { return service.available(); }

    @GetMapping("/{id}/guests")                    // GET    /api/rooms/{id}/guests     (related records)
    public List<Guest> related(@PathVariable String id) { return service.guestsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/rooms/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/rooms/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
