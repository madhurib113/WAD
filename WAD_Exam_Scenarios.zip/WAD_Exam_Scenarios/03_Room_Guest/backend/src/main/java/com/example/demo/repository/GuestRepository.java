package com.example.demo.repository;

import com.example.demo.model.Guest;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface GuestRepository extends MongoRepository<Guest, String> {
    List<Guest> findByRoomId(String roomId);                    // filter by the related record
    long countByRoomId(String roomId);                          // count related records
    long deleteByRoomId(String roomId);                         // cascade delete
    List<Guest> findByNameContainingIgnoreCase(String keyword); // search
}
