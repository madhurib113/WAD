package com.example.demo.service;

import com.example.demo.model.Room;
import com.example.demo.model.Guest;
import com.example.demo.repository.RoomRepository;
import com.example.demo.repository.GuestRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class GuestService {

    private final GuestRepository guests;
    private final RoomRepository rooms;

    public GuestService(GuestRepository guests, RoomRepository rooms) {
        this.guests = guests;
        this.rooms = rooms;
    }

    private void validate(Guest x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getRoomId() == null || x.getRoomId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "roomId is required");
    }

    // The referenced room must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkRoom(String id, boolean checkLimit) {
        Room p = rooms.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "roomId does not exist: " + id));
        if (checkLimit && guests.countByRoomId(id) >= p.getmaxGuests())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "room is full");
    }

    public Guest getById(String id) {
        return guests.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Guest not found with id " + id));
    }

    public Guest create(Guest x) {
        validate(x);
        checkRoom(x.getRoomId(), true);
        x.setId(null);
        return guests.save(x);
    }

    // optional filter by related record: ?roomId=...
    public List<Guest> getAll(String roomId) {
        if (roomId == null || roomId.isBlank()) return guests.findAll();
        return guests.findByRoomId(roomId);
    }

    public List<Guest> search(String keyword) { return guests.findByNameContainingIgnoreCase(keyword); }

    public Guest update(String id, Guest in) {
        Guest existing = getById(id);
        validate(in);
        boolean moving = !in.getRoomId().equals(existing.getRoomId());
        checkRoom(in.getRoomId(), moving);       // free-place check only when moving to another room
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setRoomId(in.getRoomId());
        return guests.save(existing);
    }

    public void delete(String id) {
        getById(id);
        guests.deleteById(id);
    }

    public long count(String roomId) {
        if (roomId == null || roomId.isBlank()) return guests.count();
        return guests.countByRoomId(roomId);
    }
}
