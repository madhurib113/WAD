package com.example.demo.controller;

import com.example.demo.model.Guest;
import com.example.demo.service.GuestService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/guests")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class GuestController {

    private final GuestService service;

    public GuestController(GuestService service) { this.service = service; }

    @PostMapping                                   // POST   /api/guests   -> 201 / 400 (bad room) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Guest create(@RequestBody Guest x) { return service.create(x); }

    @GetMapping                                    // GET    /api/guests[?roomId=..]  (filter by related record)
    public List<Guest> getAll(@RequestParam(required = false) String roomId) { return service.getAll(roomId); }

    @GetMapping("/{id}")                           // GET    /api/guests/{id}   -> 200 / 404
    public Guest getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/guests/{id}
    public Guest update(@PathVariable String id, @RequestBody Guest x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/guests/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/guests/search?keyword=an
    public List<Guest> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/guests/count[?roomId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String roomId) {
        return Map.of("count", service.count(roomId));
    }
}
