# Room - Guest (2 collections: `rooms` and `guests`)

Database `room_db`. `guests.roomId` stores the `_id` of a room (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db room_db --collection rooms --jsonArray --file sample_data/rooms.json
mongoimport --db room_db --collection guests --jsonArray --file sample_data/guests.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Room**: roomType*, facility*, floor, maxGuests* (> 0), pricePerNight* (>= 0)    (* = required)
- **Guest**: name*, phone*, roomId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/rooms | create (Room) 201 / 400 |
| GET | /api/rooms , /api/rooms/{id} | all / one (404) |
| PUT | /api/rooms/{id} | update 200 / 400 / 404 / 409 (`maxGuests` below existing guests) |
| DELETE | /api/rooms/{id}?cascade=true | 204 / 404 / 409 (has guests and no cascade) |
| GET | /api/rooms/search?keyword= | search by roomType |
| GET | /api/rooms/filter?minpricePerNight= | pricePerNight >= value |
| GET | /api/rooms/sorted | sort by pricePerNight desc |
| GET | /api/rooms/available | rooms that still have free places |
| GET | /api/rooms/{id}/guests | related guests |
| GET | /api/rooms/{id}/summary | count, placesLeft, totalAmount = count x pricePerNight |
| GET | /api/rooms/stats | totals over all rooms |
| POST | /api/guests | create (Guest) 201 / 400 (bad roomId) / 409 (full) |
| GET | /api/guests?roomId= | all / filter by room |
| GET | /api/guests/{id} | one (404) |
| PUT | /api/guests/{id} | update (move to another room: free place checked) |
| DELETE | /api/guests/{id} | 204 / 404 |
| GET | /api/guests/search?keyword= | search by name |
| GET | /api/guests/count?roomId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on rooms and on guests.
3. Validation: missing field -> 400, maxGuests <= 0 -> 400, pricePerNight < 0 -> 400, unknown id -> 404.
4. Add a guest only if the room exists (400) and is not full (409).
5. Update room: maxGuests cannot be lower than current number of guests (409).
6. Delete room: blocked if it has guests (409); `cascade=true` deletes its guests too.
7. List guests of one room; count guests of one room.
8. Search by text, filter by number, sort descending, list available rooms.
9. Calculation: totalAmount for one room, and totals over all rooms (stats).
10. Move a guest from one room to another.
