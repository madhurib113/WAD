package com.example.demo.service;

import com.example.demo.model.Doctor;
import com.example.demo.model.Patient;
import com.example.demo.repository.DoctorRepository;
import com.example.demo.repository.PatientRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class DoctorService {

    private final DoctorRepository doctors;
    private final PatientRepository patients;

    public DoctorService(DoctorRepository doctors, PatientRepository patients) {
        this.doctors = doctors;
        this.patients = patients;
    }

    private void validate(Doctor x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getSpecialization() == null || x.getSpecialization().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "specialization is required");
        if (x.getmaxPatients() == null || x.getmaxPatients() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "maxPatients is required and must be > 0");
        if (x.getconsultationFee() == null || x.getconsultationFee() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "consultationFee is required and must be >= 0");
    }

    public Doctor getById(String id) {
        return doctors.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Doctor not found with id " + id));
    }

    // ---------- CRUD ----------
    public Doctor create(Doctor x) {
        validate(x);
        x.setId(null);
        return doctors.save(x);
    }

    public List<Doctor> getAll() { return doctors.findAll(); }

    public Doctor update(String id, Doctor in) {
        Doctor existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of patients already added
        long used = patients.countByDoctorId(id);
        if (in.getmaxPatients() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "maxPatients cannot be less than the " + used + " existing patients");
        existing.setName(in.getName());
        existing.setSpecialization(in.getSpecialization());
        existing.setHospital(in.getHospital());
        existing.setMaxPatients(in.getMaxPatients());
        existing.setConsultationFee(in.getConsultationFee());
        return doctors.save(existing);
    }

    // a doctor that still has patients is NOT deleted unless cascade=true (then its patients are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = patients.countByDoctorId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "doctor has " + used + " patients; delete them first or use cascade=true");
        patients.deleteByDoctorId(id);
        doctors.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Doctor> search(String keyword) { return doctors.findByNameContainingIgnoreCase(keyword); }

    public List<Doctor> filterByconsultationFee(Double min) { return doctors.findByconsultationFeeGreaterThanEqual(min); }

    public List<Doctor> sortedByconsultationFee() { return doctors.findAll(Sort.by(Sort.Direction.DESC, "consultationFee")); }

    // only the doctors that still have a free place
    public List<Doctor> available() {
        List<Doctor> result = new ArrayList<>();
        for (Doctor x : doctors.findAll())
            if (patients.countByDoctorId(x.getId()) < x.getmaxPatients()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Patient> patientsOf(String id) {
        getById(id);                              // 404 if the doctor is missing
        return patients.findByDoctorId(id);
    }

    // count + calculations across the two collections for ONE doctor
    public Map<String, Object> summary(String id) {
        Doctor x = getById(id);
        long count = patients.countByDoctorId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("doctorId", x.getId());
        m.put("name", x.getName());
        m.put("maxPatients", x.getmaxPatients());
        m.put("patientCount", count);
        m.put("placesLeft", x.getmaxPatients() - count);
        m.put("consultationFee", x.getconsultationFee());
        m.put("totalAmount", count * x.getconsultationFee());
        return m;
    }

    // totals across ALL doctors
    public Map<String, Object> stats() {
        long totalPatient = 0;
        double totalAmount = 0;
        List<Doctor> all = doctors.findAll();
        for (Doctor x : all) {
            long c = patients.countByDoctorId(x.getId());
            totalPatient += c;
            totalAmount += c * x.getconsultationFee();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalDoctors", all.size());
        m.put("totalPatients", totalPatient);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
