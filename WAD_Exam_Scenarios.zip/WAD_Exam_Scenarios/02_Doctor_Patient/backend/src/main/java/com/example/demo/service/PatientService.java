package com.example.demo.service;

import com.example.demo.model.Doctor;
import com.example.demo.model.Patient;
import com.example.demo.repository.DoctorRepository;
import com.example.demo.repository.PatientRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class PatientService {

    private final PatientRepository patients;
    private final DoctorRepository doctors;

    public PatientService(PatientRepository patients, DoctorRepository doctors) {
        this.patients = patients;
        this.doctors = doctors;
    }

    private void validate(Patient x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getDoctorId() == null || x.getDoctorId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "doctorId is required");
    }

    // The referenced doctor must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkDoctor(String id, boolean checkLimit) {
        Doctor p = doctors.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "doctorId does not exist: " + id));
        if (checkLimit && patients.countByDoctorId(id) >= p.getmaxPatients())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "doctor is full");
    }

    public Patient getById(String id) {
        return patients.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Patient not found with id " + id));
    }

    public Patient create(Patient x) {
        validate(x);
        checkDoctor(x.getDoctorId(), true);
        x.setId(null);
        return patients.save(x);
    }

    // optional filter by related record: ?doctorId=...
    public List<Patient> getAll(String doctorId) {
        if (doctorId == null || doctorId.isBlank()) return patients.findAll();
        return patients.findByDoctorId(doctorId);
    }

    public List<Patient> search(String keyword) { return patients.findByNameContainingIgnoreCase(keyword); }

    public Patient update(String id, Patient in) {
        Patient existing = getById(id);
        validate(in);
        boolean moving = !in.getDoctorId().equals(existing.getDoctorId());
        checkDoctor(in.getDoctorId(), moving);       // free-place check only when moving to another doctor
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setDoctorId(in.getDoctorId());
        return patients.save(existing);
    }

    public void delete(String id) {
        getById(id);
        patients.deleteById(id);
    }

    public long count(String doctorId) {
        if (doctorId == null || doctorId.isBlank()) return patients.count();
        return patients.countByDoctorId(doctorId);
    }
}
