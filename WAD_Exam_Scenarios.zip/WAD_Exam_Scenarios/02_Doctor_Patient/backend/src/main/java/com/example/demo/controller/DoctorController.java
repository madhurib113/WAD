package com.example.demo.controller;

import com.example.demo.model.Doctor;
import com.example.demo.model.Patient;
import com.example.demo.service.DoctorService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/doctors")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class DoctorController {

    private final DoctorService service;

    public DoctorController(DoctorService service) { this.service = service; }

    @PostMapping                                   // POST   /api/doctors                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Doctor create(@RequestBody Doctor x) { return service.create(x); }

    @GetMapping                                    // GET    /api/doctors
    public List<Doctor> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/doctors/{id}            -> 200 / 404
    public Doctor getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/doctors/{id}            -> 200 / 400 / 404 / 409
    public Doctor update(@PathVariable String id, @RequestBody Doctor x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/doctors/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/doctors/search?keyword=ab
    public List<Doctor> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/doctors/filter?minconsultationFee=500
    public List<Doctor> filter(@RequestParam Double minconsultationFee) { return service.filterByconsultationFee(minconsultationFee); }

    @GetMapping("/sorted")                         // GET    /api/doctors/sorted          (consultationFee high -> low)
    public List<Doctor> sorted() { return service.sortedByconsultationFee(); }

    @GetMapping("/available")                      // GET    /api/doctors/available       (still have free places)
    public List<Doctor> available() { return service.available(); }

    @GetMapping("/{id}/patients")                    // GET    /api/doctors/{id}/patients     (related records)
    public List<Patient> related(@PathVariable String id) { return service.patientsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/doctors/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/doctors/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
