package com.example.demo.controller;

import com.example.demo.model.Patient;
import com.example.demo.service.PatientService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patients")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class PatientController {

    private final PatientService service;

    public PatientController(PatientService service) { this.service = service; }

    @PostMapping                                   // POST   /api/patients   -> 201 / 400 (bad doctor) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Patient create(@RequestBody Patient x) { return service.create(x); }

    @GetMapping                                    // GET    /api/patients[?doctorId=..]  (filter by related record)
    public List<Patient> getAll(@RequestParam(required = false) String doctorId) { return service.getAll(doctorId); }

    @GetMapping("/{id}")                           // GET    /api/patients/{id}   -> 200 / 404
    public Patient getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/patients/{id}
    public Patient update(@PathVariable String id, @RequestBody Patient x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/patients/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/patients/search?keyword=an
    public List<Patient> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/patients/count[?doctorId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String doctorId) {
        return Map.of("count", service.count(doctorId));
    }
}
