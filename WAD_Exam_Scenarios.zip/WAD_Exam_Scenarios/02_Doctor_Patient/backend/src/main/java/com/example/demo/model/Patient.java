package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: patients
// doctorId stores the _id of a Doctor as plain text. MongoDB has NO foreign keys,
// so PatientService checks that the doctor exists before saving.
@Document(collection = "patients")
public class Patient {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String doctorId;    // required: reference to doctors._id

    public Patient() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getDoctorId() { return doctorId; }
    public void setDoctorId(String doctorId) { this.doctorId = doctorId; }
}
