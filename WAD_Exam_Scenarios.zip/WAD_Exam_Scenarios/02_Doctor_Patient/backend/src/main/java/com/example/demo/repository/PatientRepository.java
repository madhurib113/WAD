package com.example.demo.repository;

import com.example.demo.model.Patient;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PatientRepository extends MongoRepository<Patient, String> {
    List<Patient> findByDoctorId(String doctorId);                    // filter by the related record
    long countByDoctorId(String doctorId);                          // count related records
    long deleteByDoctorId(String doctorId);                         // cascade delete
    List<Patient> findByNameContainingIgnoreCase(String keyword); // search
}
