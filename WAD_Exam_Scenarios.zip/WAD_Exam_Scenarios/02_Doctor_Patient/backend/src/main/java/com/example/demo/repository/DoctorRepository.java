package com.example.demo.repository;

import com.example.demo.model.Doctor;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DoctorRepository extends MongoRepository<Doctor, String> {
    List<Doctor> findByNameContainingIgnoreCase(String keyword);        // search
    List<Doctor> findByconsultationFeeGreaterThanEqual(Double min);                  // filter by number
}
