<script setup>
// Form for the "ONE" side (Doctor). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'specialization', label: 'Specialization', type: 'text' },
  { key: 'hospital', label: 'Hospital', type: 'text' },
  { key: 'maxPatients', label: 'Max Patients', type: 'number' },
  { key: 'consultationFee', label: 'Consultation Fee', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Doctor</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
