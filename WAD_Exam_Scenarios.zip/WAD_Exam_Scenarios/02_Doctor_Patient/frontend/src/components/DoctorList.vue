<script setup>
// Table of Doctor records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'specialization', label: 'Specialization', type: 'text' },
  { key: 'hospital', label: 'Hospital', type: 'text' },
  { key: 'maxPatients', label: 'Max Patients', type: 'number' },
  { key: 'consultationFee', label: 'Consultation Fee', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Patients</button>
          <button @click="$emit('related', x.id)">Patients</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
