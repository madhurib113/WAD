<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import DoctorForm from './components/DoctorForm.vue'
import DoctorList from './components/DoctorList.vue'
import PatientForm from './components/PatientForm.vue'
import PatientList from './components/PatientList.vue'
import ResultBox from './components/ResultBox.vue'

const DOCTORS = 'http://localhost:8080/api/doctors'
const PATIENTS = 'http://localhost:8080/api/patients'

const doctors = ref([])
const patients = ref([])
const doctorForm = ref({ name: '', specialization: '', hospital: '', maxPatients: '', consultationFee: '' })
const editingDoctorId = ref('')
const patientForm = ref({ name: '', phone: '', doctorId: '' })
const editingPatientId = ref('')
const filterDoctorId = ref('')
const keyword = ref('')
const minconsultationFee = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Doctor ----------
async function loadDoctors() {
  try { doctors.value = (await axios.get(DOCTORS)).data } catch (e) { showError(e) }
}

async function saveDoctor() {
  error.value = ''
  const body = { ...doctorForm.value, maxPatients: num(doctorForm.value.maxPatients), consultationFee: num(doctorForm.value.consultationFee) }
  try {
    if (editingDoctorId.value === '') await axios.post(DOCTORS, body)
    else await axios.put(DOCTORS + '/' + editingDoctorId.value, body)
    cancelDoctor()
    loadDoctors()
  } catch (e) { showError(e) }
}

function editDoctor(x) {
  doctorForm.value = { ...x }
  editingDoctorId.value = x.id
}

function cancelDoctor() {
  doctorForm.value = { name: '', specialization: '', hospital: '', maxPatients: '', consultationFee: '' }
  editingDoctorId.value = ''
}

// cascade = true also deletes the patients; false -> error 409 if there are patients
async function deleteDoctor(id, cascade) {
  error.value = ''
  try {
    await axios.delete(DOCTORS + '/' + id, { params: { cascade } })
    loadDoctors()
    loadPatients()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Patient ----------
async function loadPatients() {
  try { patients.value = (await axios.get(PATIENTS, { params: { doctorId: filterDoctorId.value } })).data } catch (e) { showError(e) }
}

async function savePatient() {
  error.value = ''
  try {
    if (editingPatientId.value === '') await axios.post(PATIENTS, patientForm.value)
    else await axios.put(PATIENTS + '/' + editingPatientId.value, patientForm.value)
    cancelPatient()
    loadPatients()
  } catch (e) { showError(e) }
}

function editPatient(x) {
  patientForm.value = { name: x.name, phone: x.phone, doctorId: x.doctorId }
  editingPatientId.value = x.id
}

function cancelPatient() {
  patientForm.value = { name: '', phone: '', doctorId: '' }
  editingPatientId.value = ''
}

async function deletePatient(id) {
  error.value = ''
  try {
    await axios.delete(PATIENTS + '/' + id)
    loadPatients()
  } catch (e) { showError(e) }
}

onMounted(() => { loadDoctors(); loadPatients() })
</script>

<template>
  <h1>Doctor - Patient Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Doctors</h2>
  <DoctorForm :form="doctorForm" :editing="editingDoctorId !== ''" @save="saveDoctor" @cancel="cancelDoctor" />
  <div class="box">
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(DOCTORS + '/search', { keyword })">Search</button>
    <input v-model="minconsultationFee" type="number" placeholder="min consultationFee" />
    <button @click="showGet(DOCTORS + '/filter', { minconsultationFee })">Filter</button>
    <button @click="showGet(DOCTORS + '/sorted')">Sort by consultationFee</button>
    <button @click="showGet(DOCTORS + '/available')">Available</button>
    <button @click="showGet(DOCTORS + '/stats')">Stats</button>
  </div>
  <DoctorList :items="doctors" @edit="editDoctor" @remove="deleteDoctor"
    @related="(id) => showGet(DOCTORS + '/' + id + '/patients')" @summary="(id) => showGet(DOCTORS + '/' + id + '/summary')" />

  <h2>Patients</h2>
  <PatientForm :form="patientForm" :editing="editingPatientId !== ''" :parents="doctors" @save="savePatient" @cancel="cancelPatient" />
  <div class="box">
    <select v-model="filterDoctorId" @change="loadPatients">
      <option value="">All doctors</option>
      <option v-for="p in doctors" :key="p.id" :value="p.id">{{ p.name }}</option>
    </select>
    <button @click="showGet(PATIENTS + '/count', { doctorId: filterDoctorId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(PATIENTS + '/search', { keyword })">Search</button>
  </div>
  <PatientList :items="patients" :parents="doctors" @edit="editPatient" @remove="deletePatient" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
