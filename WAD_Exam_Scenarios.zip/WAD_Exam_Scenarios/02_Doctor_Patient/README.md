# Doctor - Patient (2 collections: `doctors` and `patients`)

Database `doctor_db`. `patients.doctorId` stores the `_id` of a doctor (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db doctor_db --collection doctors --jsonArray --file sample_data/doctors.json
mongoimport --db doctor_db --collection patients --jsonArray --file sample_data/patients.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Doctor**: name*, specialization*, hospital, maxPatients* (> 0), consultationFee* (>= 0)    (* = required)
- **Patient**: name*, phone*, doctorId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/doctors | create (Doctor) 201 / 400 |
| GET | /api/doctors , /api/doctors/{id} | all / one (404) |
| PUT | /api/doctors/{id} | update 200 / 400 / 404 / 409 (`maxPatients` below existing patients) |
| DELETE | /api/doctors/{id}?cascade=true | 204 / 404 / 409 (has patients and no cascade) |
| GET | /api/doctors/search?keyword= | search by name |
| GET | /api/doctors/filter?minconsultationFee= | consultationFee >= value |
| GET | /api/doctors/sorted | sort by consultationFee desc |
| GET | /api/doctors/available | doctors that still have free places |
| GET | /api/doctors/{id}/patients | related patients |
| GET | /api/doctors/{id}/summary | count, placesLeft, totalAmount = count x consultationFee |
| GET | /api/doctors/stats | totals over all doctors |
| POST | /api/patients | create (Patient) 201 / 400 (bad doctorId) / 409 (full) |
| GET | /api/patients?doctorId= | all / filter by doctor |
| GET | /api/patients/{id} | one (404) |
| PUT | /api/patients/{id} | update (move to another doctor: free place checked) |
| DELETE | /api/patients/{id} | 204 / 404 |
| GET | /api/patients/search?keyword= | search by name |
| GET | /api/patients/count?doctorId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on doctors and on patients.
3. Validation: missing field -> 400, maxPatients <= 0 -> 400, consultationFee < 0 -> 400, unknown id -> 404.
4. Add a patient only if the doctor exists (400) and is not full (409).
5. Update doctor: maxPatients cannot be lower than current number of patients (409).
6. Delete doctor: blocked if it has patients (409); `cascade=true` deletes its patients too.
7. List patients of one doctor; count patients of one doctor.
8. Search by text, filter by number, sort descending, list available doctors.
9. Calculation: totalAmount for one doctor, and totals over all doctors (stats).
10. Move a patient from one doctor to another.
