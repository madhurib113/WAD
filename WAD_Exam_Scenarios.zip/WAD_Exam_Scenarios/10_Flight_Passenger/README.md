# Flight - Passenger (2 collections: `flights` and `passengers`)

Database `flight_db`. `passengers.flightId` stores the `_id` of a flight (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db flight_db --collection flights --jsonArray --file sample_data/flights.json
mongoimport --db flight_db --collection passengers --jsonArray --file sample_data/passengers.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Flight**: flightNo*, source*, destination, seats* (> 0), ticketPrice* (>= 0)    (* = required)
- **Passenger**: name*, phone*, flightId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/flights | create (Flight) 201 / 400 |
| GET | /api/flights , /api/flights/{id} | all / one (404) |
| PUT | /api/flights/{id} | update 200 / 400 / 404 / 409 (`seats` below existing passengers) |
| DELETE | /api/flights/{id}?cascade=true | 204 / 404 / 409 (has passengers and no cascade) |
| GET | /api/flights/search?keyword= | search by flightNo |
| GET | /api/flights/filter?minticketPrice= | ticketPrice >= value |
| GET | /api/flights/sorted | sort by ticketPrice desc |
| GET | /api/flights/available | flights that still have free places |
| GET | /api/flights/{id}/passengers | related passengers |
| GET | /api/flights/{id}/summary | count, placesLeft, totalAmount = count x ticketPrice |
| GET | /api/flights/stats | totals over all flights |
| POST | /api/passengers | create (Passenger) 201 / 400 (bad flightId) / 409 (full) |
| GET | /api/passengers?flightId= | all / filter by flight |
| GET | /api/passengers/{id} | one (404) |
| PUT | /api/passengers/{id} | update (move to another flight: free place checked) |
| DELETE | /api/passengers/{id} | 204 / 404 |
| GET | /api/passengers/search?keyword= | search by name |
| GET | /api/passengers/count?flightId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on flights and on passengers.
3. Validation: missing field -> 400, seats <= 0 -> 400, ticketPrice < 0 -> 400, unknown id -> 404.
4. Add a passenger only if the flight exists (400) and is not full (409).
5. Update flight: seats cannot be lower than current number of passengers (409).
6. Delete flight: blocked if it has passengers (409); `cascade=true` deletes its passengers too.
7. List passengers of one flight; count passengers of one flight.
8. Search by text, filter by number, sort descending, list available flights.
9. Calculation: totalAmount for one flight, and totals over all flights (stats).
10. Move a passenger from one flight to another.
