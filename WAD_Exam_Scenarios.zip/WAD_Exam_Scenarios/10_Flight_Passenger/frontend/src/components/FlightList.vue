<script setup>
// Table of Flight records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'flightNo', label: 'Flight No', type: 'text' },
  { key: 'source', label: 'Source', type: 'text' },
  { key: 'destination', label: 'Destination', type: 'text' },
  { key: 'seats', label: 'Seats', type: 'number' },
  { key: 'ticketPrice', label: 'Ticket Price', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Passengers</button>
          <button @click="$emit('related', x.id)">Passengers</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
