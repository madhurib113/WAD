<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import FlightForm from './components/FlightForm.vue'
import FlightList from './components/FlightList.vue'
import PassengerForm from './components/PassengerForm.vue'
import PassengerList from './components/PassengerList.vue'
import ResultBox from './components/ResultBox.vue'

const FLIGHTS = 'http://localhost:8080/api/flights'
const PASSENGERS = 'http://localhost:8080/api/passengers'

const flights = ref([])
const passengers = ref([])
const flightForm = ref({ flightNo: '', source: '', destination: '', seats: '', ticketPrice: '' })
const editingFlightId = ref('')
const passengerForm = ref({ name: '', phone: '', flightId: '' })
const editingPassengerId = ref('')
const filterFlightId = ref('')
const keyword = ref('')
const minticketPrice = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Flight ----------
async function loadFlights() {
  try { flights.value = (await axios.get(FLIGHTS)).data } catch (e) { showError(e) }
}

async function saveFlight() {
  error.value = ''
  const body = { ...flightForm.value, seats: num(flightForm.value.seats), ticketPrice: num(flightForm.value.ticketPrice) }
  try {
    if (editingFlightId.value === '') await axios.post(FLIGHTS, body)
    else await axios.put(FLIGHTS + '/' + editingFlightId.value, body)
    cancelFlight()
    loadFlights()
  } catch (e) { showError(e) }
}

function editFlight(x) {
  flightForm.value = { ...x }
  editingFlightId.value = x.id
}

function cancelFlight() {
  flightForm.value = { flightNo: '', source: '', destination: '', seats: '', ticketPrice: '' }
  editingFlightId.value = ''
}

// cascade = true also deletes the passengers; false -> error 409 if there are passengers
async function deleteFlight(id, cascade) {
  error.value = ''
  try {
    await axios.delete(FLIGHTS + '/' + id, { params: { cascade } })
    loadFlights()
    loadPassengers()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Passenger ----------
async function loadPassengers() {
  try { passengers.value = (await axios.get(PASSENGERS, { params: { flightId: filterFlightId.value } })).data } catch (e) { showError(e) }
}

async function savePassenger() {
  error.value = ''
  try {
    if (editingPassengerId.value === '') await axios.post(PASSENGERS, passengerForm.value)
    else await axios.put(PASSENGERS + '/' + editingPassengerId.value, passengerForm.value)
    cancelPassenger()
    loadPassengers()
  } catch (e) { showError(e) }
}

function editPassenger(x) {
  passengerForm.value = { name: x.name, phone: x.phone, flightId: x.flightId }
  editingPassengerId.value = x.id
}

function cancelPassenger() {
  passengerForm.value = { name: '', phone: '', flightId: '' }
  editingPassengerId.value = ''
}

async function deletePassenger(id) {
  error.value = ''
  try {
    await axios.delete(PASSENGERS + '/' + id)
    loadPassengers()
  } catch (e) { showError(e) }
}

onMounted(() => { loadFlights(); loadPassengers() })
</script>

<template>
  <h1>Flight - Passenger Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Flights</h2>
  <FlightForm :form="flightForm" :editing="editingFlightId !== ''" @save="saveFlight" @cancel="cancelFlight" />
  <div class="box">
    <input v-model="keyword" placeholder="search flightNo" />
    <button @click="showGet(FLIGHTS + '/search', { keyword })">Search</button>
    <input v-model="minticketPrice" type="number" placeholder="min ticketPrice" />
    <button @click="showGet(FLIGHTS + '/filter', { minticketPrice })">Filter</button>
    <button @click="showGet(FLIGHTS + '/sorted')">Sort by ticketPrice</button>
    <button @click="showGet(FLIGHTS + '/available')">Available</button>
    <button @click="showGet(FLIGHTS + '/stats')">Stats</button>
  </div>
  <FlightList :items="flights" @edit="editFlight" @remove="deleteFlight"
    @related="(id) => showGet(FLIGHTS + '/' + id + '/passengers')" @summary="(id) => showGet(FLIGHTS + '/' + id + '/summary')" />

  <h2>Passengers</h2>
  <PassengerForm :form="passengerForm" :editing="editingPassengerId !== ''" :parents="flights" @save="savePassenger" @cancel="cancelPassenger" />
  <div class="box">
    <select v-model="filterFlightId" @change="loadPassengers">
      <option value="">All flights</option>
      <option v-for="p in flights" :key="p.id" :value="p.id">{{ p.flightNo }}</option>
    </select>
    <button @click="showGet(PASSENGERS + '/count', { flightId: filterFlightId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(PASSENGERS + '/search', { keyword })">Search</button>
  </div>
  <PassengerList :items="passengers" :parents="flights" @edit="editPassenger" @remove="deletePassenger" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
