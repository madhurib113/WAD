package com.example.demo.service;

import com.example.demo.model.Flight;
import com.example.demo.model.Passenger;
import com.example.demo.repository.FlightRepository;
import com.example.demo.repository.PassengerRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class FlightService {

    private final FlightRepository flights;
    private final PassengerRepository passengers;

    public FlightService(FlightRepository flights, PassengerRepository passengers) {
        this.flights = flights;
        this.passengers = passengers;
    }

    private void validate(Flight x) {
        if (x.getFlightNo() == null || x.getFlightNo().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "flightNo is required");
        if (x.getSource() == null || x.getSource().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "source is required");
        if (x.getseats() == null || x.getseats() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "seats is required and must be > 0");
        if (x.getticketPrice() == null || x.getticketPrice() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "ticketPrice is required and must be >= 0");
    }

    public Flight getById(String id) {
        return flights.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Flight not found with id " + id));
    }

    // ---------- CRUD ----------
    public Flight create(Flight x) {
        validate(x);
        x.setId(null);
        return flights.save(x);
    }

    public List<Flight> getAll() { return flights.findAll(); }

    public Flight update(String id, Flight in) {
        Flight existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of passengers already added
        long used = passengers.countByFlightId(id);
        if (in.getseats() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "seats cannot be less than the " + used + " existing passengers");
        existing.setFlightNo(in.getFlightNo());
        existing.setSource(in.getSource());
        existing.setDestination(in.getDestination());
        existing.setSeats(in.getSeats());
        existing.setTicketPrice(in.getTicketPrice());
        return flights.save(existing);
    }

    // a flight that still has passengers is NOT deleted unless cascade=true (then its passengers are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = passengers.countByFlightId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "flight has " + used + " passengers; delete them first or use cascade=true");
        passengers.deleteByFlightId(id);
        flights.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Flight> search(String keyword) { return flights.findByFlightNoContainingIgnoreCase(keyword); }

    public List<Flight> filterByticketPrice(Double min) { return flights.findByticketPriceGreaterThanEqual(min); }

    public List<Flight> sortedByticketPrice() { return flights.findAll(Sort.by(Sort.Direction.DESC, "ticketPrice")); }

    // only the flights that still have a free place
    public List<Flight> available() {
        List<Flight> result = new ArrayList<>();
        for (Flight x : flights.findAll())
            if (passengers.countByFlightId(x.getId()) < x.getseats()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Passenger> passengersOf(String id) {
        getById(id);                              // 404 if the flight is missing
        return passengers.findByFlightId(id);
    }

    // count + calculations across the two collections for ONE flight
    public Map<String, Object> summary(String id) {
        Flight x = getById(id);
        long count = passengers.countByFlightId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("flightId", x.getId());
        m.put("name", x.getFlightNo());
        m.put("seats", x.getseats());
        m.put("passengerCount", count);
        m.put("placesLeft", x.getseats() - count);
        m.put("ticketPrice", x.getticketPrice());
        m.put("totalAmount", count * x.getticketPrice());
        return m;
    }

    // totals across ALL flights
    public Map<String, Object> stats() {
        long totalPassenger = 0;
        double totalAmount = 0;
        List<Flight> all = flights.findAll();
        for (Flight x : all) {
            long c = passengers.countByFlightId(x.getId());
            totalPassenger += c;
            totalAmount += c * x.getticketPrice();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalFlights", all.size());
        m.put("totalPassengers", totalPassenger);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
