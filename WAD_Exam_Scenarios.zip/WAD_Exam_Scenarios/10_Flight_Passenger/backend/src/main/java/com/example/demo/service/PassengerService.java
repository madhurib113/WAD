package com.example.demo.service;

import com.example.demo.model.Flight;
import com.example.demo.model.Passenger;
import com.example.demo.repository.FlightRepository;
import com.example.demo.repository.PassengerRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class PassengerService {

    private final PassengerRepository passengers;
    private final FlightRepository flights;

    public PassengerService(PassengerRepository passengers, FlightRepository flights) {
        this.passengers = passengers;
        this.flights = flights;
    }

    private void validate(Passenger x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getFlightId() == null || x.getFlightId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "flightId is required");
    }

    // The referenced flight must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkFlight(String id, boolean checkLimit) {
        Flight p = flights.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "flightId does not exist: " + id));
        if (checkLimit && passengers.countByFlightId(id) >= p.getseats())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "flight is full");
    }

    public Passenger getById(String id) {
        return passengers.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Passenger not found with id " + id));
    }

    public Passenger create(Passenger x) {
        validate(x);
        checkFlight(x.getFlightId(), true);
        x.setId(null);
        return passengers.save(x);
    }

    // optional filter by related record: ?flightId=...
    public List<Passenger> getAll(String flightId) {
        if (flightId == null || flightId.isBlank()) return passengers.findAll();
        return passengers.findByFlightId(flightId);
    }

    public List<Passenger> search(String keyword) { return passengers.findByNameContainingIgnoreCase(keyword); }

    public Passenger update(String id, Passenger in) {
        Passenger existing = getById(id);
        validate(in);
        boolean moving = !in.getFlightId().equals(existing.getFlightId());
        checkFlight(in.getFlightId(), moving);       // free-place check only when moving to another flight
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setFlightId(in.getFlightId());
        return passengers.save(existing);
    }

    public void delete(String id) {
        getById(id);
        passengers.deleteById(id);
    }

    public long count(String flightId) {
        if (flightId == null || flightId.isBlank()) return passengers.count();
        return passengers.countByFlightId(flightId);
    }
}
