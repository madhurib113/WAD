package com.example.demo.repository;

import com.example.demo.model.Flight;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FlightRepository extends MongoRepository<Flight, String> {
    List<Flight> findByFlightNoContainingIgnoreCase(String keyword);        // search
    List<Flight> findByticketPriceGreaterThanEqual(Double min);                  // filter by number
}
