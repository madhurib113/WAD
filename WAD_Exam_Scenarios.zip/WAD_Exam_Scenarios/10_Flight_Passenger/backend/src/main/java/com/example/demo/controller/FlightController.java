package com.example.demo.controller;

import com.example.demo.model.Flight;
import com.example.demo.model.Passenger;
import com.example.demo.service.FlightService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/flights")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class FlightController {

    private final FlightService service;

    public FlightController(FlightService service) { this.service = service; }

    @PostMapping                                   // POST   /api/flights                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Flight create(@RequestBody Flight x) { return service.create(x); }

    @GetMapping                                    // GET    /api/flights
    public List<Flight> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/flights/{id}            -> 200 / 404
    public Flight getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/flights/{id}            -> 200 / 400 / 404 / 409
    public Flight update(@PathVariable String id, @RequestBody Flight x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/flights/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/flights/search?keyword=ab
    public List<Flight> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/flights/filter?minticketPrice=500
    public List<Flight> filter(@RequestParam Double minticketPrice) { return service.filterByticketPrice(minticketPrice); }

    @GetMapping("/sorted")                         // GET    /api/flights/sorted          (ticketPrice high -> low)
    public List<Flight> sorted() { return service.sortedByticketPrice(); }

    @GetMapping("/available")                      // GET    /api/flights/available       (still have free places)
    public List<Flight> available() { return service.available(); }

    @GetMapping("/{id}/passengers")                    // GET    /api/flights/{id}/passengers     (related records)
    public List<Passenger> related(@PathVariable String id) { return service.passengersOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/flights/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/flights/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
