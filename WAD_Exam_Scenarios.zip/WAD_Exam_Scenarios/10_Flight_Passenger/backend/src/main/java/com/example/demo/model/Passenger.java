package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: passengers
// flightId stores the _id of a Flight as plain text. MongoDB has NO foreign keys,
// so PassengerService checks that the flight exists before saving.
@Document(collection = "passengers")
public class Passenger {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String flightId;    // required: reference to flights._id

    public Passenger() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getFlightId() { return flightId; }
    public void setFlightId(String flightId) { this.flightId = flightId; }
}
