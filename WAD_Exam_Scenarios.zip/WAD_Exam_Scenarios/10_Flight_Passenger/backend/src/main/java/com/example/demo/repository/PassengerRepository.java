package com.example.demo.repository;

import com.example.demo.model.Passenger;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PassengerRepository extends MongoRepository<Passenger, String> {
    List<Passenger> findByFlightId(String flightId);                    // filter by the related record
    long countByFlightId(String flightId);                          // count related records
    long deleteByFlightId(String flightId);                         // cascade delete
    List<Passenger> findByNameContainingIgnoreCase(String keyword); // search
}
