package com.example.demo.repository;

import com.example.demo.model.Developer;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DeveloperRepository extends MongoRepository<Developer, String> {
    List<Developer> findByProjectId(String projectId);                    // filter by the related record
    long countByProjectId(String projectId);                          // count related records
    long deleteByProjectId(String projectId);                         // cascade delete
    List<Developer> findByNameContainingIgnoreCase(String keyword); // search
}
