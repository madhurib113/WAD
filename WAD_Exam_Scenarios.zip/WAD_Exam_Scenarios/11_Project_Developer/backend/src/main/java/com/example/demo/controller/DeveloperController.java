package com.example.demo.controller;

import com.example.demo.model.Developer;
import com.example.demo.service.DeveloperService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/developers")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class DeveloperController {

    private final DeveloperService service;

    public DeveloperController(DeveloperService service) { this.service = service; }

    @PostMapping                                   // POST   /api/developers   -> 201 / 400 (bad project) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Developer create(@RequestBody Developer x) { return service.create(x); }

    @GetMapping                                    // GET    /api/developers[?projectId=..]  (filter by related record)
    public List<Developer> getAll(@RequestParam(required = false) String projectId) { return service.getAll(projectId); }

    @GetMapping("/{id}")                           // GET    /api/developers/{id}   -> 200 / 404
    public Developer getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/developers/{id}
    public Developer update(@PathVariable String id, @RequestBody Developer x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/developers/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/developers/search?keyword=an
    public List<Developer> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/developers/count[?projectId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String projectId) {
        return Map.of("count", service.count(projectId));
    }
}
