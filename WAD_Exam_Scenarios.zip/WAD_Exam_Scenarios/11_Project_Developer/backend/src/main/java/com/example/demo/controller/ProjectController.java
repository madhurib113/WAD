package com.example.demo.controller;

import com.example.demo.model.Project;
import com.example.demo.model.Developer;
import com.example.demo.service.ProjectService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/projects")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class ProjectController {

    private final ProjectService service;

    public ProjectController(ProjectService service) { this.service = service; }

    @PostMapping                                   // POST   /api/projects                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Project create(@RequestBody Project x) { return service.create(x); }

    @GetMapping                                    // GET    /api/projects
    public List<Project> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/projects/{id}            -> 200 / 404
    public Project getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/projects/{id}            -> 200 / 400 / 404 / 409
    public Project update(@PathVariable String id, @RequestBody Project x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/projects/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/projects/search?keyword=ab
    public List<Project> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/projects/filter?minratePerDay=500
    public List<Project> filter(@RequestParam Double minratePerDay) { return service.filterByratePerDay(minratePerDay); }

    @GetMapping("/sorted")                         // GET    /api/projects/sorted          (ratePerDay high -> low)
    public List<Project> sorted() { return service.sortedByratePerDay(); }

    @GetMapping("/available")                      // GET    /api/projects/available       (still have free places)
    public List<Project> available() { return service.available(); }

    @GetMapping("/{id}/developers")                    // GET    /api/projects/{id}/developers     (related records)
    public List<Developer> related(@PathVariable String id) { return service.developersOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/projects/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/projects/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
