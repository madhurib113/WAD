package com.example.demo.service;

import com.example.demo.model.Project;
import com.example.demo.model.Developer;
import com.example.demo.repository.ProjectRepository;
import com.example.demo.repository.DeveloperRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class DeveloperService {

    private final DeveloperRepository developers;
    private final ProjectRepository projects;

    public DeveloperService(DeveloperRepository developers, ProjectRepository projects) {
        this.developers = developers;
        this.projects = projects;
    }

    private void validate(Developer x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getEmail() == null || x.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (x.getProjectId() == null || x.getProjectId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "projectId is required");
    }

    // The referenced project must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkProject(String id, boolean checkLimit) {
        Project p = projects.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "projectId does not exist: " + id));
        if (checkLimit && developers.countByProjectId(id) >= p.getteamSize())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "project is full");
    }

    public Developer getById(String id) {
        return developers.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Developer not found with id " + id));
    }

    public Developer create(Developer x) {
        validate(x);
        checkProject(x.getProjectId(), true);
        x.setId(null);
        return developers.save(x);
    }

    // optional filter by related record: ?projectId=...
    public List<Developer> getAll(String projectId) {
        if (projectId == null || projectId.isBlank()) return developers.findAll();
        return developers.findByProjectId(projectId);
    }

    public List<Developer> search(String keyword) { return developers.findByNameContainingIgnoreCase(keyword); }

    public Developer update(String id, Developer in) {
        Developer existing = getById(id);
        validate(in);
        boolean moving = !in.getProjectId().equals(existing.getProjectId());
        checkProject(in.getProjectId(), moving);       // free-place check only when moving to another project
        existing.setName(in.getName());
        existing.setEmail(in.getEmail());
        existing.setProjectId(in.getProjectId());
        return developers.save(existing);
    }

    public void delete(String id) {
        getById(id);
        developers.deleteById(id);
    }

    public long count(String projectId) {
        if (projectId == null || projectId.isBlank()) return developers.count();
        return developers.countByProjectId(projectId);
    }
}
