package com.example.demo.service;

import com.example.demo.model.Project;
import com.example.demo.model.Developer;
import com.example.demo.repository.ProjectRepository;
import com.example.demo.repository.DeveloperRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ProjectService {

    private final ProjectRepository projects;
    private final DeveloperRepository developers;

    public ProjectService(ProjectRepository projects, DeveloperRepository developers) {
        this.projects = projects;
        this.developers = developers;
    }

    private void validate(Project x) {
        if (x.getTitle() == null || x.getTitle().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "title is required");
        if (x.getManager() == null || x.getManager().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "manager is required");
        if (x.getteamSize() == null || x.getteamSize() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "teamSize is required and must be > 0");
        if (x.getratePerDay() == null || x.getratePerDay() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "ratePerDay is required and must be >= 0");
    }

    public Project getById(String id) {
        return projects.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Project not found with id " + id));
    }

    // ---------- CRUD ----------
    public Project create(Project x) {
        validate(x);
        x.setId(null);
        return projects.save(x);
    }

    public List<Project> getAll() { return projects.findAll(); }

    public Project update(String id, Project in) {
        Project existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of developers already added
        long used = developers.countByProjectId(id);
        if (in.getteamSize() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "teamSize cannot be less than the " + used + " existing developers");
        existing.setTitle(in.getTitle());
        existing.setManager(in.getManager());
        existing.setTechStack(in.getTechStack());
        existing.setTeamSize(in.getTeamSize());
        existing.setRatePerDay(in.getRatePerDay());
        return projects.save(existing);
    }

    // a project that still has developers is NOT deleted unless cascade=true (then its developers are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = developers.countByProjectId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "project has " + used + " developers; delete them first or use cascade=true");
        developers.deleteByProjectId(id);
        projects.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Project> search(String keyword) { return projects.findByTitleContainingIgnoreCase(keyword); }

    public List<Project> filterByratePerDay(Double min) { return projects.findByratePerDayGreaterThanEqual(min); }

    public List<Project> sortedByratePerDay() { return projects.findAll(Sort.by(Sort.Direction.DESC, "ratePerDay")); }

    // only the projects that still have a free place
    public List<Project> available() {
        List<Project> result = new ArrayList<>();
        for (Project x : projects.findAll())
            if (developers.countByProjectId(x.getId()) < x.getteamSize()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Developer> developersOf(String id) {
        getById(id);                              // 404 if the project is missing
        return developers.findByProjectId(id);
    }

    // count + calculations across the two collections for ONE project
    public Map<String, Object> summary(String id) {
        Project x = getById(id);
        long count = developers.countByProjectId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("projectId", x.getId());
        m.put("name", x.getTitle());
        m.put("teamSize", x.getteamSize());
        m.put("developerCount", count);
        m.put("placesLeft", x.getteamSize() - count);
        m.put("ratePerDay", x.getratePerDay());
        m.put("totalAmount", count * x.getratePerDay());
        return m;
    }

    // totals across ALL projects
    public Map<String, Object> stats() {
        long totalDeveloper = 0;
        double totalAmount = 0;
        List<Project> all = projects.findAll();
        for (Project x : all) {
            long c = developers.countByProjectId(x.getId());
            totalDeveloper += c;
            totalAmount += c * x.getratePerDay();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalProjects", all.size());
        m.put("totalDevelopers", totalDeveloper);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
