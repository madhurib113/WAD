package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: developers
// projectId stores the _id of a Project as plain text. MongoDB has NO foreign keys,
// so DeveloperService checks that the project exists before saving.
@Document(collection = "developers")
public class Developer {

    @Id
    private String id;

    private String name;     // required
    private String email;     // required
    private String projectId;    // required: reference to projects._id

    public Developer() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getProjectId() { return projectId; }
    public void setProjectId(String projectId) { this.projectId = projectId; }
}
