package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: projects
@Document(collection = "projects")
public class Project {

    @Id
    private String id;

    private String title;
    private String manager;
    private String techStack;
    private Integer teamSize;
    private Double ratePerDay;

    public Project() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getManager() { return manager; }
    public void setManager(String manager) { this.manager = manager; }
    public String getTechStack() { return techStack; }
    public void setTechStack(String techStack) { this.techStack = techStack; }
    public Integer getTeamSize() { return teamSize; }
    public void setTeamSize(Integer teamSize) { this.teamSize = teamSize; }
    public Double getRatePerDay() { return ratePerDay; }
    public void setRatePerDay(Double ratePerDay) { this.ratePerDay = ratePerDay; }
}
