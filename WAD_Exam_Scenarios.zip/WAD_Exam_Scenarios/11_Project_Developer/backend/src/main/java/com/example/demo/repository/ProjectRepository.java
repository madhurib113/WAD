package com.example.demo.repository;

import com.example.demo.model.Project;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProjectRepository extends MongoRepository<Project, String> {
    List<Project> findByTitleContainingIgnoreCase(String keyword);        // search
    List<Project> findByratePerDayGreaterThanEqual(Double min);                  // filter by number
}
