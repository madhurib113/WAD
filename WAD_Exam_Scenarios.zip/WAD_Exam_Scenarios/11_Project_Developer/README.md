# Project - Developer (2 collections: `projects` and `developers`)

Database `project_db`. `developers.projectId` stores the `_id` of a project (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db project_db --collection projects --jsonArray --file sample_data/projects.json
mongoimport --db project_db --collection developers --jsonArray --file sample_data/developers.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Project**: title*, manager*, techStack, teamSize* (> 0), ratePerDay* (>= 0)    (* = required)
- **Developer**: name*, email*, projectId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/projects | create (Project) 201 / 400 |
| GET | /api/projects , /api/projects/{id} | all / one (404) |
| PUT | /api/projects/{id} | update 200 / 400 / 404 / 409 (`teamSize` below existing developers) |
| DELETE | /api/projects/{id}?cascade=true | 204 / 404 / 409 (has developers and no cascade) |
| GET | /api/projects/search?keyword= | search by title |
| GET | /api/projects/filter?minratePerDay= | ratePerDay >= value |
| GET | /api/projects/sorted | sort by ratePerDay desc |
| GET | /api/projects/available | projects that still have free places |
| GET | /api/projects/{id}/developers | related developers |
| GET | /api/projects/{id}/summary | count, placesLeft, totalAmount = count x ratePerDay |
| GET | /api/projects/stats | totals over all projects |
| POST | /api/developers | create (Developer) 201 / 400 (bad projectId) / 409 (full) |
| GET | /api/developers?projectId= | all / filter by project |
| GET | /api/developers/{id} | one (404) |
| PUT | /api/developers/{id} | update (move to another project: free place checked) |
| DELETE | /api/developers/{id} | 204 / 404 |
| GET | /api/developers/search?keyword= | search by name |
| GET | /api/developers/count?projectId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on projects and on developers.
3. Validation: missing field -> 400, teamSize <= 0 -> 400, ratePerDay < 0 -> 400, unknown id -> 404.
4. Add a developer only if the project exists (400) and is not full (409).
5. Update project: teamSize cannot be lower than current number of developers (409).
6. Delete project: blocked if it has developers (409); `cascade=true` deletes its developers too.
7. List developers of one project; count developers of one project.
8. Search by text, filter by number, sort descending, list available projects.
9. Calculation: totalAmount for one project, and totals over all projects (stats).
10. Move a developer from one project to another.
