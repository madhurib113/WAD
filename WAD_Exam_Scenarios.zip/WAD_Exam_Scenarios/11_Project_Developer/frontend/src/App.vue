<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import ProjectForm from './components/ProjectForm.vue'
import ProjectList from './components/ProjectList.vue'
import DeveloperForm from './components/DeveloperForm.vue'
import DeveloperList from './components/DeveloperList.vue'
import ResultBox from './components/ResultBox.vue'

const PROJECTS = 'http://localhost:8080/api/projects'
const DEVELOPERS = 'http://localhost:8080/api/developers'

const projects = ref([])
const developers = ref([])
const projectForm = ref({ title: '', manager: '', techStack: '', teamSize: '', ratePerDay: '' })
const editingProjectId = ref('')
const developerForm = ref({ name: '', email: '', projectId: '' })
const editingDeveloperId = ref('')
const filterProjectId = ref('')
const keyword = ref('')
const minratePerDay = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Project ----------
async function loadProjects() {
  try { projects.value = (await axios.get(PROJECTS)).data } catch (e) { showError(e) }
}

async function saveProject() {
  error.value = ''
  const body = { ...projectForm.value, teamSize: num(projectForm.value.teamSize), ratePerDay: num(projectForm.value.ratePerDay) }
  try {
    if (editingProjectId.value === '') await axios.post(PROJECTS, body)
    else await axios.put(PROJECTS + '/' + editingProjectId.value, body)
    cancelProject()
    loadProjects()
  } catch (e) { showError(e) }
}

function editProject(x) {
  projectForm.value = { ...x }
  editingProjectId.value = x.id
}

function cancelProject() {
  projectForm.value = { title: '', manager: '', techStack: '', teamSize: '', ratePerDay: '' }
  editingProjectId.value = ''
}

// cascade = true also deletes the developers; false -> error 409 if there are developers
async function deleteProject(id, cascade) {
  error.value = ''
  try {
    await axios.delete(PROJECTS + '/' + id, { params: { cascade } })
    loadProjects()
    loadDevelopers()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Developer ----------
async function loadDevelopers() {
  try { developers.value = (await axios.get(DEVELOPERS, { params: { projectId: filterProjectId.value } })).data } catch (e) { showError(e) }
}

async function saveDeveloper() {
  error.value = ''
  try {
    if (editingDeveloperId.value === '') await axios.post(DEVELOPERS, developerForm.value)
    else await axios.put(DEVELOPERS + '/' + editingDeveloperId.value, developerForm.value)
    cancelDeveloper()
    loadDevelopers()
  } catch (e) { showError(e) }
}

function editDeveloper(x) {
  developerForm.value = { name: x.name, email: x.email, projectId: x.projectId }
  editingDeveloperId.value = x.id
}

function cancelDeveloper() {
  developerForm.value = { name: '', email: '', projectId: '' }
  editingDeveloperId.value = ''
}

async function deleteDeveloper(id) {
  error.value = ''
  try {
    await axios.delete(DEVELOPERS + '/' + id)
    loadDevelopers()
  } catch (e) { showError(e) }
}

onMounted(() => { loadProjects(); loadDevelopers() })
</script>

<template>
  <h1>Project - Developer Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Projects</h2>
  <ProjectForm :form="projectForm" :editing="editingProjectId !== ''" @save="saveProject" @cancel="cancelProject" />
  <div class="box">
    <input v-model="keyword" placeholder="search title" />
    <button @click="showGet(PROJECTS + '/search', { keyword })">Search</button>
    <input v-model="minratePerDay" type="number" placeholder="min ratePerDay" />
    <button @click="showGet(PROJECTS + '/filter', { minratePerDay })">Filter</button>
    <button @click="showGet(PROJECTS + '/sorted')">Sort by ratePerDay</button>
    <button @click="showGet(PROJECTS + '/available')">Available</button>
    <button @click="showGet(PROJECTS + '/stats')">Stats</button>
  </div>
  <ProjectList :items="projects" @edit="editProject" @remove="deleteProject"
    @related="(id) => showGet(PROJECTS + '/' + id + '/developers')" @summary="(id) => showGet(PROJECTS + '/' + id + '/summary')" />

  <h2>Developers</h2>
  <DeveloperForm :form="developerForm" :editing="editingDeveloperId !== ''" :parents="projects" @save="saveDeveloper" @cancel="cancelDeveloper" />
  <div class="box">
    <select v-model="filterProjectId" @change="loadDevelopers">
      <option value="">All projects</option>
      <option v-for="p in projects" :key="p.id" :value="p.id">{{ p.title }}</option>
    </select>
    <button @click="showGet(DEVELOPERS + '/count', { projectId: filterProjectId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(DEVELOPERS + '/search', { keyword })">Search</button>
  </div>
  <DeveloperList :items="developers" :parents="projects" @edit="editDeveloper" @remove="deleteDeveloper" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
