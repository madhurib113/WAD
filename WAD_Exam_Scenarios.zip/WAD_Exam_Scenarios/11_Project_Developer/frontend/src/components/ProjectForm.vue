<script setup>
// Form for the "ONE" side (Project). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'title', label: 'Title', type: 'text' },
  { key: 'manager', label: 'Manager', type: 'text' },
  { key: 'techStack', label: 'Tech Stack', type: 'text' },
  { key: 'teamSize', label: 'Team Size', type: 'number' },
  { key: 'ratePerDay', label: 'Rate Per Day', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Project</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
