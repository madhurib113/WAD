<script setup>
// Table of Project records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'title', label: 'Title', type: 'text' },
  { key: 'manager', label: 'Manager', type: 'text' },
  { key: 'techStack', label: 'Tech Stack', type: 'text' },
  { key: 'teamSize', label: 'Team Size', type: 'number' },
  { key: 'ratePerDay', label: 'Rate Per Day', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Developers</button>
          <button @click="$emit('related', x.id)">Developers</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
