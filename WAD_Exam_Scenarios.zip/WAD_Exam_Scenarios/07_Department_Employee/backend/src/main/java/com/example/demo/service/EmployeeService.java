package com.example.demo.service;

import com.example.demo.model.Department;
import com.example.demo.model.Employee;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.EmployeeRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class EmployeeService {

    private final EmployeeRepository employees;
    private final DepartmentRepository departments;

    public EmployeeService(EmployeeRepository employees, DepartmentRepository departments) {
        this.employees = employees;
        this.departments = departments;
    }

    private void validate(Employee x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getEmail() == null || x.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (x.getDepartmentId() == null || x.getDepartmentId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "departmentId is required");
    }

    // The referenced department must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkDepartment(String id, boolean checkLimit) {
        Department p = departments.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "departmentId does not exist: " + id));
        if (checkLimit && employees.countByDepartmentId(id) >= p.getmaxStaff())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "department is full");
    }

    public Employee getById(String id) {
        return employees.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Employee not found with id " + id));
    }

    public Employee create(Employee x) {
        validate(x);
        checkDepartment(x.getDepartmentId(), true);
        x.setId(null);
        return employees.save(x);
    }

    // optional filter by related record: ?departmentId=...
    public List<Employee> getAll(String departmentId) {
        if (departmentId == null || departmentId.isBlank()) return employees.findAll();
        return employees.findByDepartmentId(departmentId);
    }

    public List<Employee> search(String keyword) { return employees.findByNameContainingIgnoreCase(keyword); }

    public Employee update(String id, Employee in) {
        Employee existing = getById(id);
        validate(in);
        boolean moving = !in.getDepartmentId().equals(existing.getDepartmentId());
        checkDepartment(in.getDepartmentId(), moving);       // free-place check only when moving to another department
        existing.setName(in.getName());
        existing.setEmail(in.getEmail());
        existing.setDepartmentId(in.getDepartmentId());
        return employees.save(existing);
    }

    public void delete(String id) {
        getById(id);
        employees.deleteById(id);
    }

    public long count(String departmentId) {
        if (departmentId == null || departmentId.isBlank()) return employees.count();
        return employees.countByDepartmentId(departmentId);
    }
}
