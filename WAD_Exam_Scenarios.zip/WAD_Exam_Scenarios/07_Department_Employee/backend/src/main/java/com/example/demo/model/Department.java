package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: departments
@Document(collection = "departments")
public class Department {

    @Id
    private String id;

    private String deptName;
    private String head;
    private String location;
    private Integer maxStaff;
    private Double salary;

    public Department() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getDeptName() { return deptName; }
    public void setDeptName(String deptName) { this.deptName = deptName; }
    public String getHead() { return head; }
    public void setHead(String head) { this.head = head; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Integer getMaxStaff() { return maxStaff; }
    public void setMaxStaff(Integer maxStaff) { this.maxStaff = maxStaff; }
    public Double getSalary() { return salary; }
    public void setSalary(Double salary) { this.salary = salary; }
}
