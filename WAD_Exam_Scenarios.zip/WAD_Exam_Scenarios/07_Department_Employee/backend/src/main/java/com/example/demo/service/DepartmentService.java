package com.example.demo.service;

import com.example.demo.model.Department;
import com.example.demo.model.Employee;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.EmployeeRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class DepartmentService {

    private final DepartmentRepository departments;
    private final EmployeeRepository employees;

    public DepartmentService(DepartmentRepository departments, EmployeeRepository employees) {
        this.departments = departments;
        this.employees = employees;
    }

    private void validate(Department x) {
        if (x.getDeptName() == null || x.getDeptName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "deptName is required");
        if (x.getHead() == null || x.getHead().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "head is required");
        if (x.getmaxStaff() == null || x.getmaxStaff() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "maxStaff is required and must be > 0");
        if (x.getsalary() == null || x.getsalary() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "salary is required and must be >= 0");
    }

    public Department getById(String id) {
        return departments.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Department not found with id " + id));
    }

    // ---------- CRUD ----------
    public Department create(Department x) {
        validate(x);
        x.setId(null);
        return departments.save(x);
    }

    public List<Department> getAll() { return departments.findAll(); }

    public Department update(String id, Department in) {
        Department existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of employees already added
        long used = employees.countByDepartmentId(id);
        if (in.getmaxStaff() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "maxStaff cannot be less than the " + used + " existing employees");
        existing.setDeptName(in.getDeptName());
        existing.setHead(in.getHead());
        existing.setLocation(in.getLocation());
        existing.setMaxStaff(in.getMaxStaff());
        existing.setSalary(in.getSalary());
        return departments.save(existing);
    }

    // a department that still has employees is NOT deleted unless cascade=true (then its employees are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = employees.countByDepartmentId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "department has " + used + " employees; delete them first or use cascade=true");
        employees.deleteByDepartmentId(id);
        departments.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Department> search(String keyword) { return departments.findByDeptNameContainingIgnoreCase(keyword); }

    public List<Department> filterBysalary(Double min) { return departments.findBysalaryGreaterThanEqual(min); }

    public List<Department> sortedBysalary() { return departments.findAll(Sort.by(Sort.Direction.DESC, "salary")); }

    // only the departments that still have a free place
    public List<Department> available() {
        List<Department> result = new ArrayList<>();
        for (Department x : departments.findAll())
            if (employees.countByDepartmentId(x.getId()) < x.getmaxStaff()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Employee> employeesOf(String id) {
        getById(id);                              // 404 if the department is missing
        return employees.findByDepartmentId(id);
    }

    // count + calculations across the two collections for ONE department
    public Map<String, Object> summary(String id) {
        Department x = getById(id);
        long count = employees.countByDepartmentId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("departmentId", x.getId());
        m.put("name", x.getDeptName());
        m.put("maxStaff", x.getmaxStaff());
        m.put("employeeCount", count);
        m.put("placesLeft", x.getmaxStaff() - count);
        m.put("salary", x.getsalary());
        m.put("totalAmount", count * x.getsalary());
        return m;
    }

    // totals across ALL departments
    public Map<String, Object> stats() {
        long totalEmployee = 0;
        double totalAmount = 0;
        List<Department> all = departments.findAll();
        for (Department x : all) {
            long c = employees.countByDepartmentId(x.getId());
            totalEmployee += c;
            totalAmount += c * x.getsalary();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalDepartments", all.size());
        m.put("totalEmployees", totalEmployee);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
