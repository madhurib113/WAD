package com.example.demo.repository;

import com.example.demo.model.Department;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DepartmentRepository extends MongoRepository<Department, String> {
    List<Department> findByDeptNameContainingIgnoreCase(String keyword);        // search
    List<Department> findBysalaryGreaterThanEqual(Double min);                  // filter by number
}
