package com.example.demo.repository;

import com.example.demo.model.Employee;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface EmployeeRepository extends MongoRepository<Employee, String> {
    List<Employee> findByDepartmentId(String departmentId);                    // filter by the related record
    long countByDepartmentId(String departmentId);                          // count related records
    long deleteByDepartmentId(String departmentId);                         // cascade delete
    List<Employee> findByNameContainingIgnoreCase(String keyword); // search
}
