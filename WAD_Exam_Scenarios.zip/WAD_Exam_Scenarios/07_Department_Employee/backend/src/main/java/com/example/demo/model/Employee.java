package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: employees
// departmentId stores the _id of a Department as plain text. MongoDB has NO foreign keys,
// so EmployeeService checks that the department exists before saving.
@Document(collection = "employees")
public class Employee {

    @Id
    private String id;

    private String name;     // required
    private String email;     // required
    private String departmentId;    // required: reference to departments._id

    public Employee() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getDepartmentId() { return departmentId; }
    public void setDepartmentId(String departmentId) { this.departmentId = departmentId; }
}
