package com.example.demo.controller;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class EmployeeController {

    private final EmployeeService service;

    public EmployeeController(EmployeeService service) { this.service = service; }

    @PostMapping                                   // POST   /api/employees   -> 201 / 400 (bad department) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Employee create(@RequestBody Employee x) { return service.create(x); }

    @GetMapping                                    // GET    /api/employees[?departmentId=..]  (filter by related record)
    public List<Employee> getAll(@RequestParam(required = false) String departmentId) { return service.getAll(departmentId); }

    @GetMapping("/{id}")                           // GET    /api/employees/{id}   -> 200 / 404
    public Employee getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/employees/{id}
    public Employee update(@PathVariable String id, @RequestBody Employee x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/employees/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/employees/search?keyword=an
    public List<Employee> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/employees/count[?departmentId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String departmentId) {
        return Map.of("count", service.count(departmentId));
    }
}
