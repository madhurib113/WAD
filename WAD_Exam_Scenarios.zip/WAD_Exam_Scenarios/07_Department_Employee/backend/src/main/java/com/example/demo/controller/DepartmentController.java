package com.example.demo.controller;

import com.example.demo.model.Department;
import com.example.demo.model.Employee;
import com.example.demo.service.DepartmentService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/departments")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class DepartmentController {

    private final DepartmentService service;

    public DepartmentController(DepartmentService service) { this.service = service; }

    @PostMapping                                   // POST   /api/departments                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Department create(@RequestBody Department x) { return service.create(x); }

    @GetMapping                                    // GET    /api/departments
    public List<Department> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/departments/{id}            -> 200 / 404
    public Department getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/departments/{id}            -> 200 / 400 / 404 / 409
    public Department update(@PathVariable String id, @RequestBody Department x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/departments/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/departments/search?keyword=ab
    public List<Department> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/departments/filter?minsalary=500
    public List<Department> filter(@RequestParam Double minsalary) { return service.filterBysalary(minsalary); }

    @GetMapping("/sorted")                         // GET    /api/departments/sorted          (salary high -> low)
    public List<Department> sorted() { return service.sortedBysalary(); }

    @GetMapping("/available")                      // GET    /api/departments/available       (still have free places)
    public List<Department> available() { return service.available(); }

    @GetMapping("/{id}/employees")                    // GET    /api/departments/{id}/employees     (related records)
    public List<Employee> related(@PathVariable String id) { return service.employeesOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/departments/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/departments/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
