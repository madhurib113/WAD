<script setup>
// Form for the "ONE" side (Department). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'deptName', label: 'Dept Name', type: 'text' },
  { key: 'head', label: 'Head', type: 'text' },
  { key: 'location', label: 'Location', type: 'text' },
  { key: 'maxStaff', label: 'Max Staff', type: 'number' },
  { key: 'salary', label: 'Salary', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Department</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
