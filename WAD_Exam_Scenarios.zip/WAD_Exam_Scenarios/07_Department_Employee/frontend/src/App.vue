<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import DepartmentForm from './components/DepartmentForm.vue'
import DepartmentList from './components/DepartmentList.vue'
import EmployeeForm from './components/EmployeeForm.vue'
import EmployeeList from './components/EmployeeList.vue'
import ResultBox from './components/ResultBox.vue'

const DEPARTMENTS = 'http://localhost:8080/api/departments'
const EMPLOYEES = 'http://localhost:8080/api/employees'

const departments = ref([])
const employees = ref([])
const departmentForm = ref({ deptName: '', head: '', location: '', maxStaff: '', salary: '' })
const editingDepartmentId = ref('')
const employeeForm = ref({ name: '', email: '', departmentId: '' })
const editingEmployeeId = ref('')
const filterDepartmentId = ref('')
const keyword = ref('')
const minsalary = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Department ----------
async function loadDepartments() {
  try { departments.value = (await axios.get(DEPARTMENTS)).data } catch (e) { showError(e) }
}

async function saveDepartment() {
  error.value = ''
  const body = { ...departmentForm.value, maxStaff: num(departmentForm.value.maxStaff), salary: num(departmentForm.value.salary) }
  try {
    if (editingDepartmentId.value === '') await axios.post(DEPARTMENTS, body)
    else await axios.put(DEPARTMENTS + '/' + editingDepartmentId.value, body)
    cancelDepartment()
    loadDepartments()
  } catch (e) { showError(e) }
}

function editDepartment(x) {
  departmentForm.value = { ...x }
  editingDepartmentId.value = x.id
}

function cancelDepartment() {
  departmentForm.value = { deptName: '', head: '', location: '', maxStaff: '', salary: '' }
  editingDepartmentId.value = ''
}

// cascade = true also deletes the employees; false -> error 409 if there are employees
async function deleteDepartment(id, cascade) {
  error.value = ''
  try {
    await axios.delete(DEPARTMENTS + '/' + id, { params: { cascade } })
    loadDepartments()
    loadEmployees()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Employee ----------
async function loadEmployees() {
  try { employees.value = (await axios.get(EMPLOYEES, { params: { departmentId: filterDepartmentId.value } })).data } catch (e) { showError(e) }
}

async function saveEmployee() {
  error.value = ''
  try {
    if (editingEmployeeId.value === '') await axios.post(EMPLOYEES, employeeForm.value)
    else await axios.put(EMPLOYEES + '/' + editingEmployeeId.value, employeeForm.value)
    cancelEmployee()
    loadEmployees()
  } catch (e) { showError(e) }
}

function editEmployee(x) {
  employeeForm.value = { name: x.name, email: x.email, departmentId: x.departmentId }
  editingEmployeeId.value = x.id
}

function cancelEmployee() {
  employeeForm.value = { name: '', email: '', departmentId: '' }
  editingEmployeeId.value = ''
}

async function deleteEmployee(id) {
  error.value = ''
  try {
    await axios.delete(EMPLOYEES + '/' + id)
    loadEmployees()
  } catch (e) { showError(e) }
}

onMounted(() => { loadDepartments(); loadEmployees() })
</script>

<template>
  <h1>Department - Employee Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Departments</h2>
  <DepartmentForm :form="departmentForm" :editing="editingDepartmentId !== ''" @save="saveDepartment" @cancel="cancelDepartment" />
  <div class="box">
    <input v-model="keyword" placeholder="search deptName" />
    <button @click="showGet(DEPARTMENTS + '/search', { keyword })">Search</button>
    <input v-model="minsalary" type="number" placeholder="min salary" />
    <button @click="showGet(DEPARTMENTS + '/filter', { minsalary })">Filter</button>
    <button @click="showGet(DEPARTMENTS + '/sorted')">Sort by salary</button>
    <button @click="showGet(DEPARTMENTS + '/available')">Available</button>
    <button @click="showGet(DEPARTMENTS + '/stats')">Stats</button>
  </div>
  <DepartmentList :items="departments" @edit="editDepartment" @remove="deleteDepartment"
    @related="(id) => showGet(DEPARTMENTS + '/' + id + '/employees')" @summary="(id) => showGet(DEPARTMENTS + '/' + id + '/summary')" />

  <h2>Employees</h2>
  <EmployeeForm :form="employeeForm" :editing="editingEmployeeId !== ''" :parents="departments" @save="saveEmployee" @cancel="cancelEmployee" />
  <div class="box">
    <select v-model="filterDepartmentId" @change="loadEmployees">
      <option value="">All departments</option>
      <option v-for="p in departments" :key="p.id" :value="p.id">{{ p.deptName }}</option>
    </select>
    <button @click="showGet(EMPLOYEES + '/count', { departmentId: filterDepartmentId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(EMPLOYEES + '/search', { keyword })">Search</button>
  </div>
  <EmployeeList :items="employees" :parents="departments" @edit="editEmployee" @remove="deleteEmployee" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
