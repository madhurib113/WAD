# Department - Employee (2 collections: `departments` and `employees`)

Database `department_db`. `employees.departmentId` stores the `_id` of a department (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db department_db --collection departments --jsonArray --file sample_data/departments.json
mongoimport --db department_db --collection employees --jsonArray --file sample_data/employees.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Department**: deptName*, head*, location, maxStaff* (> 0), salary* (>= 0)    (* = required)
- **Employee**: name*, email*, departmentId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/departments | create (Department) 201 / 400 |
| GET | /api/departments , /api/departments/{id} | all / one (404) |
| PUT | /api/departments/{id} | update 200 / 400 / 404 / 409 (`maxStaff` below existing employees) |
| DELETE | /api/departments/{id}?cascade=true | 204 / 404 / 409 (has employees and no cascade) |
| GET | /api/departments/search?keyword= | search by deptName |
| GET | /api/departments/filter?minsalary= | salary >= value |
| GET | /api/departments/sorted | sort by salary desc |
| GET | /api/departments/available | departments that still have free places |
| GET | /api/departments/{id}/employees | related employees |
| GET | /api/departments/{id}/summary | count, placesLeft, totalAmount = count x salary |
| GET | /api/departments/stats | totals over all departments |
| POST | /api/employees | create (Employee) 201 / 400 (bad departmentId) / 409 (full) |
| GET | /api/employees?departmentId= | all / filter by department |
| GET | /api/employees/{id} | one (404) |
| PUT | /api/employees/{id} | update (move to another department: free place checked) |
| DELETE | /api/employees/{id} | 204 / 404 |
| GET | /api/employees/search?keyword= | search by name |
| GET | /api/employees/count?departmentId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on departments and on employees.
3. Validation: missing field -> 400, maxStaff <= 0 -> 400, salary < 0 -> 400, unknown id -> 404.
4. Add a employee only if the department exists (400) and is not full (409).
5. Update department: maxStaff cannot be lower than current number of employees (409).
6. Delete department: blocked if it has employees (409); `cascade=true` deletes its employees too.
7. List employees of one department; count employees of one department.
8. Search by text, filter by number, sort descending, list available departments.
9. Calculation: totalAmount for one department, and totals over all departments (stats).
10. Move a employee from one department to another.
