<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import CourseForm from './components/CourseForm.vue'
import CourseList from './components/CourseList.vue'
import StudentForm from './components/StudentForm.vue'
import StudentList from './components/StudentList.vue'
import ResultBox from './components/ResultBox.vue'

const COURSES = 'http://localhost:8080/api/courses'
const STUDENTS = 'http://localhost:8080/api/students'

const courses = ref([])
const students = ref([])
const courseForm = ref({ title: '', instructor: '', room: '', seats: '', fee: '' })
const editingCourseId = ref('')
const studentForm = ref({ name: '', email: '', courseId: '' })
const editingStudentId = ref('')
const filterCourseId = ref('')
const keyword = ref('')
const minfee = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Course ----------
async function loadCourses() {
  try { courses.value = (await axios.get(COURSES)).data } catch (e) { showError(e) }
}

async function saveCourse() {
  error.value = ''
  const body = { ...courseForm.value, seats: num(courseForm.value.seats), fee: num(courseForm.value.fee) }
  try {
    if (editingCourseId.value === '') await axios.post(COURSES, body)
    else await axios.put(COURSES + '/' + editingCourseId.value, body)
    cancelCourse()
    loadCourses()
  } catch (e) { showError(e) }
}

function editCourse(x) {
  courseForm.value = { ...x }
  editingCourseId.value = x.id
}

function cancelCourse() {
  courseForm.value = { title: '', instructor: '', room: '', seats: '', fee: '' }
  editingCourseId.value = ''
}

// cascade = true also deletes the students; false -> error 409 if there are students
async function deleteCourse(id, cascade) {
  error.value = ''
  try {
    await axios.delete(COURSES + '/' + id, { params: { cascade } })
    loadCourses()
    loadStudents()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Student ----------
async function loadStudents() {
  try { students.value = (await axios.get(STUDENTS, { params: { courseId: filterCourseId.value } })).data } catch (e) { showError(e) }
}

async function saveStudent() {
  error.value = ''
  try {
    if (editingStudentId.value === '') await axios.post(STUDENTS, studentForm.value)
    else await axios.put(STUDENTS + '/' + editingStudentId.value, studentForm.value)
    cancelStudent()
    loadStudents()
  } catch (e) { showError(e) }
}

function editStudent(x) {
  studentForm.value = { name: x.name, email: x.email, courseId: x.courseId }
  editingStudentId.value = x.id
}

function cancelStudent() {
  studentForm.value = { name: '', email: '', courseId: '' }
  editingStudentId.value = ''
}

async function deleteStudent(id) {
  error.value = ''
  try {
    await axios.delete(STUDENTS + '/' + id)
    loadStudents()
  } catch (e) { showError(e) }
}

onMounted(() => { loadCourses(); loadStudents() })
</script>

<template>
  <h1>Course - Student Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Courses</h2>
  <CourseForm :form="courseForm" :editing="editingCourseId !== ''" @save="saveCourse" @cancel="cancelCourse" />
  <div class="box">
    <input v-model="keyword" placeholder="search title" />
    <button @click="showGet(COURSES + '/search', { keyword })">Search</button>
    <input v-model="minfee" type="number" placeholder="min fee" />
    <button @click="showGet(COURSES + '/filter', { minfee })">Filter</button>
    <button @click="showGet(COURSES + '/sorted')">Sort by fee</button>
    <button @click="showGet(COURSES + '/available')">Available</button>
    <button @click="showGet(COURSES + '/stats')">Stats</button>
  </div>
  <CourseList :items="courses" @edit="editCourse" @remove="deleteCourse"
    @related="(id) => showGet(COURSES + '/' + id + '/students')" @summary="(id) => showGet(COURSES + '/' + id + '/summary')" />

  <h2>Students</h2>
  <StudentForm :form="studentForm" :editing="editingStudentId !== ''" :parents="courses" @save="saveStudent" @cancel="cancelStudent" />
  <div class="box">
    <select v-model="filterCourseId" @change="loadStudents">
      <option value="">All courses</option>
      <option v-for="p in courses" :key="p.id" :value="p.id">{{ p.title }}</option>
    </select>
    <button @click="showGet(STUDENTS + '/count', { courseId: filterCourseId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(STUDENTS + '/search', { keyword })">Search</button>
  </div>
  <StudentList :items="students" :parents="courses" @edit="editStudent" @remove="deleteStudent" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
