<script setup>
// Shows the JSON result of summary / stats / related / filter calls.
defineProps({ text: String })
</script>

<template>
  <pre v-if="text" class="result">{{ text }}</pre>
</template>
