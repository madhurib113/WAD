# Course - Student (2 collections: `courses` and `students`)

Database `course_db`. `students.courseId` stores the `_id` of a course (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db course_db --collection courses --jsonArray --file sample_data/courses.json
mongoimport --db course_db --collection students --jsonArray --file sample_data/students.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Course**: title*, instructor*, room, seats* (> 0), fee* (>= 0)    (* = required)
- **Student**: name*, email*, courseId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/courses | create (Course) 201 / 400 |
| GET | /api/courses , /api/courses/{id} | all / one (404) |
| PUT | /api/courses/{id} | update 200 / 400 / 404 / 409 (`seats` below existing students) |
| DELETE | /api/courses/{id}?cascade=true | 204 / 404 / 409 (has students and no cascade) |
| GET | /api/courses/search?keyword= | search by title |
| GET | /api/courses/filter?minfee= | fee >= value |
| GET | /api/courses/sorted | sort by fee desc |
| GET | /api/courses/available | courses that still have free places |
| GET | /api/courses/{id}/students | related students |
| GET | /api/courses/{id}/summary | count, placesLeft, totalAmount = count x fee |
| GET | /api/courses/stats | totals over all courses |
| POST | /api/students | create (Student) 201 / 400 (bad courseId) / 409 (full) |
| GET | /api/students?courseId= | all / filter by course |
| GET | /api/students/{id} | one (404) |
| PUT | /api/students/{id} | update (move to another course: free place checked) |
| DELETE | /api/students/{id} | 204 / 404 |
| GET | /api/students/search?keyword= | search by name |
| GET | /api/students/count?courseId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on courses and on students.
3. Validation: missing field -> 400, seats <= 0 -> 400, fee < 0 -> 400, unknown id -> 404.
4. Add a student only if the course exists (400) and is not full (409).
5. Update course: seats cannot be lower than current number of students (409).
6. Delete course: blocked if it has students (409); `cascade=true` deletes its students too.
7. List students of one course; count students of one course.
8. Search by text, filter by number, sort descending, list available courses.
9. Calculation: totalAmount for one course, and totals over all courses (stats).
10. Move a student from one course to another.
