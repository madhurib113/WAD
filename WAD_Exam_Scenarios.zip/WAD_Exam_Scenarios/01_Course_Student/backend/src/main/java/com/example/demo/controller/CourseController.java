package com.example.demo.controller;

import com.example.demo.model.Course;
import com.example.demo.model.Student;
import com.example.demo.service.CourseService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/courses")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class CourseController {

    private final CourseService service;

    public CourseController(CourseService service) { this.service = service; }

    @PostMapping                                   // POST   /api/courses                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Course create(@RequestBody Course x) { return service.create(x); }

    @GetMapping                                    // GET    /api/courses
    public List<Course> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/courses/{id}            -> 200 / 404
    public Course getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/courses/{id}            -> 200 / 400 / 404 / 409
    public Course update(@PathVariable String id, @RequestBody Course x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/courses/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/courses/search?keyword=ab
    public List<Course> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/courses/filter?minfee=500
    public List<Course> filter(@RequestParam Double minfee) { return service.filterByfee(minfee); }

    @GetMapping("/sorted")                         // GET    /api/courses/sorted          (fee high -> low)
    public List<Course> sorted() { return service.sortedByfee(); }

    @GetMapping("/available")                      // GET    /api/courses/available       (still have free places)
    public List<Course> available() { return service.available(); }

    @GetMapping("/{id}/students")                    // GET    /api/courses/{id}/students     (related records)
    public List<Student> related(@PathVariable String id) { return service.studentsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/courses/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/courses/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
