package com.example.demo.repository;

import com.example.demo.model.Course;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CourseRepository extends MongoRepository<Course, String> {
    List<Course> findByTitleContainingIgnoreCase(String keyword);        // search
    List<Course> findByfeeGreaterThanEqual(Double min);                  // filter by number
}
