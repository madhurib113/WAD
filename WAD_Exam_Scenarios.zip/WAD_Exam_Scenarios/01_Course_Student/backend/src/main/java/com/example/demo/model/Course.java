package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: courses
@Document(collection = "courses")
public class Course {

    @Id
    private String id;

    private String title;
    private String instructor;
    private String room;
    private Integer seats;
    private Double fee;

    public Course() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getInstructor() { return instructor; }
    public void setInstructor(String instructor) { this.instructor = instructor; }
    public String getRoom() { return room; }
    public void setRoom(String room) { this.room = room; }
    public Integer getSeats() { return seats; }
    public void setSeats(Integer seats) { this.seats = seats; }
    public Double getFee() { return fee; }
    public void setFee(Double fee) { this.fee = fee; }
}
