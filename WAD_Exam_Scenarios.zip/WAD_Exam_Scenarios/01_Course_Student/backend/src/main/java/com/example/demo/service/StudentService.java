package com.example.demo.service;

import com.example.demo.model.Course;
import com.example.demo.model.Student;
import com.example.demo.repository.CourseRepository;
import com.example.demo.repository.StudentRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class StudentService {

    private final StudentRepository students;
    private final CourseRepository courses;

    public StudentService(StudentRepository students, CourseRepository courses) {
        this.students = students;
        this.courses = courses;
    }

    private void validate(Student x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getEmail() == null || x.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (x.getCourseId() == null || x.getCourseId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "courseId is required");
    }

    // The referenced course must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkCourse(String id, boolean checkLimit) {
        Course p = courses.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "courseId does not exist: " + id));
        if (checkLimit && students.countByCourseId(id) >= p.getseats())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "course is full");
    }

    public Student getById(String id) {
        return students.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Student not found with id " + id));
    }

    public Student create(Student x) {
        validate(x);
        checkCourse(x.getCourseId(), true);
        x.setId(null);
        return students.save(x);
    }

    // optional filter by related record: ?courseId=...
    public List<Student> getAll(String courseId) {
        if (courseId == null || courseId.isBlank()) return students.findAll();
        return students.findByCourseId(courseId);
    }

    public List<Student> search(String keyword) { return students.findByNameContainingIgnoreCase(keyword); }

    public Student update(String id, Student in) {
        Student existing = getById(id);
        validate(in);
        boolean moving = !in.getCourseId().equals(existing.getCourseId());
        checkCourse(in.getCourseId(), moving);       // free-place check only when moving to another course
        existing.setName(in.getName());
        existing.setEmail(in.getEmail());
        existing.setCourseId(in.getCourseId());
        return students.save(existing);
    }

    public void delete(String id) {
        getById(id);
        students.deleteById(id);
    }

    public long count(String courseId) {
        if (courseId == null || courseId.isBlank()) return students.count();
        return students.countByCourseId(courseId);
    }
}
