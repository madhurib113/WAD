package com.example.demo.controller;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) { this.service = service; }

    @PostMapping                                   // POST   /api/students   -> 201 / 400 (bad course) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Student create(@RequestBody Student x) { return service.create(x); }

    @GetMapping                                    // GET    /api/students[?courseId=..]  (filter by related record)
    public List<Student> getAll(@RequestParam(required = false) String courseId) { return service.getAll(courseId); }

    @GetMapping("/{id}")                           // GET    /api/students/{id}   -> 200 / 404
    public Student getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/students/{id}
    public Student update(@PathVariable String id, @RequestBody Student x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/students/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/students/search?keyword=an
    public List<Student> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/students/count[?courseId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String courseId) {
        return Map.of("count", service.count(courseId));
    }
}
