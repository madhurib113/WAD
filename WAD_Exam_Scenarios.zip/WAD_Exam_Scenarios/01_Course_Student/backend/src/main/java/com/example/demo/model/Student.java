package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: students
// courseId stores the _id of a Course as plain text. MongoDB has NO foreign keys,
// so StudentService checks that the course exists before saving.
@Document(collection = "students")
public class Student {

    @Id
    private String id;

    private String name;     // required
    private String email;     // required
    private String courseId;    // required: reference to courses._id

    public Student() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
}
