package com.example.demo.repository;

import com.example.demo.model.Student;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface StudentRepository extends MongoRepository<Student, String> {
    List<Student> findByCourseId(String courseId);                    // filter by the related record
    long countByCourseId(String courseId);                          // count related records
    long deleteByCourseId(String courseId);                         // cascade delete
    List<Student> findByNameContainingIgnoreCase(String keyword); // search
}
