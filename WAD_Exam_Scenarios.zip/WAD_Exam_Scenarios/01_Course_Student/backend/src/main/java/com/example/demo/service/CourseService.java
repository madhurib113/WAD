package com.example.demo.service;

import com.example.demo.model.Course;
import com.example.demo.model.Student;
import com.example.demo.repository.CourseRepository;
import com.example.demo.repository.StudentRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class CourseService {

    private final CourseRepository courses;
    private final StudentRepository students;

    public CourseService(CourseRepository courses, StudentRepository students) {
        this.courses = courses;
        this.students = students;
    }

    private void validate(Course x) {
        if (x.getTitle() == null || x.getTitle().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "title is required");
        if (x.getInstructor() == null || x.getInstructor().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "instructor is required");
        if (x.getseats() == null || x.getseats() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "seats is required and must be > 0");
        if (x.getfee() == null || x.getfee() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "fee is required and must be >= 0");
    }

    public Course getById(String id) {
        return courses.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Course not found with id " + id));
    }

    // ---------- CRUD ----------
    public Course create(Course x) {
        validate(x);
        x.setId(null);
        return courses.save(x);
    }

    public List<Course> getAll() { return courses.findAll(); }

    public Course update(String id, Course in) {
        Course existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of students already added
        long used = students.countByCourseId(id);
        if (in.getseats() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "seats cannot be less than the " + used + " existing students");
        existing.setTitle(in.getTitle());
        existing.setInstructor(in.getInstructor());
        existing.setRoom(in.getRoom());
        existing.setSeats(in.getSeats());
        existing.setFee(in.getFee());
        return courses.save(existing);
    }

    // a course that still has students is NOT deleted unless cascade=true (then its students are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = students.countByCourseId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "course has " + used + " students; delete them first or use cascade=true");
        students.deleteByCourseId(id);
        courses.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Course> search(String keyword) { return courses.findByTitleContainingIgnoreCase(keyword); }

    public List<Course> filterByfee(Double min) { return courses.findByfeeGreaterThanEqual(min); }

    public List<Course> sortedByfee() { return courses.findAll(Sort.by(Sort.Direction.DESC, "fee")); }

    // only the courses that still have a free place
    public List<Course> available() {
        List<Course> result = new ArrayList<>();
        for (Course x : courses.findAll())
            if (students.countByCourseId(x.getId()) < x.getseats()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Student> studentsOf(String id) {
        getById(id);                              // 404 if the course is missing
        return students.findByCourseId(id);
    }

    // count + calculations across the two collections for ONE course
    public Map<String, Object> summary(String id) {
        Course x = getById(id);
        long count = students.countByCourseId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("courseId", x.getId());
        m.put("name", x.getTitle());
        m.put("seats", x.getseats());
        m.put("studentCount", count);
        m.put("placesLeft", x.getseats() - count);
        m.put("fee", x.getfee());
        m.put("totalAmount", count * x.getfee());
        return m;
    }

    // totals across ALL courses
    public Map<String, Object> stats() {
        long totalStudent = 0;
        double totalAmount = 0;
        List<Course> all = courses.findAll();
        for (Course x : all) {
            long c = students.countByCourseId(x.getId());
            totalStudent += c;
            totalAmount += c * x.getfee();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalCourses", all.size());
        m.put("totalStudents", totalStudent);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
