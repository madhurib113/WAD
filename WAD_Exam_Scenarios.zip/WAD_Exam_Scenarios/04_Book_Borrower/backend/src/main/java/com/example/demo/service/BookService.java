package com.example.demo.service;

import com.example.demo.model.Book;
import com.example.demo.model.Borrower;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.BorrowerRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class BookService {

    private final BookRepository books;
    private final BorrowerRepository borrowers;

    public BookService(BookRepository books, BorrowerRepository borrowers) {
        this.books = books;
        this.borrowers = borrowers;
    }

    private void validate(Book x) {
        if (x.getTitle() == null || x.getTitle().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "title is required");
        if (x.getAuthor() == null || x.getAuthor().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "author is required");
        if (x.getcopies() == null || x.getcopies() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "copies is required and must be > 0");
        if (x.getfinePerDay() == null || x.getfinePerDay() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "finePerDay is required and must be >= 0");
    }

    public Book getById(String id) {
        return books.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found with id " + id));
    }

    // ---------- CRUD ----------
    public Book create(Book x) {
        validate(x);
        x.setId(null);
        return books.save(x);
    }

    public List<Book> getAll() { return books.findAll(); }

    public Book update(String id, Book in) {
        Book existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of borrowers already added
        long used = borrowers.countByBookId(id);
        if (in.getcopies() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "copies cannot be less than the " + used + " existing borrowers");
        existing.setTitle(in.getTitle());
        existing.setAuthor(in.getAuthor());
        existing.setCategory(in.getCategory());
        existing.setCopies(in.getCopies());
        existing.setFinePerDay(in.getFinePerDay());
        return books.save(existing);
    }

    // a book that still has borrowers is NOT deleted unless cascade=true (then its borrowers are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = borrowers.countByBookId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "book has " + used + " borrowers; delete them first or use cascade=true");
        borrowers.deleteByBookId(id);
        books.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Book> search(String keyword) { return books.findByTitleContainingIgnoreCase(keyword); }

    public List<Book> filterByfinePerDay(Double min) { return books.findByfinePerDayGreaterThanEqual(min); }

    public List<Book> sortedByfinePerDay() { return books.findAll(Sort.by(Sort.Direction.DESC, "finePerDay")); }

    // only the books that still have a free place
    public List<Book> available() {
        List<Book> result = new ArrayList<>();
        for (Book x : books.findAll())
            if (borrowers.countByBookId(x.getId()) < x.getcopies()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Borrower> borrowersOf(String id) {
        getById(id);                              // 404 if the book is missing
        return borrowers.findByBookId(id);
    }

    // count + calculations across the two collections for ONE book
    public Map<String, Object> summary(String id) {
        Book x = getById(id);
        long count = borrowers.countByBookId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("bookId", x.getId());
        m.put("name", x.getTitle());
        m.put("copies", x.getcopies());
        m.put("borrowerCount", count);
        m.put("placesLeft", x.getcopies() - count);
        m.put("finePerDay", x.getfinePerDay());
        m.put("totalAmount", count * x.getfinePerDay());
        return m;
    }

    // totals across ALL books
    public Map<String, Object> stats() {
        long totalBorrower = 0;
        double totalAmount = 0;
        List<Book> all = books.findAll();
        for (Book x : all) {
            long c = borrowers.countByBookId(x.getId());
            totalBorrower += c;
            totalAmount += c * x.getfinePerDay();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalBooks", all.size());
        m.put("totalBorrowers", totalBorrower);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
