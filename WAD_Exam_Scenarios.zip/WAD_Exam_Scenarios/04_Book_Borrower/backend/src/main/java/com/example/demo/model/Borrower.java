package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: borrowers
// bookId stores the _id of a Book as plain text. MongoDB has NO foreign keys,
// so BorrowerService checks that the book exists before saving.
@Document(collection = "borrowers")
public class Borrower {

    @Id
    private String id;

    private String name;     // required
    private String email;     // required
    private String bookId;    // required: reference to books._id

    public Borrower() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getBookId() { return bookId; }
    public void setBookId(String bookId) { this.bookId = bookId; }
}
