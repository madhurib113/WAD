package com.example.demo.controller;

import com.example.demo.model.Book;
import com.example.demo.model.Borrower;
import com.example.demo.service.BookService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/books")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class BookController {

    private final BookService service;

    public BookController(BookService service) { this.service = service; }

    @PostMapping                                   // POST   /api/books                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Book create(@RequestBody Book x) { return service.create(x); }

    @GetMapping                                    // GET    /api/books
    public List<Book> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/books/{id}            -> 200 / 404
    public Book getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/books/{id}            -> 200 / 400 / 404 / 409
    public Book update(@PathVariable String id, @RequestBody Book x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/books/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/books/search?keyword=ab
    public List<Book> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/books/filter?minfinePerDay=500
    public List<Book> filter(@RequestParam Double minfinePerDay) { return service.filterByfinePerDay(minfinePerDay); }

    @GetMapping("/sorted")                         // GET    /api/books/sorted          (finePerDay high -> low)
    public List<Book> sorted() { return service.sortedByfinePerDay(); }

    @GetMapping("/available")                      // GET    /api/books/available       (still have free places)
    public List<Book> available() { return service.available(); }

    @GetMapping("/{id}/borrowers")                    // GET    /api/books/{id}/borrowers     (related records)
    public List<Borrower> related(@PathVariable String id) { return service.borrowersOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/books/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/books/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
