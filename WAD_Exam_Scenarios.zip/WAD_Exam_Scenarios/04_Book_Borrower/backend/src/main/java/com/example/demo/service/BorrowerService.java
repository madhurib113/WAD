package com.example.demo.service;

import com.example.demo.model.Book;
import com.example.demo.model.Borrower;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.BorrowerRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class BorrowerService {

    private final BorrowerRepository borrowers;
    private final BookRepository books;

    public BorrowerService(BorrowerRepository borrowers, BookRepository books) {
        this.borrowers = borrowers;
        this.books = books;
    }

    private void validate(Borrower x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getEmail() == null || x.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (x.getBookId() == null || x.getBookId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "bookId is required");
    }

    // The referenced book must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkBook(String id, boolean checkLimit) {
        Book p = books.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "bookId does not exist: " + id));
        if (checkLimit && borrowers.countByBookId(id) >= p.getcopies())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "book is full");
    }

    public Borrower getById(String id) {
        return borrowers.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Borrower not found with id " + id));
    }

    public Borrower create(Borrower x) {
        validate(x);
        checkBook(x.getBookId(), true);
        x.setId(null);
        return borrowers.save(x);
    }

    // optional filter by related record: ?bookId=...
    public List<Borrower> getAll(String bookId) {
        if (bookId == null || bookId.isBlank()) return borrowers.findAll();
        return borrowers.findByBookId(bookId);
    }

    public List<Borrower> search(String keyword) { return borrowers.findByNameContainingIgnoreCase(keyword); }

    public Borrower update(String id, Borrower in) {
        Borrower existing = getById(id);
        validate(in);
        boolean moving = !in.getBookId().equals(existing.getBookId());
        checkBook(in.getBookId(), moving);       // free-place check only when moving to another book
        existing.setName(in.getName());
        existing.setEmail(in.getEmail());
        existing.setBookId(in.getBookId());
        return borrowers.save(existing);
    }

    public void delete(String id) {
        getById(id);
        borrowers.deleteById(id);
    }

    public long count(String bookId) {
        if (bookId == null || bookId.isBlank()) return borrowers.count();
        return borrowers.countByBookId(bookId);
    }
}
