package com.example.demo.repository;

import com.example.demo.model.Borrower;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BorrowerRepository extends MongoRepository<Borrower, String> {
    List<Borrower> findByBookId(String bookId);                    // filter by the related record
    long countByBookId(String bookId);                          // count related records
    long deleteByBookId(String bookId);                         // cascade delete
    List<Borrower> findByNameContainingIgnoreCase(String keyword); // search
}
