package com.example.demo.controller;

import com.example.demo.model.Borrower;
import com.example.demo.service.BorrowerService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/borrowers")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class BorrowerController {

    private final BorrowerService service;

    public BorrowerController(BorrowerService service) { this.service = service; }

    @PostMapping                                   // POST   /api/borrowers   -> 201 / 400 (bad book) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Borrower create(@RequestBody Borrower x) { return service.create(x); }

    @GetMapping                                    // GET    /api/borrowers[?bookId=..]  (filter by related record)
    public List<Borrower> getAll(@RequestParam(required = false) String bookId) { return service.getAll(bookId); }

    @GetMapping("/{id}")                           // GET    /api/borrowers/{id}   -> 200 / 404
    public Borrower getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/borrowers/{id}
    public Borrower update(@PathVariable String id, @RequestBody Borrower x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/borrowers/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/borrowers/search?keyword=an
    public List<Borrower> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/borrowers/count[?bookId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String bookId) {
        return Map.of("count", service.count(bookId));
    }
}
