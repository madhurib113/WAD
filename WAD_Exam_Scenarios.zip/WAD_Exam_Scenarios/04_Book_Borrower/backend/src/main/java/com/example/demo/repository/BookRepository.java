package com.example.demo.repository;

import com.example.demo.model.Book;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BookRepository extends MongoRepository<Book, String> {
    List<Book> findByTitleContainingIgnoreCase(String keyword);        // search
    List<Book> findByfinePerDayGreaterThanEqual(Double min);                  // filter by number
}
