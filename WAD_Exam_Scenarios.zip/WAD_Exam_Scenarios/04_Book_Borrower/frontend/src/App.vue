<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import BookForm from './components/BookForm.vue'
import BookList from './components/BookList.vue'
import BorrowerForm from './components/BorrowerForm.vue'
import BorrowerList from './components/BorrowerList.vue'
import ResultBox from './components/ResultBox.vue'

const BOOKS = 'http://localhost:8080/api/books'
const BORROWERS = 'http://localhost:8080/api/borrowers'

const books = ref([])
const borrowers = ref([])
const bookForm = ref({ title: '', author: '', category: '', copies: '', finePerDay: '' })
const editingBookId = ref('')
const borrowerForm = ref({ name: '', email: '', bookId: '' })
const editingBorrowerId = ref('')
const filterBookId = ref('')
const keyword = ref('')
const minfinePerDay = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Book ----------
async function loadBooks() {
  try { books.value = (await axios.get(BOOKS)).data } catch (e) { showError(e) }
}

async function saveBook() {
  error.value = ''
  const body = { ...bookForm.value, copies: num(bookForm.value.copies), finePerDay: num(bookForm.value.finePerDay) }
  try {
    if (editingBookId.value === '') await axios.post(BOOKS, body)
    else await axios.put(BOOKS + '/' + editingBookId.value, body)
    cancelBook()
    loadBooks()
  } catch (e) { showError(e) }
}

function editBook(x) {
  bookForm.value = { ...x }
  editingBookId.value = x.id
}

function cancelBook() {
  bookForm.value = { title: '', author: '', category: '', copies: '', finePerDay: '' }
  editingBookId.value = ''
}

// cascade = true also deletes the borrowers; false -> error 409 if there are borrowers
async function deleteBook(id, cascade) {
  error.value = ''
  try {
    await axios.delete(BOOKS + '/' + id, { params: { cascade } })
    loadBooks()
    loadBorrowers()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Borrower ----------
async function loadBorrowers() {
  try { borrowers.value = (await axios.get(BORROWERS, { params: { bookId: filterBookId.value } })).data } catch (e) { showError(e) }
}

async function saveBorrower() {
  error.value = ''
  try {
    if (editingBorrowerId.value === '') await axios.post(BORROWERS, borrowerForm.value)
    else await axios.put(BORROWERS + '/' + editingBorrowerId.value, borrowerForm.value)
    cancelBorrower()
    loadBorrowers()
  } catch (e) { showError(e) }
}

function editBorrower(x) {
  borrowerForm.value = { name: x.name, email: x.email, bookId: x.bookId }
  editingBorrowerId.value = x.id
}

function cancelBorrower() {
  borrowerForm.value = { name: '', email: '', bookId: '' }
  editingBorrowerId.value = ''
}

async function deleteBorrower(id) {
  error.value = ''
  try {
    await axios.delete(BORROWERS + '/' + id)
    loadBorrowers()
  } catch (e) { showError(e) }
}

onMounted(() => { loadBooks(); loadBorrowers() })
</script>

<template>
  <h1>Book - Borrower Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Books</h2>
  <BookForm :form="bookForm" :editing="editingBookId !== ''" @save="saveBook" @cancel="cancelBook" />
  <div class="box">
    <input v-model="keyword" placeholder="search title" />
    <button @click="showGet(BOOKS + '/search', { keyword })">Search</button>
    <input v-model="minfinePerDay" type="number" placeholder="min finePerDay" />
    <button @click="showGet(BOOKS + '/filter', { minfinePerDay })">Filter</button>
    <button @click="showGet(BOOKS + '/sorted')">Sort by finePerDay</button>
    <button @click="showGet(BOOKS + '/available')">Available</button>
    <button @click="showGet(BOOKS + '/stats')">Stats</button>
  </div>
  <BookList :items="books" @edit="editBook" @remove="deleteBook"
    @related="(id) => showGet(BOOKS + '/' + id + '/borrowers')" @summary="(id) => showGet(BOOKS + '/' + id + '/summary')" />

  <h2>Borrowers</h2>
  <BorrowerForm :form="borrowerForm" :editing="editingBorrowerId !== ''" :parents="books" @save="saveBorrower" @cancel="cancelBorrower" />
  <div class="box">
    <select v-model="filterBookId" @change="loadBorrowers">
      <option value="">All books</option>
      <option v-for="p in books" :key="p.id" :value="p.id">{{ p.title }}</option>
    </select>
    <button @click="showGet(BORROWERS + '/count', { bookId: filterBookId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(BORROWERS + '/search', { keyword })">Search</button>
  </div>
  <BorrowerList :items="borrowers" :parents="books" @edit="editBorrower" @remove="deleteBorrower" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
