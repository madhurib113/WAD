<script setup>
// Table of Borrower records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the book name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Name</th><th>Email</th><th>Book</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.name }}</td>
        <td>{{ x.email }}</td>
        <td>{{ (parents.find(p => p.id === x.bookId) || {}).title || x.bookId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
