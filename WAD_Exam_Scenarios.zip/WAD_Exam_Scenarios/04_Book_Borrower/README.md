# Book - Borrower (2 collections: `books` and `borrowers`)

Database `book_db`. `borrowers.bookId` stores the `_id` of a book (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db book_db --collection books --jsonArray --file sample_data/books.json
mongoimport --db book_db --collection borrowers --jsonArray --file sample_data/borrowers.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Book**: title*, author*, category, copies* (> 0), finePerDay* (>= 0)    (* = required)
- **Borrower**: name*, email*, bookId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/books | create (Book) 201 / 400 |
| GET | /api/books , /api/books/{id} | all / one (404) |
| PUT | /api/books/{id} | update 200 / 400 / 404 / 409 (`copies` below existing borrowers) |
| DELETE | /api/books/{id}?cascade=true | 204 / 404 / 409 (has borrowers and no cascade) |
| GET | /api/books/search?keyword= | search by title |
| GET | /api/books/filter?minfinePerDay= | finePerDay >= value |
| GET | /api/books/sorted | sort by finePerDay desc |
| GET | /api/books/available | books that still have free places |
| GET | /api/books/{id}/borrowers | related borrowers |
| GET | /api/books/{id}/summary | count, placesLeft, totalAmount = count x finePerDay |
| GET | /api/books/stats | totals over all books |
| POST | /api/borrowers | create (Borrower) 201 / 400 (bad bookId) / 409 (full) |
| GET | /api/borrowers?bookId= | all / filter by book |
| GET | /api/borrowers/{id} | one (404) |
| PUT | /api/borrowers/{id} | update (move to another book: free place checked) |
| DELETE | /api/borrowers/{id} | 204 / 404 |
| GET | /api/borrowers/search?keyword= | search by name |
| GET | /api/borrowers/count?bookId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on books and on borrowers.
3. Validation: missing field -> 400, copies <= 0 -> 400, finePerDay < 0 -> 400, unknown id -> 404.
4. Add a borrower only if the book exists (400) and is not full (409).
5. Update book: copies cannot be lower than current number of borrowers (409).
6. Delete book: blocked if it has borrowers (409); `cascade=true` deletes its borrowers too.
7. List borrowers of one book; count borrowers of one book.
8. Search by text, filter by number, sort descending, list available books.
9. Calculation: totalAmount for one book, and totals over all books (stats).
10. Move a borrower from one book to another.
