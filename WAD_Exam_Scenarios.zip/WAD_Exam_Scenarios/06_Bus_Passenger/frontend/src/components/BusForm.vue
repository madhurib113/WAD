<script setup>
// Form for the "ONE" side (Bus). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'busName', label: 'Bus Name', type: 'text' },
  { key: 'source', label: 'Source', type: 'text' },
  { key: 'destination', label: 'Destination', type: 'text' },
  { key: 'seats', label: 'Seats', type: 'number' },
  { key: 'fare', label: 'Fare', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Bus</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
