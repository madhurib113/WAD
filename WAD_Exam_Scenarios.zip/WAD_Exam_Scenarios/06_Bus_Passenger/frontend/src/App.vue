<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import BusForm from './components/BusForm.vue'
import BusList from './components/BusList.vue'
import PassengerForm from './components/PassengerForm.vue'
import PassengerList from './components/PassengerList.vue'
import ResultBox from './components/ResultBox.vue'

const BUSS = 'http://localhost:8080/api/buss'
const PASSENGERS = 'http://localhost:8080/api/passengers'

const buss = ref([])
const passengers = ref([])
const busForm = ref({ busName: '', source: '', destination: '', seats: '', fare: '' })
const editingBusId = ref('')
const passengerForm = ref({ name: '', phone: '', busId: '' })
const editingPassengerId = ref('')
const filterBusId = ref('')
const keyword = ref('')
const minfare = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Bus ----------
async function loadBuss() {
  try { buss.value = (await axios.get(BUSS)).data } catch (e) { showError(e) }
}

async function saveBus() {
  error.value = ''
  const body = { ...busForm.value, seats: num(busForm.value.seats), fare: num(busForm.value.fare) }
  try {
    if (editingBusId.value === '') await axios.post(BUSS, body)
    else await axios.put(BUSS + '/' + editingBusId.value, body)
    cancelBus()
    loadBuss()
  } catch (e) { showError(e) }
}

function editBus(x) {
  busForm.value = { ...x }
  editingBusId.value = x.id
}

function cancelBus() {
  busForm.value = { busName: '', source: '', destination: '', seats: '', fare: '' }
  editingBusId.value = ''
}

// cascade = true also deletes the passengers; false -> error 409 if there are passengers
async function deleteBus(id, cascade) {
  error.value = ''
  try {
    await axios.delete(BUSS + '/' + id, { params: { cascade } })
    loadBuss()
    loadPassengers()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Passenger ----------
async function loadPassengers() {
  try { passengers.value = (await axios.get(PASSENGERS, { params: { busId: filterBusId.value } })).data } catch (e) { showError(e) }
}

async function savePassenger() {
  error.value = ''
  try {
    if (editingPassengerId.value === '') await axios.post(PASSENGERS, passengerForm.value)
    else await axios.put(PASSENGERS + '/' + editingPassengerId.value, passengerForm.value)
    cancelPassenger()
    loadPassengers()
  } catch (e) { showError(e) }
}

function editPassenger(x) {
  passengerForm.value = { name: x.name, phone: x.phone, busId: x.busId }
  editingPassengerId.value = x.id
}

function cancelPassenger() {
  passengerForm.value = { name: '', phone: '', busId: '' }
  editingPassengerId.value = ''
}

async function deletePassenger(id) {
  error.value = ''
  try {
    await axios.delete(PASSENGERS + '/' + id)
    loadPassengers()
  } catch (e) { showError(e) }
}

onMounted(() => { loadBuss(); loadPassengers() })
</script>

<template>
  <h1>Bus - Passenger Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Buss</h2>
  <BusForm :form="busForm" :editing="editingBusId !== ''" @save="saveBus" @cancel="cancelBus" />
  <div class="box">
    <input v-model="keyword" placeholder="search busName" />
    <button @click="showGet(BUSS + '/search', { keyword })">Search</button>
    <input v-model="minfare" type="number" placeholder="min fare" />
    <button @click="showGet(BUSS + '/filter', { minfare })">Filter</button>
    <button @click="showGet(BUSS + '/sorted')">Sort by fare</button>
    <button @click="showGet(BUSS + '/available')">Available</button>
    <button @click="showGet(BUSS + '/stats')">Stats</button>
  </div>
  <BusList :items="buss" @edit="editBus" @remove="deleteBus"
    @related="(id) => showGet(BUSS + '/' + id + '/passengers')" @summary="(id) => showGet(BUSS + '/' + id + '/summary')" />

  <h2>Passengers</h2>
  <PassengerForm :form="passengerForm" :editing="editingPassengerId !== ''" :parents="buss" @save="savePassenger" @cancel="cancelPassenger" />
  <div class="box">
    <select v-model="filterBusId" @change="loadPassengers">
      <option value="">All buss</option>
      <option v-for="p in buss" :key="p.id" :value="p.id">{{ p.busName }}</option>
    </select>
    <button @click="showGet(PASSENGERS + '/count', { busId: filterBusId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(PASSENGERS + '/search', { keyword })">Search</button>
  </div>
  <PassengerList :items="passengers" :parents="buss" @edit="editPassenger" @remove="deletePassenger" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
