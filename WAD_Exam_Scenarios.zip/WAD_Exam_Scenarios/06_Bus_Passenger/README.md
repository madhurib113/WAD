# Bus - Passenger (2 collections: `buss` and `passengers`)

Database `bus_db`. `passengers.busId` stores the `_id` of a bus (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db bus_db --collection buss --jsonArray --file sample_data/buss.json
mongoimport --db bus_db --collection passengers --jsonArray --file sample_data/passengers.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Bus**: busName*, source*, destination, seats* (> 0), fare* (>= 0)    (* = required)
- **Passenger**: name*, phone*, busId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/buss | create (Bus) 201 / 400 |
| GET | /api/buss , /api/buss/{id} | all / one (404) |
| PUT | /api/buss/{id} | update 200 / 400 / 404 / 409 (`seats` below existing passengers) |
| DELETE | /api/buss/{id}?cascade=true | 204 / 404 / 409 (has passengers and no cascade) |
| GET | /api/buss/search?keyword= | search by busName |
| GET | /api/buss/filter?minfare= | fare >= value |
| GET | /api/buss/sorted | sort by fare desc |
| GET | /api/buss/available | buss that still have free places |
| GET | /api/buss/{id}/passengers | related passengers |
| GET | /api/buss/{id}/summary | count, placesLeft, totalAmount = count x fare |
| GET | /api/buss/stats | totals over all buss |
| POST | /api/passengers | create (Passenger) 201 / 400 (bad busId) / 409 (full) |
| GET | /api/passengers?busId= | all / filter by bus |
| GET | /api/passengers/{id} | one (404) |
| PUT | /api/passengers/{id} | update (move to another bus: free place checked) |
| DELETE | /api/passengers/{id} | 204 / 404 |
| GET | /api/passengers/search?keyword= | search by name |
| GET | /api/passengers/count?busId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on buss and on passengers.
3. Validation: missing field -> 400, seats <= 0 -> 400, fare < 0 -> 400, unknown id -> 404.
4. Add a passenger only if the bus exists (400) and is not full (409).
5. Update bus: seats cannot be lower than current number of passengers (409).
6. Delete bus: blocked if it has passengers (409); `cascade=true` deletes its passengers too.
7. List passengers of one bus; count passengers of one bus.
8. Search by text, filter by number, sort descending, list available buss.
9. Calculation: totalAmount for one bus, and totals over all buss (stats).
10. Move a passenger from one bus to another.
