package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: buss
@Document(collection = "buss")
public class Bus {

    @Id
    private String id;

    private String busName;
    private String source;
    private String destination;
    private Integer seats;
    private Double fare;

    public Bus() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getBusName() { return busName; }
    public void setBusName(String busName) { this.busName = busName; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public Integer getSeats() { return seats; }
    public void setSeats(Integer seats) { this.seats = seats; }
    public Double getFare() { return fare; }
    public void setFare(Double fare) { this.fare = fare; }
}
