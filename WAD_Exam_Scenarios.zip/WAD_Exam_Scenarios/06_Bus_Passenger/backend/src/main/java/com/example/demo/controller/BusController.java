package com.example.demo.controller;

import com.example.demo.model.Bus;
import com.example.demo.model.Passenger;
import com.example.demo.service.BusService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/buss")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class BusController {

    private final BusService service;

    public BusController(BusService service) { this.service = service; }

    @PostMapping                                   // POST   /api/buss                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Bus create(@RequestBody Bus x) { return service.create(x); }

    @GetMapping                                    // GET    /api/buss
    public List<Bus> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/buss/{id}            -> 200 / 404
    public Bus getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/buss/{id}            -> 200 / 400 / 404 / 409
    public Bus update(@PathVariable String id, @RequestBody Bus x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/buss/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/buss/search?keyword=ab
    public List<Bus> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/buss/filter?minfare=500
    public List<Bus> filter(@RequestParam Double minfare) { return service.filterByfare(minfare); }

    @GetMapping("/sorted")                         // GET    /api/buss/sorted          (fare high -> low)
    public List<Bus> sorted() { return service.sortedByfare(); }

    @GetMapping("/available")                      // GET    /api/buss/available       (still have free places)
    public List<Bus> available() { return service.available(); }

    @GetMapping("/{id}/passengers")                    // GET    /api/buss/{id}/passengers     (related records)
    public List<Passenger> related(@PathVariable String id) { return service.passengersOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/buss/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/buss/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
