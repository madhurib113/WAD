package com.example.demo.repository;

import com.example.demo.model.Bus;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BusRepository extends MongoRepository<Bus, String> {
    List<Bus> findByBusNameContainingIgnoreCase(String keyword);        // search
    List<Bus> findByfareGreaterThanEqual(Double min);                  // filter by number
}
