package com.example.demo.repository;

import com.example.demo.model.Passenger;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PassengerRepository extends MongoRepository<Passenger, String> {
    List<Passenger> findByBusId(String busId);                    // filter by the related record
    long countByBusId(String busId);                          // count related records
    long deleteByBusId(String busId);                         // cascade delete
    List<Passenger> findByNameContainingIgnoreCase(String keyword); // search
}
