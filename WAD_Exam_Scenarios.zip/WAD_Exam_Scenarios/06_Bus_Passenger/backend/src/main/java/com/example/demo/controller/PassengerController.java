package com.example.demo.controller;

import com.example.demo.model.Passenger;
import com.example.demo.service.PassengerService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/passengers")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class PassengerController {

    private final PassengerService service;

    public PassengerController(PassengerService service) { this.service = service; }

    @PostMapping                                   // POST   /api/passengers   -> 201 / 400 (bad bus) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Passenger create(@RequestBody Passenger x) { return service.create(x); }

    @GetMapping                                    // GET    /api/passengers[?busId=..]  (filter by related record)
    public List<Passenger> getAll(@RequestParam(required = false) String busId) { return service.getAll(busId); }

    @GetMapping("/{id}")                           // GET    /api/passengers/{id}   -> 200 / 404
    public Passenger getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/passengers/{id}
    public Passenger update(@PathVariable String id, @RequestBody Passenger x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/passengers/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/passengers/search?keyword=an
    public List<Passenger> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/passengers/count[?busId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String busId) {
        return Map.of("count", service.count(busId));
    }
}
