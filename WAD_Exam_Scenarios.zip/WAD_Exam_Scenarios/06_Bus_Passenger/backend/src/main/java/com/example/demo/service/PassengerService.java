package com.example.demo.service;

import com.example.demo.model.Bus;
import com.example.demo.model.Passenger;
import com.example.demo.repository.BusRepository;
import com.example.demo.repository.PassengerRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class PassengerService {

    private final PassengerRepository passengers;
    private final BusRepository buss;

    public PassengerService(PassengerRepository passengers, BusRepository buss) {
        this.passengers = passengers;
        this.buss = buss;
    }

    private void validate(Passenger x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getBusId() == null || x.getBusId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "busId is required");
    }

    // The referenced bus must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkBus(String id, boolean checkLimit) {
        Bus p = buss.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "busId does not exist: " + id));
        if (checkLimit && passengers.countByBusId(id) >= p.getseats())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "bus is full");
    }

    public Passenger getById(String id) {
        return passengers.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Passenger not found with id " + id));
    }

    public Passenger create(Passenger x) {
        validate(x);
        checkBus(x.getBusId(), true);
        x.setId(null);
        return passengers.save(x);
    }

    // optional filter by related record: ?busId=...
    public List<Passenger> getAll(String busId) {
        if (busId == null || busId.isBlank()) return passengers.findAll();
        return passengers.findByBusId(busId);
    }

    public List<Passenger> search(String keyword) { return passengers.findByNameContainingIgnoreCase(keyword); }

    public Passenger update(String id, Passenger in) {
        Passenger existing = getById(id);
        validate(in);
        boolean moving = !in.getBusId().equals(existing.getBusId());
        checkBus(in.getBusId(), moving);       // free-place check only when moving to another bus
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setBusId(in.getBusId());
        return passengers.save(existing);
    }

    public void delete(String id) {
        getById(id);
        passengers.deleteById(id);
    }

    public long count(String busId) {
        if (busId == null || busId.isBlank()) return passengers.count();
        return passengers.countByBusId(busId);
    }
}
