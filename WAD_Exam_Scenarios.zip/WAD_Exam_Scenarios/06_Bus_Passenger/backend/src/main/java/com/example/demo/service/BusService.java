package com.example.demo.service;

import com.example.demo.model.Bus;
import com.example.demo.model.Passenger;
import com.example.demo.repository.BusRepository;
import com.example.demo.repository.PassengerRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class BusService {

    private final BusRepository buss;
    private final PassengerRepository passengers;

    public BusService(BusRepository buss, PassengerRepository passengers) {
        this.buss = buss;
        this.passengers = passengers;
    }

    private void validate(Bus x) {
        if (x.getBusName() == null || x.getBusName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "busName is required");
        if (x.getSource() == null || x.getSource().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "source is required");
        if (x.getseats() == null || x.getseats() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "seats is required and must be > 0");
        if (x.getfare() == null || x.getfare() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "fare is required and must be >= 0");
    }

    public Bus getById(String id) {
        return buss.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Bus not found with id " + id));
    }

    // ---------- CRUD ----------
    public Bus create(Bus x) {
        validate(x);
        x.setId(null);
        return buss.save(x);
    }

    public List<Bus> getAll() { return buss.findAll(); }

    public Bus update(String id, Bus in) {
        Bus existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of passengers already added
        long used = passengers.countByBusId(id);
        if (in.getseats() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "seats cannot be less than the " + used + " existing passengers");
        existing.setBusName(in.getBusName());
        existing.setSource(in.getSource());
        existing.setDestination(in.getDestination());
        existing.setSeats(in.getSeats());
        existing.setFare(in.getFare());
        return buss.save(existing);
    }

    // a bus that still has passengers is NOT deleted unless cascade=true (then its passengers are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = passengers.countByBusId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "bus has " + used + " passengers; delete them first or use cascade=true");
        passengers.deleteByBusId(id);
        buss.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Bus> search(String keyword) { return buss.findByBusNameContainingIgnoreCase(keyword); }

    public List<Bus> filterByfare(Double min) { return buss.findByfareGreaterThanEqual(min); }

    public List<Bus> sortedByfare() { return buss.findAll(Sort.by(Sort.Direction.DESC, "fare")); }

    // only the buss that still have a free place
    public List<Bus> available() {
        List<Bus> result = new ArrayList<>();
        for (Bus x : buss.findAll())
            if (passengers.countByBusId(x.getId()) < x.getseats()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Passenger> passengersOf(String id) {
        getById(id);                              // 404 if the bus is missing
        return passengers.findByBusId(id);
    }

    // count + calculations across the two collections for ONE bus
    public Map<String, Object> summary(String id) {
        Bus x = getById(id);
        long count = passengers.countByBusId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("busId", x.getId());
        m.put("name", x.getBusName());
        m.put("seats", x.getseats());
        m.put("passengerCount", count);
        m.put("placesLeft", x.getseats() - count);
        m.put("fare", x.getfare());
        m.put("totalAmount", count * x.getfare());
        return m;
    }

    // totals across ALL buss
    public Map<String, Object> stats() {
        long totalPassenger = 0;
        double totalAmount = 0;
        List<Bus> all = buss.findAll();
        for (Bus x : all) {
            long c = passengers.countByBusId(x.getId());
            totalPassenger += c;
            totalAmount += c * x.getfare();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalBuss", all.size());
        m.put("totalPassengers", totalPassenger);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
