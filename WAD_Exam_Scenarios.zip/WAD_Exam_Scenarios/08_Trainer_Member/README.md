# Trainer - Member (2 collections: `trainers` and `members`)

Database `trainer_db`. `members.trainerId` stores the `_id` of a trainer (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db trainer_db --collection trainers --jsonArray --file sample_data/trainers.json
mongoimport --db trainer_db --collection members --jsonArray --file sample_data/members.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Trainer**: name*, specialty*, shift, maxMembers* (> 0), monthlyFee* (>= 0)    (* = required)
- **Member**: name*, phone*, trainerId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/trainers | create (Trainer) 201 / 400 |
| GET | /api/trainers , /api/trainers/{id} | all / one (404) |
| PUT | /api/trainers/{id} | update 200 / 400 / 404 / 409 (`maxMembers` below existing members) |
| DELETE | /api/trainers/{id}?cascade=true | 204 / 404 / 409 (has members and no cascade) |
| GET | /api/trainers/search?keyword= | search by name |
| GET | /api/trainers/filter?minmonthlyFee= | monthlyFee >= value |
| GET | /api/trainers/sorted | sort by monthlyFee desc |
| GET | /api/trainers/available | trainers that still have free places |
| GET | /api/trainers/{id}/members | related members |
| GET | /api/trainers/{id}/summary | count, placesLeft, totalAmount = count x monthlyFee |
| GET | /api/trainers/stats | totals over all trainers |
| POST | /api/members | create (Member) 201 / 400 (bad trainerId) / 409 (full) |
| GET | /api/members?trainerId= | all / filter by trainer |
| GET | /api/members/{id} | one (404) |
| PUT | /api/members/{id} | update (move to another trainer: free place checked) |
| DELETE | /api/members/{id} | 204 / 404 |
| GET | /api/members/search?keyword= | search by name |
| GET | /api/members/count?trainerId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on trainers and on members.
3. Validation: missing field -> 400, maxMembers <= 0 -> 400, monthlyFee < 0 -> 400, unknown id -> 404.
4. Add a member only if the trainer exists (400) and is not full (409).
5. Update trainer: maxMembers cannot be lower than current number of members (409).
6. Delete trainer: blocked if it has members (409); `cascade=true` deletes its members too.
7. List members of one trainer; count members of one trainer.
8. Search by text, filter by number, sort descending, list available trainers.
9. Calculation: totalAmount for one trainer, and totals over all trainers (stats).
10. Move a member from one trainer to another.
