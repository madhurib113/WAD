package com.example.demo.service;

import com.example.demo.model.Trainer;
import com.example.demo.model.Member;
import com.example.demo.repository.TrainerRepository;
import com.example.demo.repository.MemberRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class TrainerService {

    private final TrainerRepository trainers;
    private final MemberRepository members;

    public TrainerService(TrainerRepository trainers, MemberRepository members) {
        this.trainers = trainers;
        this.members = members;
    }

    private void validate(Trainer x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getSpecialty() == null || x.getSpecialty().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "specialty is required");
        if (x.getmaxMembers() == null || x.getmaxMembers() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "maxMembers is required and must be > 0");
        if (x.getmonthlyFee() == null || x.getmonthlyFee() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "monthlyFee is required and must be >= 0");
    }

    public Trainer getById(String id) {
        return trainers.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Trainer not found with id " + id));
    }

    // ---------- CRUD ----------
    public Trainer create(Trainer x) {
        validate(x);
        x.setId(null);
        return trainers.save(x);
    }

    public List<Trainer> getAll() { return trainers.findAll(); }

    public Trainer update(String id, Trainer in) {
        Trainer existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of members already added
        long used = members.countByTrainerId(id);
        if (in.getmaxMembers() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "maxMembers cannot be less than the " + used + " existing members");
        existing.setName(in.getName());
        existing.setSpecialty(in.getSpecialty());
        existing.setShift(in.getShift());
        existing.setMaxMembers(in.getMaxMembers());
        existing.setMonthlyFee(in.getMonthlyFee());
        return trainers.save(existing);
    }

    // a trainer that still has members is NOT deleted unless cascade=true (then its members are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = members.countByTrainerId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "trainer has " + used + " members; delete them first or use cascade=true");
        members.deleteByTrainerId(id);
        trainers.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Trainer> search(String keyword) { return trainers.findByNameContainingIgnoreCase(keyword); }

    public List<Trainer> filterBymonthlyFee(Double min) { return trainers.findBymonthlyFeeGreaterThanEqual(min); }

    public List<Trainer> sortedBymonthlyFee() { return trainers.findAll(Sort.by(Sort.Direction.DESC, "monthlyFee")); }

    // only the trainers that still have a free place
    public List<Trainer> available() {
        List<Trainer> result = new ArrayList<>();
        for (Trainer x : trainers.findAll())
            if (members.countByTrainerId(x.getId()) < x.getmaxMembers()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Member> membersOf(String id) {
        getById(id);                              // 404 if the trainer is missing
        return members.findByTrainerId(id);
    }

    // count + calculations across the two collections for ONE trainer
    public Map<String, Object> summary(String id) {
        Trainer x = getById(id);
        long count = members.countByTrainerId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("trainerId", x.getId());
        m.put("name", x.getName());
        m.put("maxMembers", x.getmaxMembers());
        m.put("memberCount", count);
        m.put("placesLeft", x.getmaxMembers() - count);
        m.put("monthlyFee", x.getmonthlyFee());
        m.put("totalAmount", count * x.getmonthlyFee());
        return m;
    }

    // totals across ALL trainers
    public Map<String, Object> stats() {
        long totalMember = 0;
        double totalAmount = 0;
        List<Trainer> all = trainers.findAll();
        for (Trainer x : all) {
            long c = members.countByTrainerId(x.getId());
            totalMember += c;
            totalAmount += c * x.getmonthlyFee();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalTrainers", all.size());
        m.put("totalMembers", totalMember);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
