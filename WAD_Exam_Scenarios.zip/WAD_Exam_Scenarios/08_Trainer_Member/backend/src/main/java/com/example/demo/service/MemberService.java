package com.example.demo.service;

import com.example.demo.model.Trainer;
import com.example.demo.model.Member;
import com.example.demo.repository.TrainerRepository;
import com.example.demo.repository.MemberRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class MemberService {

    private final MemberRepository members;
    private final TrainerRepository trainers;

    public MemberService(MemberRepository members, TrainerRepository trainers) {
        this.members = members;
        this.trainers = trainers;
    }

    private void validate(Member x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getTrainerId() == null || x.getTrainerId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "trainerId is required");
    }

    // The referenced trainer must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkTrainer(String id, boolean checkLimit) {
        Trainer p = trainers.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "trainerId does not exist: " + id));
        if (checkLimit && members.countByTrainerId(id) >= p.getmaxMembers())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "trainer is full");
    }

    public Member getById(String id) {
        return members.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Member not found with id " + id));
    }

    public Member create(Member x) {
        validate(x);
        checkTrainer(x.getTrainerId(), true);
        x.setId(null);
        return members.save(x);
    }

    // optional filter by related record: ?trainerId=...
    public List<Member> getAll(String trainerId) {
        if (trainerId == null || trainerId.isBlank()) return members.findAll();
        return members.findByTrainerId(trainerId);
    }

    public List<Member> search(String keyword) { return members.findByNameContainingIgnoreCase(keyword); }

    public Member update(String id, Member in) {
        Member existing = getById(id);
        validate(in);
        boolean moving = !in.getTrainerId().equals(existing.getTrainerId());
        checkTrainer(in.getTrainerId(), moving);       // free-place check only when moving to another trainer
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setTrainerId(in.getTrainerId());
        return members.save(existing);
    }

    public void delete(String id) {
        getById(id);
        members.deleteById(id);
    }

    public long count(String trainerId) {
        if (trainerId == null || trainerId.isBlank()) return members.count();
        return members.countByTrainerId(trainerId);
    }
}
