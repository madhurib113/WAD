package com.example.demo.controller;

import com.example.demo.model.Trainer;
import com.example.demo.model.Member;
import com.example.demo.service.TrainerService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/trainers")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class TrainerController {

    private final TrainerService service;

    public TrainerController(TrainerService service) { this.service = service; }

    @PostMapping                                   // POST   /api/trainers                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Trainer create(@RequestBody Trainer x) { return service.create(x); }

    @GetMapping                                    // GET    /api/trainers
    public List<Trainer> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/trainers/{id}            -> 200 / 404
    public Trainer getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/trainers/{id}            -> 200 / 400 / 404 / 409
    public Trainer update(@PathVariable String id, @RequestBody Trainer x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/trainers/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/trainers/search?keyword=ab
    public List<Trainer> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/trainers/filter?minmonthlyFee=500
    public List<Trainer> filter(@RequestParam Double minmonthlyFee) { return service.filterBymonthlyFee(minmonthlyFee); }

    @GetMapping("/sorted")                         // GET    /api/trainers/sorted          (monthlyFee high -> low)
    public List<Trainer> sorted() { return service.sortedBymonthlyFee(); }

    @GetMapping("/available")                      // GET    /api/trainers/available       (still have free places)
    public List<Trainer> available() { return service.available(); }

    @GetMapping("/{id}/members")                    // GET    /api/trainers/{id}/members     (related records)
    public List<Member> related(@PathVariable String id) { return service.membersOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/trainers/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/trainers/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
