package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: members
// trainerId stores the _id of a Trainer as plain text. MongoDB has NO foreign keys,
// so MemberService checks that the trainer exists before saving.
@Document(collection = "members")
public class Member {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String trainerId;    // required: reference to trainers._id

    public Member() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getTrainerId() { return trainerId; }
    public void setTrainerId(String trainerId) { this.trainerId = trainerId; }
}
