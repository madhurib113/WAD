package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: trainers
@Document(collection = "trainers")
public class Trainer {

    @Id
    private String id;

    private String name;
    private String specialty;
    private String shift;
    private Integer maxMembers;
    private Double monthlyFee;

    public Trainer() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSpecialty() { return specialty; }
    public void setSpecialty(String specialty) { this.specialty = specialty; }
    public String getShift() { return shift; }
    public void setShift(String shift) { this.shift = shift; }
    public Integer getMaxMembers() { return maxMembers; }
    public void setMaxMembers(Integer maxMembers) { this.maxMembers = maxMembers; }
    public Double getMonthlyFee() { return monthlyFee; }
    public void setMonthlyFee(Double monthlyFee) { this.monthlyFee = monthlyFee; }
}
