package com.example.demo.repository;

import com.example.demo.model.Member;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MemberRepository extends MongoRepository<Member, String> {
    List<Member> findByTrainerId(String trainerId);                    // filter by the related record
    long countByTrainerId(String trainerId);                          // count related records
    long deleteByTrainerId(String trainerId);                         // cascade delete
    List<Member> findByNameContainingIgnoreCase(String keyword); // search
}
