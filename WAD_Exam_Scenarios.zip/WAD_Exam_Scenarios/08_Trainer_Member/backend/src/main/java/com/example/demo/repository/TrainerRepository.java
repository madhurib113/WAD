package com.example.demo.repository;

import com.example.demo.model.Trainer;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TrainerRepository extends MongoRepository<Trainer, String> {
    List<Trainer> findByNameContainingIgnoreCase(String keyword);        // search
    List<Trainer> findBymonthlyFeeGreaterThanEqual(Double min);                  // filter by number
}
