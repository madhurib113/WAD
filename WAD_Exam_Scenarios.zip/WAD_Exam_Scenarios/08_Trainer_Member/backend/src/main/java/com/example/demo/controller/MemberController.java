package com.example.demo.controller;

import com.example.demo.model.Member;
import com.example.demo.service.MemberService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/members")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class MemberController {

    private final MemberService service;

    public MemberController(MemberService service) { this.service = service; }

    @PostMapping                                   // POST   /api/members   -> 201 / 400 (bad trainer) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Member create(@RequestBody Member x) { return service.create(x); }

    @GetMapping                                    // GET    /api/members[?trainerId=..]  (filter by related record)
    public List<Member> getAll(@RequestParam(required = false) String trainerId) { return service.getAll(trainerId); }

    @GetMapping("/{id}")                           // GET    /api/members/{id}   -> 200 / 404
    public Member getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/members/{id}
    public Member update(@PathVariable String id, @RequestBody Member x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/members/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/members/search?keyword=an
    public List<Member> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/members/count[?trainerId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String trainerId) {
        return Map.of("count", service.count(trainerId));
    }
}
