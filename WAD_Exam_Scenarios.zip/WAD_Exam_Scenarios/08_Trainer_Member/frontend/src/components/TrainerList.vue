<script setup>
// Table of Trainer records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'specialty', label: 'Specialty', type: 'text' },
  { key: 'shift', label: 'Shift', type: 'text' },
  { key: 'maxMembers', label: 'Max Members', type: 'number' },
  { key: 'monthlyFee', label: 'Monthly Fee', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Members</button>
          <button @click="$emit('related', x.id)">Members</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
