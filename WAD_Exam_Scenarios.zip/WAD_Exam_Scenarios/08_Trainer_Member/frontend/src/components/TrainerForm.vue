<script setup>
// Form for the "ONE" side (Trainer). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'specialty', label: 'Specialty', type: 'text' },
  { key: 'shift', label: 'Shift', type: 'text' },
  { key: 'maxMembers', label: 'Max Members', type: 'number' },
  { key: 'monthlyFee', label: 'Monthly Fee', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Trainer</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
