<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import TrainerForm from './components/TrainerForm.vue'
import TrainerList from './components/TrainerList.vue'
import MemberForm from './components/MemberForm.vue'
import MemberList from './components/MemberList.vue'
import ResultBox from './components/ResultBox.vue'

const TRAINERS = 'http://localhost:8080/api/trainers'
const MEMBERS = 'http://localhost:8080/api/members'

const trainers = ref([])
const members = ref([])
const trainerForm = ref({ name: '', specialty: '', shift: '', maxMembers: '', monthlyFee: '' })
const editingTrainerId = ref('')
const memberForm = ref({ name: '', phone: '', trainerId: '' })
const editingMemberId = ref('')
const filterTrainerId = ref('')
const keyword = ref('')
const minmonthlyFee = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Trainer ----------
async function loadTrainers() {
  try { trainers.value = (await axios.get(TRAINERS)).data } catch (e) { showError(e) }
}

async function saveTrainer() {
  error.value = ''
  const body = { ...trainerForm.value, maxMembers: num(trainerForm.value.maxMembers), monthlyFee: num(trainerForm.value.monthlyFee) }
  try {
    if (editingTrainerId.value === '') await axios.post(TRAINERS, body)
    else await axios.put(TRAINERS + '/' + editingTrainerId.value, body)
    cancelTrainer()
    loadTrainers()
  } catch (e) { showError(e) }
}

function editTrainer(x) {
  trainerForm.value = { ...x }
  editingTrainerId.value = x.id
}

function cancelTrainer() {
  trainerForm.value = { name: '', specialty: '', shift: '', maxMembers: '', monthlyFee: '' }
  editingTrainerId.value = ''
}

// cascade = true also deletes the members; false -> error 409 if there are members
async function deleteTrainer(id, cascade) {
  error.value = ''
  try {
    await axios.delete(TRAINERS + '/' + id, { params: { cascade } })
    loadTrainers()
    loadMembers()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Member ----------
async function loadMembers() {
  try { members.value = (await axios.get(MEMBERS, { params: { trainerId: filterTrainerId.value } })).data } catch (e) { showError(e) }
}

async function saveMember() {
  error.value = ''
  try {
    if (editingMemberId.value === '') await axios.post(MEMBERS, memberForm.value)
    else await axios.put(MEMBERS + '/' + editingMemberId.value, memberForm.value)
    cancelMember()
    loadMembers()
  } catch (e) { showError(e) }
}

function editMember(x) {
  memberForm.value = { name: x.name, phone: x.phone, trainerId: x.trainerId }
  editingMemberId.value = x.id
}

function cancelMember() {
  memberForm.value = { name: '', phone: '', trainerId: '' }
  editingMemberId.value = ''
}

async function deleteMember(id) {
  error.value = ''
  try {
    await axios.delete(MEMBERS + '/' + id)
    loadMembers()
  } catch (e) { showError(e) }
}

onMounted(() => { loadTrainers(); loadMembers() })
</script>

<template>
  <h1>Trainer - Member Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Trainers</h2>
  <TrainerForm :form="trainerForm" :editing="editingTrainerId !== ''" @save="saveTrainer" @cancel="cancelTrainer" />
  <div class="box">
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(TRAINERS + '/search', { keyword })">Search</button>
    <input v-model="minmonthlyFee" type="number" placeholder="min monthlyFee" />
    <button @click="showGet(TRAINERS + '/filter', { minmonthlyFee })">Filter</button>
    <button @click="showGet(TRAINERS + '/sorted')">Sort by monthlyFee</button>
    <button @click="showGet(TRAINERS + '/available')">Available</button>
    <button @click="showGet(TRAINERS + '/stats')">Stats</button>
  </div>
  <TrainerList :items="trainers" @edit="editTrainer" @remove="deleteTrainer"
    @related="(id) => showGet(TRAINERS + '/' + id + '/members')" @summary="(id) => showGet(TRAINERS + '/' + id + '/summary')" />

  <h2>Members</h2>
  <MemberForm :form="memberForm" :editing="editingMemberId !== ''" :parents="trainers" @save="saveMember" @cancel="cancelMember" />
  <div class="box">
    <select v-model="filterTrainerId" @change="loadMembers">
      <option value="">All trainers</option>
      <option v-for="p in trainers" :key="p.id" :value="p.id">{{ p.name }}</option>
    </select>
    <button @click="showGet(MEMBERS + '/count', { trainerId: filterTrainerId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(MEMBERS + '/search', { keyword })">Search</button>
  </div>
  <MemberList :items="members" :parents="trainers" @edit="editMember" @remove="deleteMember" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
