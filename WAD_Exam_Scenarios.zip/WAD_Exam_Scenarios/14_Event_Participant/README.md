# Event - Participant (2 collections: `events` and `participants`)

Database `event_db`. `participants.eventId` stores the `_id` of a event (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db event_db --collection events --jsonArray --file sample_data/events.json
mongoimport --db event_db --collection participants --jsonArray --file sample_data/participants.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Event**: name*, date*, venue, capacity* (> 0), ticketPrice* (>= 0)    (* = required)
- **Participant**: name*, email*, eventId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/events | create (Event) 201 / 400 |
| GET | /api/events , /api/events/{id} | all / one (404) |
| PUT | /api/events/{id} | update 200 / 400 / 404 / 409 (`capacity` below existing participants) |
| DELETE | /api/events/{id}?cascade=true | 204 / 404 / 409 (has participants and no cascade) |
| GET | /api/events/search?keyword= | search by name |
| GET | /api/events/filter?minticketPrice= | ticketPrice >= value |
| GET | /api/events/sorted | sort by ticketPrice desc |
| GET | /api/events/available | events that still have free places |
| GET | /api/events/{id}/participants | related participants |
| GET | /api/events/{id}/summary | count, placesLeft, totalAmount = count x ticketPrice |
| GET | /api/events/stats | totals over all events |
| POST | /api/participants | create (Participant) 201 / 400 (bad eventId) / 409 (full) |
| GET | /api/participants?eventId= | all / filter by event |
| GET | /api/participants/{id} | one (404) |
| PUT | /api/participants/{id} | update (move to another event: free place checked) |
| DELETE | /api/participants/{id} | 204 / 404 |
| GET | /api/participants/search?keyword= | search by name |
| GET | /api/participants/count?eventId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on events and on participants.
3. Validation: missing field -> 400, capacity <= 0 -> 400, ticketPrice < 0 -> 400, unknown id -> 404.
4. Add a participant only if the event exists (400) and is not full (409).
5. Update event: capacity cannot be lower than current number of participants (409).
6. Delete event: blocked if it has participants (409); `cascade=true` deletes its participants too.
7. List participants of one event; count participants of one event.
8. Search by text, filter by number, sort descending, list available events.
9. Calculation: totalAmount for one event, and totals over all events (stats).
10. Move a participant from one event to another.
