package com.example.demo.service;

import com.example.demo.model.Event;
import com.example.demo.model.Participant;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.ParticipantRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class EventService {

    private final EventRepository events;
    private final ParticipantRepository participants;

    public EventService(EventRepository events, ParticipantRepository participants) {
        this.events = events;
        this.participants = participants;
    }

    private void validate(Event x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getDate() == null || x.getDate().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "date is required");
        if (x.getcapacity() == null || x.getcapacity() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "capacity is required and must be > 0");
        if (x.getticketPrice() == null || x.getticketPrice() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "ticketPrice is required and must be >= 0");
    }

    public Event getById(String id) {
        return events.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Event not found with id " + id));
    }

    // ---------- CRUD ----------
    public Event create(Event x) {
        validate(x);
        x.setId(null);
        return events.save(x);
    }

    public List<Event> getAll() { return events.findAll(); }

    public Event update(String id, Event in) {
        Event existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of participants already added
        long used = participants.countByEventId(id);
        if (in.getcapacity() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "capacity cannot be less than the " + used + " existing participants");
        existing.setName(in.getName());
        existing.setDate(in.getDate());
        existing.setVenue(in.getVenue());
        existing.setCapacity(in.getCapacity());
        existing.setTicketPrice(in.getTicketPrice());
        return events.save(existing);
    }

    // a event that still has participants is NOT deleted unless cascade=true (then its participants are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = participants.countByEventId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "event has " + used + " participants; delete them first or use cascade=true");
        participants.deleteByEventId(id);
        events.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Event> search(String keyword) { return events.findByNameContainingIgnoreCase(keyword); }

    public List<Event> filterByticketPrice(Double min) { return events.findByticketPriceGreaterThanEqual(min); }

    public List<Event> sortedByticketPrice() { return events.findAll(Sort.by(Sort.Direction.DESC, "ticketPrice")); }

    // only the events that still have a free place
    public List<Event> available() {
        List<Event> result = new ArrayList<>();
        for (Event x : events.findAll())
            if (participants.countByEventId(x.getId()) < x.getcapacity()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Participant> participantsOf(String id) {
        getById(id);                              // 404 if the event is missing
        return participants.findByEventId(id);
    }

    // count + calculations across the two collections for ONE event
    public Map<String, Object> summary(String id) {
        Event x = getById(id);
        long count = participants.countByEventId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("eventId", x.getId());
        m.put("name", x.getName());
        m.put("capacity", x.getcapacity());
        m.put("participantCount", count);
        m.put("placesLeft", x.getcapacity() - count);
        m.put("ticketPrice", x.getticketPrice());
        m.put("totalAmount", count * x.getticketPrice());
        return m;
    }

    // totals across ALL events
    public Map<String, Object> stats() {
        long totalParticipant = 0;
        double totalAmount = 0;
        List<Event> all = events.findAll();
        for (Event x : all) {
            long c = participants.countByEventId(x.getId());
            totalParticipant += c;
            totalAmount += c * x.getticketPrice();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalEvents", all.size());
        m.put("totalParticipants", totalParticipant);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
