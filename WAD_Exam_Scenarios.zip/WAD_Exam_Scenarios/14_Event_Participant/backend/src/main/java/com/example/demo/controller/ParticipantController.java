package com.example.demo.controller;

import com.example.demo.model.Participant;
import com.example.demo.service.ParticipantService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/participants")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class ParticipantController {

    private final ParticipantService service;

    public ParticipantController(ParticipantService service) { this.service = service; }

    @PostMapping                                   // POST   /api/participants   -> 201 / 400 (bad event) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Participant create(@RequestBody Participant x) { return service.create(x); }

    @GetMapping                                    // GET    /api/participants[?eventId=..]  (filter by related record)
    public List<Participant> getAll(@RequestParam(required = false) String eventId) { return service.getAll(eventId); }

    @GetMapping("/{id}")                           // GET    /api/participants/{id}   -> 200 / 404
    public Participant getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/participants/{id}
    public Participant update(@PathVariable String id, @RequestBody Participant x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/participants/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/participants/search?keyword=an
    public List<Participant> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/participants/count[?eventId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String eventId) {
        return Map.of("count", service.count(eventId));
    }
}
