package com.example.demo.service;

import com.example.demo.model.Event;
import com.example.demo.model.Participant;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.ParticipantRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ParticipantService {

    private final ParticipantRepository participants;
    private final EventRepository events;

    public ParticipantService(ParticipantRepository participants, EventRepository events) {
        this.participants = participants;
        this.events = events;
    }

    private void validate(Participant x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getEmail() == null || x.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (x.getEventId() == null || x.getEventId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "eventId is required");
    }

    // The referenced event must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkEvent(String id, boolean checkLimit) {
        Event p = events.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "eventId does not exist: " + id));
        if (checkLimit && participants.countByEventId(id) >= p.getcapacity())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "event is full");
    }

    public Participant getById(String id) {
        return participants.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Participant not found with id " + id));
    }

    public Participant create(Participant x) {
        validate(x);
        checkEvent(x.getEventId(), true);
        x.setId(null);
        return participants.save(x);
    }

    // optional filter by related record: ?eventId=...
    public List<Participant> getAll(String eventId) {
        if (eventId == null || eventId.isBlank()) return participants.findAll();
        return participants.findByEventId(eventId);
    }

    public List<Participant> search(String keyword) { return participants.findByNameContainingIgnoreCase(keyword); }

    public Participant update(String id, Participant in) {
        Participant existing = getById(id);
        validate(in);
        boolean moving = !in.getEventId().equals(existing.getEventId());
        checkEvent(in.getEventId(), moving);       // free-place check only when moving to another event
        existing.setName(in.getName());
        existing.setEmail(in.getEmail());
        existing.setEventId(in.getEventId());
        return participants.save(existing);
    }

    public void delete(String id) {
        getById(id);
        participants.deleteById(id);
    }

    public long count(String eventId) {
        if (eventId == null || eventId.isBlank()) return participants.count();
        return participants.countByEventId(eventId);
    }
}
