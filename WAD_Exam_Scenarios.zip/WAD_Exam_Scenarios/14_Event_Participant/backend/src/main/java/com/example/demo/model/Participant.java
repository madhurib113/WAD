package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: participants
// eventId stores the _id of a Event as plain text. MongoDB has NO foreign keys,
// so ParticipantService checks that the event exists before saving.
@Document(collection = "participants")
public class Participant {

    @Id
    private String id;

    private String name;     // required
    private String email;     // required
    private String eventId;    // required: reference to events._id

    public Participant() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }
}
