<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import EventForm from './components/EventForm.vue'
import EventList from './components/EventList.vue'
import ParticipantForm from './components/ParticipantForm.vue'
import ParticipantList from './components/ParticipantList.vue'
import ResultBox from './components/ResultBox.vue'

const EVENTS = 'http://localhost:8080/api/events'
const PARTICIPANTS = 'http://localhost:8080/api/participants'

const events = ref([])
const participants = ref([])
const eventForm = ref({ name: '', date: '', venue: '', capacity: '', ticketPrice: '' })
const editingEventId = ref('')
const participantForm = ref({ name: '', email: '', eventId: '' })
const editingParticipantId = ref('')
const filterEventId = ref('')
const keyword = ref('')
const minticketPrice = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Event ----------
async function loadEvents() {
  try { events.value = (await axios.get(EVENTS)).data } catch (e) { showError(e) }
}

async function saveEvent() {
  error.value = ''
  const body = { ...eventForm.value, capacity: num(eventForm.value.capacity), ticketPrice: num(eventForm.value.ticketPrice) }
  try {
    if (editingEventId.value === '') await axios.post(EVENTS, body)
    else await axios.put(EVENTS + '/' + editingEventId.value, body)
    cancelEvent()
    loadEvents()
  } catch (e) { showError(e) }
}

function editEvent(x) {
  eventForm.value = { ...x }
  editingEventId.value = x.id
}

function cancelEvent() {
  eventForm.value = { name: '', date: '', venue: '', capacity: '', ticketPrice: '' }
  editingEventId.value = ''
}

// cascade = true also deletes the participants; false -> error 409 if there are participants
async function deleteEvent(id, cascade) {
  error.value = ''
  try {
    await axios.delete(EVENTS + '/' + id, { params: { cascade } })
    loadEvents()
    loadParticipants()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Participant ----------
async function loadParticipants() {
  try { participants.value = (await axios.get(PARTICIPANTS, { params: { eventId: filterEventId.value } })).data } catch (e) { showError(e) }
}

async function saveParticipant() {
  error.value = ''
  try {
    if (editingParticipantId.value === '') await axios.post(PARTICIPANTS, participantForm.value)
    else await axios.put(PARTICIPANTS + '/' + editingParticipantId.value, participantForm.value)
    cancelParticipant()
    loadParticipants()
  } catch (e) { showError(e) }
}

function editParticipant(x) {
  participantForm.value = { name: x.name, email: x.email, eventId: x.eventId }
  editingParticipantId.value = x.id
}

function cancelParticipant() {
  participantForm.value = { name: '', email: '', eventId: '' }
  editingParticipantId.value = ''
}

async function deleteParticipant(id) {
  error.value = ''
  try {
    await axios.delete(PARTICIPANTS + '/' + id)
    loadParticipants()
  } catch (e) { showError(e) }
}

onMounted(() => { loadEvents(); loadParticipants() })
</script>

<template>
  <h1>Event - Participant Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Events</h2>
  <EventForm :form="eventForm" :editing="editingEventId !== ''" @save="saveEvent" @cancel="cancelEvent" />
  <div class="box">
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(EVENTS + '/search', { keyword })">Search</button>
    <input v-model="minticketPrice" type="number" placeholder="min ticketPrice" />
    <button @click="showGet(EVENTS + '/filter', { minticketPrice })">Filter</button>
    <button @click="showGet(EVENTS + '/sorted')">Sort by ticketPrice</button>
    <button @click="showGet(EVENTS + '/available')">Available</button>
    <button @click="showGet(EVENTS + '/stats')">Stats</button>
  </div>
  <EventList :items="events" @edit="editEvent" @remove="deleteEvent"
    @related="(id) => showGet(EVENTS + '/' + id + '/participants')" @summary="(id) => showGet(EVENTS + '/' + id + '/summary')" />

  <h2>Participants</h2>
  <ParticipantForm :form="participantForm" :editing="editingParticipantId !== ''" :parents="events" @save="saveParticipant" @cancel="cancelParticipant" />
  <div class="box">
    <select v-model="filterEventId" @change="loadParticipants">
      <option value="">All events</option>
      <option v-for="p in events" :key="p.id" :value="p.id">{{ p.name }}</option>
    </select>
    <button @click="showGet(PARTICIPANTS + '/count', { eventId: filterEventId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(PARTICIPANTS + '/search', { keyword })">Search</button>
  </div>
  <ParticipantList :items="participants" :parents="events" @edit="editParticipant" @remove="deleteParticipant" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
