<script setup>
// Form for the "MANY" side (Participant). The event is chosen from a dropdown.
defineProps({ form: Object, editing: Boolean, parents: Array })
defineEmits(['save', 'cancel'])
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Participant</h3>
    <input v-model="form.name" placeholder="Name" />
    <input v-model="form.email" placeholder="Email" />
    <select v-model="form.eventId">
      <option value="">-- select event --</option>
      <option v-for="p in parents" :key="p.id" :value="p.id">{{ p.name }}</option>
    </select>
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
