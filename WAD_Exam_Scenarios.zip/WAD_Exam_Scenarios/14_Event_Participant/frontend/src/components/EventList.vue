<script setup>
// Table of Event records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'date', label: 'Date', type: 'text' },
  { key: 'venue', label: 'Venue', type: 'text' },
  { key: 'capacity', label: 'Capacity', type: 'number' },
  { key: 'ticketPrice', label: 'Ticket Price', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Participants</button>
          <button @click="$emit('related', x.id)">Participants</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
