<script setup>
// Form for the "ONE" side (Event). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'date', label: 'Date', type: 'text' },
  { key: 'venue', label: 'Venue', type: 'text' },
  { key: 'capacity', label: 'Capacity', type: 'number' },
  { key: 'ticketPrice', label: 'Ticket Price', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Event</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
