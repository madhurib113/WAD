# Camp - Beneficiary (2 collections: `camps` and `beneficiarys`)

Database `camp_db`. `beneficiarys.campId` stores the `_id` of a camp (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db camp_db --collection camps --jsonArray --file sample_data/camps.json
mongoimport --db camp_db --collection beneficiarys --jsonArray --file sample_data/beneficiarys.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Camp**: campName*, doctor*, location, slots* (> 0), feePerDose* (>= 0)    (* = required)
- **Beneficiary**: name*, phone*, campId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/camps | create (Camp) 201 / 400 |
| GET | /api/camps , /api/camps/{id} | all / one (404) |
| PUT | /api/camps/{id} | update 200 / 400 / 404 / 409 (`slots` below existing beneficiarys) |
| DELETE | /api/camps/{id}?cascade=true | 204 / 404 / 409 (has beneficiarys and no cascade) |
| GET | /api/camps/search?keyword= | search by campName |
| GET | /api/camps/filter?minfeePerDose= | feePerDose >= value |
| GET | /api/camps/sorted | sort by feePerDose desc |
| GET | /api/camps/available | camps that still have free places |
| GET | /api/camps/{id}/beneficiarys | related beneficiarys |
| GET | /api/camps/{id}/summary | count, placesLeft, totalAmount = count x feePerDose |
| GET | /api/camps/stats | totals over all camps |
| POST | /api/beneficiarys | create (Beneficiary) 201 / 400 (bad campId) / 409 (full) |
| GET | /api/beneficiarys?campId= | all / filter by camp |
| GET | /api/beneficiarys/{id} | one (404) |
| PUT | /api/beneficiarys/{id} | update (move to another camp: free place checked) |
| DELETE | /api/beneficiarys/{id} | 204 / 404 |
| GET | /api/beneficiarys/search?keyword= | search by name |
| GET | /api/beneficiarys/count?campId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on camps and on beneficiarys.
3. Validation: missing field -> 400, slots <= 0 -> 400, feePerDose < 0 -> 400, unknown id -> 404.
4. Add a beneficiary only if the camp exists (400) and is not full (409).
5. Update camp: slots cannot be lower than current number of beneficiarys (409).
6. Delete camp: blocked if it has beneficiarys (409); `cascade=true` deletes its beneficiarys too.
7. List beneficiarys of one camp; count beneficiarys of one camp.
8. Search by text, filter by number, sort descending, list available camps.
9. Calculation: totalAmount for one camp, and totals over all camps (stats).
10. Move a beneficiary from one camp to another.
