package com.example.demo.repository;

import com.example.demo.model.Camp;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CampRepository extends MongoRepository<Camp, String> {
    List<Camp> findByCampNameContainingIgnoreCase(String keyword);        // search
    List<Camp> findByfeePerDoseGreaterThanEqual(Double min);                  // filter by number
}
