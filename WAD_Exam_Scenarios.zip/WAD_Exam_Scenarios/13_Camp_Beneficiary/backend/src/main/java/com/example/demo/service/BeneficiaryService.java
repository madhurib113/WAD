package com.example.demo.service;

import com.example.demo.model.Camp;
import com.example.demo.model.Beneficiary;
import com.example.demo.repository.CampRepository;
import com.example.demo.repository.BeneficiaryRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class BeneficiaryService {

    private final BeneficiaryRepository beneficiarys;
    private final CampRepository camps;

    public BeneficiaryService(BeneficiaryRepository beneficiarys, CampRepository camps) {
        this.beneficiarys = beneficiarys;
        this.camps = camps;
    }

    private void validate(Beneficiary x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getCampId() == null || x.getCampId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "campId is required");
    }

    // The referenced camp must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkCamp(String id, boolean checkLimit) {
        Camp p = camps.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "campId does not exist: " + id));
        if (checkLimit && beneficiarys.countByCampId(id) >= p.getslots())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "camp is full");
    }

    public Beneficiary getById(String id) {
        return beneficiarys.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Beneficiary not found with id " + id));
    }

    public Beneficiary create(Beneficiary x) {
        validate(x);
        checkCamp(x.getCampId(), true);
        x.setId(null);
        return beneficiarys.save(x);
    }

    // optional filter by related record: ?campId=...
    public List<Beneficiary> getAll(String campId) {
        if (campId == null || campId.isBlank()) return beneficiarys.findAll();
        return beneficiarys.findByCampId(campId);
    }

    public List<Beneficiary> search(String keyword) { return beneficiarys.findByNameContainingIgnoreCase(keyword); }

    public Beneficiary update(String id, Beneficiary in) {
        Beneficiary existing = getById(id);
        validate(in);
        boolean moving = !in.getCampId().equals(existing.getCampId());
        checkCamp(in.getCampId(), moving);       // free-place check only when moving to another camp
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setCampId(in.getCampId());
        return beneficiarys.save(existing);
    }

    public void delete(String id) {
        getById(id);
        beneficiarys.deleteById(id);
    }

    public long count(String campId) {
        if (campId == null || campId.isBlank()) return beneficiarys.count();
        return beneficiarys.countByCampId(campId);
    }
}
