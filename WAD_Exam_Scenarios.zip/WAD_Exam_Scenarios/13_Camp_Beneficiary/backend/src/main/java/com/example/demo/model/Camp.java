package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: camps
@Document(collection = "camps")
public class Camp {

    @Id
    private String id;

    private String campName;
    private String doctor;
    private String location;
    private Integer slots;
    private Double feePerDose;

    public Camp() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCampName() { return campName; }
    public void setCampName(String campName) { this.campName = campName; }
    public String getDoctor() { return doctor; }
    public void setDoctor(String doctor) { this.doctor = doctor; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Integer getSlots() { return slots; }
    public void setSlots(Integer slots) { this.slots = slots; }
    public Double getFeePerDose() { return feePerDose; }
    public void setFeePerDose(Double feePerDose) { this.feePerDose = feePerDose; }
}
