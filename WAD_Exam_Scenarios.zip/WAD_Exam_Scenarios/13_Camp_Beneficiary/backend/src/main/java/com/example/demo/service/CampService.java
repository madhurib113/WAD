package com.example.demo.service;

import com.example.demo.model.Camp;
import com.example.demo.model.Beneficiary;
import com.example.demo.repository.CampRepository;
import com.example.demo.repository.BeneficiaryRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class CampService {

    private final CampRepository camps;
    private final BeneficiaryRepository beneficiarys;

    public CampService(CampRepository camps, BeneficiaryRepository beneficiarys) {
        this.camps = camps;
        this.beneficiarys = beneficiarys;
    }

    private void validate(Camp x) {
        if (x.getCampName() == null || x.getCampName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "campName is required");
        if (x.getDoctor() == null || x.getDoctor().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "doctor is required");
        if (x.getslots() == null || x.getslots() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "slots is required and must be > 0");
        if (x.getfeePerDose() == null || x.getfeePerDose() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "feePerDose is required and must be >= 0");
    }

    public Camp getById(String id) {
        return camps.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Camp not found with id " + id));
    }

    // ---------- CRUD ----------
    public Camp create(Camp x) {
        validate(x);
        x.setId(null);
        return camps.save(x);
    }

    public List<Camp> getAll() { return camps.findAll(); }

    public Camp update(String id, Camp in) {
        Camp existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of beneficiarys already added
        long used = beneficiarys.countByCampId(id);
        if (in.getslots() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "slots cannot be less than the " + used + " existing beneficiarys");
        existing.setCampName(in.getCampName());
        existing.setDoctor(in.getDoctor());
        existing.setLocation(in.getLocation());
        existing.setSlots(in.getSlots());
        existing.setFeePerDose(in.getFeePerDose());
        return camps.save(existing);
    }

    // a camp that still has beneficiarys is NOT deleted unless cascade=true (then its beneficiarys are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = beneficiarys.countByCampId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "camp has " + used + " beneficiarys; delete them first or use cascade=true");
        beneficiarys.deleteByCampId(id);
        camps.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Camp> search(String keyword) { return camps.findByCampNameContainingIgnoreCase(keyword); }

    public List<Camp> filterByfeePerDose(Double min) { return camps.findByfeePerDoseGreaterThanEqual(min); }

    public List<Camp> sortedByfeePerDose() { return camps.findAll(Sort.by(Sort.Direction.DESC, "feePerDose")); }

    // only the camps that still have a free place
    public List<Camp> available() {
        List<Camp> result = new ArrayList<>();
        for (Camp x : camps.findAll())
            if (beneficiarys.countByCampId(x.getId()) < x.getslots()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Beneficiary> beneficiarysOf(String id) {
        getById(id);                              // 404 if the camp is missing
        return beneficiarys.findByCampId(id);
    }

    // count + calculations across the two collections for ONE camp
    public Map<String, Object> summary(String id) {
        Camp x = getById(id);
        long count = beneficiarys.countByCampId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("campId", x.getId());
        m.put("name", x.getCampName());
        m.put("slots", x.getslots());
        m.put("beneficiaryCount", count);
        m.put("placesLeft", x.getslots() - count);
        m.put("feePerDose", x.getfeePerDose());
        m.put("totalAmount", count * x.getfeePerDose());
        return m;
    }

    // totals across ALL camps
    public Map<String, Object> stats() {
        long totalBeneficiary = 0;
        double totalAmount = 0;
        List<Camp> all = camps.findAll();
        for (Camp x : all) {
            long c = beneficiarys.countByCampId(x.getId());
            totalBeneficiary += c;
            totalAmount += c * x.getfeePerDose();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalCamps", all.size());
        m.put("totalBeneficiarys", totalBeneficiary);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
