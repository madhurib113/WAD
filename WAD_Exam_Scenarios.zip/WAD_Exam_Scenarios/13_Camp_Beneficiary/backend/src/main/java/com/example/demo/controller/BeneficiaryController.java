package com.example.demo.controller;

import com.example.demo.model.Beneficiary;
import com.example.demo.service.BeneficiaryService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/beneficiarys")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class BeneficiaryController {

    private final BeneficiaryService service;

    public BeneficiaryController(BeneficiaryService service) { this.service = service; }

    @PostMapping                                   // POST   /api/beneficiarys   -> 201 / 400 (bad camp) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Beneficiary create(@RequestBody Beneficiary x) { return service.create(x); }

    @GetMapping                                    // GET    /api/beneficiarys[?campId=..]  (filter by related record)
    public List<Beneficiary> getAll(@RequestParam(required = false) String campId) { return service.getAll(campId); }

    @GetMapping("/{id}")                           // GET    /api/beneficiarys/{id}   -> 200 / 404
    public Beneficiary getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/beneficiarys/{id}
    public Beneficiary update(@PathVariable String id, @RequestBody Beneficiary x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/beneficiarys/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/beneficiarys/search?keyword=an
    public List<Beneficiary> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/beneficiarys/count[?campId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String campId) {
        return Map.of("count", service.count(campId));
    }
}
