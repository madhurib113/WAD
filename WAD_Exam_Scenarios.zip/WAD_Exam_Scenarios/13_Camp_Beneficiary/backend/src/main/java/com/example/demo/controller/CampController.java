package com.example.demo.controller;

import com.example.demo.model.Camp;
import com.example.demo.model.Beneficiary;
import com.example.demo.service.CampService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/camps")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class CampController {

    private final CampService service;

    public CampController(CampService service) { this.service = service; }

    @PostMapping                                   // POST   /api/camps                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Camp create(@RequestBody Camp x) { return service.create(x); }

    @GetMapping                                    // GET    /api/camps
    public List<Camp> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/camps/{id}            -> 200 / 404
    public Camp getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/camps/{id}            -> 200 / 400 / 404 / 409
    public Camp update(@PathVariable String id, @RequestBody Camp x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/camps/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/camps/search?keyword=ab
    public List<Camp> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/camps/filter?minfeePerDose=500
    public List<Camp> filter(@RequestParam Double minfeePerDose) { return service.filterByfeePerDose(minfeePerDose); }

    @GetMapping("/sorted")                         // GET    /api/camps/sorted          (feePerDose high -> low)
    public List<Camp> sorted() { return service.sortedByfeePerDose(); }

    @GetMapping("/available")                      // GET    /api/camps/available       (still have free places)
    public List<Camp> available() { return service.available(); }

    @GetMapping("/{id}/beneficiarys")                    // GET    /api/camps/{id}/beneficiarys     (related records)
    public List<Beneficiary> related(@PathVariable String id) { return service.beneficiarysOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/camps/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/camps/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
