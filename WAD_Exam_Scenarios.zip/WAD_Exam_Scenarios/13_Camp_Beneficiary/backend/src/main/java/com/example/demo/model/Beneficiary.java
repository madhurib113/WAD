package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: beneficiarys
// campId stores the _id of a Camp as plain text. MongoDB has NO foreign keys,
// so BeneficiaryService checks that the camp exists before saving.
@Document(collection = "beneficiarys")
public class Beneficiary {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String campId;    // required: reference to camps._id

    public Beneficiary() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getCampId() { return campId; }
    public void setCampId(String campId) { this.campId = campId; }
}
