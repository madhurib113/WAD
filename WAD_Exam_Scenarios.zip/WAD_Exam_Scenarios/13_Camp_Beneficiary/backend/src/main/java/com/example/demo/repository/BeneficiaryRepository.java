package com.example.demo.repository;

import com.example.demo.model.Beneficiary;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BeneficiaryRepository extends MongoRepository<Beneficiary, String> {
    List<Beneficiary> findByCampId(String campId);                    // filter by the related record
    long countByCampId(String campId);                          // count related records
    long deleteByCampId(String campId);                         // cascade delete
    List<Beneficiary> findByNameContainingIgnoreCase(String keyword); // search
}
