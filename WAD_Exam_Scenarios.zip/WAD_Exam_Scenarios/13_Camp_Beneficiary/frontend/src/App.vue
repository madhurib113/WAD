<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import CampForm from './components/CampForm.vue'
import CampList from './components/CampList.vue'
import BeneficiaryForm from './components/BeneficiaryForm.vue'
import BeneficiaryList from './components/BeneficiaryList.vue'
import ResultBox from './components/ResultBox.vue'

const CAMPS = 'http://localhost:8080/api/camps'
const BENEFICIARYS = 'http://localhost:8080/api/beneficiarys'

const camps = ref([])
const beneficiarys = ref([])
const campForm = ref({ campName: '', doctor: '', location: '', slots: '', feePerDose: '' })
const editingCampId = ref('')
const beneficiaryForm = ref({ name: '', phone: '', campId: '' })
const editingBeneficiaryId = ref('')
const filterCampId = ref('')
const keyword = ref('')
const minfeePerDose = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Camp ----------
async function loadCamps() {
  try { camps.value = (await axios.get(CAMPS)).data } catch (e) { showError(e) }
}

async function saveCamp() {
  error.value = ''
  const body = { ...campForm.value, slots: num(campForm.value.slots), feePerDose: num(campForm.value.feePerDose) }
  try {
    if (editingCampId.value === '') await axios.post(CAMPS, body)
    else await axios.put(CAMPS + '/' + editingCampId.value, body)
    cancelCamp()
    loadCamps()
  } catch (e) { showError(e) }
}

function editCamp(x) {
  campForm.value = { ...x }
  editingCampId.value = x.id
}

function cancelCamp() {
  campForm.value = { campName: '', doctor: '', location: '', slots: '', feePerDose: '' }
  editingCampId.value = ''
}

// cascade = true also deletes the beneficiarys; false -> error 409 if there are beneficiarys
async function deleteCamp(id, cascade) {
  error.value = ''
  try {
    await axios.delete(CAMPS + '/' + id, { params: { cascade } })
    loadCamps()
    loadBeneficiarys()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Beneficiary ----------
async function loadBeneficiarys() {
  try { beneficiarys.value = (await axios.get(BENEFICIARYS, { params: { campId: filterCampId.value } })).data } catch (e) { showError(e) }
}

async function saveBeneficiary() {
  error.value = ''
  try {
    if (editingBeneficiaryId.value === '') await axios.post(BENEFICIARYS, beneficiaryForm.value)
    else await axios.put(BENEFICIARYS + '/' + editingBeneficiaryId.value, beneficiaryForm.value)
    cancelBeneficiary()
    loadBeneficiarys()
  } catch (e) { showError(e) }
}

function editBeneficiary(x) {
  beneficiaryForm.value = { name: x.name, phone: x.phone, campId: x.campId }
  editingBeneficiaryId.value = x.id
}

function cancelBeneficiary() {
  beneficiaryForm.value = { name: '', phone: '', campId: '' }
  editingBeneficiaryId.value = ''
}

async function deleteBeneficiary(id) {
  error.value = ''
  try {
    await axios.delete(BENEFICIARYS + '/' + id)
    loadBeneficiarys()
  } catch (e) { showError(e) }
}

onMounted(() => { loadCamps(); loadBeneficiarys() })
</script>

<template>
  <h1>Camp - Beneficiary Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Camps</h2>
  <CampForm :form="campForm" :editing="editingCampId !== ''" @save="saveCamp" @cancel="cancelCamp" />
  <div class="box">
    <input v-model="keyword" placeholder="search campName" />
    <button @click="showGet(CAMPS + '/search', { keyword })">Search</button>
    <input v-model="minfeePerDose" type="number" placeholder="min feePerDose" />
    <button @click="showGet(CAMPS + '/filter', { minfeePerDose })">Filter</button>
    <button @click="showGet(CAMPS + '/sorted')">Sort by feePerDose</button>
    <button @click="showGet(CAMPS + '/available')">Available</button>
    <button @click="showGet(CAMPS + '/stats')">Stats</button>
  </div>
  <CampList :items="camps" @edit="editCamp" @remove="deleteCamp"
    @related="(id) => showGet(CAMPS + '/' + id + '/beneficiarys')" @summary="(id) => showGet(CAMPS + '/' + id + '/summary')" />

  <h2>Beneficiarys</h2>
  <BeneficiaryForm :form="beneficiaryForm" :editing="editingBeneficiaryId !== ''" :parents="camps" @save="saveBeneficiary" @cancel="cancelBeneficiary" />
  <div class="box">
    <select v-model="filterCampId" @change="loadBeneficiarys">
      <option value="">All camps</option>
      <option v-for="p in camps" :key="p.id" :value="p.id">{{ p.campName }}</option>
    </select>
    <button @click="showGet(BENEFICIARYS + '/count', { campId: filterCampId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(BENEFICIARYS + '/search', { keyword })">Search</button>
  </div>
  <BeneficiaryList :items="beneficiarys" :parents="camps" @edit="editBeneficiary" @remove="deleteBeneficiary" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
