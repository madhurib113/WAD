<script setup>
// Table of Beneficiary records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the camp name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Name</th><th>Phone</th><th>Camp</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.name }}</td>
        <td>{{ x.phone }}</td>
        <td>{{ (parents.find(p => p.id === x.campId) || {}).campName || x.campId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
