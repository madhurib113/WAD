<script setup>
// Table of Camp records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'campName', label: 'Camp Name', type: 'text' },
  { key: 'doctor', label: 'Doctor', type: 'text' },
  { key: 'location', label: 'Location', type: 'text' },
  { key: 'slots', label: 'Slots', type: 'number' },
  { key: 'feePerDose', label: 'Fee Per Dose', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Beneficiarys</button>
          <button @click="$emit('related', x.id)">Beneficiarys</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
