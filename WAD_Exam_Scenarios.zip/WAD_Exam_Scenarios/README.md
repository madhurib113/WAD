# WAD Exam Scenarios (14 x 2-collection Spring Boot + MongoDB + Vue)

Every scenario has the SAME structure (same pom.xml, Boot 4.1.1, Java 17, same package layout, same endpoints,
same Vue components). Only the names/fields change. No tests / MockMvc.

| # | Folder | Collection 1 (ONE) | Collection 2 (MANY) | Database |
|---|---|---|---|---|
| 1 | 01_Course_Student | courses | students | course_db |
| 2 | 02_Doctor_Patient | doctors | patients | doctor_db |
| 3 | 03_Room_Guest | rooms | guests | room_db |
| 4 | 04_Book_Borrower | books | borrowers | book_db |
| 5 | 05_Movie_Booking | movies | bookings | movie_db |
| 6 | 06_Bus_Passenger | buss | passengers | bus_db |
| 7 | 07_Department_Employee | departments | employees | department_db |
| 8 | 08_Trainer_Member | trainers | members | trainer_db |
| 9 | 09_Hostel_Resident | hostels | residents | hostel_db |
| 10 | 10_Flight_Passenger | flights | passengers | flight_db |
| 11 | 11_Project_Developer | projects | developers | project_db |
| 12 | 12_Team_Player | teams | players | team_db |
| 13 | 13_Camp_Beneficiary | camps | beneficiarys | camp_db |
| 14 | 14_Event_Participant | events | participants | event_db |

## Run any scenario
1. Start MongoDB, import `sample_data/*.json` with `mongoimport` (commands are in each scenario README).
2. Backend: `cd backend && ./mvnw spring-boot:run` (port 8080)
3. Frontend: `cd frontend && npm install && npm run dev` (port 5173)

## Folder layout (same in all)
```
backend/src/main/java/com/example/demo/{model,repository,service,controller,exception}
frontend/src/App.vue + components/{Parent}Form, {Parent}List, {Child}Form, {Child}List, ResultBox
```
Each scenario README lists all endpoints and the typical exam questions covered.
