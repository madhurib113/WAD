<script setup>
// Form for the "MANY" side (Booking). The movie is chosen from a dropdown.
defineProps({ form: Object, editing: Boolean, parents: Array })
defineEmits(['save', 'cancel'])
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Booking</h3>
    <input v-model="form.name" placeholder="Name" />
    <input v-model="form.phone" placeholder="Phone" />
    <select v-model="form.movieId">
      <option value="">-- select movie --</option>
      <option v-for="p in parents" :key="p.id" :value="p.id">{{ p.title }}</option>
    </select>
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
