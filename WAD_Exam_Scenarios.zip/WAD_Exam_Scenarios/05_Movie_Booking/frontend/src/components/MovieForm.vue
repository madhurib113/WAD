<script setup>
// Form for the "ONE" side (Movie). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'title', label: 'Title', type: 'text' },
  { key: 'language', label: 'Language', type: 'text' },
  { key: 'theatre', label: 'Theatre', type: 'text' },
  { key: 'seats', label: 'Seats', type: 'number' },
  { key: 'ticketPrice', label: 'Ticket Price', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Movie</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
