<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import MovieForm from './components/MovieForm.vue'
import MovieList from './components/MovieList.vue'
import BookingForm from './components/BookingForm.vue'
import BookingList from './components/BookingList.vue'
import ResultBox from './components/ResultBox.vue'

const MOVIES = 'http://localhost:8080/api/movies'
const BOOKINGS = 'http://localhost:8080/api/bookings'

const movies = ref([])
const bookings = ref([])
const movieForm = ref({ title: '', language: '', theatre: '', seats: '', ticketPrice: '' })
const editingMovieId = ref('')
const bookingForm = ref({ name: '', phone: '', movieId: '' })
const editingBookingId = ref('')
const filterMovieId = ref('')
const keyword = ref('')
const minticketPrice = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Movie ----------
async function loadMovies() {
  try { movies.value = (await axios.get(MOVIES)).data } catch (e) { showError(e) }
}

async function saveMovie() {
  error.value = ''
  const body = { ...movieForm.value, seats: num(movieForm.value.seats), ticketPrice: num(movieForm.value.ticketPrice) }
  try {
    if (editingMovieId.value === '') await axios.post(MOVIES, body)
    else await axios.put(MOVIES + '/' + editingMovieId.value, body)
    cancelMovie()
    loadMovies()
  } catch (e) { showError(e) }
}

function editMovie(x) {
  movieForm.value = { ...x }
  editingMovieId.value = x.id
}

function cancelMovie() {
  movieForm.value = { title: '', language: '', theatre: '', seats: '', ticketPrice: '' }
  editingMovieId.value = ''
}

// cascade = true also deletes the bookings; false -> error 409 if there are bookings
async function deleteMovie(id, cascade) {
  error.value = ''
  try {
    await axios.delete(MOVIES + '/' + id, { params: { cascade } })
    loadMovies()
    loadBookings()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Booking ----------
async function loadBookings() {
  try { bookings.value = (await axios.get(BOOKINGS, { params: { movieId: filterMovieId.value } })).data } catch (e) { showError(e) }
}

async function saveBooking() {
  error.value = ''
  try {
    if (editingBookingId.value === '') await axios.post(BOOKINGS, bookingForm.value)
    else await axios.put(BOOKINGS + '/' + editingBookingId.value, bookingForm.value)
    cancelBooking()
    loadBookings()
  } catch (e) { showError(e) }
}

function editBooking(x) {
  bookingForm.value = { name: x.name, phone: x.phone, movieId: x.movieId }
  editingBookingId.value = x.id
}

function cancelBooking() {
  bookingForm.value = { name: '', phone: '', movieId: '' }
  editingBookingId.value = ''
}

async function deleteBooking(id) {
  error.value = ''
  try {
    await axios.delete(BOOKINGS + '/' + id)
    loadBookings()
  } catch (e) { showError(e) }
}

onMounted(() => { loadMovies(); loadBookings() })
</script>

<template>
  <h1>Movie - Booking Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Movies</h2>
  <MovieForm :form="movieForm" :editing="editingMovieId !== ''" @save="saveMovie" @cancel="cancelMovie" />
  <div class="box">
    <input v-model="keyword" placeholder="search title" />
    <button @click="showGet(MOVIES + '/search', { keyword })">Search</button>
    <input v-model="minticketPrice" type="number" placeholder="min ticketPrice" />
    <button @click="showGet(MOVIES + '/filter', { minticketPrice })">Filter</button>
    <button @click="showGet(MOVIES + '/sorted')">Sort by ticketPrice</button>
    <button @click="showGet(MOVIES + '/available')">Available</button>
    <button @click="showGet(MOVIES + '/stats')">Stats</button>
  </div>
  <MovieList :items="movies" @edit="editMovie" @remove="deleteMovie"
    @related="(id) => showGet(MOVIES + '/' + id + '/bookings')" @summary="(id) => showGet(MOVIES + '/' + id + '/summary')" />

  <h2>Bookings</h2>
  <BookingForm :form="bookingForm" :editing="editingBookingId !== ''" :parents="movies" @save="saveBooking" @cancel="cancelBooking" />
  <div class="box">
    <select v-model="filterMovieId" @change="loadBookings">
      <option value="">All movies</option>
      <option v-for="p in movies" :key="p.id" :value="p.id">{{ p.title }}</option>
    </select>
    <button @click="showGet(BOOKINGS + '/count', { movieId: filterMovieId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(BOOKINGS + '/search', { keyword })">Search</button>
  </div>
  <BookingList :items="bookings" :parents="movies" @edit="editBooking" @remove="deleteBooking" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
