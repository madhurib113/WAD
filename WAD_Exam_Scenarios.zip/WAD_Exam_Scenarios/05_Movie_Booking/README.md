# Movie - Booking (2 collections: `movies` and `bookings`)

Database `movie_db`. `bookings.movieId` stores the `_id` of a movie (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db movie_db --collection movies --jsonArray --file sample_data/movies.json
mongoimport --db movie_db --collection bookings --jsonArray --file sample_data/bookings.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Movie**: title*, language*, theatre, seats* (> 0), ticketPrice* (>= 0)    (* = required)
- **Booking**: name*, phone*, movieId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/movies | create (Movie) 201 / 400 |
| GET | /api/movies , /api/movies/{id} | all / one (404) |
| PUT | /api/movies/{id} | update 200 / 400 / 404 / 409 (`seats` below existing bookings) |
| DELETE | /api/movies/{id}?cascade=true | 204 / 404 / 409 (has bookings and no cascade) |
| GET | /api/movies/search?keyword= | search by title |
| GET | /api/movies/filter?minticketPrice= | ticketPrice >= value |
| GET | /api/movies/sorted | sort by ticketPrice desc |
| GET | /api/movies/available | movies that still have free places |
| GET | /api/movies/{id}/bookings | related bookings |
| GET | /api/movies/{id}/summary | count, placesLeft, totalAmount = count x ticketPrice |
| GET | /api/movies/stats | totals over all movies |
| POST | /api/bookings | create (Booking) 201 / 400 (bad movieId) / 409 (full) |
| GET | /api/bookings?movieId= | all / filter by movie |
| GET | /api/bookings/{id} | one (404) |
| PUT | /api/bookings/{id} | update (move to another movie: free place checked) |
| DELETE | /api/bookings/{id} | 204 / 404 |
| GET | /api/bookings/search?keyword= | search by name |
| GET | /api/bookings/count?movieId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on movies and on bookings.
3. Validation: missing field -> 400, seats <= 0 -> 400, ticketPrice < 0 -> 400, unknown id -> 404.
4. Add a booking only if the movie exists (400) and is not full (409).
5. Update movie: seats cannot be lower than current number of bookings (409).
6. Delete movie: blocked if it has bookings (409); `cascade=true` deletes its bookings too.
7. List bookings of one movie; count bookings of one movie.
8. Search by text, filter by number, sort descending, list available movies.
9. Calculation: totalAmount for one movie, and totals over all movies (stats).
10. Move a booking from one movie to another.
