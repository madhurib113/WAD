package com.example.demo.service;

import com.example.demo.model.Movie;
import com.example.demo.model.Booking;
import com.example.demo.repository.MovieRepository;
import com.example.demo.repository.BookingRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class BookingService {

    private final BookingRepository bookings;
    private final MovieRepository movies;

    public BookingService(BookingRepository bookings, MovieRepository movies) {
        this.bookings = bookings;
        this.movies = movies;
    }

    private void validate(Booking x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getMovieId() == null || x.getMovieId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "movieId is required");
    }

    // The referenced movie must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkMovie(String id, boolean checkLimit) {
        Movie p = movies.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "movieId does not exist: " + id));
        if (checkLimit && bookings.countByMovieId(id) >= p.getseats())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "movie is full");
    }

    public Booking getById(String id) {
        return bookings.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking not found with id " + id));
    }

    public Booking create(Booking x) {
        validate(x);
        checkMovie(x.getMovieId(), true);
        x.setId(null);
        return bookings.save(x);
    }

    // optional filter by related record: ?movieId=...
    public List<Booking> getAll(String movieId) {
        if (movieId == null || movieId.isBlank()) return bookings.findAll();
        return bookings.findByMovieId(movieId);
    }

    public List<Booking> search(String keyword) { return bookings.findByNameContainingIgnoreCase(keyword); }

    public Booking update(String id, Booking in) {
        Booking existing = getById(id);
        validate(in);
        boolean moving = !in.getMovieId().equals(existing.getMovieId());
        checkMovie(in.getMovieId(), moving);       // free-place check only when moving to another movie
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setMovieId(in.getMovieId());
        return bookings.save(existing);
    }

    public void delete(String id) {
        getById(id);
        bookings.deleteById(id);
    }

    public long count(String movieId) {
        if (movieId == null || movieId.isBlank()) return bookings.count();
        return bookings.countByMovieId(movieId);
    }
}
