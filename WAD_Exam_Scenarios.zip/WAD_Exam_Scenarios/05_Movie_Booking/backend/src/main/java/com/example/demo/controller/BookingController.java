package com.example.demo.controller;

import com.example.demo.model.Booking;
import com.example.demo.service.BookingService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class BookingController {

    private final BookingService service;

    public BookingController(BookingService service) { this.service = service; }

    @PostMapping                                   // POST   /api/bookings   -> 201 / 400 (bad movie) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Booking create(@RequestBody Booking x) { return service.create(x); }

    @GetMapping                                    // GET    /api/bookings[?movieId=..]  (filter by related record)
    public List<Booking> getAll(@RequestParam(required = false) String movieId) { return service.getAll(movieId); }

    @GetMapping("/{id}")                           // GET    /api/bookings/{id}   -> 200 / 404
    public Booking getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/bookings/{id}
    public Booking update(@PathVariable String id, @RequestBody Booking x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/bookings/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/bookings/search?keyword=an
    public List<Booking> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/bookings/count[?movieId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String movieId) {
        return Map.of("count", service.count(movieId));
    }
}
