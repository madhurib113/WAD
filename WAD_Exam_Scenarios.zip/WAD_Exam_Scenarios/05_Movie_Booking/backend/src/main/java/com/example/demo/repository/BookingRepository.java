package com.example.demo.repository;

import com.example.demo.model.Booking;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BookingRepository extends MongoRepository<Booking, String> {
    List<Booking> findByMovieId(String movieId);                    // filter by the related record
    long countByMovieId(String movieId);                          // count related records
    long deleteByMovieId(String movieId);                         // cascade delete
    List<Booking> findByNameContainingIgnoreCase(String keyword); // search
}
