package com.example.demo.controller;

import com.example.demo.model.Movie;
import com.example.demo.model.Booking;
import com.example.demo.service.MovieService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/movies")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class MovieController {

    private final MovieService service;

    public MovieController(MovieService service) { this.service = service; }

    @PostMapping                                   // POST   /api/movies                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Movie create(@RequestBody Movie x) { return service.create(x); }

    @GetMapping                                    // GET    /api/movies
    public List<Movie> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/movies/{id}            -> 200 / 404
    public Movie getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/movies/{id}            -> 200 / 400 / 404 / 409
    public Movie update(@PathVariable String id, @RequestBody Movie x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/movies/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/movies/search?keyword=ab
    public List<Movie> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/movies/filter?minticketPrice=500
    public List<Movie> filter(@RequestParam Double minticketPrice) { return service.filterByticketPrice(minticketPrice); }

    @GetMapping("/sorted")                         // GET    /api/movies/sorted          (ticketPrice high -> low)
    public List<Movie> sorted() { return service.sortedByticketPrice(); }

    @GetMapping("/available")                      // GET    /api/movies/available       (still have free places)
    public List<Movie> available() { return service.available(); }

    @GetMapping("/{id}/bookings")                    // GET    /api/movies/{id}/bookings     (related records)
    public List<Booking> related(@PathVariable String id) { return service.bookingsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/movies/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/movies/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
