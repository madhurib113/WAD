package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: bookings
// movieId stores the _id of a Movie as plain text. MongoDB has NO foreign keys,
// so BookingService checks that the movie exists before saving.
@Document(collection = "bookings")
public class Booking {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String movieId;    // required: reference to movies._id

    public Booking() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getMovieId() { return movieId; }
    public void setMovieId(String movieId) { this.movieId = movieId; }
}
