package com.example.demo.repository;

import com.example.demo.model.Movie;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MovieRepository extends MongoRepository<Movie, String> {
    List<Movie> findByTitleContainingIgnoreCase(String keyword);        // search
    List<Movie> findByticketPriceGreaterThanEqual(Double min);                  // filter by number
}
