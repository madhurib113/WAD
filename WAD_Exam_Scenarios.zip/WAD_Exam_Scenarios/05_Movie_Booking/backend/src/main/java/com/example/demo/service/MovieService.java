package com.example.demo.service;

import com.example.demo.model.Movie;
import com.example.demo.model.Booking;
import com.example.demo.repository.MovieRepository;
import com.example.demo.repository.BookingRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class MovieService {

    private final MovieRepository movies;
    private final BookingRepository bookings;

    public MovieService(MovieRepository movies, BookingRepository bookings) {
        this.movies = movies;
        this.bookings = bookings;
    }

    private void validate(Movie x) {
        if (x.getTitle() == null || x.getTitle().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "title is required");
        if (x.getLanguage() == null || x.getLanguage().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "language is required");
        if (x.getseats() == null || x.getseats() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "seats is required and must be > 0");
        if (x.getticketPrice() == null || x.getticketPrice() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "ticketPrice is required and must be >= 0");
    }

    public Movie getById(String id) {
        return movies.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Movie not found with id " + id));
    }

    // ---------- CRUD ----------
    public Movie create(Movie x) {
        validate(x);
        x.setId(null);
        return movies.save(x);
    }

    public List<Movie> getAll() { return movies.findAll(); }

    public Movie update(String id, Movie in) {
        Movie existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of bookings already added
        long used = bookings.countByMovieId(id);
        if (in.getseats() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "seats cannot be less than the " + used + " existing bookings");
        existing.setTitle(in.getTitle());
        existing.setLanguage(in.getLanguage());
        existing.setTheatre(in.getTheatre());
        existing.setSeats(in.getSeats());
        existing.setTicketPrice(in.getTicketPrice());
        return movies.save(existing);
    }

    // a movie that still has bookings is NOT deleted unless cascade=true (then its bookings are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = bookings.countByMovieId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "movie has " + used + " bookings; delete them first or use cascade=true");
        bookings.deleteByMovieId(id);
        movies.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Movie> search(String keyword) { return movies.findByTitleContainingIgnoreCase(keyword); }

    public List<Movie> filterByticketPrice(Double min) { return movies.findByticketPriceGreaterThanEqual(min); }

    public List<Movie> sortedByticketPrice() { return movies.findAll(Sort.by(Sort.Direction.DESC, "ticketPrice")); }

    // only the movies that still have a free place
    public List<Movie> available() {
        List<Movie> result = new ArrayList<>();
        for (Movie x : movies.findAll())
            if (bookings.countByMovieId(x.getId()) < x.getseats()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Booking> bookingsOf(String id) {
        getById(id);                              // 404 if the movie is missing
        return bookings.findByMovieId(id);
    }

    // count + calculations across the two collections for ONE movie
    public Map<String, Object> summary(String id) {
        Movie x = getById(id);
        long count = bookings.countByMovieId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("movieId", x.getId());
        m.put("name", x.getTitle());
        m.put("seats", x.getseats());
        m.put("bookingCount", count);
        m.put("placesLeft", x.getseats() - count);
        m.put("ticketPrice", x.getticketPrice());
        m.put("totalAmount", count * x.getticketPrice());
        return m;
    }

    // totals across ALL movies
    public Map<String, Object> stats() {
        long totalBooking = 0;
        double totalAmount = 0;
        List<Movie> all = movies.findAll();
        for (Movie x : all) {
            long c = bookings.countByMovieId(x.getId());
            totalBooking += c;
            totalAmount += c * x.getticketPrice();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalMovies", all.size());
        m.put("totalBookings", totalBooking);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
