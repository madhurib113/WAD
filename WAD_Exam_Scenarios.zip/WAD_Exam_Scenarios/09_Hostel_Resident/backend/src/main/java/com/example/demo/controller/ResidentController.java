package com.example.demo.controller;

import com.example.demo.model.Resident;
import com.example.demo.service.ResidentService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/residents")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class ResidentController {

    private final ResidentService service;

    public ResidentController(ResidentService service) { this.service = service; }

    @PostMapping                                   // POST   /api/residents   -> 201 / 400 (bad hostel) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Resident create(@RequestBody Resident x) { return service.create(x); }

    @GetMapping                                    // GET    /api/residents[?hostelId=..]  (filter by related record)
    public List<Resident> getAll(@RequestParam(required = false) String hostelId) { return service.getAll(hostelId); }

    @GetMapping("/{id}")                           // GET    /api/residents/{id}   -> 200 / 404
    public Resident getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/residents/{id}
    public Resident update(@PathVariable String id, @RequestBody Resident x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/residents/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/residents/search?keyword=an
    public List<Resident> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/residents/count[?hostelId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String hostelId) {
        return Map.of("count", service.count(hostelId));
    }
}
