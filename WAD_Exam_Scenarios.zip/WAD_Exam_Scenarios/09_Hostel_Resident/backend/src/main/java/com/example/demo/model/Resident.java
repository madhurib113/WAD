package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: residents
// hostelId stores the _id of a Hostel as plain text. MongoDB has NO foreign keys,
// so ResidentService checks that the hostel exists before saving.
@Document(collection = "residents")
public class Resident {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String hostelId;    // required: reference to hostels._id

    public Resident() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getHostelId() { return hostelId; }
    public void setHostelId(String hostelId) { this.hostelId = hostelId; }
}
