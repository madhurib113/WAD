package com.example.demo.service;

import com.example.demo.model.Hostel;
import com.example.demo.model.Resident;
import com.example.demo.repository.HostelRepository;
import com.example.demo.repository.ResidentRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class HostelService {

    private final HostelRepository hostels;
    private final ResidentRepository residents;

    public HostelService(HostelRepository hostels, ResidentRepository residents) {
        this.hostels = hostels;
        this.residents = residents;
    }

    private void validate(Hostel x) {
        if (x.getHostelName() == null || x.getHostelName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "hostelName is required");
        if (x.getWarden() == null || x.getWarden().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "warden is required");
        if (x.getrooms() == null || x.getrooms() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "rooms is required and must be > 0");
        if (x.getrentPerMonth() == null || x.getrentPerMonth() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "rentPerMonth is required and must be >= 0");
    }

    public Hostel getById(String id) {
        return hostels.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Hostel not found with id " + id));
    }

    // ---------- CRUD ----------
    public Hostel create(Hostel x) {
        validate(x);
        x.setId(null);
        return hostels.save(x);
    }

    public List<Hostel> getAll() { return hostels.findAll(); }

    public Hostel update(String id, Hostel in) {
        Hostel existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of residents already added
        long used = residents.countByHostelId(id);
        if (in.getrooms() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "rooms cannot be less than the " + used + " existing residents");
        existing.setHostelName(in.getHostelName());
        existing.setWarden(in.getWarden());
        existing.setLocation(in.getLocation());
        existing.setRooms(in.getRooms());
        existing.setRentPerMonth(in.getRentPerMonth());
        return hostels.save(existing);
    }

    // a hostel that still has residents is NOT deleted unless cascade=true (then its residents are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = residents.countByHostelId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "hostel has " + used + " residents; delete them first or use cascade=true");
        residents.deleteByHostelId(id);
        hostels.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Hostel> search(String keyword) { return hostels.findByHostelNameContainingIgnoreCase(keyword); }

    public List<Hostel> filterByrentPerMonth(Double min) { return hostels.findByrentPerMonthGreaterThanEqual(min); }

    public List<Hostel> sortedByrentPerMonth() { return hostels.findAll(Sort.by(Sort.Direction.DESC, "rentPerMonth")); }

    // only the hostels that still have a free place
    public List<Hostel> available() {
        List<Hostel> result = new ArrayList<>();
        for (Hostel x : hostels.findAll())
            if (residents.countByHostelId(x.getId()) < x.getrooms()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Resident> residentsOf(String id) {
        getById(id);                              // 404 if the hostel is missing
        return residents.findByHostelId(id);
    }

    // count + calculations across the two collections for ONE hostel
    public Map<String, Object> summary(String id) {
        Hostel x = getById(id);
        long count = residents.countByHostelId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("hostelId", x.getId());
        m.put("name", x.getHostelName());
        m.put("rooms", x.getrooms());
        m.put("residentCount", count);
        m.put("placesLeft", x.getrooms() - count);
        m.put("rentPerMonth", x.getrentPerMonth());
        m.put("totalAmount", count * x.getrentPerMonth());
        return m;
    }

    // totals across ALL hostels
    public Map<String, Object> stats() {
        long totalResident = 0;
        double totalAmount = 0;
        List<Hostel> all = hostels.findAll();
        for (Hostel x : all) {
            long c = residents.countByHostelId(x.getId());
            totalResident += c;
            totalAmount += c * x.getrentPerMonth();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalHostels", all.size());
        m.put("totalResidents", totalResident);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
