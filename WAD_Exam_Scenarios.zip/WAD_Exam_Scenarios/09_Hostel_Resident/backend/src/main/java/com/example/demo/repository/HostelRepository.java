package com.example.demo.repository;

import com.example.demo.model.Hostel;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface HostelRepository extends MongoRepository<Hostel, String> {
    List<Hostel> findByHostelNameContainingIgnoreCase(String keyword);        // search
    List<Hostel> findByrentPerMonthGreaterThanEqual(Double min);                  // filter by number
}
