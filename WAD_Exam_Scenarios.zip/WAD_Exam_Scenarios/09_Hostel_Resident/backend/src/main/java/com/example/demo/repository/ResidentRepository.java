package com.example.demo.repository;

import com.example.demo.model.Resident;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ResidentRepository extends MongoRepository<Resident, String> {
    List<Resident> findByHostelId(String hostelId);                    // filter by the related record
    long countByHostelId(String hostelId);                          // count related records
    long deleteByHostelId(String hostelId);                         // cascade delete
    List<Resident> findByNameContainingIgnoreCase(String keyword); // search
}
