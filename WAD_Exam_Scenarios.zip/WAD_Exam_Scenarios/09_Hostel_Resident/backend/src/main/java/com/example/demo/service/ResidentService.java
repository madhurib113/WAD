package com.example.demo.service;

import com.example.demo.model.Hostel;
import com.example.demo.model.Resident;
import com.example.demo.repository.HostelRepository;
import com.example.demo.repository.ResidentRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ResidentService {

    private final ResidentRepository residents;
    private final HostelRepository hostels;

    public ResidentService(ResidentRepository residents, HostelRepository hostels) {
        this.residents = residents;
        this.hostels = hostels;
    }

    private void validate(Resident x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getHostelId() == null || x.getHostelId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "hostelId is required");
    }

    // The referenced hostel must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkHostel(String id, boolean checkLimit) {
        Hostel p = hostels.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "hostelId does not exist: " + id));
        if (checkLimit && residents.countByHostelId(id) >= p.getrooms())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "hostel is full");
    }

    public Resident getById(String id) {
        return residents.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Resident not found with id " + id));
    }

    public Resident create(Resident x) {
        validate(x);
        checkHostel(x.getHostelId(), true);
        x.setId(null);
        return residents.save(x);
    }

    // optional filter by related record: ?hostelId=...
    public List<Resident> getAll(String hostelId) {
        if (hostelId == null || hostelId.isBlank()) return residents.findAll();
        return residents.findByHostelId(hostelId);
    }

    public List<Resident> search(String keyword) { return residents.findByNameContainingIgnoreCase(keyword); }

    public Resident update(String id, Resident in) {
        Resident existing = getById(id);
        validate(in);
        boolean moving = !in.getHostelId().equals(existing.getHostelId());
        checkHostel(in.getHostelId(), moving);       // free-place check only when moving to another hostel
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setHostelId(in.getHostelId());
        return residents.save(existing);
    }

    public void delete(String id) {
        getById(id);
        residents.deleteById(id);
    }

    public long count(String hostelId) {
        if (hostelId == null || hostelId.isBlank()) return residents.count();
        return residents.countByHostelId(hostelId);
    }
}
