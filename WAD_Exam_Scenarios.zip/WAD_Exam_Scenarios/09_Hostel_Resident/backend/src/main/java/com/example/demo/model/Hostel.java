package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: hostels
@Document(collection = "hostels")
public class Hostel {

    @Id
    private String id;

    private String hostelName;
    private String warden;
    private String location;
    private Integer rooms;
    private Double rentPerMonth;

    public Hostel() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getHostelName() { return hostelName; }
    public void setHostelName(String hostelName) { this.hostelName = hostelName; }
    public String getWarden() { return warden; }
    public void setWarden(String warden) { this.warden = warden; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Integer getRooms() { return rooms; }
    public void setRooms(Integer rooms) { this.rooms = rooms; }
    public Double getRentPerMonth() { return rentPerMonth; }
    public void setRentPerMonth(Double rentPerMonth) { this.rentPerMonth = rentPerMonth; }
}
