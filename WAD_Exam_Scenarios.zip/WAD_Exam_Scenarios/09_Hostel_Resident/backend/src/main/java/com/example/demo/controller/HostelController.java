package com.example.demo.controller;

import com.example.demo.model.Hostel;
import com.example.demo.model.Resident;
import com.example.demo.service.HostelService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/hostels")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class HostelController {

    private final HostelService service;

    public HostelController(HostelService service) { this.service = service; }

    @PostMapping                                   // POST   /api/hostels                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Hostel create(@RequestBody Hostel x) { return service.create(x); }

    @GetMapping                                    // GET    /api/hostels
    public List<Hostel> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/hostels/{id}            -> 200 / 404
    public Hostel getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/hostels/{id}            -> 200 / 400 / 404 / 409
    public Hostel update(@PathVariable String id, @RequestBody Hostel x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/hostels/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/hostels/search?keyword=ab
    public List<Hostel> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/hostels/filter?minrentPerMonth=500
    public List<Hostel> filter(@RequestParam Double minrentPerMonth) { return service.filterByrentPerMonth(minrentPerMonth); }

    @GetMapping("/sorted")                         // GET    /api/hostels/sorted          (rentPerMonth high -> low)
    public List<Hostel> sorted() { return service.sortedByrentPerMonth(); }

    @GetMapping("/available")                      // GET    /api/hostels/available       (still have free places)
    public List<Hostel> available() { return service.available(); }

    @GetMapping("/{id}/residents")                    // GET    /api/hostels/{id}/residents     (related records)
    public List<Resident> related(@PathVariable String id) { return service.residentsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/hostels/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/hostels/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
