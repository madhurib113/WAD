<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import HostelForm from './components/HostelForm.vue'
import HostelList from './components/HostelList.vue'
import ResidentForm from './components/ResidentForm.vue'
import ResidentList from './components/ResidentList.vue'
import ResultBox from './components/ResultBox.vue'

const HOSTELS = 'http://localhost:8080/api/hostels'
const RESIDENTS = 'http://localhost:8080/api/residents'

const hostels = ref([])
const residents = ref([])
const hostelForm = ref({ hostelName: '', warden: '', location: '', rooms: '', rentPerMonth: '' })
const editingHostelId = ref('')
const residentForm = ref({ name: '', phone: '', hostelId: '' })
const editingResidentId = ref('')
const filterHostelId = ref('')
const keyword = ref('')
const minrentPerMonth = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Hostel ----------
async function loadHostels() {
  try { hostels.value = (await axios.get(HOSTELS)).data } catch (e) { showError(e) }
}

async function saveHostel() {
  error.value = ''
  const body = { ...hostelForm.value, rooms: num(hostelForm.value.rooms), rentPerMonth: num(hostelForm.value.rentPerMonth) }
  try {
    if (editingHostelId.value === '') await axios.post(HOSTELS, body)
    else await axios.put(HOSTELS + '/' + editingHostelId.value, body)
    cancelHostel()
    loadHostels()
  } catch (e) { showError(e) }
}

function editHostel(x) {
  hostelForm.value = { ...x }
  editingHostelId.value = x.id
}

function cancelHostel() {
  hostelForm.value = { hostelName: '', warden: '', location: '', rooms: '', rentPerMonth: '' }
  editingHostelId.value = ''
}

// cascade = true also deletes the residents; false -> error 409 if there are residents
async function deleteHostel(id, cascade) {
  error.value = ''
  try {
    await axios.delete(HOSTELS + '/' + id, { params: { cascade } })
    loadHostels()
    loadResidents()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Resident ----------
async function loadResidents() {
  try { residents.value = (await axios.get(RESIDENTS, { params: { hostelId: filterHostelId.value } })).data } catch (e) { showError(e) }
}

async function saveResident() {
  error.value = ''
  try {
    if (editingResidentId.value === '') await axios.post(RESIDENTS, residentForm.value)
    else await axios.put(RESIDENTS + '/' + editingResidentId.value, residentForm.value)
    cancelResident()
    loadResidents()
  } catch (e) { showError(e) }
}

function editResident(x) {
  residentForm.value = { name: x.name, phone: x.phone, hostelId: x.hostelId }
  editingResidentId.value = x.id
}

function cancelResident() {
  residentForm.value = { name: '', phone: '', hostelId: '' }
  editingResidentId.value = ''
}

async function deleteResident(id) {
  error.value = ''
  try {
    await axios.delete(RESIDENTS + '/' + id)
    loadResidents()
  } catch (e) { showError(e) }
}

onMounted(() => { loadHostels(); loadResidents() })
</script>

<template>
  <h1>Hostel - Resident Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Hostels</h2>
  <HostelForm :form="hostelForm" :editing="editingHostelId !== ''" @save="saveHostel" @cancel="cancelHostel" />
  <div class="box">
    <input v-model="keyword" placeholder="search hostelName" />
    <button @click="showGet(HOSTELS + '/search', { keyword })">Search</button>
    <input v-model="minrentPerMonth" type="number" placeholder="min rentPerMonth" />
    <button @click="showGet(HOSTELS + '/filter', { minrentPerMonth })">Filter</button>
    <button @click="showGet(HOSTELS + '/sorted')">Sort by rentPerMonth</button>
    <button @click="showGet(HOSTELS + '/available')">Available</button>
    <button @click="showGet(HOSTELS + '/stats')">Stats</button>
  </div>
  <HostelList :items="hostels" @edit="editHostel" @remove="deleteHostel"
    @related="(id) => showGet(HOSTELS + '/' + id + '/residents')" @summary="(id) => showGet(HOSTELS + '/' + id + '/summary')" />

  <h2>Residents</h2>
  <ResidentForm :form="residentForm" :editing="editingResidentId !== ''" :parents="hostels" @save="saveResident" @cancel="cancelResident" />
  <div class="box">
    <select v-model="filterHostelId" @change="loadResidents">
      <option value="">All hostels</option>
      <option v-for="p in hostels" :key="p.id" :value="p.id">{{ p.hostelName }}</option>
    </select>
    <button @click="showGet(RESIDENTS + '/count', { hostelId: filterHostelId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(RESIDENTS + '/search', { keyword })">Search</button>
  </div>
  <ResidentList :items="residents" :parents="hostels" @edit="editResident" @remove="deleteResident" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
