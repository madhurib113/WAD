<script setup>
// Form for the "ONE" side (Hostel). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'hostelName', label: 'Hostel Name', type: 'text' },
  { key: 'warden', label: 'Warden', type: 'text' },
  { key: 'location', label: 'Location', type: 'text' },
  { key: 'rooms', label: 'Rooms', type: 'number' },
  { key: 'rentPerMonth', label: 'Rent Per Month', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Hostel</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
