# Hostel - Resident (2 collections: `hostels` and `residents`)

Database `hostel_db`. `residents.hostelId` stores the `_id` of a hostel (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db hostel_db --collection hostels --jsonArray --file sample_data/hostels.json
mongoimport --db hostel_db --collection residents --jsonArray --file sample_data/residents.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Hostel**: hostelName*, warden*, location, rooms* (> 0), rentPerMonth* (>= 0)    (* = required)
- **Resident**: name*, phone*, hostelId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/hostels | create (Hostel) 201 / 400 |
| GET | /api/hostels , /api/hostels/{id} | all / one (404) |
| PUT | /api/hostels/{id} | update 200 / 400 / 404 / 409 (`rooms` below existing residents) |
| DELETE | /api/hostels/{id}?cascade=true | 204 / 404 / 409 (has residents and no cascade) |
| GET | /api/hostels/search?keyword= | search by hostelName |
| GET | /api/hostels/filter?minrentPerMonth= | rentPerMonth >= value |
| GET | /api/hostels/sorted | sort by rentPerMonth desc |
| GET | /api/hostels/available | hostels that still have free places |
| GET | /api/hostels/{id}/residents | related residents |
| GET | /api/hostels/{id}/summary | count, placesLeft, totalAmount = count x rentPerMonth |
| GET | /api/hostels/stats | totals over all hostels |
| POST | /api/residents | create (Resident) 201 / 400 (bad hostelId) / 409 (full) |
| GET | /api/residents?hostelId= | all / filter by hostel |
| GET | /api/residents/{id} | one (404) |
| PUT | /api/residents/{id} | update (move to another hostel: free place checked) |
| DELETE | /api/residents/{id} | 204 / 404 |
| GET | /api/residents/search?keyword= | search by name |
| GET | /api/residents/count?hostelId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on hostels and on residents.
3. Validation: missing field -> 400, rooms <= 0 -> 400, rentPerMonth < 0 -> 400, unknown id -> 404.
4. Add a resident only if the hostel exists (400) and is not full (409).
5. Update hostel: rooms cannot be lower than current number of residents (409).
6. Delete hostel: blocked if it has residents (409); `cascade=true` deletes its residents too.
7. List residents of one hostel; count residents of one hostel.
8. Search by text, filter by number, sort descending, list available hostels.
9. Calculation: totalAmount for one hostel, and totals over all hostels (stats).
10. Move a resident from one hostel to another.
