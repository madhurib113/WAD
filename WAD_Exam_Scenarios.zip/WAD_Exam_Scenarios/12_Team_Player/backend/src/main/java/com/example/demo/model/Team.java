package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: teams
@Document(collection = "teams")
public class Team {

    @Id
    private String id;

    private String teamName;
    private String coach;
    private String city;
    private Integer squadSize;
    private Double salaryPerPlayer;

    public Team() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTeamName() { return teamName; }
    public void setTeamName(String teamName) { this.teamName = teamName; }
    public String getCoach() { return coach; }
    public void setCoach(String coach) { this.coach = coach; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public Integer getSquadSize() { return squadSize; }
    public void setSquadSize(Integer squadSize) { this.squadSize = squadSize; }
    public Double getSalaryPerPlayer() { return salaryPerPlayer; }
    public void setSalaryPerPlayer(Double salaryPerPlayer) { this.salaryPerPlayer = salaryPerPlayer; }
}
