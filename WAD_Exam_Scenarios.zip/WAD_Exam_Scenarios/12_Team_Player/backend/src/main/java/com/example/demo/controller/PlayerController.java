package com.example.demo.controller;

import com.example.demo.model.Player;
import com.example.demo.service.PlayerService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/players")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class PlayerController {

    private final PlayerService service;

    public PlayerController(PlayerService service) { this.service = service; }

    @PostMapping                                   // POST   /api/players   -> 201 / 400 (bad team) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Player create(@RequestBody Player x) { return service.create(x); }

    @GetMapping                                    // GET    /api/players[?teamId=..]  (filter by related record)
    public List<Player> getAll(@RequestParam(required = false) String teamId) { return service.getAll(teamId); }

    @GetMapping("/{id}")                           // GET    /api/players/{id}   -> 200 / 404
    public Player getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/players/{id}
    public Player update(@PathVariable String id, @RequestBody Player x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/players/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/players/search?keyword=an
    public List<Player> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/players/count[?teamId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String teamId) {
        return Map.of("count", service.count(teamId));
    }
}
