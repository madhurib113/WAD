package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: players
// teamId stores the _id of a Team as plain text. MongoDB has NO foreign keys,
// so PlayerService checks that the team exists before saving.
@Document(collection = "players")
public class Player {

    @Id
    private String id;

    private String name;     // required
    private String role;     // required
    private String teamId;    // required: reference to teams._id

    public Player() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getTeamId() { return teamId; }
    public void setTeamId(String teamId) { this.teamId = teamId; }
}
