package com.example.demo.controller;

import com.example.demo.model.Team;
import com.example.demo.model.Player;
import com.example.demo.service.TeamService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/teams")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class TeamController {

    private final TeamService service;

    public TeamController(TeamService service) { this.service = service; }

    @PostMapping                                   // POST   /api/teams                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Team create(@RequestBody Team x) { return service.create(x); }

    @GetMapping                                    // GET    /api/teams
    public List<Team> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/teams/{id}            -> 200 / 404
    public Team getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/teams/{id}            -> 200 / 400 / 404 / 409
    public Team update(@PathVariable String id, @RequestBody Team x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/teams/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/teams/search?keyword=ab
    public List<Team> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/teams/filter?minsalaryPerPlayer=500
    public List<Team> filter(@RequestParam Double minsalaryPerPlayer) { return service.filterBysalaryPerPlayer(minsalaryPerPlayer); }

    @GetMapping("/sorted")                         // GET    /api/teams/sorted          (salaryPerPlayer high -> low)
    public List<Team> sorted() { return service.sortedBysalaryPerPlayer(); }

    @GetMapping("/available")                      // GET    /api/teams/available       (still have free places)
    public List<Team> available() { return service.available(); }

    @GetMapping("/{id}/players")                    // GET    /api/teams/{id}/players     (related records)
    public List<Player> related(@PathVariable String id) { return service.playersOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/teams/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/teams/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
