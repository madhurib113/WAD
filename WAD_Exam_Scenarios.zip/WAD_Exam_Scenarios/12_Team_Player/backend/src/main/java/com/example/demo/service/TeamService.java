package com.example.demo.service;

import com.example.demo.model.Team;
import com.example.demo.model.Player;
import com.example.demo.repository.TeamRepository;
import com.example.demo.repository.PlayerRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class TeamService {

    private final TeamRepository teams;
    private final PlayerRepository players;

    public TeamService(TeamRepository teams, PlayerRepository players) {
        this.teams = teams;
        this.players = players;
    }

    private void validate(Team x) {
        if (x.getTeamName() == null || x.getTeamName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "teamName is required");
        if (x.getCoach() == null || x.getCoach().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "coach is required");
        if (x.getsquadSize() == null || x.getsquadSize() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "squadSize is required and must be > 0");
        if (x.getsalaryPerPlayer() == null || x.getsalaryPerPlayer() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "salaryPerPlayer is required and must be >= 0");
    }

    public Team getById(String id) {
        return teams.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Team not found with id " + id));
    }

    // ---------- CRUD ----------
    public Team create(Team x) {
        validate(x);
        x.setId(null);
        return teams.save(x);
    }

    public List<Team> getAll() { return teams.findAll(); }

    public Team update(String id, Team in) {
        Team existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of players already added
        long used = players.countByTeamId(id);
        if (in.getsquadSize() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "squadSize cannot be less than the " + used + " existing players");
        existing.setTeamName(in.getTeamName());
        existing.setCoach(in.getCoach());
        existing.setCity(in.getCity());
        existing.setSquadSize(in.getSquadSize());
        existing.setSalaryPerPlayer(in.getSalaryPerPlayer());
        return teams.save(existing);
    }

    // a team that still has players is NOT deleted unless cascade=true (then its players are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = players.countByTeamId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "team has " + used + " players; delete them first or use cascade=true");
        players.deleteByTeamId(id);
        teams.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Team> search(String keyword) { return teams.findByTeamNameContainingIgnoreCase(keyword); }

    public List<Team> filterBysalaryPerPlayer(Double min) { return teams.findBysalaryPerPlayerGreaterThanEqual(min); }

    public List<Team> sortedBysalaryPerPlayer() { return teams.findAll(Sort.by(Sort.Direction.DESC, "salaryPerPlayer")); }

    // only the teams that still have a free place
    public List<Team> available() {
        List<Team> result = new ArrayList<>();
        for (Team x : teams.findAll())
            if (players.countByTeamId(x.getId()) < x.getsquadSize()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Player> playersOf(String id) {
        getById(id);                              // 404 if the team is missing
        return players.findByTeamId(id);
    }

    // count + calculations across the two collections for ONE team
    public Map<String, Object> summary(String id) {
        Team x = getById(id);
        long count = players.countByTeamId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("teamId", x.getId());
        m.put("name", x.getTeamName());
        m.put("squadSize", x.getsquadSize());
        m.put("playerCount", count);
        m.put("placesLeft", x.getsquadSize() - count);
        m.put("salaryPerPlayer", x.getsalaryPerPlayer());
        m.put("totalAmount", count * x.getsalaryPerPlayer());
        return m;
    }

    // totals across ALL teams
    public Map<String, Object> stats() {
        long totalPlayer = 0;
        double totalAmount = 0;
        List<Team> all = teams.findAll();
        for (Team x : all) {
            long c = players.countByTeamId(x.getId());
            totalPlayer += c;
            totalAmount += c * x.getsalaryPerPlayer();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalTeams", all.size());
        m.put("totalPlayers", totalPlayer);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
