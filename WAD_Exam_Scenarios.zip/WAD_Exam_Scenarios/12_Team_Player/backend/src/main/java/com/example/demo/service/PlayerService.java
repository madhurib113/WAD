package com.example.demo.service;

import com.example.demo.model.Team;
import com.example.demo.model.Player;
import com.example.demo.repository.TeamRepository;
import com.example.demo.repository.PlayerRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class PlayerService {

    private final PlayerRepository players;
    private final TeamRepository teams;

    public PlayerService(PlayerRepository players, TeamRepository teams) {
        this.players = players;
        this.teams = teams;
    }

    private void validate(Player x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getRole() == null || x.getRole().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "role is required");
        if (x.getTeamId() == null || x.getTeamId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "teamId is required");
    }

    // The referenced team must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkTeam(String id, boolean checkLimit) {
        Team p = teams.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "teamId does not exist: " + id));
        if (checkLimit && players.countByTeamId(id) >= p.getsquadSize())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "team is full");
    }

    public Player getById(String id) {
        return players.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Player not found with id " + id));
    }

    public Player create(Player x) {
        validate(x);
        checkTeam(x.getTeamId(), true);
        x.setId(null);
        return players.save(x);
    }

    // optional filter by related record: ?teamId=...
    public List<Player> getAll(String teamId) {
        if (teamId == null || teamId.isBlank()) return players.findAll();
        return players.findByTeamId(teamId);
    }

    public List<Player> search(String keyword) { return players.findByNameContainingIgnoreCase(keyword); }

    public Player update(String id, Player in) {
        Player existing = getById(id);
        validate(in);
        boolean moving = !in.getTeamId().equals(existing.getTeamId());
        checkTeam(in.getTeamId(), moving);       // free-place check only when moving to another team
        existing.setName(in.getName());
        existing.setRole(in.getRole());
        existing.setTeamId(in.getTeamId());
        return players.save(existing);
    }

    public void delete(String id) {
        getById(id);
        players.deleteById(id);
    }

    public long count(String teamId) {
        if (teamId == null || teamId.isBlank()) return players.count();
        return players.countByTeamId(teamId);
    }
}
