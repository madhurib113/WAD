package com.example.demo.repository;

import com.example.demo.model.Player;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PlayerRepository extends MongoRepository<Player, String> {
    List<Player> findByTeamId(String teamId);                    // filter by the related record
    long countByTeamId(String teamId);                          // count related records
    long deleteByTeamId(String teamId);                         // cascade delete
    List<Player> findByNameContainingIgnoreCase(String keyword); // search
}
