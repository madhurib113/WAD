package com.example.demo.repository;

import com.example.demo.model.Team;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TeamRepository extends MongoRepository<Team, String> {
    List<Team> findByTeamNameContainingIgnoreCase(String keyword);        // search
    List<Team> findBysalaryPerPlayerGreaterThanEqual(Double min);                  // filter by number
}
