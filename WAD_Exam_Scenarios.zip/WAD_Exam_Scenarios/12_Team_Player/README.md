# Team - Player (2 collections: `teams` and `players`)

Database `team_db`. `players.teamId` stores the `_id` of a team (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db team_db --collection teams --jsonArray --file sample_data/teams.json
mongoimport --db team_db --collection players --jsonArray --file sample_data/players.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Team**: teamName*, coach*, city, squadSize* (> 0), salaryPerPlayer* (>= 0)    (* = required)
- **Player**: name*, role*, teamId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/teams | create (Team) 201 / 400 |
| GET | /api/teams , /api/teams/{id} | all / one (404) |
| PUT | /api/teams/{id} | update 200 / 400 / 404 / 409 (`squadSize` below existing players) |
| DELETE | /api/teams/{id}?cascade=true | 204 / 404 / 409 (has players and no cascade) |
| GET | /api/teams/search?keyword= | search by teamName |
| GET | /api/teams/filter?minsalaryPerPlayer= | salaryPerPlayer >= value |
| GET | /api/teams/sorted | sort by salaryPerPlayer desc |
| GET | /api/teams/available | teams that still have free places |
| GET | /api/teams/{id}/players | related players |
| GET | /api/teams/{id}/summary | count, placesLeft, totalAmount = count x salaryPerPlayer |
| GET | /api/teams/stats | totals over all teams |
| POST | /api/players | create (Player) 201 / 400 (bad teamId) / 409 (full) |
| GET | /api/players?teamId= | all / filter by team |
| GET | /api/players/{id} | one (404) |
| PUT | /api/players/{id} | update (move to another team: free place checked) |
| DELETE | /api/players/{id} | 204 / 404 |
| GET | /api/players/search?keyword= | search by name |
| GET | /api/players/count?teamId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on teams and on players.
3. Validation: missing field -> 400, squadSize <= 0 -> 400, salaryPerPlayer < 0 -> 400, unknown id -> 404.
4. Add a player only if the team exists (400) and is not full (409).
5. Update team: squadSize cannot be lower than current number of players (409).
6. Delete team: blocked if it has players (409); `cascade=true` deletes its players too.
7. List players of one team; count players of one team.
8. Search by text, filter by number, sort descending, list available teams.
9. Calculation: totalAmount for one team, and totals over all teams (stats).
10. Move a player from one team to another.
