<script setup>
// Form for the "MANY" side (Player). The team is chosen from a dropdown.
defineProps({ form: Object, editing: Boolean, parents: Array })
defineEmits(['save', 'cancel'])
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Player</h3>
    <input v-model="form.name" placeholder="Name" />
    <input v-model="form.role" placeholder="Role" />
    <select v-model="form.teamId">
      <option value="">-- select team --</option>
      <option v-for="p in parents" :key="p.id" :value="p.id">{{ p.teamName }}</option>
    </select>
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
