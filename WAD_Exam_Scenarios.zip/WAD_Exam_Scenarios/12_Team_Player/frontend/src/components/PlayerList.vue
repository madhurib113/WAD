<script setup>
// Table of Player records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the team name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Name</th><th>Role</th><th>Team</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.name }}</td>
        <td>{{ x.role }}</td>
        <td>{{ (parents.find(p => p.id === x.teamId) || {}).teamName || x.teamId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
