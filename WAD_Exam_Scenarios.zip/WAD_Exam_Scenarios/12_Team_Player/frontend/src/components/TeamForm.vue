<script setup>
// Form for the "ONE" side (Team). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'teamName', label: 'Team Name', type: 'text' },
  { key: 'coach', label: 'Coach', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'squadSize', label: 'Squad Size', type: 'number' },
  { key: 'salaryPerPlayer', label: 'Salary Per Player', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Team</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
