<script setup>
// Table of Team records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'teamName', label: 'Team Name', type: 'text' },
  { key: 'coach', label: 'Coach', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'squadSize', label: 'Squad Size', type: 'number' },
  { key: 'salaryPerPlayer', label: 'Salary Per Player', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Players</button>
          <button @click="$emit('related', x.id)">Players</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
