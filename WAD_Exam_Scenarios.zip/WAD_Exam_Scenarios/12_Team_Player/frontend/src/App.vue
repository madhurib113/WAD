<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import TeamForm from './components/TeamForm.vue'
import TeamList from './components/TeamList.vue'
import PlayerForm from './components/PlayerForm.vue'
import PlayerList from './components/PlayerList.vue'
import ResultBox from './components/ResultBox.vue'

const TEAMS = 'http://localhost:8080/api/teams'
const PLAYERS = 'http://localhost:8080/api/players'

const teams = ref([])
const players = ref([])
const teamForm = ref({ teamName: '', coach: '', city: '', squadSize: '', salaryPerPlayer: '' })
const editingTeamId = ref('')
const playerForm = ref({ name: '', role: '', teamId: '' })
const editingPlayerId = ref('')
const filterTeamId = ref('')
const keyword = ref('')
const minsalaryPerPlayer = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Team ----------
async function loadTeams() {
  try { teams.value = (await axios.get(TEAMS)).data } catch (e) { showError(e) }
}

async function saveTeam() {
  error.value = ''
  const body = { ...teamForm.value, squadSize: num(teamForm.value.squadSize), salaryPerPlayer: num(teamForm.value.salaryPerPlayer) }
  try {
    if (editingTeamId.value === '') await axios.post(TEAMS, body)
    else await axios.put(TEAMS + '/' + editingTeamId.value, body)
    cancelTeam()
    loadTeams()
  } catch (e) { showError(e) }
}

function editTeam(x) {
  teamForm.value = { ...x }
  editingTeamId.value = x.id
}

function cancelTeam() {
  teamForm.value = { teamName: '', coach: '', city: '', squadSize: '', salaryPerPlayer: '' }
  editingTeamId.value = ''
}

// cascade = true also deletes the players; false -> error 409 if there are players
async function deleteTeam(id, cascade) {
  error.value = ''
  try {
    await axios.delete(TEAMS + '/' + id, { params: { cascade } })
    loadTeams()
    loadPlayers()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Player ----------
async function loadPlayers() {
  try { players.value = (await axios.get(PLAYERS, { params: { teamId: filterTeamId.value } })).data } catch (e) { showError(e) }
}

async function savePlayer() {
  error.value = ''
  try {
    if (editingPlayerId.value === '') await axios.post(PLAYERS, playerForm.value)
    else await axios.put(PLAYERS + '/' + editingPlayerId.value, playerForm.value)
    cancelPlayer()
    loadPlayers()
  } catch (e) { showError(e) }
}

function editPlayer(x) {
  playerForm.value = { name: x.name, role: x.role, teamId: x.teamId }
  editingPlayerId.value = x.id
}

function cancelPlayer() {
  playerForm.value = { name: '', role: '', teamId: '' }
  editingPlayerId.value = ''
}

async function deletePlayer(id) {
  error.value = ''
  try {
    await axios.delete(PLAYERS + '/' + id)
    loadPlayers()
  } catch (e) { showError(e) }
}

onMounted(() => { loadTeams(); loadPlayers() })
</script>

<template>
  <h1>Team - Player Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Teams</h2>
  <TeamForm :form="teamForm" :editing="editingTeamId !== ''" @save="saveTeam" @cancel="cancelTeam" />
  <div class="box">
    <input v-model="keyword" placeholder="search teamName" />
    <button @click="showGet(TEAMS + '/search', { keyword })">Search</button>
    <input v-model="minsalaryPerPlayer" type="number" placeholder="min salaryPerPlayer" />
    <button @click="showGet(TEAMS + '/filter', { minsalaryPerPlayer })">Filter</button>
    <button @click="showGet(TEAMS + '/sorted')">Sort by salaryPerPlayer</button>
    <button @click="showGet(TEAMS + '/available')">Available</button>
    <button @click="showGet(TEAMS + '/stats')">Stats</button>
  </div>
  <TeamList :items="teams" @edit="editTeam" @remove="deleteTeam"
    @related="(id) => showGet(TEAMS + '/' + id + '/players')" @summary="(id) => showGet(TEAMS + '/' + id + '/summary')" />

  <h2>Players</h2>
  <PlayerForm :form="playerForm" :editing="editingPlayerId !== ''" :parents="teams" @save="savePlayer" @cancel="cancelPlayer" />
  <div class="box">
    <select v-model="filterTeamId" @change="loadPlayers">
      <option value="">All teams</option>
      <option v-for="p in teams" :key="p.id" :value="p.id">{{ p.teamName }}</option>
    </select>
    <button @click="showGet(PLAYERS + '/count', { teamId: filterTeamId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(PLAYERS + '/search', { keyword })">Search</button>
  </div>
  <PlayerList :items="players" :parents="teams" @edit="editPlayer" @remove="deletePlayer" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
