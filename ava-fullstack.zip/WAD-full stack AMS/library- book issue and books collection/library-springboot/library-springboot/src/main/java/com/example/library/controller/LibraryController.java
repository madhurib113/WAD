package com.example.library.controller;

import com.example.library.model.Book;
import com.example.library.model.BookIssue;
import com.example.library.service.LibraryService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class LibraryController {
  private final LibraryService service;
  public LibraryController(LibraryService service) { this.service = service; }

  @PostMapping("/books")
  @ResponseStatus(HttpStatus.CREATED)
  public Book addBook(@RequestBody Book b) { return service.addBook(b); }
  @GetMapping("/books") public List<Book> getBooks() { return service.getBooks(); }
  @GetMapping("/books/{id}") public Book getBook(@PathVariable String id) { return service.getBook(id); }
  @PutMapping("/books/{id}") public Book updateBook(@PathVariable String id, @RequestBody Book b) { return service.updateBook(id, b); }
  @DeleteMapping("/books/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
  public void deleteBook(@PathVariable String id) { service.deleteBook(id); }
  @GetMapping("/books/count") public long getBookCount() { return service.getBookCount(); }

  @PostMapping("/issues") @ResponseStatus(HttpStatus.CREATED)
  public BookIssue issueBook(@RequestBody BookIssue i) { return service.issueBook(i); }
  @GetMapping("/issues") public List<BookIssue> getIssues() { return service.getIssues(); }
  @GetMapping("/issues/book/{bookId}") public List<BookIssue> getIssuesForBook(@PathVariable String bookId) { return service.getIssuesForBook(bookId); }
  @PutMapping("/issues/{id}") public BookIssue updateIssue(@PathVariable String id, @RequestBody BookIssue i) { return service.updateIssue(id, i); }
  @DeleteMapping("/issues/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
  public void returnBook(@PathVariable String id) { service.returnIssue(id); }
}
