package com.example.library.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Data @NoArgsConstructor @AllArgsConstructor
@Document(collection = "bookIssues")
public class BookIssue {
  @Id private String issueId;
  private String studentName;
  private String bookId;
  private int quantity;
}
