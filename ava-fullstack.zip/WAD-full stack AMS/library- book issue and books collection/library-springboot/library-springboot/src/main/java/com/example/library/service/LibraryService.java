package com.example.library.service;

import com.example.library.model.Book;
import com.example.library.model.BookIssue;
import com.example.library.repository.BookIssueRepository;
import com.example.library.repository.BookRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LibraryService {
  private final BookRepository books;
  private final BookIssueRepository issues;

  public LibraryService(BookRepository books, BookIssueRepository issues) {
    this.books = books;
    this.issues = issues;
  }

  public Book addBook(Book book) {
    if (book.getAvailableCopies() < 0) throw new IllegalArgumentException("Copies cannot be negative");
    return books.save(book);
  }
  public List<Book> getBooks() { return books.findAll(); }
  public Book getBook(String id) {
    return books.findById(id).orElseThrow(() -> new IllegalArgumentException("Book not found: " + id));
  }
  public Book updateBook(String id, Book b) {
    Book old = getBook(id);
    if (b.getAvailableCopies() < 0) throw new IllegalArgumentException("Copies cannot be negative");
    old.setTitle(b.getTitle()); old.setAuthor(b.getAuthor()); old.setAvailableCopies(b.getAvailableCopies());
    return books.save(old);
  }
  public void deleteBook(String id) {
    Book b = getBook(id);
    if (!issues.findByBookId(id).isEmpty()) throw new IllegalArgumentException("Delete issue records before deleting this book");
    books.delete(b);
  }
  public long getBookCount() { return books.count(); }

  public BookIssue issueBook(BookIssue issue) {
    if (issue.getQuantity() <= 0) throw new IllegalArgumentException("Quantity must be greater than zero");
    Book b = getBook(issue.getBookId());
    if (b.getAvailableCopies() < issue.getQuantity()) throw new IllegalArgumentException("Not enough copies available");
    b.setAvailableCopies(b.getAvailableCopies() - issue.getQuantity());
    books.save(b);
    try { return issues.save(issue); }
    catch (RuntimeException e) {
      b.setAvailableCopies(b.getAvailableCopies() + issue.getQuantity());
      books.save(b);
      throw e;
    }
  }
  public List<BookIssue> getIssues() { return issues.findAll(); }
  public List<BookIssue> getIssuesForBook(String id) {
    getBook(id);
    return issues.findByBookId(id);
  }
  public BookIssue updateIssue(String id, BookIssue update) {
    BookIssue old = issues.findById(id).orElseThrow(() -> new IllegalArgumentException("Issue not found: " + id));
    if (update.getQuantity() <= 0) throw new IllegalArgumentException("Quantity must be greater than zero");
    if (!old.getBookId().equals(update.getBookId())) throw new IllegalArgumentException("Changing book during update is not supported");
    int diff = update.getQuantity() - old.getQuantity();
    Book b = getBook(old.getBookId());
    if (diff > 0 && b.getAvailableCopies() < diff) throw new IllegalArgumentException("Not enough copies available");
    b.setAvailableCopies(b.getAvailableCopies() - diff);
    books.save(b);
    old.setStudentName(update.getStudentName()); old.setQuantity(update.getQuantity());
    return issues.save(old);
  }
  public void returnIssue(String id) {
    BookIssue issue = issues.findById(id).orElseThrow(() -> new IllegalArgumentException("Issue not found: " + id));
    Book b = getBook(issue.getBookId());
    b.setAvailableCopies(b.getAvailableCopies() + issue.getQuantity());
    books.save(b);
    issues.delete(issue);
  }
}
