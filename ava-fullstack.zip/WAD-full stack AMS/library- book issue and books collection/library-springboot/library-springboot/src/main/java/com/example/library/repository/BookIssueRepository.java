package com.example.library.repository;
import com.example.library.model.BookIssue;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;
public interface BookIssueRepository extends MongoRepository<BookIssue, String> {
  List<BookIssue> findByBookId(String bookId);
}
