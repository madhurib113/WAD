package com.example.library.controller;
import com.example.library.model.Book;
import com.example.library.model.BookIssue;
import com.example.library.service.LibraryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LibraryController.class)
class LibraryControllerTest {
  @Autowired MockMvc mockMvc;
  @Autowired ObjectMapper mapper;
  @MockBean LibraryService service;

  @Test void getBooksReturnsList() throws Exception {
    when(service.getBooks()).thenReturn(List.of(new Book("BK1", "Java Basics", "James", 5)));
    mockMvc.perform(get("/books")).andExpect(status().isOk()).andExpect(jsonPath("$[0].bookId").value("BK1"));
  }
  @Test void addBookReturnsCreated() throws Exception {
    Book b = new Book("BK1", "Java Basics", "James", 5);
    when(service.addBook(any(Book.class))).thenReturn(b);
    mockMvc.perform(post("/books").contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(b)))
      .andExpect(status().isCreated()).andExpect(jsonPath("$.bookId").value("BK1"));
  }
  @Test void issueBookReturnsCreated() throws Exception {
    BookIssue i = new BookIssue("IS1", "Sanjay", "BK1", 2);
    when(service.issueBook(any(BookIssue.class))).thenReturn(i);
    mockMvc.perform(post("/issues").contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(i)))
      .andExpect(status().isCreated()).andExpect(jsonPath("$.quantity").value(2));
  }
  @Test void countReturnsNumber() throws Exception {
    when(service.getBookCount()).thenReturn(3L);
    mockMvc.perform(get("/books/count")).andExpect(status().isOk()).andExpect(content().string("3"));
  }
}
