# Library Spring Boot backend
Requirements: JDK 17 and MongoDB running at localhost:27017.
Open this folder in IntelliJ as a Maven project and run LibrarySystemApplication.
Backend URL: http://localhost:8082
Database: librarydb. Collections: books and bookIssues (created automatically on save).

Lombok and MockMvc test dependencies are included. The MockMvc test is in src/test/java.
Endpoints:
POST/GET /books; GET /books/{id}; PUT/DELETE /books/{id}; GET /books/count
POST/GET /issues; GET /issues/book/{bookId}; PUT/DELETE /issues/{id}
POST /books JSON: {"bookId":"BK1","title":"Java Basics","author":"James","availableCopies":5}
POST /issues JSON: {"issueId":"IS1","studentName":"Sanjay","bookId":"BK1","quantity":2}
Issue checks availability, reduces copies and saves the issue. DELETE /issues/{id} restores copies and deletes the issue.
