# Library Vue frontend (no Axios)
Requirements: Node.js and npm.
1. Open this folder in a terminal.
2. Run `npm install` (downloads Vue and Vite; Axios is not used).
3. Run `npm run dev`.
4. Open http://localhost:5173.
Start the Spring Boot backend first at http://localhost:8082.
