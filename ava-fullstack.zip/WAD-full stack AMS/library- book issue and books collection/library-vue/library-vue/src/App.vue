<template>
  <div>
    <h1>Library Management</h1>
    <p>{{ message }}</p>

    <h3>Add Book</h3>
    <input v-model="book.bookId" placeholder="Book ID">
    <input v-model="book.title" placeholder="Title">
    <input v-model="book.author" placeholder="Author">
    <input v-model.number="book.availableCopies" type="number" placeholder="Copies">
    <button @click="addBook">Add</button>

    <h3>Books</h3>
    <button @click="getBooks">Refresh Books</button>
    <ul>
      <li v-for="b in books" :key="b.bookId">
        {{ b.bookId }} - {{ b.title }} - {{ b.author }} - Copies: {{ b.availableCopies }}
        <button @click="deleteBook(b.bookId)">Delete</button>
      </li>
    </ul>
    <p>Total books: {{ count }} <button @click="getCount">Refresh count</button></p>

    <h3>Issue Book</h3>
    <input v-model="issue.issueId" placeholder="Issue ID">
    <input v-model="issue.studentName" placeholder="Student name">
    <input v-model="issue.bookId" placeholder="Book ID">
    <input v-model.number="issue.quantity" type="number" placeholder="Quantity">
    <button @click="issueBook">Issue</button>

    <h3>Issues</h3>
    <button @click="getIssues">Refresh Issues</button>
    <ul>
      <li v-for="i in issues" :key="i.issueId">
        {{ i.issueId }} - {{ i.studentName }} - {{ i.bookId }} - Qty: {{ i.quantity }}
        <button @click="returnBook(i.issueId)">Return</button>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      url: 'http://localhost:8082',
      books: [],
      issues: [],
      count: 0,
      message: '',
      book: { bookId: '', title: '', author: '', availableCopies: 5 },
      issue: { issueId: '', studentName: '', bookId: '', quantity: 1 }
    };
  },
  methods: {
    async request(path, options = {}) {
      const res = await fetch(this.url + path, options);
      if (!res.ok) {
        const text = await res.text();
        throw new Error('HTTP ' + res.status + (text ? ': ' + text : ''));
      }
      if (res.status === 204) return null;
      return res.json();
    },
    async addBook() {
      try {
        await this.request('/books', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(this.book)
        });
        this.message = 'Book added';
        this.book = { bookId: '', title: '', author: '', availableCopies: 5 };
        await this.refresh();
      } catch (e) { this.message = 'Add failed: ' + e.message; }
    },
    async getBooks() {
      try { this.books = await this.request('/books'); }
      catch (e) { this.message = 'Get books failed: ' + e.message; }
    },
    async issueBook() {
      try {
        await this.request('/issues', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(this.issue)
        });
        this.message = 'Book issued';
        this.issue = { issueId: '', studentName: '', bookId: '', quantity: 1 };
        await this.refresh();
      } catch (e) { this.message = 'Issue failed: ' + e.message; }
    },
    async getIssues() {
      try { this.issues = await this.request('/issues'); }
      catch (e) { this.message = 'Get issues failed: ' + e.message; }
    },
    async returnBook(id) {
      try {
        await this.request('/issues/' + encodeURIComponent(id), { method: 'DELETE' });
        this.message = 'Book returned';
        await this.refresh();
      } catch (e) { this.message = 'Return failed: ' + e.message; }
    },
    async deleteBook(id) {
      try {
        await this.request('/books/' + encodeURIComponent(id), { method: 'DELETE' });
        this.message = 'Book deleted';
        await this.refresh();
      } catch (e) { this.message = 'Delete failed: ' + e.message; }
    },
    async getCount() {
      try { this.count = await this.request('/books/count'); }
      catch (e) { this.message = 'Count failed: ' + e.message; }
    },
    async refresh() {
      await Promise.all([this.getBooks(), this.getIssues(), this.getCount()]);
    }
  },
  mounted() { this.refresh(); }
};
</script>
