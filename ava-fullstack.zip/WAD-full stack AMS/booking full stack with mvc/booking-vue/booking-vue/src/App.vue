<script setup>
import { onMounted, ref, computed } from 'vue'
const API = 'http://localhost:8082'
const rooms = ref([])
const bookings = ref([])
const message = ref('')
const isError = ref(false)
const busy = ref(false)
const form = ref({ customerName: '', roomType: '', quantity: 1, nights: 1 })
const selectedRoom = computed(() => rooms.value.find(r => r.roomType === form.value.roomType))

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: options.body ? { 'Content-Type': 'application/json', ...(options.headers || {}) } : (options.headers || {})
  })
  if (!response.ok) {
    let detail = `Request failed (${response.status})`
    try { const body = await response.json(); detail = body.message || detail } catch {}
    throw new Error(detail)
  }
  if (response.status === 204) return null
  return response.json()
}
async function loadData() {
  try {
    const [roomData, bookingData] = await Promise.all([request('/rooms'), request('/bookings')])
    rooms.value = roomData
    bookings.value = bookingData
    if (!form.value.roomType && roomData.length) form.value.roomType = roomData[0].roomType
  } catch (error) { isError.value = true; message.value = error.message + ' — check that Spring Boot (port 8082) and MongoDB are running.' }
}
async function bookRoom() {
  busy.value = true; message.value = ''; isError.value = false
  try {
    const booking = await request('/bookings', { method: 'POST', body: JSON.stringify({
      customerName: form.value.customerName, roomType: form.value.roomType,
      quantity: Number(form.value.quantity), nights: Number(form.value.nights)
    })})
    isError.value = false
    message.value = `Booking successful! Booking ID: ${booking.bookingId}`
    form.value.customerName = ''
    await loadData()
  } catch (error) { isError.value = true; message.value = error.message }
  finally { busy.value = false }
}
async function cancelBooking(id) {
  if (!confirm('Cancel this booking and restore the room availability?')) return
  message.value = ''; isError.value = false
  try { await request(`/bookings/${id}`, { method: 'DELETE' }); message.value = 'Booking cancelled. Availability restored.'; await loadData() }
  catch (error) { isError.value = true; message.value = error.message }
}
onMounted(loadData)
</script>

<template>
  <main class="page">
    <header class="hero"><div class="eyebrow">STAY EASY · ROOM RESERVATIONS</div><h1>Find your <span>room.</span></h1><p>Choose a room type, check availability, and book your stay.</p></header>
    <p v-if="message" class="notice" :class="{ error: isError }" role="status">{{ message }}</p>
    <section class="layout">
      <div class="panel">
        <div class="section-heading"><div><div class="eyebrow">MAKE A RESERVATION</div><h2>Book a room</h2></div><span class="emoji">🛎️</span></div>
        <form @submit.prevent="bookRoom">
          <label>Your name<input v-model.trim="form.customerName" required placeholder="Enter full name"></label>
          <label>Room type<select v-model="form.roomType" required><option v-for="room in rooms" :key="room.roomId" :value="room.roomType">{{ room.roomType }} — ₹{{ room.pricePerNight.toLocaleString('en-IN') }}/night</option></select></label>
          <div class="two-cols"><label>Number of rooms<input v-model.number="form.quantity" type="number" min="1" step="1" required></label><label>Number of nights<input v-model.number="form.nights" type="number" min="1" step="1" required></label></div>
          <div v-if="selectedRoom" class="total"><span>Estimated total</span><strong>₹{{ (selectedRoom.pricePerNight * Number(form.quantity || 0) * Number(form.nights || 0)).toLocaleString('en-IN') }}</strong></div>
          <button :disabled="busy || !rooms.length">{{ busy ? 'Booking…' : 'Confirm booking' }} <span>→</span></button>
        </form>
      </div>
      <div class="panel rooms-panel">
        <div class="section-heading"><div><div class="eyebrow">LIVE INVENTORY</div><h2>Available rooms</h2></div><span class="count">{{ rooms.length }} types</span></div>
        <article v-for="room in rooms" :key="room.roomId" class="room-card"><div class="room-icon">{{ room.roomType === 'Suite' ? '🛏️' : room.roomType === 'Deluxe' ? '🌿' : '🗝️' }}</div><div class="room-info"><h3>{{ room.roomType }}</h3><p>₹{{ room.pricePerNight.toLocaleString('en-IN') }} <span>/ night</span></p></div><div class="availability" :class="{ low: room.availableRooms === 0 }"><strong>{{ room.availableRooms }}</strong><small>available</small></div></article>
        <p class="hint">Availability updates after a booking or cancellation.</p>
      </div>
    </section>
    <section class="panel booking-list">
      <div class="section-heading"><div><div class="eyebrow">YOUR RESERVATIONS</div><h2>Booking records</h2></div><span class="count">{{ bookings.length }} bookings</span></div>
      <div v-if="!bookings.length" class="empty">No bookings yet. Your first reservation will appear here.</div>
      <div v-for="booking in bookings" :key="booking.bookingId" class="booking-row"><div class="booking-mark">✓</div><div class="booking-details"><strong>{{ booking.customerName }}</strong><p>{{ booking.roomType }} · {{ booking.quantity }} room(s) · {{ booking.nights }} night(s)</p><small>ID: {{ booking.bookingId }}</small></div><button class="cancel" @click="cancelBooking(booking.bookingId)">Cancel</button></div>
    </section>
    <footer>Room Booking Demo · Vue 3 + Spring Boot + MongoDB</footer>
  </main>
</template>
