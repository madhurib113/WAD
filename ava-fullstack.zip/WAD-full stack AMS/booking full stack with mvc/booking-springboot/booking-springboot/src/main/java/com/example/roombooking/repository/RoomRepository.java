package com.example.roombooking.repository;

import com.example.roombooking.model.Room;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface RoomRepository extends MongoRepository<Room, String> {
    Optional<Room> findByRoomTypeIgnoreCase(String roomType);
}
