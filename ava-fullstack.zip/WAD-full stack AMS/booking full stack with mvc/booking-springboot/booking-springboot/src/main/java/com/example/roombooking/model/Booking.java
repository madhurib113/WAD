package com.example.roombooking.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data @NoArgsConstructor @AllArgsConstructor
@Document(collection = "bookings")
public class Booking {
    @Id private String bookingId;
    private String customerName;
    private String roomType;
    private int quantity;
    private int nights;
}
