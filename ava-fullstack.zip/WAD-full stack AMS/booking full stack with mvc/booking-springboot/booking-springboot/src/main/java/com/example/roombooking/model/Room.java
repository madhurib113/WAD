package com.example.roombooking.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data @NoArgsConstructor @AllArgsConstructor
@Document(collection = "rooms")
public class Room {
    @Id private String roomId;
    private String roomType;
    private int availableRooms;
    private double pricePerNight;
}
