package com.example.roombooking.config;

import com.example.roombooking.model.Room;
import com.example.roombooking.repository.RoomRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Seeds the rooms collection only when it is empty (your existing data is left untouched). */
@Component
public class DataSeeder implements CommandLineRunner {
    private final RoomRepository rooms;

    public DataSeeder(RoomRepository rooms) { this.rooms = rooms; }

    @Override
    public void run(String... args) {
        if (rooms.count() == 0) {
            rooms.save(new Room(null, "Standard", 10, 1800));
            rooms.save(new Room(null, "Deluxe", 5, 3000));
            rooms.save(new Room(null, "Suite", 2, 5500));
        }
    }
}
