package com.example.roombooking.controller;

import com.example.roombooking.model.Booking;
import com.example.roombooking.model.Room;
import com.example.roombooking.service.BookingService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class RoomBookingController {
    private final BookingService service;
    public RoomBookingController(BookingService service) { this.service = service; }

    @GetMapping("/rooms") public List<Room> getRooms() { return service.getRooms(); }
    @GetMapping("/rooms/count") public long countRooms() { return service.countRoomTypes(); }
    @GetMapping("/bookings") public List<Booking> getBookings() { return service.getBookings(); }
    @GetMapping("/bookings/{id}") public Booking getBooking(@PathVariable String id) { return service.getBooking(id); }

    @PostMapping("/bookings")
    @ResponseStatus(HttpStatus.CREATED)
    public Booking createBooking(@RequestBody Booking booking) { return service.createBooking(booking); }

    @DeleteMapping("/bookings/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cancelBooking(@PathVariable String id) { service.cancelBooking(id); }
}
