package com.example.roombooking.service;

import com.example.roombooking.model.Booking;
import com.example.roombooking.model.Room;
import com.example.roombooking.repository.BookingRepository;
import com.example.roombooking.repository.RoomRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BookingService {
    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;

    public BookingService(RoomRepository roomRepository, BookingRepository bookingRepository) {
        this.roomRepository = roomRepository;
        this.bookingRepository = bookingRepository;
    }

    public List<Room> getRooms() { return roomRepository.findAll(); }
    public long countRoomTypes() { return roomRepository.count(); }
    public List<Booking> getBookings() { return bookingRepository.findAll(); }

    public Booking getBooking(String id) {
        return bookingRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Booking not found: " + id));
    }

    public Booking createBooking(Booking request) {
        if (request.getCustomerName() == null || request.getCustomerName().isBlank())
            throw new IllegalArgumentException("Customer name is required");
        if (request.getRoomType() == null || request.getRoomType().isBlank())
            throw new IllegalArgumentException("Room type is required");
        if (request.getQuantity() <= 0 || request.getNights() <= 0)
            throw new IllegalArgumentException("Quantity and nights must be greater than zero");

        Room room = roomRepository.findByRoomTypeIgnoreCase(request.getRoomType())
            .orElseThrow(() -> new IllegalArgumentException("Room type does not exist"));
        if (room.getAvailableRooms() < request.getQuantity())
            throw new IllegalArgumentException("Not enough rooms available for " + room.getRoomType());

        room.setAvailableRooms(room.getAvailableRooms() - request.getQuantity());
        roomRepository.save(room);

        Booking booking = new Booking(null, request.getCustomerName().trim(),
            room.getRoomType(), request.getQuantity(), request.getNights());
        return bookingRepository.save(booking);
    }

    public void cancelBooking(String id) {
        Booking booking = getBooking(id);
        Room room = roomRepository.findByRoomTypeIgnoreCase(booking.getRoomType())
            .orElseThrow(() -> new IllegalArgumentException("Room type not found for this booking"));
        room.setAvailableRooms(room.getAvailableRooms() + booking.getQuantity());
        roomRepository.save(room);
        bookingRepository.deleteById(id);
    }
}
