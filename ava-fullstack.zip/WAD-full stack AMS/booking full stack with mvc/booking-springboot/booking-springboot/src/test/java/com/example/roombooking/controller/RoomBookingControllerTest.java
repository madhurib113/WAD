package com.example.roombooking.controller;

import com.example.roombooking.model.Booking;
import com.example.roombooking.model.Room;
import com.example.roombooking.service.BookingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RoomBookingController.class)
class RoomBookingControllerTest {
    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @MockBean BookingService service;

    @Test void getRoomsReturnsJson() throws Exception {
        when(service.getRooms()).thenReturn(List.of(new Room("r1", "Standard", 10, 1800)));
        mockMvc.perform(get("/rooms")).andExpect(status().isOk())
            .andExpect(jsonPath("$[0].roomType").value("Standard"))
            .andExpect(jsonPath("$[0].availableRooms").value(10));
    }

    @Test void createBookingReturnsCreated() throws Exception {
        when(service.createBooking(any(Booking.class))).thenReturn(new Booking("b1", "Anu", "Deluxe", 2, 3));
        mockMvc.perform(post("/bookings").contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(new Booking(null, "Anu", "Deluxe", 2, 3))))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.bookingId").value("b1"))
            .andExpect(jsonPath("$.quantity").value(2));
    }

    @Test void getBookingsReturnsList() throws Exception {
        when(service.getBookings()).thenReturn(List.of(new Booking("b1", "Anu", "Standard", 1, 2)));
        mockMvc.perform(get("/bookings")).andExpect(status().isOk())
            .andExpect(jsonPath("$[0].customerName").value("Anu"));
    }

    @Test void roomCountReturnsNumber() throws Exception {
        when(service.countRoomTypes()).thenReturn(3L);
        mockMvc.perform(get("/rooms/count")).andExpect(status().isOk()).andExpect(content().string("3"));
    }
}
