import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ResultServlet extends HttpServlet {

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
                       throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = (String) request.getAttribute("name");
        String department = (String) request.getAttribute("department");
        Double salary = (Double) request.getAttribute("salary");

        out.println("<html><body>");
        out.println("<h2>Employee Registration Successful</h2>");
        out.println("<p>Name: " + name + "</p>");
        out.println("<p>Department: " + department + "</p>");
        out.println("<p>Salary: " + salary + "</p>");
        out.println("</body></html>");
    }
}
