import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmployeeServlet extends HttpServlet {

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
                       throws ServletException, IOException {

        String name = request.getParameter("name");
        String department = request.getParameter("department");
        double salary = Double.parseDouble(
            request.getParameter("salary"));

        request.setAttribute("name", name);
        request.setAttribute("department", department);
        request.setAttribute("salary", salary);

        RequestDispatcher rd =
            request.getRequestDispatcher("/ResultServlet");

        rd.forward(request, response);
    }
}
