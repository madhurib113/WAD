
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VoterServlet extends HttpServlet {

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
                       throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get details from the HTML form
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        String voterid = request.getParameter("voterid");

        // Display the result
        out.println("<html><body>");

        out.println("<h2>Voter Details</h2>");
        out.println("<p>Name: " + name + "</p>");
        out.println("<p>Age: " + age + "</p>");
        out.println("<p>Voter ID: " + voterid + "</p>");

        if (age >= 18) {
            out.println("<h3>You are eligible to vote!</h3>");
        } else {
            out.println("<h3>You are NOT eligible to vote!</h3>");
        }

        out.println("</body></html>");
    }
}
