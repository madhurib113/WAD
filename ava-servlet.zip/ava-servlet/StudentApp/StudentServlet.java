import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String regnoText = request.getParameter("regno");
        String marksText = request.getParameter("marks");
        String gradeText = request.getParameter("grade");
        boolean attendance = "yes".equals(request.getParameter("attendance"));

        long regno;
        double marks;
        char grade;

        try {
            regno = Long.parseLong(regnoText);
            marks = Double.parseDouble(marksText);
            if (gradeText == null || gradeText.isEmpty()) {
                throw new IllegalArgumentException("Grade is required.");
            }
            grade = gradeText.charAt(0);
        } catch (NumberFormatException | IllegalArgumentException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                               "Please enter valid student details.");
            return;
        }

        String result = marks >= 40 ? "PASS" : "FAIL";

        out.println("<!DOCTYPE html>");
        out.println("<html><head><meta charset='UTF-8'><title>Student Result</title></head><body>");
        out.println("<h2>Student Result</h2>");
        out.println("<p>Name: " + escapeHtml(name) + "</p>");
        out.println("<p>Register Number: " + regno + "</p>");
        out.println("<p>Marks: " + marks + "</p>");
        out.println("<p>Grade: " + escapeHtml(String.valueOf(grade)) + "</p>");
        out.println("<p>Attendance: " + attendance + "</p>");
        out.println("<h3>Result: " + result + "</h3>");
        out.println("<p><a href='index.html'>Go back</a></p>");
        out.println("</body></html>");
    }

    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
