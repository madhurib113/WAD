StudentApp - Apache Tomcat 9

1. Extract this ZIP inside Tomcat's webapps folder.
2. Compile the servlet from the Tomcat root folder using Windows CMD:

   javac -cp "lib\servlet-api.jar" -d "webapps\StudentApp\WEB-INF\classes" "webapps\StudentApp\WEB-INF\classes\StudentServlet.java"

3. Start Tomcat with bin\startup.bat (JAVA_HOME must be configured for that CMD session if needed).
4. Open http://localhost:8080/StudentApp/

This package targets Tomcat 9 and uses javax.servlet.
The compiled .class file is not included because it must be compiled on your computer.
