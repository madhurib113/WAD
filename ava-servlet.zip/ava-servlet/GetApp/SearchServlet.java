import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SearchServlet extends HttpServlet {

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
                      throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String regno = request.getParameter("regno");

        out.println("<html><body>");
        out.println("<h2>Student Search Result</h2>");
        out.println("<p>Register Number: " + regno + "</p>");
        out.println("<p>Student record received successfully!</p>");
        out.println("</body></html>");
    }
}
