FULL-STACK END-SEM PRACTICE — SIMPLE VERSION
================================================

Included projects:
1. HospitalManagement
2. ShoppingCart
3. VehicleService
4. MovieTicketBooking

Each project contains:
- backend: Spring Boot + MongoDB
- frontend: Vue + basic CSS
- servlet: a separate basic Java Servlet project for Tomcat 9
- README.md and POSTMAN-EXAMPLES.txt

IMPORTANT CODE STYLE
- Simple model, repository, service and controller classes.
- Straightforward methods and indentation.
- No ResponseEntity<?> or complicated exception-handling structure.
- Basic forms, record displays, colours, borders and button hover.
- Each backend uses two MongoDB collections and simple logic linking them.

RUN ONE BACKEND AT A TIME
All four Spring Boot projects use port 8082. Do not run them simultaneously.
Each project's database name is set in backend/src/main/resources/application.properties.

RUN BACKEND
1. Start MongoDB.
2. Open one project's backend folder in IntelliJ.
3. Run Application.java.
4. Test with Postman at http://localhost:8082.

RUN FRONTEND
1. Open that project's frontend folder in VS Code.
2. Run: npm install
3. Run: npm run dev
4. Open the URL printed by Vite.

RUN SERVLET
1. Open that project's servlet folder.
2. Build with: mvn clean package
3. Copy target/simple-servlet-1.0.war into Tomcat 9's webapps folder.
4. Start Tomcat.
5. The servlet mapping is /calculate and expects POST parameters named first and second.

QUESTION BANK
Open ALL-POSSIBLE-PRACTICAL-MODIFICATIONS.txt for task-style questions:
- CRUD and count tasks
- searching, filtering and status changes
- connecting the two collections
- all four project-specific practical variations
- Vue, CSS, JavaScript, Postman, MongoDB and Servlet practice

EXAM REMINDER
The question bank covers a broad range of likely modifications but cannot guarantee the exact question.
I could not run Maven builds here because Maven is not installed in the build environment. Run each project once on your Windows laptop before the exam.
