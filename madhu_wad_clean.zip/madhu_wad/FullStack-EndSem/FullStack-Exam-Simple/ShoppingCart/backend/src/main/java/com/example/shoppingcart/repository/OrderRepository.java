package com.example.shoppingcart.repository;

import com.example.shoppingcart.model.Order;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface OrderRepository extends MongoRepository<Order, String> {
    List<Order> findByProductId(String value);
    List<Order> findByCustomerName(String customerName);
    long countByCustomerName(String customerName);
}
