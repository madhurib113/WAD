package com.example.shoppingcart.service;

import com.example.shoppingcart.model.*;
import com.example.shoppingcart.repository.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MainService {
    private final ProductRepository productRepo;
    private final OrderRepository orderRepo;

    public MainService(ProductRepository productRepo, OrderRepository orderRepo) {
        this.productRepo = productRepo;
        this.orderRepo = orderRepo;
    }

    public List<Product> getProducts() {
        return productRepo.findAll();
    }

    public Product addProduct(Product item) {
        return productRepo.save(item);
    }

    public Product updateProduct(String id, Product item) {
        item.setId(id);
        return productRepo.save(item);
    }

    public void deleteProduct(String id) {
        productRepo.deleteById(id);
    }

    public long countProducts() {
        return productRepo.count();
    }

    public List<Order> getOrders() {
        return orderRepo.findAll();
    }

    public Order addOrder(Order order) {
        Product product = productRepo.findByProductId(order.getProductId()).stream().findFirst().orElse(null);
        if (product == null || order.getQuantity() < 1 || product.getStock() < order.getQuantity()) return null;
        order.setTotal(product.getPrice() * order.getQuantity());
        product.setStock(product.getStock() - order.getQuantity());
        productRepo.save(product);
        return orderRepo.save(order);
    }

    public Order updateOrder(String id, Order item) {
        item.setId(id);
        return orderRepo.save(item);
    }

    public void deleteOrder(String id) {
        orderRepo.deleteById(id);
    }

    public long countOrders() {
        return orderRepo.count();
    }
    public long countOrdersByCustomer(String customerName) { return orderRepo.countByCustomerName(customerName); }
}
