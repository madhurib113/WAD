package com.example.shoppingcart.controller;

import com.example.shoppingcart.model.*;
import com.example.shoppingcart.service.MainService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin
public class MainController {
    private final MainService service;

    public MainController(MainService service) {
        this.service = service;
    }

    @GetMapping("/products")
    public List<Product> getProducts() {
        return service.getProducts();
    }

    @PostMapping("/products")
    public Product addProduct(@RequestBody Product item) {
        return service.addProduct(item);
    }

    @PutMapping("/products/{id}")
    public Product updateProduct(@PathVariable String id, @RequestBody Product item) {
        return service.updateProduct(id, item);
    }

    @DeleteMapping("/products/{id}")
    public String deleteProduct(@PathVariable String id) {
        service.deleteProduct(id);
        return "Deleted successfully";
    }

    @GetMapping("/products/count")
    public long countProducts() {
        return service.countProducts();
    }

    @GetMapping("/orders")
    public List<Order> getOrders() {
        return service.getOrders();
    }

    @PostMapping("/orders")
    public Order addOrder(@RequestBody Order item) {
        return service.addOrder(item);
    }

    @PutMapping("/orders/{id}")
    public Order updateOrder(@PathVariable String id, @RequestBody Order item) {
        return service.updateOrder(id, item);
    }

    @DeleteMapping("/orders/{id}")
    public String deleteOrder(@PathVariable String id) {
        service.deleteOrder(id);
        return "Deleted successfully";
    }

    @GetMapping("/orders/count")
    public long countOrders() {
        return service.countOrders();
    }

    @GetMapping("/orders/count/customer/{customerName}")
    public long countOrdersByCustomer(@PathVariable String customerName) {
        return service.countOrdersByCustomer(customerName);
    }
}
