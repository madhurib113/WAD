```vue
<script setup>
import { ref, onMounted } from 'vue'

const products = ref([])
const orders = ref([])

const product = ref({
  productId: '',
  name: '',
  price: 0,
  stock: 0
})

const order = ref({
  orderId: '',
  customerName: '',
  productId: '',
  quantity: 1,
  total: 0
})

const url = 'http://localhost:8082'

async function getProducts() {
  const res = await fetch(url + '/products')
  products.value = await res.json()
}

async function getOrders() {
  const res = await fetch(url + '/orders')
  orders.value = await res.json()
}

async function addProduct() {
  await fetch(url + '/products', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(product.value)
  })

  product.value = { productId: '', name: '', price: 0, stock: 0 }
  getProducts()
}

async function addOrder() {
  await fetch(url + '/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(order.value)
  })

  getProducts()
  getOrders()
}

onMounted(() => {
  getProducts()
  getOrders()
})
</script>

<template>
  <h1>Shopping Cart</h1>

  <h2>Add Product</h2>
  <form @submit.prevent="addProduct">
    <input v-model="product.productId" placeholder="Product ID" required />
    <input v-model="product.name" placeholder="Product Name" required />
    <input v-model.number="product.price" type="number" placeholder="Price" required />
    <input v-model.number="product.stock" type="number" placeholder="Stock" required />
    <button>Add Product</button>
  </form>

  <h2>Product Records</h2>
  <div v-for="p in products" :key="p.id" class="record">
    <p>Product ID: {{ p.productId }}</p>
    <p>Name: {{ p.name }}</p>
    <p>Price: ₹{{ p.price }}</p>
    <p>Stock: {{ p.stock }}</p>
  </div>

  <h2>Place Order</h2>
  <form @submit.prevent="addOrder">
    <input v-model="order.orderId" placeholder="Order ID" required />
    <input v-model="order.customerName" placeholder="Customer Name" required />

    <select v-model="order.productId" required>
      <option value="" disabled>Select Product</option>
      <option v-for="p in products" :key="p.id" :value="p.productId">
        {{ p.name }} ({{ p.productId }})
      </option>
    </select>

    <input v-model.number="order.quantity" type="number" min="1" placeholder="Quantity" required />
    <button>Place Order</button>
  </form>

  <h2>Order Records</h2>
  <div v-for="o in orders" :key="o.id" class="record">
    <p>Order ID: {{ o.orderId }}</p>
    <p>Customer: {{ o.customerName }}</p>
    <p>Product ID: {{ o.productId }}</p>
    <p>Quantity: {{ o.quantity }}</p>
    <p>Total: ₹{{ o.total }}</p>
  </div>
</template>
```