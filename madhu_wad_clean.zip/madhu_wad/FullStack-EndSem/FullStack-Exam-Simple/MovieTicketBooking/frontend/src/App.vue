```vue
<script setup>
import { ref, reactive, onMounted } from 'vue'

const API = 'http://localhost:8082'
const firstList = ref([])
const secondList = ref([])
const message = ref('')
const firstCount = ref(0)
const secondCount = ref(0)

const first = reactive({showId:'', movieName:'', screen:'', availableSeats:0, ticketPrice:0})
const second = reactive({ticketId:'', customerName:'', showId:'', seats:0})

async function request(path, method = 'GET', body = null) {
    const options = { method, headers: { 'Content-Type': 'application/json' } }
    if (body !== null) options.body = JSON.stringify(body)
    const response = await fetch(API + path, options)
    const text = await response.text()
    if (!response.ok) throw new Error(text || 'Request failed')
    return text ? JSON.parse(text) : null
}

async function loadData() {
    try {
        firstList.value = await request('/shows')
        secondList.value = await request('/tickets')
        firstCount.value = await request('/shows/count')
        secondCount.value = await request('/tickets/count')
        message.value = 'Records loaded'
    } catch (error) {
        message.value = 'Could not load data. Check backend and MongoDB.'
    }
}

async function addFirst() {
    try {
        await request('/shows', 'POST', first)
        message.value = 'Show added'
        Object.keys(first).forEach(key => first[key] = (typeof first[key] === 'boolean' ? false : (typeof first[key] === 'number' ? 0 : '')))
        await loadData()
    } catch (error) {
        message.value = error.message
    }
}

async function addSecond() {
    try {
        const result = await request('/tickets', 'POST', second)
        if (result === null) {
            message.value = 'Not saved. Check related ID and available amount.'
            return
        }
        message.value = 'Ticket added'
        Object.keys(second).forEach(key => second[key] = (typeof second[key] === 'boolean' ? false : (typeof second[key] === 'number' ? 0 : '')))
        await loadData()
    } catch (error) {
        message.value = error.message
    }
}

async function removeRecord(path, id) {
    try {
        await request('/' + path + '/' + id, 'DELETE')
        message.value = 'Record deleted'
        await loadData()
    } catch (error) {
        message.value = error.message
    }
}

onMounted(loadData)
</script>

<template>
  <main>
    <header>
      <h1>Movie Ticket Booking</h1>
      <p>Spring Boot · MongoDB · Vue</p>
    </header>

    <p class="message">{{ message }}</p>

    <section class="panel">
      <h2>Add Show</h2>
      <form @submit.prevent="addFirst">
        <input v-model="first.showId" type="text" placeholder="showId" required>
        <input v-model="first.movieName" type="text" placeholder="movieName" required>
        <input v-model="first.screen" type="text" placeholder="screen" required>
        <input v-model.number="first.availableSeats" type="number" placeholder="availableSeats" required>
        <input v-model.number="first.ticketPrice" type="number" placeholder="ticketPrice" required>
        <button type="submit">Add Show</button>
      </form>
    </section>

    <section class="panel">
      <h2>Add Ticket</h2>
      <p>Enter the existing Show ID in the related ID field.</p>
      <form @submit.prevent="addSecond">
        <input v-model="second.ticketId" type="text" placeholder="ticketId" required>
        <input v-model="second.customerName" type="text" placeholder="customerName" required>
        <input v-model="second.showId" type="text" placeholder="showId" required>
        <input v-model.number="second.seats" type="number" placeholder="seats" required>
        <button type="submit">Add Ticket</button>
      </form>
    </section>

    <section class="panel">
      <h2>Counts</h2>
      <p>Total shows: {{ firstCount }}</p>
      <p>Total tickets: {{ secondCount }}</p>
      <button @click="loadData">Refresh counts and records</button>
    </section>

    <section class="panel">
      <h2>Show records</h2>
      <div v-for="item in firstList" :key="item.id" class="record">
        <p><b>Show ID:</b> {{ item.showId }}</p>
        <p><b>Movie Name:</b> {{ item.movieName }}</p>
        <p><b>Screen:</b> {{ item.screen }}</p>
        <p><b>Available Seats:</b> {{ item.availableSeats }}</p>
        <p><b>Ticket Price:</b> ₹{{ item.ticketPrice }}</p>
        <button class="delete" @click="removeRecord('shows', item.id)">Delete</button>
      </div>
    </section>

    <section class="panel">
      <h2>Ticket records</h2>
      <div v-for="item in secondList" :key="item.id" class="record">
        <p><b>Ticket ID:</b> {{ item.ticketId }}</p>
        <p><b>Customer Name:</b> {{ item.customerName }}</p>
        <p><b>Show ID:</b> {{ item.showId }}</p>
        <p><b>Seats:</b> {{ item.seats }}</p>
        <button class="delete" @click="removeRecord('tickets', item.id)">Delete</button>
      </div>
    </section>
  </main>
</template>
```