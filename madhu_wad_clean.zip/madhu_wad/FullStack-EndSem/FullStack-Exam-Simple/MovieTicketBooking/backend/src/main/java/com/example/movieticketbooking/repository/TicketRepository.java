package com.example.movieticketbooking.repository;

import com.example.movieticketbooking.model.Ticket;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface TicketRepository extends MongoRepository<Ticket, String> {
    List<Ticket> findByShowId(String value);
    List<Ticket> findByCustomerName(String customerName);
    long countByShowId(String showId);
}
