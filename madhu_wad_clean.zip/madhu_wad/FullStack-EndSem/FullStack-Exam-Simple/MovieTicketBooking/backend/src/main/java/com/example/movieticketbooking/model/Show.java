package com.example.movieticketbooking.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "shows")
public class Show {
    @Id
    private String id;
    private String showId;
    private String movieName;
    private String screen;
    private int availableSeats;
    private double ticketPrice;
}
