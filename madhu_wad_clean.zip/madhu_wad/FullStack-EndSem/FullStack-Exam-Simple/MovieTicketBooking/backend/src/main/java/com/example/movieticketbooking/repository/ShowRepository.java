package com.example.movieticketbooking.repository;

import com.example.movieticketbooking.model.Show;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface ShowRepository extends MongoRepository<Show, String> {
    List<Show> findByShowId(String value);
    List<Show> findByAvailableSeatsGreaterThan(int seats);
}
