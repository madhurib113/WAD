package com.example.movieticketbooking.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "tickets")
public class Ticket {
    @Id
    private String id;
    private String ticketId;
    private String customerName;
    private String showId;
    private int seats;
    private double totalPrice;
}
