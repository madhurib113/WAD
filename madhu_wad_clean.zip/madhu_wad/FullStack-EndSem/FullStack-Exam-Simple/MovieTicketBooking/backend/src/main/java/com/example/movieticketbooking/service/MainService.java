package com.example.movieticketbooking.service;

import com.example.movieticketbooking.model.*;
import com.example.movieticketbooking.repository.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MainService {
    private final ShowRepository showRepo;
    private final TicketRepository ticketRepo;

    public MainService(ShowRepository showRepo, TicketRepository ticketRepo) {
        this.showRepo = showRepo;
        this.ticketRepo = ticketRepo;
    }

    public List<Show> getShows() {
        return showRepo.findAll();
    }

    public Show addShow(Show item) {
        return showRepo.save(item);
    }

    public Show updateShow(String id, Show item) {
        item.setId(id);
        return showRepo.save(item);
    }

    public void deleteShow(String id) {
        showRepo.deleteById(id);
    }

    public long countShows() {
        return showRepo.count();
    }

    public List<Ticket> getTickets() {
        return ticketRepo.findAll();
    }

    public Ticket addTicket(Ticket ticket) {
        Show show = showRepo.findByShowId(ticket.getShowId()).stream().findFirst().orElse(null);
        if (show == null || ticket.getSeats() < 1 || show.getAvailableSeats() < ticket.getSeats()) return null;
        ticket.setTotalPrice(show.getTicketPrice() * ticket.getSeats());
        show.setAvailableSeats(show.getAvailableSeats() - ticket.getSeats());
        showRepo.save(show);
        return ticketRepo.save(ticket);
    }

    public Ticket updateTicket(String id, Ticket item) {
        item.setId(id);
        return ticketRepo.save(item);
    }

    public void deleteTicket(String id) {
        ticketRepo.deleteById(id);
    }

    public long countTickets() {
        return ticketRepo.count();
    }
    public List<Show> getAvailableShows() { return showRepo.findByAvailableSeatsGreaterThan(0); }
    public long countTicketsByShow(String showId) { return ticketRepo.countByShowId(showId); }
}
