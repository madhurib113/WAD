package com.example.movieticketbooking.controller;

import com.example.movieticketbooking.model.*;
import com.example.movieticketbooking.service.MainService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin
public class MainController {
    private final MainService service;

    public MainController(MainService service) {
        this.service = service;
    }

    @GetMapping("/shows")
    public List<Show> getShows() {
        return service.getShows();
    }

    @PostMapping("/shows")
    public Show addShow(@RequestBody Show item) {
        return service.addShow(item);
    }

    @PutMapping("/shows/{id}")
    public Show updateShow(@PathVariable String id, @RequestBody Show item) {
        return service.updateShow(id, item);
    }

    @DeleteMapping("/shows/{id}")
    public String deleteShow(@PathVariable String id) {
        service.deleteShow(id);
        return "Deleted successfully";
    }

    @GetMapping("/shows/count")
    public long countShows() {
        return service.countShows();
    }

    @GetMapping("/tickets")
    public List<Ticket> getTickets() {
        return service.getTickets();
    }

    @PostMapping("/tickets")
    public Ticket addTicket(@RequestBody Ticket item) {
        return service.addTicket(item);
    }

    @PutMapping("/tickets/{id}")
    public Ticket updateTicket(@PathVariable String id, @RequestBody Ticket item) {
        return service.updateTicket(id, item);
    }

    @DeleteMapping("/tickets/{id}")
    public String deleteTicket(@PathVariable String id) {
        service.deleteTicket(id);
        return "Deleted successfully";
    }

    @GetMapping("/tickets/count")
    public long countTickets() {
        return service.countTickets();
    }

    @GetMapping("/shows/available")
    public List<Show> getAvailableShows() {
        return service.getAvailableShows();
    }
    @GetMapping("/tickets/count/show/{showId}")
    public long countTicketsByShow(@PathVariable String showId) {
        return service.countTicketsByShow(showId);
    }
}
