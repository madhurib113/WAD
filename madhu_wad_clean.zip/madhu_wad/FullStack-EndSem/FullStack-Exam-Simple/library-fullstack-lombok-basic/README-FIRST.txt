LIBRARY FULL-STACK PRACTICE PROJECT
Simple structure, Lombok included, no MockMvc.

Folders:
- backend: Spring Boot + MongoDB. Model, Repository, Service, Controller.
- frontend: plain Vue forms and tables. No styling.
- servlet: separate basic Servlet form for Tomcat 9.

Database: librarydb
Collections: books, issues
Ports: backend 8082, Vue 5173, Servlet Tomcat 8080

Open backend/ in IntelliJ.
Open frontend/ in VS Code.
Open servlet/ separately for Servlet practice.

Code comments explain each file's purpose and each main operation.
