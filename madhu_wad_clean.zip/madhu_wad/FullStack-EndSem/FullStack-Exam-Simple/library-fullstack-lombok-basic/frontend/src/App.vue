```vue
<script setup>
import { ref, onMounted } from 'vue'

const API = 'http://localhost:8082'

const books = ref([])
const issues = ref([])
const message = ref('Vue is running.')

const book = ref({
  bookId: '',
  title: '',
  author: '',
  availCopies: 0
})

const issue = ref({
  issueId: '',
  studentName: '',
  bookId: '',
  quantity: 1
})

async function loadBooks() {
  try {
    const res = await fetch(API + '/books')
    if (!res.ok) throw new Error()
    books.value = await res.json()
  } catch {
    message.value = 'Cannot connect to backend. Check Spring Boot.'
  }
}

async function loadIssues() {
  try {
    const res = await fetch(API + '/issues')
    if (!res.ok) throw new Error()
    issues.value = await res.json()
  } catch {
    message.value = 'Cannot load issues. Check backend and CORS.'
  }
}

async function addBook() {
  try {
    const res = await fetch(API + '/books', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        bookId: book.value.bookId,
        title: book.value.title,
        author: book.value.author,
        availCopies: Number(book.value.availCopies)
      })
    })

    if (!res.ok) {
      message.value = 'Book add failed: HTTP ' + res.status
      return
    }

    message.value = 'Book added successfully!'
    book.value = {
      bookId: '', title: '', author: '', availCopies: 0
    }
    await loadBooks()
  } catch {
    message.value = 'Book add failed. Check backend and CORS.'
  }
}

async function addIssue() {
  try {
    const res = await fetch(API + '/issues', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        issueId: issue.value.issueId,
        studentName: issue.value.studentName,
        bookId: issue.value.bookId,
        quantity: Number(issue.value.quantity)
      })
    })

    if (!res.ok) {
      message.value = 'Issue add failed: HTTP ' + res.status
      return
    }

    message.value = 'Issue added successfully!'
    issue.value = {
      issueId: '', studentName: '', bookId: '', quantity: 1
    }
    await loadIssues()
  } catch {
    message.value = 'Issue add failed. Check backend and CORS.'
  }
}

onMounted(() => {
  loadBooks()
  loadIssues()
})
</script>

<template>
  <div>
    <h1>Library Management System</h1>
    <p>{{ message }}</p>

    <hr>

    <h2>Add Book</h2>

    <form @submit.prevent="addBook">
      <p>
        Book ID:
        <input v-model="book.bookId" required>
      </p>

      <p>
        Title:
        <input v-model="book.title" required>
      </p>

      <p>
        Author:
        <input v-model="book.author" required>
      </p>

      <p>
        Available Copies:
        <input v-model.number="book.availCopies"
               type="number" min="0" required>
      </p>

      <button type="submit">Add Book</button>
    </form>

    <h2>Book List</h2>

    <table border="1" cellpadding="5">
      <thead>
        <tr>
          <th>Book ID</th>
          <th>Title</th>
          <th>Author</th>
          <th>Copies</th>
        </tr>
      </thead>

      <tbody>
        <tr v-for="b in books" :key="b.id">
          <td>{{ b.bookId }}</td>
          <td>{{ b.title }}</td>
          <td>{{ b.author }}</td>
          <td>{{ b.availCopies }}</td>
        </tr>
      </tbody>
    </table>

    <hr>

    <h2>Add Book Issue</h2>

    <form @submit.prevent="addIssue">
      <p>
        Issue ID:
        <input v-model="issue.issueId" required>
      </p>

      <p>
        Student Name:
        <input v-model="issue.studentName" required>
      </p>

      <p>
        Book ID:
        <input v-model="issue.bookId" required>
      </p>

      <p>
        Quantity:
        <input v-model.number="issue.quantity"
               type="number" min="1" required>
      </p>

      <button type="submit">Add Issue</button>
    </form>

    <h2>Issue List</h2>

    <table border="1" cellpadding="5">
      <thead>
        <tr>
          <th>Issue ID</th>
          <th>Student Name</th>
          <th>Book ID</th>
          <th>Quantity</th>
        </tr>
      </thead>

      <tbody>
        <tr v-for="i in issues" :key="i.id">
          <td>{{ i.issueId }}</td>
          <td>{{ i.studentName }}</td>
          <td>{{ i.bookId }}</td>
          <td>{{ i.quantity }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
```