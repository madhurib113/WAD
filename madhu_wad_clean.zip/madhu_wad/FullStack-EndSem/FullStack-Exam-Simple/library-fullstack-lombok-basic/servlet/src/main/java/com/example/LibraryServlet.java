package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Simple form servlet: GET displays the form; POST displays submitted values.
@WebServlet("/library")
public class LibraryServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html><body><h2>Library Book Issue Form</h2>");
        out.println("<form method='post' action='library'>");
        out.println("Student name: <input name='studentName' required><br><br>");
        out.println("Book ID: <input name='bookId' required><br><br>");
        out.println("Quantity: <input name='quantity' type='number' min='1' required><br><br>");
        out.println("<button type='submit'>Submit</button></form></body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html><body><h2>Submitted Book Issue</h2>");
        out.println("<p>Student: " + escape(request.getParameter("studentName")) + "</p>");
        out.println("<p>Book ID: " + escape(request.getParameter("bookId")) + "</p>");
        out.println("<p>Quantity: " + escape(request.getParameter("quantity")) + "</p>");
        out.println("<a href='library'>Back</a></body></html>");
    }

    // Escape submitted text before displaying it in HTML.
    private String escape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#x27;");
    }
}
