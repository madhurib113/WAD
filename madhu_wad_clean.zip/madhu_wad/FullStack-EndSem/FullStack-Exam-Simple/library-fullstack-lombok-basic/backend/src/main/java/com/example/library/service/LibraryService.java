package com.example.library.service;

import com.example.library.model.Book;
import com.example.library.model.BookIssue;
import com.example.library.repository.BookRepository;
import com.example.library.repository.BookIssueRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// Service contains the application's basic operations and simple validation.
@Service
public class LibraryService {
    private final BookRepository bookRepository;
    private final BookIssueRepository issueRepository;

    public LibraryService(BookRepository bookRepository, BookIssueRepository issueRepository) {
        this.bookRepository = bookRepository;
        this.issueRepository = issueRepository;
    }

    // BOOK OPERATIONS
    public Book addBook(Book book) {
        if (book.getAvailCopies() < 0) throw new IllegalArgumentException("Copies cannot be negative");
        return bookRepository.save(book);
    }
    public List<Book> getBooks() { return bookRepository.findAll(); }
    public Optional<Book> getBook(String id) { return bookRepository.findById(id); }

    public Optional<Book> updateBook(String id, Book updated) {
        if (updated.getAvailCopies() < 0) throw new IllegalArgumentException("Copies cannot be negative");
        return bookRepository.findById(id).map(book -> {
            book.setBookId(updated.getBookId());
            book.setTitle(updated.getTitle());
            book.setAuthor(updated.getAuthor());
            book.setAvailCopies(updated.getAvailCopies());
            return bookRepository.save(book);
        });
    }

    // PATCH-style operation: changes only the available-copy count.
    public Optional<Book> updateCopies(String id, int copies) {
        if (copies < 0) throw new IllegalArgumentException("Copies cannot be negative");
        return bookRepository.findById(id).map(book -> {
            book.setAvailCopies(copies);
            return bookRepository.save(book);
        });
    }
    public boolean deleteBook(String id) {
        if (!bookRepository.existsById(id)) return false;
        bookRepository.deleteById(id);
        return true;
    }
    public long countBooks() { return bookRepository.count(); }
    public List<Book> searchTitle(String title) { return bookRepository.findByTitleContainingIgnoreCase(title); }
    public List<Book> searchAuthor(String author) { return bookRepository.findByAuthorContainingIgnoreCase(author); }
    public List<Book> availableBooks() { return bookRepository.findByAvailCopiesGreaterThan(0); }

    // ISSUE OPERATIONS
    public BookIssue addIssue(BookIssue issue) {
        if (issue.getQuantity() <= 0) throw new IllegalArgumentException("Quantity must be positive");
        return issueRepository.save(issue);
    }
    public List<BookIssue> getIssues() { return issueRepository.findAll(); }
    public Optional<BookIssue> getIssue(String id) { return issueRepository.findById(id); }
    public Optional<BookIssue> updateIssue(String id, BookIssue updated) {
        if (updated.getQuantity() <= 0) throw new IllegalArgumentException("Quantity must be positive");
        return issueRepository.findById(id).map(issue -> {
            issue.setIssueId(updated.getIssueId());
            issue.setStudentName(updated.getStudentName());
            issue.setBookId(updated.getBookId());
            issue.setQuantity(updated.getQuantity());
            return issueRepository.save(issue);
        });
    }
    public boolean deleteIssue(String id) {
        if (!issueRepository.existsById(id)) return false;
        issueRepository.deleteById(id);
        return true;
    }
    public long countIssues() { return issueRepository.count(); }
    public List<BookIssue> searchStudent(String name) { return issueRepository.findByStudentNameContainingIgnoreCase(name); }
    public List<BookIssue> issuesForBook(String bookId) { return issueRepository.findByBookId(bookId); }
}
