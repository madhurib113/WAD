package com.example.library.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// One Book object is stored as one document in the books collection.
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "books")
public class Book {
    @Id
    private String id;          // MongoDB document ID
    private String bookId;      // ID used by the library
    private String title;
    private String author;
    private int availCopies;
}
