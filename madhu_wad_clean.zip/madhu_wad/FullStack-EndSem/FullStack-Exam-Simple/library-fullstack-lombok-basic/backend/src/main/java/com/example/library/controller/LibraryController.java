package com.example.library.controller;

import com.example.library.model.Book;
import com.example.library.model.BookIssue;
import com.example.library.service.LibraryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

// Controller maps URLs to service operations.
@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class LibraryController {
    private final LibraryService service;

    public LibraryController(LibraryService service) {
        this.service = service;
    }

    // BOOK URLS
    @PostMapping("/books")
    public ResponseEntity<?> addBook(@RequestBody Book book) {
        try { return ResponseEntity.status(201).body(service.addBook(book)); }
        catch (IllegalArgumentException e) { return ResponseEntity.badRequest().body(e.getMessage()); }
    }
    @GetMapping("/books")
    public List<Book> getBooks() { return service.getBooks(); }

    @GetMapping("/books/{id}")
    public ResponseEntity<Book> getBook(@PathVariable String id) {
        return service.getBook(id).map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/books/{id}")
    public ResponseEntity<?> updateBook(@PathVariable String id, @RequestBody Book book) {
        try { return service.updateBook(id, book).<ResponseEntity<?>>map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build()); }
        catch (IllegalArgumentException e) { return ResponseEntity.badRequest().body(e.getMessage()); }
    }

    @PatchMapping("/books/{id}/copies")
    public ResponseEntity<?> updateCopies(@PathVariable String id, @RequestParam int copies) {
        try { return service.updateCopies(id, copies).<ResponseEntity<?>>map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build()); }
        catch (IllegalArgumentException e) { return ResponseEntity.badRequest().body(e.getMessage()); }
    }

    @DeleteMapping("/books/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable String id) {
        return service.deleteBook(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
    @GetMapping("/books/count")
    public long countBooks() { return service.countBooks(); }
    @GetMapping("/books/search")
    public List<Book> searchTitle(@RequestParam String title) { return service.searchTitle(title); }
    @GetMapping("/books/author")
    public List<Book> searchAuthor(@RequestParam String author) { return service.searchAuthor(author); }
    @GetMapping("/books/available")
    public List<Book> availableBooks() { return service.availableBooks(); }

    // ISSUE URLS
    @PostMapping("/issues")
    public ResponseEntity<?> addIssue(@RequestBody BookIssue issue) {
        try { return ResponseEntity.status(201).body(service.addIssue(issue)); }
        catch (IllegalArgumentException e) { return ResponseEntity.badRequest().body(e.getMessage()); }
    }
    @GetMapping("/issues")
    public List<BookIssue> getIssues() { return service.getIssues(); }
    @GetMapping("/issues/{id}")
    public ResponseEntity<BookIssue> getIssue(@PathVariable String id) {
        return service.getIssue(id).map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
    @PutMapping("/issues/{id}")
    public ResponseEntity<?> updateIssue(@PathVariable String id, @RequestBody BookIssue issue) {
        try { return service.updateIssue(id, issue).<ResponseEntity<?>>map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build()); }
        catch (IllegalArgumentException e) { return ResponseEntity.badRequest().body(e.getMessage()); }
    }
    @DeleteMapping("/issues/{id}")
    public ResponseEntity<Void> deleteIssue(@PathVariable String id) {
        return service.deleteIssue(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
    @GetMapping("/issues/count")
    public long countIssues() { return service.countIssues(); }
    @GetMapping("/issues/student")
    public List<BookIssue> searchStudent(@RequestParam String name) { return service.searchStudent(name); }
    @GetMapping("/issues/book/{bookId}")
    public List<BookIssue> issuesForBook(@PathVariable String bookId) { return service.issuesForBook(bookId); }
}
