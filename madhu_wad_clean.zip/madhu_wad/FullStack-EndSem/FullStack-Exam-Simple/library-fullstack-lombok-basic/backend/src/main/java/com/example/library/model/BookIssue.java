package com.example.library.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// One book issue record is stored in the issues collection.
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "issues")
public class BookIssue {
    @Id
    private String id;          // MongoDB document ID
    private String issueId;     // ID used by the library
    private String studentName;
    private String bookId;
    private int quantity;
}
