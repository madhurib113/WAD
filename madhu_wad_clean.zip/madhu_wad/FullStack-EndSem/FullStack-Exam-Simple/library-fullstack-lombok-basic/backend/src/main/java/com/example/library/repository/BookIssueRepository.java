package com.example.library.repository;

import com.example.library.model.BookIssue;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

// Extra find methods are translated into MongoDB queries by Spring Data.
public interface BookIssueRepository extends MongoRepository<BookIssue, String> {
    List<BookIssue> findByStudentNameContainingIgnoreCase(String studentName);
    List<BookIssue> findByBookId(String bookId);
}
