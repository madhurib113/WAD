# Hospital Management — simple exam practice

## Stack
- Spring Boot 3, Java 17, MongoDB
- Vue 3, Vite, basic CSS
- Separate simple Servlet project for Tomcat 9

## Backend structure
- `model`: the two MongoDB document classes
- `repository`: simple `MongoRepository` interfaces
- `service`: CRUD methods and the connection between the two collections
- `controller`: straightforward GET, POST, PUT, DELETE and count endpoints

## Run backend
1. Start MongoDB.
2. Open the `backend` folder in IntelliJ.
3. Check `src/main/resources/application.properties`.
4. Run `Application.java`. The backend uses port 8082.

Only run one project's backend on port 8082 at a time.

## Run Vue
1. Open the `frontend` folder in VS Code terminal.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the Vite URL shown in the terminal.

## Important connection rule
Create a record in the first collection before adding a related record in the second collection.
The second record must use the first record's business ID. If the related record is missing or has no available quantity, the service returns `null`.

## Endpoints
- `GET /doctors`
- `POST /doctors`
- `PUT /doctors/{id}`
- `DELETE /doctors/{id}`
- `GET /doctors/count`
- `GET /appointments`
- `POST /appointments`
- `PUT /appointments/{id}`
- `DELETE /appointments/{id}`
- `GET /appointments/count`
- `GET /appointments/count/doctor/{doctorId}`
