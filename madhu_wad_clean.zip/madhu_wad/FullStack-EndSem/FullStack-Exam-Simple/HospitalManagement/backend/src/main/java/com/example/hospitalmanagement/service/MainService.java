package com.example.hospitalmanagement.service;

import com.example.hospitalmanagement.model.*;
import com.example.hospitalmanagement.repository.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MainService {
    private final DoctorRepository doctorRepo;
    private final AppointmentRepository appointmentRepo;

    public MainService(DoctorRepository doctorRepo, AppointmentRepository appointmentRepo) {
        this.doctorRepo = doctorRepo;
        this.appointmentRepo = appointmentRepo;
    }

    public List<Doctor> getDoctors() {
        return doctorRepo.findAll();
    }

    public Doctor addDoctor(Doctor item) {
        return doctorRepo.save(item);
    }

    public Doctor updateDoctor(String id, Doctor item) {
        item.setId(id);
        return doctorRepo.save(item);
    }

    public void deleteDoctor(String id) {
        doctorRepo.deleteById(id);
    }

    public long countDoctors() {
        return doctorRepo.count();
    }

    public List<Appointment> getAppointments() {
        return appointmentRepo.findAll();
    }

    public Appointment addAppointment(Appointment appointment) {
        Doctor doctor = doctorRepo.findByDoctorId(appointment.getDoctorId()).stream().findFirst().orElse(null);
        if (doctor == null || doctor.getAvailableSlots() < 1) return null;
        doctor.setAvailableSlots(doctor.getAvailableSlots() - 1);
        doctorRepo.save(doctor);
        return appointmentRepo.save(appointment);
    }

    public Appointment updateAppointment(String id, Appointment item) {
        item.setId(id);
        return appointmentRepo.save(item);
    }

    public void deleteAppointment(String id) {
        appointmentRepo.deleteById(id);
    }

    public long countAppointments() {
        return appointmentRepo.count();
    }
    public long countAppointmentsByDoctor(String doctorId) { return appointmentRepo.countByDoctorId(doctorId); }
}
