package com.example.hospitalmanagement.controller;

import com.example.hospitalmanagement.model.*;
import com.example.hospitalmanagement.service.MainService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin
public class MainController {
    private final MainService service;

    public MainController(MainService service) {
        this.service = service;
    }

    @GetMapping("/doctors")
    public List<Doctor> getDoctors() {
        return service.getDoctors();
    }

    @PostMapping("/doctors")
    public Doctor addDoctor(@RequestBody Doctor item) {
        return service.addDoctor(item);
    }

    @PutMapping("/doctors/{id}")
    public Doctor updateDoctor(@PathVariable String id, @RequestBody Doctor item) {
        return service.updateDoctor(id, item);
    }

    @DeleteMapping("/doctors/{id}")
    public String deleteDoctor(@PathVariable String id) {
        service.deleteDoctor(id);
        return "Deleted successfully";
    }

    @GetMapping("/doctors/count")
    public long countDoctors() {
        return service.countDoctors();
    }

    @GetMapping("/appointments")
    public List<Appointment> getAppointments() {
        return service.getAppointments();
    }

    @PostMapping("/appointments")
    public Appointment addAppointment(@RequestBody Appointment item) {
        return service.addAppointment(item);
    }

    @PutMapping("/appointments/{id}")
    public Appointment updateAppointment(@PathVariable String id, @RequestBody Appointment item) {
        return service.updateAppointment(id, item);
    }

    @DeleteMapping("/appointments/{id}")
    public String deleteAppointment(@PathVariable String id) {
        service.deleteAppointment(id);
        return "Deleted successfully";
    }

    @GetMapping("/appointments/count")
    public long countAppointments() {
        return service.countAppointments();
    }

    @GetMapping("/appointments/count/doctor/{doctorId}")
    public long countAppointmentsByDoctor(@PathVariable String doctorId) {
        return service.countAppointmentsByDoctor(doctorId);
    }
}
