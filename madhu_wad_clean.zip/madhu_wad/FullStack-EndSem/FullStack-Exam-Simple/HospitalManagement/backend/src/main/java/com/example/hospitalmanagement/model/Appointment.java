package com.example.hospitalmanagement.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "appointments")
public class Appointment {
    @Id
    private String id;
    private String appointmentId;
    private String patientName;
    private String doctorId;
    private String date;
    private String status;
}
