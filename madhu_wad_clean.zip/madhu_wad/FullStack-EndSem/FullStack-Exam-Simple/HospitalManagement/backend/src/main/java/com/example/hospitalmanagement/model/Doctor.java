package com.example.hospitalmanagement.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "doctors")
public class Doctor {
    @Id
    private String id;
    private String doctorId;
    private String name;
    private String specialization;
    private int availableSlots;
}
