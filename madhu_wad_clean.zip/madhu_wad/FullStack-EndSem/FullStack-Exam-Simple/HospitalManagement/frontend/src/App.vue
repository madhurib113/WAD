```vue
<script setup>
import { ref, onMounted } from 'vue'

const doctors = ref([])
const appointments = ref([])

const doctorCount = ref(0)
const appointmentCount = ref(0)

const doctor = ref({
  doctorId: '',
  name: '',
  specialization: '',
  availableSlots: 0
})

const appointment = ref({
  appointmentId: '',
  patientName: '',
  doctorId: '',
  date: ''
})

const API = 'http://localhost:8082'

async function getDoctors() {
  const response = await fetch(API + '/doctors')
  doctors.value = await response.json()
  doctorCount.value = doctors.value.length
}

async function getAppointments() {
  const response = await fetch(API + '/appointments')
  appointments.value = await response.json()
  appointmentCount.value = appointments.value.length
}

async function addDoctor() {
  const response = await fetch(API + '/doctors', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(doctor.value)
  })

  if (response.ok) {
    alert('Doctor added successfully!')
    doctor.value = {
      doctorId: '',
      name: '',
      specialization: '',
      availableSlots: 0
    }
    getDoctors()
  } else {
    alert('Could not add doctor')
  }
}

async function addAppointment() {
  const response = await fetch(API + '/appointments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(appointment.value)
  })

  if (response.ok) {
    alert('Appointment added successfully!')
    appointment.value = {
      appointmentId: '',
      patientName: '',
      doctorId: '',
      date: ''
    }
    getDoctors()
    getAppointments()
  } else {
    alert('Booking failed. Check doctor ID and available slots.')
  }
}

async function deleteDoctor(id) {
  if (!confirm('Delete this doctor?')) return

  const response = await fetch(API + '/doctors/' + id, {
    method: 'DELETE'
  })

  if (response.ok) {
    getDoctors()
  } else {
    alert('Could not delete doctor')
  }
}

async function deleteAppointment(id) {
  if (!confirm('Delete this appointment?')) return

  const response = await fetch(API + '/appointments/' + id, {
    method: 'DELETE'
  })

  if (response.ok) {
    getAppointments()
  } else {
    alert('Could not delete appointment')
  }
}

async function refreshAll() {
  await getDoctors()
  await getAppointments()
}

onMounted(refreshAll)
</script>

<template>
  <div class="container">
    <h1>Hospital Management System</h1>

    <div class="counts">
      <div class="count-box">
        <h3>Total Doctors</h3>
        <p>{{ doctorCount }}</p>
      </div>

      <div class="count-box">
        <h3>Total Appointments</h3>
        <p>{{ appointmentCount }}</p>
      </div>
    </div>

    <button @click="refreshAll">Refresh Counts and Records</button>

    <div class="section">
      <h2>Add Doctor</h2>

      <form @submit.prevent="addDoctor">
        <input v-model="doctor.doctorId" placeholder="Doctor ID" required />
        <input v-model="doctor.name" placeholder="Doctor Name" required />
        <input v-model="doctor.specialization" placeholder="Specialization" required />
        <input
          v-model.number="doctor.availableSlots"
          type="number"
          min="0"
          placeholder="Available Slots"
          required
        />
        <button type="submit">Add Doctor</button>
      </form>
    </div>

    <div class="section">
      <h2>Doctor Records</h2>

      <p v-if="doctors.length === 0">No doctors found.</p>

      <div v-for="d in doctors" :key="d.id" class="record">
        <p><b>Doctor ID:</b> {{ d.doctorId }}</p>
        <p><b>Name:</b> {{ d.name }}</p>
        <p><b>Specialization:</b> {{ d.specialization }}</p>
        <p><b>Available Slots:</b> {{ d.availableSlots }}</p>
        <button class="delete" @click="deleteDoctor(d.id)">Delete</button>
      </div>
    </div>

    <div class="section">
      <h2>Book Appointment</h2>

      <form @submit.prevent="addAppointment">
        <input v-model="appointment.appointmentId" placeholder="Appointment ID" required />
        <input v-model="appointment.patientName" placeholder="Patient Name" required />

        <select v-model="appointment.doctorId" required>
          <option value="" disabled>Select Doctor</option>
          <option v-for="d in doctors" :key="d.id" :value="d.doctorId">
            {{ d.name }} ({{ d.doctorId }})
          </option>
        </select>

        <input v-model="appointment.date" type="date" required />
        <button type="submit">Book Appointment</button>
      </form>
    </div>

    <div class="section">
      <h2>Appointment Records</h2>

      <p v-if="appointments.length === 0">No appointments found.</p>

      <div v-for="a in appointments" :key="a.id" class="record">
        <p><b>Appointment ID:</b> {{ a.appointmentId }}</p>
        <p><b>Patient Name:</b> {{ a.patientName }}</p>
        <p><b>Doctor ID:</b> {{ a.doctorId }}</p>
        <p><b>Date:</b> {{ a.date }}</p>
        <button class="delete" @click="deleteAppointment(a.id)">Delete</button>
      </div>
    </div>
  </div>
</template>
```