package com.example.vehicleservice.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "servicebookings")
public class ServiceBooking {
    @Id
    private String id;
    private String bookingId;
    private String vehicleNumber;
    private String customerName;
    private String serviceType;
    private String date;
    private String status;
}
