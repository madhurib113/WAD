package com.example.vehicleservice.repository;

import com.example.vehicleservice.model.ServiceBooking;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface ServiceBookingRepository extends MongoRepository<ServiceBooking, String> {
    List<ServiceBooking> findByVehicleNumber(String value);
    List<ServiceBooking> findByCustomerName(String customerName);
    long countByServiceType(String serviceType);
}
