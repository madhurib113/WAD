package com.example.vehicleservice.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "vehicles")
public class Vehicle {
    @Id
    private String id;
    private String vehicleNumber;
    private String ownerName;
    private String model;
    private boolean available;
}
