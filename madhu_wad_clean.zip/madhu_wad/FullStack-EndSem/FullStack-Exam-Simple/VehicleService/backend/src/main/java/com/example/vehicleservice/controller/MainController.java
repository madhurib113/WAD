package com.example.vehicleservice.controller;

import com.example.vehicleservice.model.*;
import com.example.vehicleservice.service.MainService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin
public class MainController {
    private final MainService service;

    public MainController(MainService service) {
        this.service = service;
    }

    @GetMapping("/vehicles")
    public List<Vehicle> getVehicles() {
        return service.getVehicles();
    }

    @PostMapping("/vehicles")
    public Vehicle addVehicle(@RequestBody Vehicle item) {
        return service.addVehicle(item);
    }

    @PutMapping("/vehicles/{id}")
    public Vehicle updateVehicle(@PathVariable String id, @RequestBody Vehicle item) {
        return service.updateVehicle(id, item);
    }

    @DeleteMapping("/vehicles/{id}")
    public String deleteVehicle(@PathVariable String id) {
        service.deleteVehicle(id);
        return "Deleted successfully";
    }

    @GetMapping("/vehicles/count")
    public long countVehicles() {
        return service.countVehicles();
    }

    @GetMapping("/servicebookings")
    public List<ServiceBooking> getServiceBookings() {
        return service.getServiceBookings();
    }

    @PostMapping("/servicebookings")
    public ServiceBooking addServiceBooking(@RequestBody ServiceBooking item) {
        return service.addServiceBooking(item);
    }

    @PutMapping("/servicebookings/{id}")
    public ServiceBooking updateServiceBooking(@PathVariable String id, @RequestBody ServiceBooking item) {
        return service.updateServiceBooking(id, item);
    }

    @DeleteMapping("/servicebookings/{id}")
    public String deleteServiceBooking(@PathVariable String id) {
        service.deleteServiceBooking(id);
        return "Deleted successfully";
    }

    @GetMapping("/servicebookings/count")
    public long countServiceBookings() {
        return service.countServiceBookings();
    }

    @GetMapping("/vehicles/available")
    public List<Vehicle> getAvailableVehicles() {
        return service.getAvailableVehicles();
    }
    @GetMapping("/servicebookings/count/type/{serviceType}")
    public long countByServiceType(@PathVariable String serviceType) {
        return service.countByServiceType(serviceType);
    }
}
