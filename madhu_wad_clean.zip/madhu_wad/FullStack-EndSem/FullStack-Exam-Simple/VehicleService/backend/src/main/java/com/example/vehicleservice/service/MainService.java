package com.example.vehicleservice.service;

import com.example.vehicleservice.model.*;
import com.example.vehicleservice.repository.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MainService {
    private final VehicleRepository vehicleRepo;
    private final ServiceBookingRepository serviceBookingRepo;

    public MainService(VehicleRepository vehicleRepo, ServiceBookingRepository serviceBookingRepo) {
        this.vehicleRepo = vehicleRepo;
        this.serviceBookingRepo = serviceBookingRepo;
    }

    public List<Vehicle> getVehicles() {
        return vehicleRepo.findAll();
    }

    public Vehicle addVehicle(Vehicle item) {
        return vehicleRepo.save(item);
    }

    public Vehicle updateVehicle(String id, Vehicle item) {
        item.setId(id);
        return vehicleRepo.save(item);
    }

    public void deleteVehicle(String id) {
        vehicleRepo.deleteById(id);
    }

    public long countVehicles() {
        return vehicleRepo.count();
    }

    public List<ServiceBooking> getServiceBookings() {
        return serviceBookingRepo.findAll();
    }

    public ServiceBooking addServiceBooking(ServiceBooking serviceBooking) {
        Vehicle vehicle = vehicleRepo.findByVehicleNumber(serviceBooking.getVehicleNumber()).stream().findFirst().orElse(null);
        if (vehicle == null || !vehicle.isAvailable()) return null;
        vehicle.setAvailable(false);
        vehicleRepo.save(vehicle);
        return serviceBookingRepo.save(serviceBooking);
    }

    public ServiceBooking updateServiceBooking(String id, ServiceBooking item) {
        item.setId(id);
        return serviceBookingRepo.save(item);
    }

    public void deleteServiceBooking(String id) {
        serviceBookingRepo.deleteById(id);
    }

    public long countServiceBookings() {
        return serviceBookingRepo.count();
    }
    public List<Vehicle> getAvailableVehicles() { return vehicleRepo.findByAvailable(true); }
    public long countByServiceType(String serviceType) { return serviceBookingRepo.countByServiceType(serviceType); }
}
