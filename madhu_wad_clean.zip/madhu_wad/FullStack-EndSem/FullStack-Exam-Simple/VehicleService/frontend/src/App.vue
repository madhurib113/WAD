```vue
<script setup>
import { ref, onMounted } from 'vue'

const vehicles = ref([])
const bookings = ref([])

const vehicle = ref({
  vehicleNumber: '',
  ownerName: '',
  model: '',
  available: true
})

const booking = ref({
  bookingId: '',
  vehicleNumber: '',
  customerName: '',
  serviceType: '',
  date: ''
})

const url = 'http://localhost:8082'

async function getVehicles() {
  const res = await fetch(url + '/vehicles')
  vehicles.value = await res.json()
}

async function getBookings() {
  const res = await fetch(url + '/servicebookings')
  bookings.value = await res.json()
}

async function addVehicle() {
  await fetch(url + '/vehicles', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(vehicle.value)
  })

  getVehicles()
}

async function addBooking() {
  await fetch(url + '/servicebookings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(booking.value)
  })

  getVehicles()
  getBookings()
}

onMounted(() => {
  getVehicles()
  getBookings()
})
</script>

<template>
  <h1>Vehicle Service</h1>

  <h2>Add Vehicle</h2>
  <form @submit.prevent="addVehicle">
    <input v-model="vehicle.vehicleNumber" placeholder="Vehicle Number" required />
    <input v-model="vehicle.ownerName" placeholder="Owner Name" required />
    <input v-model="vehicle.model" placeholder="Model" required />
    <button>Add Vehicle</button>
  </form>

  <h2>Vehicle Records</h2>
  <div v-for="v in vehicles" :key="v.id" class="record">
    <p>Number: {{ v.vehicleNumber }}</p>
    <p>Owner: {{ v.ownerName }}</p>
    <p>Model: {{ v.model }}</p>
    <p>Available: {{ v.available }}</p>
  </div>

  <h2>Book Service</h2>
  <form @submit.prevent="addBooking">
    <input v-model="booking.bookingId" placeholder="Booking ID" required />
    <input v-model="booking.vehicleNumber" placeholder="Vehicle Number" required />
    <input v-model="booking.customerName" placeholder="Customer Name" required />
    <input v-model="booking.serviceType" placeholder="Service Type" required />
    <input v-model="booking.date" type="date" required />
    <button>Book Service</button>
  </form>

  <h2>Service Booking Records</h2>
  <div v-for="b in bookings" :key="b.id" class="record">
    <p>Booking ID: {{ b.bookingId }}</p>
    <p>Vehicle: {{ b.vehicleNumber }}</p>
    <p>Customer: {{ b.customerName }}</p>
    <p>Service: {{ b.serviceType }}</p>
    <p>Date: {{ b.date }}</p>
  </div>
</template>
```