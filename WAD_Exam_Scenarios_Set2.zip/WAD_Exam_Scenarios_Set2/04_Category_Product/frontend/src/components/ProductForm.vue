<script setup>
// Form for the "MANY" side (Product). The category is chosen from a dropdown.
defineProps({ form: Object, editing: Boolean, parents: Array })
defineEmits(['save', 'cancel'])
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Product</h3>
    <input v-model="form.name" placeholder="Name" />
    <input v-model="form.brand" placeholder="Brand" />
    <select v-model="form.categoryId">
      <option value="">-- select category --</option>
      <option v-for="p in parents" :key="p.id" :value="p.id">{{ p.categoryName }}</option>
    </select>
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
