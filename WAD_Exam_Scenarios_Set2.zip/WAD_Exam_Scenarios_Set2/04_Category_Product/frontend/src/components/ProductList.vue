<script setup>
// Table of Product records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the category name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Name</th><th>Brand</th><th>Category</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.name }}</td>
        <td>{{ x.brand }}</td>
        <td>{{ (parents.find(p => p.id === x.categoryId) || {}).categoryName || x.categoryId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
