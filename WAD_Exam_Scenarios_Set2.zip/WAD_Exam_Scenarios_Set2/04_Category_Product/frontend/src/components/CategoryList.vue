<script setup>
// Table of Category records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'categoryName', label: 'Category Name', type: 'text' },
  { key: 'section', label: 'Section', type: 'text' },
  { key: 'manager', label: 'Manager', type: 'text' },
  { key: 'maxProducts', label: 'Max Products', type: 'number' },
  { key: 'avgPrice', label: 'Avg Price', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Products</button>
          <button @click="$emit('related', x.id)">Products</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
