<script setup>
// Form for the "ONE" side (Category). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'categoryName', label: 'Category Name', type: 'text' },
  { key: 'section', label: 'Section', type: 'text' },
  { key: 'manager', label: 'Manager', type: 'text' },
  { key: 'maxProducts', label: 'Max Products', type: 'number' },
  { key: 'avgPrice', label: 'Avg Price', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Category</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
