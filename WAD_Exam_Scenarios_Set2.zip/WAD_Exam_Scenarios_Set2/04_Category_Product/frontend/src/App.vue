<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import CategoryForm from './components/CategoryForm.vue'
import CategoryList from './components/CategoryList.vue'
import ProductForm from './components/ProductForm.vue'
import ProductList from './components/ProductList.vue'
import ResultBox from './components/ResultBox.vue'

const CATEGORYS = 'http://localhost:8080/api/categorys'
const PRODUCTS = 'http://localhost:8080/api/products'

const categorys = ref([])
const products = ref([])
const categoryForm = ref({ categoryName: '', section: '', manager: '', maxProducts: '', avgPrice: '' })
const editingCategoryId = ref('')
const productForm = ref({ name: '', brand: '', categoryId: '' })
const editingProductId = ref('')
const filterCategoryId = ref('')
const keyword = ref('')
const minavgPrice = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Category ----------
async function loadCategorys() {
  try { categorys.value = (await axios.get(CATEGORYS)).data } catch (e) { showError(e) }
}

async function saveCategory() {
  error.value = ''
  const body = { ...categoryForm.value, maxProducts: num(categoryForm.value.maxProducts), avgPrice: num(categoryForm.value.avgPrice) }
  try {
    if (editingCategoryId.value === '') await axios.post(CATEGORYS, body)
    else await axios.put(CATEGORYS + '/' + editingCategoryId.value, body)
    cancelCategory()
    loadCategorys()
  } catch (e) { showError(e) }
}

function editCategory(x) {
  categoryForm.value = { ...x }
  editingCategoryId.value = x.id
}

function cancelCategory() {
  categoryForm.value = { categoryName: '', section: '', manager: '', maxProducts: '', avgPrice: '' }
  editingCategoryId.value = ''
}

// cascade = true also deletes the products; false -> error 409 if there are products
async function deleteCategory(id, cascade) {
  error.value = ''
  try {
    await axios.delete(CATEGORYS + '/' + id, { params: { cascade } })
    loadCategorys()
    loadProducts()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Product ----------
async function loadProducts() {
  try { products.value = (await axios.get(PRODUCTS, { params: { categoryId: filterCategoryId.value } })).data } catch (e) { showError(e) }
}

async function saveProduct() {
  error.value = ''
  try {
    if (editingProductId.value === '') await axios.post(PRODUCTS, productForm.value)
    else await axios.put(PRODUCTS + '/' + editingProductId.value, productForm.value)
    cancelProduct()
    loadProducts()
  } catch (e) { showError(e) }
}

function editProduct(x) {
  productForm.value = { name: x.name, brand: x.brand, categoryId: x.categoryId }
  editingProductId.value = x.id
}

function cancelProduct() {
  productForm.value = { name: '', brand: '', categoryId: '' }
  editingProductId.value = ''
}

async function deleteProduct(id) {
  error.value = ''
  try {
    await axios.delete(PRODUCTS + '/' + id)
    loadProducts()
  } catch (e) { showError(e) }
}

onMounted(() => { loadCategorys(); loadProducts() })
</script>

<template>
  <h1>Category - Product Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Categorys</h2>
  <CategoryForm :form="categoryForm" :editing="editingCategoryId !== ''" @save="saveCategory" @cancel="cancelCategory" />
  <div class="box">
    <input v-model="keyword" placeholder="search categoryName" />
    <button @click="showGet(CATEGORYS + '/search', { keyword })">Search</button>
    <input v-model="minavgPrice" type="number" placeholder="min avgPrice" />
    <button @click="showGet(CATEGORYS + '/filter', { minavgPrice })">Filter</button>
    <button @click="showGet(CATEGORYS + '/sorted')">Sort by avgPrice</button>
    <button @click="showGet(CATEGORYS + '/available')">Available</button>
    <button @click="showGet(CATEGORYS + '/stats')">Stats</button>
  </div>
  <CategoryList :items="categorys" @edit="editCategory" @remove="deleteCategory"
    @related="(id) => showGet(CATEGORYS + '/' + id + '/products')" @summary="(id) => showGet(CATEGORYS + '/' + id + '/summary')" />

  <h2>Products</h2>
  <ProductForm :form="productForm" :editing="editingProductId !== ''" :parents="categorys" @save="saveProduct" @cancel="cancelProduct" />
  <div class="box">
    <select v-model="filterCategoryId" @change="loadProducts">
      <option value="">All categorys</option>
      <option v-for="p in categorys" :key="p.id" :value="p.id">{{ p.categoryName }}</option>
    </select>
    <button @click="showGet(PRODUCTS + '/count', { categoryId: filterCategoryId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(PRODUCTS + '/search', { keyword })">Search</button>
  </div>
  <ProductList :items="products" :parents="categorys" @edit="editProduct" @remove="deleteProduct" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
