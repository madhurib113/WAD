# Category - Product (2 collections: `categorys` and `products`)

Database `category_db`. `products.categoryId` stores the `_id` of a category (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db category_db --collection categorys --jsonArray --file sample_data/categorys.json
mongoimport --db category_db --collection products --jsonArray --file sample_data/products.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Category**: categoryName*, section*, manager, maxProducts* (> 0), avgPrice* (>= 0)    (* = required)
- **Product**: name*, brand*, categoryId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/categorys | create (Category) 201 / 400 |
| GET | /api/categorys , /api/categorys/{id} | all / one (404) |
| PUT | /api/categorys/{id} | update 200 / 400 / 404 / 409 (`maxProducts` below existing products) |
| DELETE | /api/categorys/{id}?cascade=true | 204 / 404 / 409 (has products and no cascade) |
| GET | /api/categorys/search?keyword= | search by categoryName |
| GET | /api/categorys/filter?minavgPrice= | avgPrice >= value |
| GET | /api/categorys/sorted | sort by avgPrice desc |
| GET | /api/categorys/available | categorys that still have free places |
| GET | /api/categorys/{id}/products | related products |
| GET | /api/categorys/{id}/summary | count, placesLeft, totalAmount = count x avgPrice |
| GET | /api/categorys/stats | totals over all categorys |
| POST | /api/products | create (Product) 201 / 400 (bad categoryId) / 409 (full) |
| GET | /api/products?categoryId= | all / filter by category |
| GET | /api/products/{id} | one (404) |
| PUT | /api/products/{id} | update (move to another category: free place checked) |
| DELETE | /api/products/{id} | 204 / 404 |
| GET | /api/products/search?keyword= | search by name |
| GET | /api/products/count?categoryId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on categorys and on products.
3. Validation: missing field -> 400, maxProducts <= 0 -> 400, avgPrice < 0 -> 400, unknown id -> 404.
4. Add a product only if the category exists (400) and is not full (409).
5. Update category: maxProducts cannot be lower than current number of products (409).
6. Delete category: blocked if it has products (409); `cascade=true` deletes its products too.
7. List products of one category; count products of one category.
8. Search by text, filter by number, sort descending, list available categorys.
9. Calculation: totalAmount for one category, and totals over all categorys (stats).
10. Move a product from one category to another.
