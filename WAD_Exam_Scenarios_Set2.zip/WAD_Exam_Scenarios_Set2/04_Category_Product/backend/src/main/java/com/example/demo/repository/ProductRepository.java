package com.example.demo.repository;

import com.example.demo.model.Product;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product, String> {
    List<Product> findByCategoryId(String categoryId);                    // filter by the related record
    long countByCategoryId(String categoryId);                          // count related records
    long deleteByCategoryId(String categoryId);                         // cascade delete
    List<Product> findByNameContainingIgnoreCase(String keyword); // search
}
