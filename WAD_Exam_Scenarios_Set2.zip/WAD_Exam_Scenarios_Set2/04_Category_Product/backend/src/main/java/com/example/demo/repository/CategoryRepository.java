package com.example.demo.repository;

import com.example.demo.model.Category;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CategoryRepository extends MongoRepository<Category, String> {
    List<Category> findByCategoryNameContainingIgnoreCase(String keyword);        // search
    List<Category> findByavgPriceGreaterThanEqual(Double min);                  // filter by number
}
