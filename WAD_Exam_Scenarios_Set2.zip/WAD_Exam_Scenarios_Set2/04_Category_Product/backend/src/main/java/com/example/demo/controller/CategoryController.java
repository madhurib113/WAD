package com.example.demo.controller;

import com.example.demo.model.Category;
import com.example.demo.model.Product;
import com.example.demo.service.CategoryService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/categorys")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class CategoryController {

    private final CategoryService service;

    public CategoryController(CategoryService service) { this.service = service; }

    @PostMapping                                   // POST   /api/categorys                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Category create(@RequestBody Category x) { return service.create(x); }

    @GetMapping                                    // GET    /api/categorys
    public List<Category> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/categorys/{id}            -> 200 / 404
    public Category getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/categorys/{id}            -> 200 / 400 / 404 / 409
    public Category update(@PathVariable String id, @RequestBody Category x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/categorys/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/categorys/search?keyword=ab
    public List<Category> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/categorys/filter?minavgPrice=500
    public List<Category> filter(@RequestParam Double minavgPrice) { return service.filterByavgPrice(minavgPrice); }

    @GetMapping("/sorted")                         // GET    /api/categorys/sorted          (avgPrice high -> low)
    public List<Category> sorted() { return service.sortedByavgPrice(); }

    @GetMapping("/available")                      // GET    /api/categorys/available       (still have free places)
    public List<Category> available() { return service.available(); }

    @GetMapping("/{id}/products")                    // GET    /api/categorys/{id}/products     (related records)
    public List<Product> related(@PathVariable String id) { return service.productsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/categorys/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/categorys/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
