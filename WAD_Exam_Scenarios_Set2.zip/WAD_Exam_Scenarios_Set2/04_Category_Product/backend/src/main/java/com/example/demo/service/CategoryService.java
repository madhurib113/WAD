package com.example.demo.service;

import com.example.demo.model.Category;
import com.example.demo.model.Product;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.ProductRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class CategoryService {

    private final CategoryRepository categorys;
    private final ProductRepository products;

    public CategoryService(CategoryRepository categorys, ProductRepository products) {
        this.categorys = categorys;
        this.products = products;
    }

    private void validate(Category x) {
        if (x.getCategoryName() == null || x.getCategoryName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "categoryName is required");
        if (x.getSection() == null || x.getSection().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "section is required");
        if (x.getmaxProducts() == null || x.getmaxProducts() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "maxProducts is required and must be > 0");
        if (x.getavgPrice() == null || x.getavgPrice() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "avgPrice is required and must be >= 0");
    }

    public Category getById(String id) {
        return categorys.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Category not found with id " + id));
    }

    // ---------- CRUD ----------
    public Category create(Category x) {
        validate(x);
        x.setId(null);
        return categorys.save(x);
    }

    public List<Category> getAll() { return categorys.findAll(); }

    public Category update(String id, Category in) {
        Category existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of products already added
        long used = products.countByCategoryId(id);
        if (in.getmaxProducts() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "maxProducts cannot be less than the " + used + " existing products");
        existing.setCategoryName(in.getCategoryName());
        existing.setSection(in.getSection());
        existing.setManager(in.getManager());
        existing.setMaxProducts(in.getMaxProducts());
        existing.setAvgPrice(in.getAvgPrice());
        return categorys.save(existing);
    }

    // a category that still has products is NOT deleted unless cascade=true (then its products are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = products.countByCategoryId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "category has " + used + " products; delete them first or use cascade=true");
        products.deleteByCategoryId(id);
        categorys.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Category> search(String keyword) { return categorys.findByCategoryNameContainingIgnoreCase(keyword); }

    public List<Category> filterByavgPrice(Double min) { return categorys.findByavgPriceGreaterThanEqual(min); }

    public List<Category> sortedByavgPrice() { return categorys.findAll(Sort.by(Sort.Direction.DESC, "avgPrice")); }

    // only the categorys that still have a free place
    public List<Category> available() {
        List<Category> result = new ArrayList<>();
        for (Category x : categorys.findAll())
            if (products.countByCategoryId(x.getId()) < x.getmaxProducts()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Product> productsOf(String id) {
        getById(id);                              // 404 if the category is missing
        return products.findByCategoryId(id);
    }

    // count + calculations across the two collections for ONE category
    public Map<String, Object> summary(String id) {
        Category x = getById(id);
        long count = products.countByCategoryId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("categoryId", x.getId());
        m.put("name", x.getCategoryName());
        m.put("maxProducts", x.getmaxProducts());
        m.put("productCount", count);
        m.put("placesLeft", x.getmaxProducts() - count);
        m.put("avgPrice", x.getavgPrice());
        m.put("totalAmount", count * x.getavgPrice());
        return m;
    }

    // totals across ALL categorys
    public Map<String, Object> stats() {
        long totalProduct = 0;
        double totalAmount = 0;
        List<Category> all = categorys.findAll();
        for (Category x : all) {
            long c = products.countByCategoryId(x.getId());
            totalProduct += c;
            totalAmount += c * x.getavgPrice();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalCategorys", all.size());
        m.put("totalProducts", totalProduct);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
