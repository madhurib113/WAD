package com.example.demo.service;

import com.example.demo.model.Category;
import com.example.demo.model.Product;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.ProductRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ProductService {

    private final ProductRepository products;
    private final CategoryRepository categorys;

    public ProductService(ProductRepository products, CategoryRepository categorys) {
        this.products = products;
        this.categorys = categorys;
    }

    private void validate(Product x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getBrand() == null || x.getBrand().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "brand is required");
        if (x.getCategoryId() == null || x.getCategoryId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "categoryId is required");
    }

    // The referenced category must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkCategory(String id, boolean checkLimit) {
        Category p = categorys.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "categoryId does not exist: " + id));
        if (checkLimit && products.countByCategoryId(id) >= p.getmaxProducts())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "category is full");
    }

    public Product getById(String id) {
        return products.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found with id " + id));
    }

    public Product create(Product x) {
        validate(x);
        checkCategory(x.getCategoryId(), true);
        x.setId(null);
        return products.save(x);
    }

    // optional filter by related record: ?categoryId=...
    public List<Product> getAll(String categoryId) {
        if (categoryId == null || categoryId.isBlank()) return products.findAll();
        return products.findByCategoryId(categoryId);
    }

    public List<Product> search(String keyword) { return products.findByNameContainingIgnoreCase(keyword); }

    public Product update(String id, Product in) {
        Product existing = getById(id);
        validate(in);
        boolean moving = !in.getCategoryId().equals(existing.getCategoryId());
        checkCategory(in.getCategoryId(), moving);       // free-place check only when moving to another category
        existing.setName(in.getName());
        existing.setBrand(in.getBrand());
        existing.setCategoryId(in.getCategoryId());
        return products.save(existing);
    }

    public void delete(String id) {
        getById(id);
        products.deleteById(id);
    }

    public long count(String categoryId) {
        if (categoryId == null || categoryId.isBlank()) return products.count();
        return products.countByCategoryId(categoryId);
    }
}
