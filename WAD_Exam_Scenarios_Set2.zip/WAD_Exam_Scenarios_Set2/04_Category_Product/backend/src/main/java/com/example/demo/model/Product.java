package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: products
// categoryId stores the _id of a Category as plain text. MongoDB has NO foreign keys,
// so ProductService checks that the category exists before saving.
@Document(collection = "products")
public class Product {

    @Id
    private String id;

    private String name;     // required
    private String brand;     // required
    private String categoryId;    // required: reference to categorys._id

    public Product() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }
    public String getCategoryId() { return categoryId; }
    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }
}
