package com.example.demo.controller;

import com.example.demo.model.Product;
import com.example.demo.service.ProductService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) { this.service = service; }

    @PostMapping                                   // POST   /api/products   -> 201 / 400 (bad category) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Product create(@RequestBody Product x) { return service.create(x); }

    @GetMapping                                    // GET    /api/products[?categoryId=..]  (filter by related record)
    public List<Product> getAll(@RequestParam(required = false) String categoryId) { return service.getAll(categoryId); }

    @GetMapping("/{id}")                           // GET    /api/products/{id}   -> 200 / 404
    public Product getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/products/{id}
    public Product update(@PathVariable String id, @RequestBody Product x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/products/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/products/search?keyword=an
    public List<Product> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/products/count[?categoryId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String categoryId) {
        return Map.of("count", service.count(categoryId));
    }
}
