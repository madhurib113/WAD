package com.example.demo.repository;

import com.example.demo.model.Account;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AccountRepository extends MongoRepository<Account, String> {
    List<Account> findByBranchId(String branchId);                    // filter by the related record
    long countByBranchId(String branchId);                          // count related records
    long deleteByBranchId(String branchId);                         // cascade delete
    List<Account> findByNameContainingIgnoreCase(String keyword); // search
}
