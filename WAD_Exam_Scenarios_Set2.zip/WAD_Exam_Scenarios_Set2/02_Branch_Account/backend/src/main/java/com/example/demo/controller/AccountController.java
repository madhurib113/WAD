package com.example.demo.controller;

import com.example.demo.model.Account;
import com.example.demo.service.AccountService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/accounts")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class AccountController {

    private final AccountService service;

    public AccountController(AccountService service) { this.service = service; }

    @PostMapping                                   // POST   /api/accounts   -> 201 / 400 (bad branch) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Account create(@RequestBody Account x) { return service.create(x); }

    @GetMapping                                    // GET    /api/accounts[?branchId=..]  (filter by related record)
    public List<Account> getAll(@RequestParam(required = false) String branchId) { return service.getAll(branchId); }

    @GetMapping("/{id}")                           // GET    /api/accounts/{id}   -> 200 / 404
    public Account getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/accounts/{id}
    public Account update(@PathVariable String id, @RequestBody Account x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/accounts/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/accounts/search?keyword=an
    public List<Account> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/accounts/count[?branchId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String branchId) {
        return Map.of("count", service.count(branchId));
    }
}
