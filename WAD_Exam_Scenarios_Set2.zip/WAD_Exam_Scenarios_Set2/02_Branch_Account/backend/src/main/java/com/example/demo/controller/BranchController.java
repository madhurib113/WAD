package com.example.demo.controller;

import com.example.demo.model.Branch;
import com.example.demo.model.Account;
import com.example.demo.service.BranchService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/branchs")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class BranchController {

    private final BranchService service;

    public BranchController(BranchService service) { this.service = service; }

    @PostMapping                                   // POST   /api/branchs                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Branch create(@RequestBody Branch x) { return service.create(x); }

    @GetMapping                                    // GET    /api/branchs
    public List<Branch> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/branchs/{id}            -> 200 / 404
    public Branch getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/branchs/{id}            -> 200 / 400 / 404 / 409
    public Branch update(@PathVariable String id, @RequestBody Branch x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/branchs/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/branchs/search?keyword=ab
    public List<Branch> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/branchs/filter?minopeningFee=500
    public List<Branch> filter(@RequestParam Double minopeningFee) { return service.filterByopeningFee(minopeningFee); }

    @GetMapping("/sorted")                         // GET    /api/branchs/sorted          (openingFee high -> low)
    public List<Branch> sorted() { return service.sortedByopeningFee(); }

    @GetMapping("/available")                      // GET    /api/branchs/available       (still have free places)
    public List<Branch> available() { return service.available(); }

    @GetMapping("/{id}/accounts")                    // GET    /api/branchs/{id}/accounts     (related records)
    public List<Account> related(@PathVariable String id) { return service.accountsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/branchs/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/branchs/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
