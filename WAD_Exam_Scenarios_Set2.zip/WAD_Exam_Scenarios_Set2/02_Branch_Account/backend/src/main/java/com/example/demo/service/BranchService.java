package com.example.demo.service;

import com.example.demo.model.Branch;
import com.example.demo.model.Account;
import com.example.demo.repository.BranchRepository;
import com.example.demo.repository.AccountRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class BranchService {

    private final BranchRepository branchs;
    private final AccountRepository accounts;

    public BranchService(BranchRepository branchs, AccountRepository accounts) {
        this.branchs = branchs;
        this.accounts = accounts;
    }

    private void validate(Branch x) {
        if (x.getBranchName() == null || x.getBranchName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "branchName is required");
        if (x.getManager() == null || x.getManager().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "manager is required");
        if (x.getmaxAccounts() == null || x.getmaxAccounts() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "maxAccounts is required and must be > 0");
        if (x.getopeningFee() == null || x.getopeningFee() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "openingFee is required and must be >= 0");
    }

    public Branch getById(String id) {
        return branchs.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Branch not found with id " + id));
    }

    // ---------- CRUD ----------
    public Branch create(Branch x) {
        validate(x);
        x.setId(null);
        return branchs.save(x);
    }

    public List<Branch> getAll() { return branchs.findAll(); }

    public Branch update(String id, Branch in) {
        Branch existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of accounts already added
        long used = accounts.countByBranchId(id);
        if (in.getmaxAccounts() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "maxAccounts cannot be less than the " + used + " existing accounts");
        existing.setBranchName(in.getBranchName());
        existing.setManager(in.getManager());
        existing.setCity(in.getCity());
        existing.setMaxAccounts(in.getMaxAccounts());
        existing.setOpeningFee(in.getOpeningFee());
        return branchs.save(existing);
    }

    // a branch that still has accounts is NOT deleted unless cascade=true (then its accounts are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = accounts.countByBranchId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "branch has " + used + " accounts; delete them first or use cascade=true");
        accounts.deleteByBranchId(id);
        branchs.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Branch> search(String keyword) { return branchs.findByBranchNameContainingIgnoreCase(keyword); }

    public List<Branch> filterByopeningFee(Double min) { return branchs.findByopeningFeeGreaterThanEqual(min); }

    public List<Branch> sortedByopeningFee() { return branchs.findAll(Sort.by(Sort.Direction.DESC, "openingFee")); }

    // only the branchs that still have a free place
    public List<Branch> available() {
        List<Branch> result = new ArrayList<>();
        for (Branch x : branchs.findAll())
            if (accounts.countByBranchId(x.getId()) < x.getmaxAccounts()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Account> accountsOf(String id) {
        getById(id);                              // 404 if the branch is missing
        return accounts.findByBranchId(id);
    }

    // count + calculations across the two collections for ONE branch
    public Map<String, Object> summary(String id) {
        Branch x = getById(id);
        long count = accounts.countByBranchId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("branchId", x.getId());
        m.put("name", x.getBranchName());
        m.put("maxAccounts", x.getmaxAccounts());
        m.put("accountCount", count);
        m.put("placesLeft", x.getmaxAccounts() - count);
        m.put("openingFee", x.getopeningFee());
        m.put("totalAmount", count * x.getopeningFee());
        return m;
    }

    // totals across ALL branchs
    public Map<String, Object> stats() {
        long totalAccount = 0;
        double totalAmount = 0;
        List<Branch> all = branchs.findAll();
        for (Branch x : all) {
            long c = accounts.countByBranchId(x.getId());
            totalAccount += c;
            totalAmount += c * x.getopeningFee();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalBranchs", all.size());
        m.put("totalAccounts", totalAccount);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
