package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: branchs
@Document(collection = "branchs")
public class Branch {

    @Id
    private String id;

    private String branchName;
    private String manager;
    private String city;
    private Integer maxAccounts;
    private Double openingFee;

    public Branch() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
    public String getManager() { return manager; }
    public void setManager(String manager) { this.manager = manager; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public Integer getMaxAccounts() { return maxAccounts; }
    public void setMaxAccounts(Integer maxAccounts) { this.maxAccounts = maxAccounts; }
    public Double getOpeningFee() { return openingFee; }
    public void setOpeningFee(Double openingFee) { this.openingFee = openingFee; }
}
