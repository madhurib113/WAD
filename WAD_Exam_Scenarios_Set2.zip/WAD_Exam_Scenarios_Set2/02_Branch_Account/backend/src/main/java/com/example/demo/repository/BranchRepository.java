package com.example.demo.repository;

import com.example.demo.model.Branch;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BranchRepository extends MongoRepository<Branch, String> {
    List<Branch> findByBranchNameContainingIgnoreCase(String keyword);        // search
    List<Branch> findByopeningFeeGreaterThanEqual(Double min);                  // filter by number
}
