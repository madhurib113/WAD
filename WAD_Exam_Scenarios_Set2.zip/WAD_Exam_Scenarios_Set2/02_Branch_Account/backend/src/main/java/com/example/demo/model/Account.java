package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: accounts
// branchId stores the _id of a Branch as plain text. MongoDB has NO foreign keys,
// so AccountService checks that the branch exists before saving.
@Document(collection = "accounts")
public class Account {

    @Id
    private String id;

    private String name;     // required
    private String email;     // required
    private String branchId;    // required: reference to branchs._id

    public Account() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getBranchId() { return branchId; }
    public void setBranchId(String branchId) { this.branchId = branchId; }
}
