package com.example.demo.service;

import com.example.demo.model.Branch;
import com.example.demo.model.Account;
import com.example.demo.repository.BranchRepository;
import com.example.demo.repository.AccountRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AccountService {

    private final AccountRepository accounts;
    private final BranchRepository branchs;

    public AccountService(AccountRepository accounts, BranchRepository branchs) {
        this.accounts = accounts;
        this.branchs = branchs;
    }

    private void validate(Account x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getEmail() == null || x.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (x.getBranchId() == null || x.getBranchId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "branchId is required");
    }

    // The referenced branch must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkBranch(String id, boolean checkLimit) {
        Branch p = branchs.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "branchId does not exist: " + id));
        if (checkLimit && accounts.countByBranchId(id) >= p.getmaxAccounts())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "branch is full");
    }

    public Account getById(String id) {
        return accounts.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Account not found with id " + id));
    }

    public Account create(Account x) {
        validate(x);
        checkBranch(x.getBranchId(), true);
        x.setId(null);
        return accounts.save(x);
    }

    // optional filter by related record: ?branchId=...
    public List<Account> getAll(String branchId) {
        if (branchId == null || branchId.isBlank()) return accounts.findAll();
        return accounts.findByBranchId(branchId);
    }

    public List<Account> search(String keyword) { return accounts.findByNameContainingIgnoreCase(keyword); }

    public Account update(String id, Account in) {
        Account existing = getById(id);
        validate(in);
        boolean moving = !in.getBranchId().equals(existing.getBranchId());
        checkBranch(in.getBranchId(), moving);       // free-place check only when moving to another branch
        existing.setName(in.getName());
        existing.setEmail(in.getEmail());
        existing.setBranchId(in.getBranchId());
        return accounts.save(existing);
    }

    public void delete(String id) {
        getById(id);
        accounts.deleteById(id);
    }

    public long count(String branchId) {
        if (branchId == null || branchId.isBlank()) return accounts.count();
        return accounts.countByBranchId(branchId);
    }
}
