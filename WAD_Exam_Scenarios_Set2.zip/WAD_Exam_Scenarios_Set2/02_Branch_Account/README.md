# Branch - Account (2 collections: `branchs` and `accounts`)

Database `branch_db`. `accounts.branchId` stores the `_id` of a branch (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db branch_db --collection branchs --jsonArray --file sample_data/branchs.json
mongoimport --db branch_db --collection accounts --jsonArray --file sample_data/accounts.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Branch**: branchName*, manager*, city, maxAccounts* (> 0), openingFee* (>= 0)    (* = required)
- **Account**: name*, email*, branchId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/branchs | create (Branch) 201 / 400 |
| GET | /api/branchs , /api/branchs/{id} | all / one (404) |
| PUT | /api/branchs/{id} | update 200 / 400 / 404 / 409 (`maxAccounts` below existing accounts) |
| DELETE | /api/branchs/{id}?cascade=true | 204 / 404 / 409 (has accounts and no cascade) |
| GET | /api/branchs/search?keyword= | search by branchName |
| GET | /api/branchs/filter?minopeningFee= | openingFee >= value |
| GET | /api/branchs/sorted | sort by openingFee desc |
| GET | /api/branchs/available | branchs that still have free places |
| GET | /api/branchs/{id}/accounts | related accounts |
| GET | /api/branchs/{id}/summary | count, placesLeft, totalAmount = count x openingFee |
| GET | /api/branchs/stats | totals over all branchs |
| POST | /api/accounts | create (Account) 201 / 400 (bad branchId) / 409 (full) |
| GET | /api/accounts?branchId= | all / filter by branch |
| GET | /api/accounts/{id} | one (404) |
| PUT | /api/accounts/{id} | update (move to another branch: free place checked) |
| DELETE | /api/accounts/{id} | 204 / 404 |
| GET | /api/accounts/search?keyword= | search by name |
| GET | /api/accounts/count?branchId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on branchs and on accounts.
3. Validation: missing field -> 400, maxAccounts <= 0 -> 400, openingFee < 0 -> 400, unknown id -> 404.
4. Add a account only if the branch exists (400) and is not full (409).
5. Update branch: maxAccounts cannot be lower than current number of accounts (409).
6. Delete branch: blocked if it has accounts (409); `cascade=true` deletes its accounts too.
7. List accounts of one branch; count accounts of one branch.
8. Search by text, filter by number, sort descending, list available branchs.
9. Calculation: totalAmount for one branch, and totals over all branchs (stats).
10. Move a account from one branch to another.
