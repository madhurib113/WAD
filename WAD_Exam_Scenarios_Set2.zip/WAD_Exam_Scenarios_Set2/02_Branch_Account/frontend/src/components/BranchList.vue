<script setup>
// Table of Branch records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'branchName', label: 'Branch Name', type: 'text' },
  { key: 'manager', label: 'Manager', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'maxAccounts', label: 'Max Accounts', type: 'number' },
  { key: 'openingFee', label: 'Opening Fee', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Accounts</button>
          <button @click="$emit('related', x.id)">Accounts</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
