<script setup>
// Form for the "ONE" side (Branch). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'branchName', label: 'Branch Name', type: 'text' },
  { key: 'manager', label: 'Manager', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'maxAccounts', label: 'Max Accounts', type: 'number' },
  { key: 'openingFee', label: 'Opening Fee', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Branch</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
