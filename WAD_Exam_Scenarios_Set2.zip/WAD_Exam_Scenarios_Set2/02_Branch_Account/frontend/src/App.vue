<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import BranchForm from './components/BranchForm.vue'
import BranchList from './components/BranchList.vue'
import AccountForm from './components/AccountForm.vue'
import AccountList from './components/AccountList.vue'
import ResultBox from './components/ResultBox.vue'

const BRANCHS = 'http://localhost:8080/api/branchs'
const ACCOUNTS = 'http://localhost:8080/api/accounts'

const branchs = ref([])
const accounts = ref([])
const branchForm = ref({ branchName: '', manager: '', city: '', maxAccounts: '', openingFee: '' })
const editingBranchId = ref('')
const accountForm = ref({ name: '', email: '', branchId: '' })
const editingAccountId = ref('')
const filterBranchId = ref('')
const keyword = ref('')
const minopeningFee = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Branch ----------
async function loadBranchs() {
  try { branchs.value = (await axios.get(BRANCHS)).data } catch (e) { showError(e) }
}

async function saveBranch() {
  error.value = ''
  const body = { ...branchForm.value, maxAccounts: num(branchForm.value.maxAccounts), openingFee: num(branchForm.value.openingFee) }
  try {
    if (editingBranchId.value === '') await axios.post(BRANCHS, body)
    else await axios.put(BRANCHS + '/' + editingBranchId.value, body)
    cancelBranch()
    loadBranchs()
  } catch (e) { showError(e) }
}

function editBranch(x) {
  branchForm.value = { ...x }
  editingBranchId.value = x.id
}

function cancelBranch() {
  branchForm.value = { branchName: '', manager: '', city: '', maxAccounts: '', openingFee: '' }
  editingBranchId.value = ''
}

// cascade = true also deletes the accounts; false -> error 409 if there are accounts
async function deleteBranch(id, cascade) {
  error.value = ''
  try {
    await axios.delete(BRANCHS + '/' + id, { params: { cascade } })
    loadBranchs()
    loadAccounts()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Account ----------
async function loadAccounts() {
  try { accounts.value = (await axios.get(ACCOUNTS, { params: { branchId: filterBranchId.value } })).data } catch (e) { showError(e) }
}

async function saveAccount() {
  error.value = ''
  try {
    if (editingAccountId.value === '') await axios.post(ACCOUNTS, accountForm.value)
    else await axios.put(ACCOUNTS + '/' + editingAccountId.value, accountForm.value)
    cancelAccount()
    loadAccounts()
  } catch (e) { showError(e) }
}

function editAccount(x) {
  accountForm.value = { name: x.name, email: x.email, branchId: x.branchId }
  editingAccountId.value = x.id
}

function cancelAccount() {
  accountForm.value = { name: '', email: '', branchId: '' }
  editingAccountId.value = ''
}

async function deleteAccount(id) {
  error.value = ''
  try {
    await axios.delete(ACCOUNTS + '/' + id)
    loadAccounts()
  } catch (e) { showError(e) }
}

onMounted(() => { loadBranchs(); loadAccounts() })
</script>

<template>
  <h1>Branch - Account Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Branchs</h2>
  <BranchForm :form="branchForm" :editing="editingBranchId !== ''" @save="saveBranch" @cancel="cancelBranch" />
  <div class="box">
    <input v-model="keyword" placeholder="search branchName" />
    <button @click="showGet(BRANCHS + '/search', { keyword })">Search</button>
    <input v-model="minopeningFee" type="number" placeholder="min openingFee" />
    <button @click="showGet(BRANCHS + '/filter', { minopeningFee })">Filter</button>
    <button @click="showGet(BRANCHS + '/sorted')">Sort by openingFee</button>
    <button @click="showGet(BRANCHS + '/available')">Available</button>
    <button @click="showGet(BRANCHS + '/stats')">Stats</button>
  </div>
  <BranchList :items="branchs" @edit="editBranch" @remove="deleteBranch"
    @related="(id) => showGet(BRANCHS + '/' + id + '/accounts')" @summary="(id) => showGet(BRANCHS + '/' + id + '/summary')" />

  <h2>Accounts</h2>
  <AccountForm :form="accountForm" :editing="editingAccountId !== ''" :parents="branchs" @save="saveAccount" @cancel="cancelAccount" />
  <div class="box">
    <select v-model="filterBranchId" @change="loadAccounts">
      <option value="">All branchs</option>
      <option v-for="p in branchs" :key="p.id" :value="p.id">{{ p.branchName }}</option>
    </select>
    <button @click="showGet(ACCOUNTS + '/count', { branchId: filterBranchId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(ACCOUNTS + '/search', { keyword })">Search</button>
  </div>
  <AccountList :items="accounts" :parents="branchs" @edit="editAccount" @remove="deleteAccount" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
