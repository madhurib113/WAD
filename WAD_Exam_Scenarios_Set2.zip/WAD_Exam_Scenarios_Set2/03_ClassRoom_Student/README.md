# ClassRoom - Student (2 collections: `classRooms` and `students`)

Database `classRoom_db`. `students.classRoomId` stores the `_id` of a classRoom (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db classRoom_db --collection classRooms --jsonArray --file sample_data/classRooms.json
mongoimport --db classRoom_db --collection students --jsonArray --file sample_data/students.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **ClassRoom**: className*, teacher*, block, strength* (> 0), feePerStudent* (>= 0)    (* = required)
- **Student**: name*, rollNo*, classRoomId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/classRooms | create (ClassRoom) 201 / 400 |
| GET | /api/classRooms , /api/classRooms/{id} | all / one (404) |
| PUT | /api/classRooms/{id} | update 200 / 400 / 404 / 409 (`strength` below existing students) |
| DELETE | /api/classRooms/{id}?cascade=true | 204 / 404 / 409 (has students and no cascade) |
| GET | /api/classRooms/search?keyword= | search by className |
| GET | /api/classRooms/filter?minfeePerStudent= | feePerStudent >= value |
| GET | /api/classRooms/sorted | sort by feePerStudent desc |
| GET | /api/classRooms/available | classRooms that still have free places |
| GET | /api/classRooms/{id}/students | related students |
| GET | /api/classRooms/{id}/summary | count, placesLeft, totalAmount = count x feePerStudent |
| GET | /api/classRooms/stats | totals over all classRooms |
| POST | /api/students | create (Student) 201 / 400 (bad classRoomId) / 409 (full) |
| GET | /api/students?classRoomId= | all / filter by classRoom |
| GET | /api/students/{id} | one (404) |
| PUT | /api/students/{id} | update (move to another classRoom: free place checked) |
| DELETE | /api/students/{id} | 204 / 404 |
| GET | /api/students/search?keyword= | search by name |
| GET | /api/students/count?classRoomId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on classRooms and on students.
3. Validation: missing field -> 400, strength <= 0 -> 400, feePerStudent < 0 -> 400, unknown id -> 404.
4. Add a student only if the classRoom exists (400) and is not full (409).
5. Update classRoom: strength cannot be lower than current number of students (409).
6. Delete classRoom: blocked if it has students (409); `cascade=true` deletes its students too.
7. List students of one classRoom; count students of one classRoom.
8. Search by text, filter by number, sort descending, list available classRooms.
9. Calculation: totalAmount for one classRoom, and totals over all classRooms (stats).
10. Move a student from one classRoom to another.
