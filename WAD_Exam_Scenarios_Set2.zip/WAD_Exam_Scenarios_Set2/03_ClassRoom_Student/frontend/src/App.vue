<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import ClassRoomForm from './components/ClassRoomForm.vue'
import ClassRoomList from './components/ClassRoomList.vue'
import StudentForm from './components/StudentForm.vue'
import StudentList from './components/StudentList.vue'
import ResultBox from './components/ResultBox.vue'

const CLASSROOMS = 'http://localhost:8080/api/classRooms'
const STUDENTS = 'http://localhost:8080/api/students'

const classRooms = ref([])
const students = ref([])
const classRoomForm = ref({ className: '', teacher: '', block: '', strength: '', feePerStudent: '' })
const editingClassRoomId = ref('')
const studentForm = ref({ name: '', rollNo: '', classRoomId: '' })
const editingStudentId = ref('')
const filterClassRoomId = ref('')
const keyword = ref('')
const minfeePerStudent = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- ClassRoom ----------
async function loadClassRooms() {
  try { classRooms.value = (await axios.get(CLASSROOMS)).data } catch (e) { showError(e) }
}

async function saveClassRoom() {
  error.value = ''
  const body = { ...classRoomForm.value, strength: num(classRoomForm.value.strength), feePerStudent: num(classRoomForm.value.feePerStudent) }
  try {
    if (editingClassRoomId.value === '') await axios.post(CLASSROOMS, body)
    else await axios.put(CLASSROOMS + '/' + editingClassRoomId.value, body)
    cancelClassRoom()
    loadClassRooms()
  } catch (e) { showError(e) }
}

function editClassRoom(x) {
  classRoomForm.value = { ...x }
  editingClassRoomId.value = x.id
}

function cancelClassRoom() {
  classRoomForm.value = { className: '', teacher: '', block: '', strength: '', feePerStudent: '' }
  editingClassRoomId.value = ''
}

// cascade = true also deletes the students; false -> error 409 if there are students
async function deleteClassRoom(id, cascade) {
  error.value = ''
  try {
    await axios.delete(CLASSROOMS + '/' + id, { params: { cascade } })
    loadClassRooms()
    loadStudents()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Student ----------
async function loadStudents() {
  try { students.value = (await axios.get(STUDENTS, { params: { classRoomId: filterClassRoomId.value } })).data } catch (e) { showError(e) }
}

async function saveStudent() {
  error.value = ''
  try {
    if (editingStudentId.value === '') await axios.post(STUDENTS, studentForm.value)
    else await axios.put(STUDENTS + '/' + editingStudentId.value, studentForm.value)
    cancelStudent()
    loadStudents()
  } catch (e) { showError(e) }
}

function editStudent(x) {
  studentForm.value = { name: x.name, rollNo: x.rollNo, classRoomId: x.classRoomId }
  editingStudentId.value = x.id
}

function cancelStudent() {
  studentForm.value = { name: '', rollNo: '', classRoomId: '' }
  editingStudentId.value = ''
}

async function deleteStudent(id) {
  error.value = ''
  try {
    await axios.delete(STUDENTS + '/' + id)
    loadStudents()
  } catch (e) { showError(e) }
}

onMounted(() => { loadClassRooms(); loadStudents() })
</script>

<template>
  <h1>ClassRoom - Student Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>ClassRooms</h2>
  <ClassRoomForm :form="classRoomForm" :editing="editingClassRoomId !== ''" @save="saveClassRoom" @cancel="cancelClassRoom" />
  <div class="box">
    <input v-model="keyword" placeholder="search className" />
    <button @click="showGet(CLASSROOMS + '/search', { keyword })">Search</button>
    <input v-model="minfeePerStudent" type="number" placeholder="min feePerStudent" />
    <button @click="showGet(CLASSROOMS + '/filter', { minfeePerStudent })">Filter</button>
    <button @click="showGet(CLASSROOMS + '/sorted')">Sort by feePerStudent</button>
    <button @click="showGet(CLASSROOMS + '/available')">Available</button>
    <button @click="showGet(CLASSROOMS + '/stats')">Stats</button>
  </div>
  <ClassRoomList :items="classRooms" @edit="editClassRoom" @remove="deleteClassRoom"
    @related="(id) => showGet(CLASSROOMS + '/' + id + '/students')" @summary="(id) => showGet(CLASSROOMS + '/' + id + '/summary')" />

  <h2>Students</h2>
  <StudentForm :form="studentForm" :editing="editingStudentId !== ''" :parents="classRooms" @save="saveStudent" @cancel="cancelStudent" />
  <div class="box">
    <select v-model="filterClassRoomId" @change="loadStudents">
      <option value="">All classRooms</option>
      <option v-for="p in classRooms" :key="p.id" :value="p.id">{{ p.className }}</option>
    </select>
    <button @click="showGet(STUDENTS + '/count', { classRoomId: filterClassRoomId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(STUDENTS + '/search', { keyword })">Search</button>
  </div>
  <StudentList :items="students" :parents="classRooms" @edit="editStudent" @remove="deleteStudent" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
