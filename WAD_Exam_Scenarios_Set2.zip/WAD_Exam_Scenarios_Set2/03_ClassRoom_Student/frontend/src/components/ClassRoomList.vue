<script setup>
// Table of ClassRoom records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'className', label: 'Class Name', type: 'text' },
  { key: 'teacher', label: 'Teacher', type: 'text' },
  { key: 'block', label: 'Block', type: 'text' },
  { key: 'strength', label: 'Strength', type: 'number' },
  { key: 'feePerStudent', label: 'Fee Per Student', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Students</button>
          <button @click="$emit('related', x.id)">Students</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
