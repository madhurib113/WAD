<script setup>
// Form for the "ONE" side (ClassRoom). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'className', label: 'Class Name', type: 'text' },
  { key: 'teacher', label: 'Teacher', type: 'text' },
  { key: 'block', label: 'Block', type: 'text' },
  { key: 'strength', label: 'Strength', type: 'number' },
  { key: 'feePerStudent', label: 'Fee Per Student', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} ClassRoom</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
