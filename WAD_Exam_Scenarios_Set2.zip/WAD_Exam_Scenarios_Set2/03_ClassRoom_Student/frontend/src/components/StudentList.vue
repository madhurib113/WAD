<script setup>
// Table of Student records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the classRoom name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Name</th><th>Roll No</th><th>ClassRoom</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.name }}</td>
        <td>{{ x.rollNo }}</td>
        <td>{{ (parents.find(p => p.id === x.classRoomId) || {}).className || x.classRoomId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
