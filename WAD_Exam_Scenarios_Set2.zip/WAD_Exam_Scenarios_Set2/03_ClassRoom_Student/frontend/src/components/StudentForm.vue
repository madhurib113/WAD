<script setup>
// Form for the "MANY" side (Student). The classRoom is chosen from a dropdown.
defineProps({ form: Object, editing: Boolean, parents: Array })
defineEmits(['save', 'cancel'])
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Student</h3>
    <input v-model="form.name" placeholder="Name" />
    <input v-model="form.rollNo" placeholder="Roll No" />
    <select v-model="form.classRoomId">
      <option value="">-- select classRoom --</option>
      <option v-for="p in parents" :key="p.id" :value="p.id">{{ p.className }}</option>
    </select>
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
