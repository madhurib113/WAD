package com.example.demo.service;

import com.example.demo.model.ClassRoom;
import com.example.demo.model.Student;
import com.example.demo.repository.ClassRoomRepository;
import com.example.demo.repository.StudentRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ClassRoomService {

    private final ClassRoomRepository classRooms;
    private final StudentRepository students;

    public ClassRoomService(ClassRoomRepository classRooms, StudentRepository students) {
        this.classRooms = classRooms;
        this.students = students;
    }

    private void validate(ClassRoom x) {
        if (x.getClassName() == null || x.getClassName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "className is required");
        if (x.getTeacher() == null || x.getTeacher().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "teacher is required");
        if (x.getstrength() == null || x.getstrength() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "strength is required and must be > 0");
        if (x.getfeePerStudent() == null || x.getfeePerStudent() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "feePerStudent is required and must be >= 0");
    }

    public ClassRoom getById(String id) {
        return classRooms.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "ClassRoom not found with id " + id));
    }

    // ---------- CRUD ----------
    public ClassRoom create(ClassRoom x) {
        validate(x);
        x.setId(null);
        return classRooms.save(x);
    }

    public List<ClassRoom> getAll() { return classRooms.findAll(); }

    public ClassRoom update(String id, ClassRoom in) {
        ClassRoom existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of students already added
        long used = students.countByClassRoomId(id);
        if (in.getstrength() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "strength cannot be less than the " + used + " existing students");
        existing.setClassName(in.getClassName());
        existing.setTeacher(in.getTeacher());
        existing.setBlock(in.getBlock());
        existing.setStrength(in.getStrength());
        existing.setFeePerStudent(in.getFeePerStudent());
        return classRooms.save(existing);
    }

    // a classRoom that still has students is NOT deleted unless cascade=true (then its students are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = students.countByClassRoomId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "classRoom has " + used + " students; delete them first or use cascade=true");
        students.deleteByClassRoomId(id);
        classRooms.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<ClassRoom> search(String keyword) { return classRooms.findByClassNameContainingIgnoreCase(keyword); }

    public List<ClassRoom> filterByfeePerStudent(Double min) { return classRooms.findByfeePerStudentGreaterThanEqual(min); }

    public List<ClassRoom> sortedByfeePerStudent() { return classRooms.findAll(Sort.by(Sort.Direction.DESC, "feePerStudent")); }

    // only the classRooms that still have a free place
    public List<ClassRoom> available() {
        List<ClassRoom> result = new ArrayList<>();
        for (ClassRoom x : classRooms.findAll())
            if (students.countByClassRoomId(x.getId()) < x.getstrength()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Student> studentsOf(String id) {
        getById(id);                              // 404 if the classRoom is missing
        return students.findByClassRoomId(id);
    }

    // count + calculations across the two collections for ONE classRoom
    public Map<String, Object> summary(String id) {
        ClassRoom x = getById(id);
        long count = students.countByClassRoomId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("classRoomId", x.getId());
        m.put("name", x.getClassName());
        m.put("strength", x.getstrength());
        m.put("studentCount", count);
        m.put("placesLeft", x.getstrength() - count);
        m.put("feePerStudent", x.getfeePerStudent());
        m.put("totalAmount", count * x.getfeePerStudent());
        return m;
    }

    // totals across ALL classRooms
    public Map<String, Object> stats() {
        long totalStudent = 0;
        double totalAmount = 0;
        List<ClassRoom> all = classRooms.findAll();
        for (ClassRoom x : all) {
            long c = students.countByClassRoomId(x.getId());
            totalStudent += c;
            totalAmount += c * x.getfeePerStudent();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalClassRooms", all.size());
        m.put("totalStudents", totalStudent);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
