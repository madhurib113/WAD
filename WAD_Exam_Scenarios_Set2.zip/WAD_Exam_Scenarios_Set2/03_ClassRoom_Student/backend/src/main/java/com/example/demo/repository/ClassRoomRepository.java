package com.example.demo.repository;

import com.example.demo.model.ClassRoom;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ClassRoomRepository extends MongoRepository<ClassRoom, String> {
    List<ClassRoom> findByClassNameContainingIgnoreCase(String keyword);        // search
    List<ClassRoom> findByfeePerStudentGreaterThanEqual(Double min);                  // filter by number
}
