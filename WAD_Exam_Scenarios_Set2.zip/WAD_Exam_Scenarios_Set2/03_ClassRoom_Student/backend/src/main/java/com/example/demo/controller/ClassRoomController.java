package com.example.demo.controller;

import com.example.demo.model.ClassRoom;
import com.example.demo.model.Student;
import com.example.demo.service.ClassRoomService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/classRooms")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class ClassRoomController {

    private final ClassRoomService service;

    public ClassRoomController(ClassRoomService service) { this.service = service; }

    @PostMapping                                   // POST   /api/classRooms                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public ClassRoom create(@RequestBody ClassRoom x) { return service.create(x); }

    @GetMapping                                    // GET    /api/classRooms
    public List<ClassRoom> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/classRooms/{id}            -> 200 / 404
    public ClassRoom getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/classRooms/{id}            -> 200 / 400 / 404 / 409
    public ClassRoom update(@PathVariable String id, @RequestBody ClassRoom x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/classRooms/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/classRooms/search?keyword=ab
    public List<ClassRoom> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/classRooms/filter?minfeePerStudent=500
    public List<ClassRoom> filter(@RequestParam Double minfeePerStudent) { return service.filterByfeePerStudent(minfeePerStudent); }

    @GetMapping("/sorted")                         // GET    /api/classRooms/sorted          (feePerStudent high -> low)
    public List<ClassRoom> sorted() { return service.sortedByfeePerStudent(); }

    @GetMapping("/available")                      // GET    /api/classRooms/available       (still have free places)
    public List<ClassRoom> available() { return service.available(); }

    @GetMapping("/{id}/students")                    // GET    /api/classRooms/{id}/students     (related records)
    public List<Student> related(@PathVariable String id) { return service.studentsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/classRooms/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/classRooms/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
