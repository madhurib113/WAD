package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: students
// classRoomId stores the _id of a ClassRoom as plain text. MongoDB has NO foreign keys,
// so StudentService checks that the classRoom exists before saving.
@Document(collection = "students")
public class Student {

    @Id
    private String id;

    private String name;     // required
    private String rollNo;     // required
    private String classRoomId;    // required: reference to classRooms._id

    public Student() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getRollNo() { return rollNo; }
    public void setRollNo(String rollNo) { this.rollNo = rollNo; }
    public String getClassRoomId() { return classRoomId; }
    public void setClassRoomId(String classRoomId) { this.classRoomId = classRoomId; }
}
