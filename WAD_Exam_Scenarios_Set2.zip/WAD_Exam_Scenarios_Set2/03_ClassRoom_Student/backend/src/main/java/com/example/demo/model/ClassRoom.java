package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: classRooms
@Document(collection = "classRooms")
public class ClassRoom {

    @Id
    private String id;

    private String className;
    private String teacher;
    private String block;
    private Integer strength;
    private Double feePerStudent;

    public ClassRoom() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }
    public String getTeacher() { return teacher; }
    public void setTeacher(String teacher) { this.teacher = teacher; }
    public String getBlock() { return block; }
    public void setBlock(String block) { this.block = block; }
    public Integer getStrength() { return strength; }
    public void setStrength(Integer strength) { this.strength = strength; }
    public Double getFeePerStudent() { return feePerStudent; }
    public void setFeePerStudent(Double feePerStudent) { this.feePerStudent = feePerStudent; }
}
