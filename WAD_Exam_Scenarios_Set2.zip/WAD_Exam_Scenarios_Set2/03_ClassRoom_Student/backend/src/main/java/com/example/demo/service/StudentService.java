package com.example.demo.service;

import com.example.demo.model.ClassRoom;
import com.example.demo.model.Student;
import com.example.demo.repository.ClassRoomRepository;
import com.example.demo.repository.StudentRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class StudentService {

    private final StudentRepository students;
    private final ClassRoomRepository classRooms;

    public StudentService(StudentRepository students, ClassRoomRepository classRooms) {
        this.students = students;
        this.classRooms = classRooms;
    }

    private void validate(Student x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getRollNo() == null || x.getRollNo().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "rollNo is required");
        if (x.getClassRoomId() == null || x.getClassRoomId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "classRoomId is required");
    }

    // The referenced classRoom must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkClassRoom(String id, boolean checkLimit) {
        ClassRoom p = classRooms.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "classRoomId does not exist: " + id));
        if (checkLimit && students.countByClassRoomId(id) >= p.getstrength())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "classRoom is full");
    }

    public Student getById(String id) {
        return students.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Student not found with id " + id));
    }

    public Student create(Student x) {
        validate(x);
        checkClassRoom(x.getClassRoomId(), true);
        x.setId(null);
        return students.save(x);
    }

    // optional filter by related record: ?classRoomId=...
    public List<Student> getAll(String classRoomId) {
        if (classRoomId == null || classRoomId.isBlank()) return students.findAll();
        return students.findByClassRoomId(classRoomId);
    }

    public List<Student> search(String keyword) { return students.findByNameContainingIgnoreCase(keyword); }

    public Student update(String id, Student in) {
        Student existing = getById(id);
        validate(in);
        boolean moving = !in.getClassRoomId().equals(existing.getClassRoomId());
        checkClassRoom(in.getClassRoomId(), moving);       // free-place check only when moving to another classRoom
        existing.setName(in.getName());
        existing.setRollNo(in.getRollNo());
        existing.setClassRoomId(in.getClassRoomId());
        return students.save(existing);
    }

    public void delete(String id) {
        getById(id);
        students.deleteById(id);
    }

    public long count(String classRoomId) {
        if (classRoomId == null || classRoomId.isBlank()) return students.count();
        return students.countByClassRoomId(classRoomId);
    }
}
