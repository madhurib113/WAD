package com.example.demo.repository;

import com.example.demo.model.Student;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface StudentRepository extends MongoRepository<Student, String> {
    List<Student> findByClassRoomId(String classRoomId);                    // filter by the related record
    long countByClassRoomId(String classRoomId);                          // count related records
    long deleteByClassRoomId(String classRoomId);                         // cascade delete
    List<Student> findByNameContainingIgnoreCase(String keyword); // search
}
