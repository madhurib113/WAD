# Warehouse - Item (2 collections: `warehouses` and `items`)

Database `warehouse_db`. `items.warehouseId` stores the `_id` of a warehouse (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db warehouse_db --collection warehouses --jsonArray --file sample_data/warehouses.json
mongoimport --db warehouse_db --collection items --jsonArray --file sample_data/items.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Warehouse**: warehouseName*, manager*, city, capacity* (> 0), rentPerItem* (>= 0)    (* = required)
- **Item**: name*, category*, warehouseId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/warehouses | create (Warehouse) 201 / 400 |
| GET | /api/warehouses , /api/warehouses/{id} | all / one (404) |
| PUT | /api/warehouses/{id} | update 200 / 400 / 404 / 409 (`capacity` below existing items) |
| DELETE | /api/warehouses/{id}?cascade=true | 204 / 404 / 409 (has items and no cascade) |
| GET | /api/warehouses/search?keyword= | search by warehouseName |
| GET | /api/warehouses/filter?minrentPerItem= | rentPerItem >= value |
| GET | /api/warehouses/sorted | sort by rentPerItem desc |
| GET | /api/warehouses/available | warehouses that still have free places |
| GET | /api/warehouses/{id}/items | related items |
| GET | /api/warehouses/{id}/summary | count, placesLeft, totalAmount = count x rentPerItem |
| GET | /api/warehouses/stats | totals over all warehouses |
| POST | /api/items | create (Item) 201 / 400 (bad warehouseId) / 409 (full) |
| GET | /api/items?warehouseId= | all / filter by warehouse |
| GET | /api/items/{id} | one (404) |
| PUT | /api/items/{id} | update (move to another warehouse: free place checked) |
| DELETE | /api/items/{id} | 204 / 404 |
| GET | /api/items/search?keyword= | search by name |
| GET | /api/items/count?warehouseId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on warehouses and on items.
3. Validation: missing field -> 400, capacity <= 0 -> 400, rentPerItem < 0 -> 400, unknown id -> 404.
4. Add a item only if the warehouse exists (400) and is not full (409).
5. Update warehouse: capacity cannot be lower than current number of items (409).
6. Delete warehouse: blocked if it has items (409); `cascade=true` deletes its items too.
7. List items of one warehouse; count items of one warehouse.
8. Search by text, filter by number, sort descending, list available warehouses.
9. Calculation: totalAmount for one warehouse, and totals over all warehouses (stats).
10. Move a item from one warehouse to another.
