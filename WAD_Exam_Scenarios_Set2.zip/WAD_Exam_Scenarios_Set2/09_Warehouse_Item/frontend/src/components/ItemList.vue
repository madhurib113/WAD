<script setup>
// Table of Item records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the warehouse name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Name</th><th>Category</th><th>Warehouse</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.name }}</td>
        <td>{{ x.category }}</td>
        <td>{{ (parents.find(p => p.id === x.warehouseId) || {}).warehouseName || x.warehouseId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
