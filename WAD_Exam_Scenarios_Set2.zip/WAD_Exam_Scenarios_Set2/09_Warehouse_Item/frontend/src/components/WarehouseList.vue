<script setup>
// Table of Warehouse records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'warehouseName', label: 'Warehouse Name', type: 'text' },
  { key: 'manager', label: 'Manager', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'capacity', label: 'Capacity', type: 'number' },
  { key: 'rentPerItem', label: 'Rent Per Item', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Items</button>
          <button @click="$emit('related', x.id)">Items</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
