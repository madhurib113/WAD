<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import WarehouseForm from './components/WarehouseForm.vue'
import WarehouseList from './components/WarehouseList.vue'
import ItemForm from './components/ItemForm.vue'
import ItemList from './components/ItemList.vue'
import ResultBox from './components/ResultBox.vue'

const WAREHOUSES = 'http://localhost:8080/api/warehouses'
const ITEMS = 'http://localhost:8080/api/items'

const warehouses = ref([])
const items = ref([])
const warehouseForm = ref({ warehouseName: '', manager: '', city: '', capacity: '', rentPerItem: '' })
const editingWarehouseId = ref('')
const itemForm = ref({ name: '', category: '', warehouseId: '' })
const editingItemId = ref('')
const filterWarehouseId = ref('')
const keyword = ref('')
const minrentPerItem = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Warehouse ----------
async function loadWarehouses() {
  try { warehouses.value = (await axios.get(WAREHOUSES)).data } catch (e) { showError(e) }
}

async function saveWarehouse() {
  error.value = ''
  const body = { ...warehouseForm.value, capacity: num(warehouseForm.value.capacity), rentPerItem: num(warehouseForm.value.rentPerItem) }
  try {
    if (editingWarehouseId.value === '') await axios.post(WAREHOUSES, body)
    else await axios.put(WAREHOUSES + '/' + editingWarehouseId.value, body)
    cancelWarehouse()
    loadWarehouses()
  } catch (e) { showError(e) }
}

function editWarehouse(x) {
  warehouseForm.value = { ...x }
  editingWarehouseId.value = x.id
}

function cancelWarehouse() {
  warehouseForm.value = { warehouseName: '', manager: '', city: '', capacity: '', rentPerItem: '' }
  editingWarehouseId.value = ''
}

// cascade = true also deletes the items; false -> error 409 if there are items
async function deleteWarehouse(id, cascade) {
  error.value = ''
  try {
    await axios.delete(WAREHOUSES + '/' + id, { params: { cascade } })
    loadWarehouses()
    loadItems()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Item ----------
async function loadItems() {
  try { items.value = (await axios.get(ITEMS, { params: { warehouseId: filterWarehouseId.value } })).data } catch (e) { showError(e) }
}

async function saveItem() {
  error.value = ''
  try {
    if (editingItemId.value === '') await axios.post(ITEMS, itemForm.value)
    else await axios.put(ITEMS + '/' + editingItemId.value, itemForm.value)
    cancelItem()
    loadItems()
  } catch (e) { showError(e) }
}

function editItem(x) {
  itemForm.value = { name: x.name, category: x.category, warehouseId: x.warehouseId }
  editingItemId.value = x.id
}

function cancelItem() {
  itemForm.value = { name: '', category: '', warehouseId: '' }
  editingItemId.value = ''
}

async function deleteItem(id) {
  error.value = ''
  try {
    await axios.delete(ITEMS + '/' + id)
    loadItems()
  } catch (e) { showError(e) }
}

onMounted(() => { loadWarehouses(); loadItems() })
</script>

<template>
  <h1>Warehouse - Item Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Warehouses</h2>
  <WarehouseForm :form="warehouseForm" :editing="editingWarehouseId !== ''" @save="saveWarehouse" @cancel="cancelWarehouse" />
  <div class="box">
    <input v-model="keyword" placeholder="search warehouseName" />
    <button @click="showGet(WAREHOUSES + '/search', { keyword })">Search</button>
    <input v-model="minrentPerItem" type="number" placeholder="min rentPerItem" />
    <button @click="showGet(WAREHOUSES + '/filter', { minrentPerItem })">Filter</button>
    <button @click="showGet(WAREHOUSES + '/sorted')">Sort by rentPerItem</button>
    <button @click="showGet(WAREHOUSES + '/available')">Available</button>
    <button @click="showGet(WAREHOUSES + '/stats')">Stats</button>
  </div>
  <WarehouseList :items="warehouses" @edit="editWarehouse" @remove="deleteWarehouse"
    @related="(id) => showGet(WAREHOUSES + '/' + id + '/items')" @summary="(id) => showGet(WAREHOUSES + '/' + id + '/summary')" />

  <h2>Items</h2>
  <ItemForm :form="itemForm" :editing="editingItemId !== ''" :parents="warehouses" @save="saveItem" @cancel="cancelItem" />
  <div class="box">
    <select v-model="filterWarehouseId" @change="loadItems">
      <option value="">All warehouses</option>
      <option v-for="p in warehouses" :key="p.id" :value="p.id">{{ p.warehouseName }}</option>
    </select>
    <button @click="showGet(ITEMS + '/count', { warehouseId: filterWarehouseId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(ITEMS + '/search', { keyword })">Search</button>
  </div>
  <ItemList :items="items" :parents="warehouses" @edit="editItem" @remove="deleteItem" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
