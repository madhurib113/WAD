package com.example.demo.controller;

import com.example.demo.model.Warehouse;
import com.example.demo.model.Item;
import com.example.demo.service.WarehouseService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/warehouses")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class WarehouseController {

    private final WarehouseService service;

    public WarehouseController(WarehouseService service) { this.service = service; }

    @PostMapping                                   // POST   /api/warehouses                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Warehouse create(@RequestBody Warehouse x) { return service.create(x); }

    @GetMapping                                    // GET    /api/warehouses
    public List<Warehouse> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/warehouses/{id}            -> 200 / 404
    public Warehouse getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/warehouses/{id}            -> 200 / 400 / 404 / 409
    public Warehouse update(@PathVariable String id, @RequestBody Warehouse x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/warehouses/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/warehouses/search?keyword=ab
    public List<Warehouse> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/warehouses/filter?minrentPerItem=500
    public List<Warehouse> filter(@RequestParam Double minrentPerItem) { return service.filterByrentPerItem(minrentPerItem); }

    @GetMapping("/sorted")                         // GET    /api/warehouses/sorted          (rentPerItem high -> low)
    public List<Warehouse> sorted() { return service.sortedByrentPerItem(); }

    @GetMapping("/available")                      // GET    /api/warehouses/available       (still have free places)
    public List<Warehouse> available() { return service.available(); }

    @GetMapping("/{id}/items")                    // GET    /api/warehouses/{id}/items     (related records)
    public List<Item> related(@PathVariable String id) { return service.itemsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/warehouses/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/warehouses/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
