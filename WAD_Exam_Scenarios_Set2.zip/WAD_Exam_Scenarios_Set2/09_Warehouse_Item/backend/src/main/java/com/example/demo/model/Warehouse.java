package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: warehouses
@Document(collection = "warehouses")
public class Warehouse {

    @Id
    private String id;

    private String warehouseName;
    private String manager;
    private String city;
    private Integer capacity;
    private Double rentPerItem;

    public Warehouse() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getWarehouseName() { return warehouseName; }
    public void setWarehouseName(String warehouseName) { this.warehouseName = warehouseName; }
    public String getManager() { return manager; }
    public void setManager(String manager) { this.manager = manager; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    public Double getRentPerItem() { return rentPerItem; }
    public void setRentPerItem(Double rentPerItem) { this.rentPerItem = rentPerItem; }
}
