package com.example.demo.repository;

import com.example.demo.model.Item;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ItemRepository extends MongoRepository<Item, String> {
    List<Item> findByWarehouseId(String warehouseId);                    // filter by the related record
    long countByWarehouseId(String warehouseId);                          // count related records
    long deleteByWarehouseId(String warehouseId);                         // cascade delete
    List<Item> findByNameContainingIgnoreCase(String keyword); // search
}
