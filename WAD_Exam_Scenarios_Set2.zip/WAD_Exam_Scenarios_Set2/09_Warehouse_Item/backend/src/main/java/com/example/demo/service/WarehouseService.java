package com.example.demo.service;

import com.example.demo.model.Warehouse;
import com.example.demo.model.Item;
import com.example.demo.repository.WarehouseRepository;
import com.example.demo.repository.ItemRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class WarehouseService {

    private final WarehouseRepository warehouses;
    private final ItemRepository items;

    public WarehouseService(WarehouseRepository warehouses, ItemRepository items) {
        this.warehouses = warehouses;
        this.items = items;
    }

    private void validate(Warehouse x) {
        if (x.getWarehouseName() == null || x.getWarehouseName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "warehouseName is required");
        if (x.getManager() == null || x.getManager().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "manager is required");
        if (x.getcapacity() == null || x.getcapacity() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "capacity is required and must be > 0");
        if (x.getrentPerItem() == null || x.getrentPerItem() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "rentPerItem is required and must be >= 0");
    }

    public Warehouse getById(String id) {
        return warehouses.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Warehouse not found with id " + id));
    }

    // ---------- CRUD ----------
    public Warehouse create(Warehouse x) {
        validate(x);
        x.setId(null);
        return warehouses.save(x);
    }

    public List<Warehouse> getAll() { return warehouses.findAll(); }

    public Warehouse update(String id, Warehouse in) {
        Warehouse existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of items already added
        long used = items.countByWarehouseId(id);
        if (in.getcapacity() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "capacity cannot be less than the " + used + " existing items");
        existing.setWarehouseName(in.getWarehouseName());
        existing.setManager(in.getManager());
        existing.setCity(in.getCity());
        existing.setCapacity(in.getCapacity());
        existing.setRentPerItem(in.getRentPerItem());
        return warehouses.save(existing);
    }

    // a warehouse that still has items is NOT deleted unless cascade=true (then its items are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = items.countByWarehouseId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "warehouse has " + used + " items; delete them first or use cascade=true");
        items.deleteByWarehouseId(id);
        warehouses.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Warehouse> search(String keyword) { return warehouses.findByWarehouseNameContainingIgnoreCase(keyword); }

    public List<Warehouse> filterByrentPerItem(Double min) { return warehouses.findByrentPerItemGreaterThanEqual(min); }

    public List<Warehouse> sortedByrentPerItem() { return warehouses.findAll(Sort.by(Sort.Direction.DESC, "rentPerItem")); }

    // only the warehouses that still have a free place
    public List<Warehouse> available() {
        List<Warehouse> result = new ArrayList<>();
        for (Warehouse x : warehouses.findAll())
            if (items.countByWarehouseId(x.getId()) < x.getcapacity()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Item> itemsOf(String id) {
        getById(id);                              // 404 if the warehouse is missing
        return items.findByWarehouseId(id);
    }

    // count + calculations across the two collections for ONE warehouse
    public Map<String, Object> summary(String id) {
        Warehouse x = getById(id);
        long count = items.countByWarehouseId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("warehouseId", x.getId());
        m.put("name", x.getWarehouseName());
        m.put("capacity", x.getcapacity());
        m.put("itemCount", count);
        m.put("placesLeft", x.getcapacity() - count);
        m.put("rentPerItem", x.getrentPerItem());
        m.put("totalAmount", count * x.getrentPerItem());
        return m;
    }

    // totals across ALL warehouses
    public Map<String, Object> stats() {
        long totalItem = 0;
        double totalAmount = 0;
        List<Warehouse> all = warehouses.findAll();
        for (Warehouse x : all) {
            long c = items.countByWarehouseId(x.getId());
            totalItem += c;
            totalAmount += c * x.getrentPerItem();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalWarehouses", all.size());
        m.put("totalItems", totalItem);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
