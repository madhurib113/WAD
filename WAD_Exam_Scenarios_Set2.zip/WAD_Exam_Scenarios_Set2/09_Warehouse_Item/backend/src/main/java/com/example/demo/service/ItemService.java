package com.example.demo.service;

import com.example.demo.model.Warehouse;
import com.example.demo.model.Item;
import com.example.demo.repository.WarehouseRepository;
import com.example.demo.repository.ItemRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ItemService {

    private final ItemRepository items;
    private final WarehouseRepository warehouses;

    public ItemService(ItemRepository items, WarehouseRepository warehouses) {
        this.items = items;
        this.warehouses = warehouses;
    }

    private void validate(Item x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getCategory() == null || x.getCategory().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "category is required");
        if (x.getWarehouseId() == null || x.getWarehouseId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "warehouseId is required");
    }

    // The referenced warehouse must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkWarehouse(String id, boolean checkLimit) {
        Warehouse p = warehouses.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "warehouseId does not exist: " + id));
        if (checkLimit && items.countByWarehouseId(id) >= p.getcapacity())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "warehouse is full");
    }

    public Item getById(String id) {
        return items.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Item not found with id " + id));
    }

    public Item create(Item x) {
        validate(x);
        checkWarehouse(x.getWarehouseId(), true);
        x.setId(null);
        return items.save(x);
    }

    // optional filter by related record: ?warehouseId=...
    public List<Item> getAll(String warehouseId) {
        if (warehouseId == null || warehouseId.isBlank()) return items.findAll();
        return items.findByWarehouseId(warehouseId);
    }

    public List<Item> search(String keyword) { return items.findByNameContainingIgnoreCase(keyword); }

    public Item update(String id, Item in) {
        Item existing = getById(id);
        validate(in);
        boolean moving = !in.getWarehouseId().equals(existing.getWarehouseId());
        checkWarehouse(in.getWarehouseId(), moving);       // free-place check only when moving to another warehouse
        existing.setName(in.getName());
        existing.setCategory(in.getCategory());
        existing.setWarehouseId(in.getWarehouseId());
        return items.save(existing);
    }

    public void delete(String id) {
        getById(id);
        items.deleteById(id);
    }

    public long count(String warehouseId) {
        if (warehouseId == null || warehouseId.isBlank()) return items.count();
        return items.countByWarehouseId(warehouseId);
    }
}
