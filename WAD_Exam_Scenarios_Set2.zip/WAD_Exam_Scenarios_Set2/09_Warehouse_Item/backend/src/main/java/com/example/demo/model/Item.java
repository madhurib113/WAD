package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: items
// warehouseId stores the _id of a Warehouse as plain text. MongoDB has NO foreign keys,
// so ItemService checks that the warehouse exists before saving.
@Document(collection = "items")
public class Item {

    @Id
    private String id;

    private String name;     // required
    private String category;     // required
    private String warehouseId;    // required: reference to warehouses._id

    public Item() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getWarehouseId() { return warehouseId; }
    public void setWarehouseId(String warehouseId) { this.warehouseId = warehouseId; }
}
