package com.example.demo.controller;

import com.example.demo.model.Item;
import com.example.demo.service.ItemService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/items")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class ItemController {

    private final ItemService service;

    public ItemController(ItemService service) { this.service = service; }

    @PostMapping                                   // POST   /api/items   -> 201 / 400 (bad warehouse) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Item create(@RequestBody Item x) { return service.create(x); }

    @GetMapping                                    // GET    /api/items[?warehouseId=..]  (filter by related record)
    public List<Item> getAll(@RequestParam(required = false) String warehouseId) { return service.getAll(warehouseId); }

    @GetMapping("/{id}")                           // GET    /api/items/{id}   -> 200 / 404
    public Item getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/items/{id}
    public Item update(@PathVariable String id, @RequestBody Item x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/items/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/items/search?keyword=an
    public List<Item> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/items/count[?warehouseId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String warehouseId) {
        return Map.of("count", service.count(warehouseId));
    }
}
