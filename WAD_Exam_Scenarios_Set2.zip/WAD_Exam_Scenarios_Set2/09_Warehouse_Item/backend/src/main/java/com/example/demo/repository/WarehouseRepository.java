package com.example.demo.repository;

import com.example.demo.model.Warehouse;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface WarehouseRepository extends MongoRepository<Warehouse, String> {
    List<Warehouse> findByWarehouseNameContainingIgnoreCase(String keyword);        // search
    List<Warehouse> findByrentPerItemGreaterThanEqual(Double min);                  // filter by number
}
