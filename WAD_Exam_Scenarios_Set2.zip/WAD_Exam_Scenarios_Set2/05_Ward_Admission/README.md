# Ward - Admission (2 collections: `wards` and `admissions`)

Database `ward_db`. `admissions.wardId` stores the `_id` of a ward (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db ward_db --collection wards --jsonArray --file sample_data/wards.json
mongoimport --db ward_db --collection admissions --jsonArray --file sample_data/admissions.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Ward**: wardName*, nurse*, floor, beds* (> 0), chargePerDay* (>= 0)    (* = required)
- **Admission**: name*, phone*, wardId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/wards | create (Ward) 201 / 400 |
| GET | /api/wards , /api/wards/{id} | all / one (404) |
| PUT | /api/wards/{id} | update 200 / 400 / 404 / 409 (`beds` below existing admissions) |
| DELETE | /api/wards/{id}?cascade=true | 204 / 404 / 409 (has admissions and no cascade) |
| GET | /api/wards/search?keyword= | search by wardName |
| GET | /api/wards/filter?minchargePerDay= | chargePerDay >= value |
| GET | /api/wards/sorted | sort by chargePerDay desc |
| GET | /api/wards/available | wards that still have free places |
| GET | /api/wards/{id}/admissions | related admissions |
| GET | /api/wards/{id}/summary | count, placesLeft, totalAmount = count x chargePerDay |
| GET | /api/wards/stats | totals over all wards |
| POST | /api/admissions | create (Admission) 201 / 400 (bad wardId) / 409 (full) |
| GET | /api/admissions?wardId= | all / filter by ward |
| GET | /api/admissions/{id} | one (404) |
| PUT | /api/admissions/{id} | update (move to another ward: free place checked) |
| DELETE | /api/admissions/{id} | 204 / 404 |
| GET | /api/admissions/search?keyword= | search by name |
| GET | /api/admissions/count?wardId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on wards and on admissions.
3. Validation: missing field -> 400, beds <= 0 -> 400, chargePerDay < 0 -> 400, unknown id -> 404.
4. Add a admission only if the ward exists (400) and is not full (409).
5. Update ward: beds cannot be lower than current number of admissions (409).
6. Delete ward: blocked if it has admissions (409); `cascade=true` deletes its admissions too.
7. List admissions of one ward; count admissions of one ward.
8. Search by text, filter by number, sort descending, list available wards.
9. Calculation: totalAmount for one ward, and totals over all wards (stats).
10. Move a admission from one ward to another.
