<script setup>
// Table of Admission records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the ward name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Name</th><th>Phone</th><th>Ward</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.name }}</td>
        <td>{{ x.phone }}</td>
        <td>{{ (parents.find(p => p.id === x.wardId) || {}).wardName || x.wardId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
