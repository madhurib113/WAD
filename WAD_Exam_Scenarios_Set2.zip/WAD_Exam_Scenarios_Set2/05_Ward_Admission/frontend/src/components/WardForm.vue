<script setup>
// Form for the "ONE" side (Ward). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'wardName', label: 'Ward Name', type: 'text' },
  { key: 'nurse', label: 'Nurse', type: 'text' },
  { key: 'floor', label: 'Floor', type: 'text' },
  { key: 'beds', label: 'Beds', type: 'number' },
  { key: 'chargePerDay', label: 'Charge Per Day', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Ward</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
