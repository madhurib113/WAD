<script setup>
// Table of Ward records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'wardName', label: 'Ward Name', type: 'text' },
  { key: 'nurse', label: 'Nurse', type: 'text' },
  { key: 'floor', label: 'Floor', type: 'text' },
  { key: 'beds', label: 'Beds', type: 'number' },
  { key: 'chargePerDay', label: 'Charge Per Day', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Admissions</button>
          <button @click="$emit('related', x.id)">Admissions</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
