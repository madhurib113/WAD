<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import WardForm from './components/WardForm.vue'
import WardList from './components/WardList.vue'
import AdmissionForm from './components/AdmissionForm.vue'
import AdmissionList from './components/AdmissionList.vue'
import ResultBox from './components/ResultBox.vue'

const WARDS = 'http://localhost:8080/api/wards'
const ADMISSIONS = 'http://localhost:8080/api/admissions'

const wards = ref([])
const admissions = ref([])
const wardForm = ref({ wardName: '', nurse: '', floor: '', beds: '', chargePerDay: '' })
const editingWardId = ref('')
const admissionForm = ref({ name: '', phone: '', wardId: '' })
const editingAdmissionId = ref('')
const filterWardId = ref('')
const keyword = ref('')
const minchargePerDay = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Ward ----------
async function loadWards() {
  try { wards.value = (await axios.get(WARDS)).data } catch (e) { showError(e) }
}

async function saveWard() {
  error.value = ''
  const body = { ...wardForm.value, beds: num(wardForm.value.beds), chargePerDay: num(wardForm.value.chargePerDay) }
  try {
    if (editingWardId.value === '') await axios.post(WARDS, body)
    else await axios.put(WARDS + '/' + editingWardId.value, body)
    cancelWard()
    loadWards()
  } catch (e) { showError(e) }
}

function editWard(x) {
  wardForm.value = { ...x }
  editingWardId.value = x.id
}

function cancelWard() {
  wardForm.value = { wardName: '', nurse: '', floor: '', beds: '', chargePerDay: '' }
  editingWardId.value = ''
}

// cascade = true also deletes the admissions; false -> error 409 if there are admissions
async function deleteWard(id, cascade) {
  error.value = ''
  try {
    await axios.delete(WARDS + '/' + id, { params: { cascade } })
    loadWards()
    loadAdmissions()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Admission ----------
async function loadAdmissions() {
  try { admissions.value = (await axios.get(ADMISSIONS, { params: { wardId: filterWardId.value } })).data } catch (e) { showError(e) }
}

async function saveAdmission() {
  error.value = ''
  try {
    if (editingAdmissionId.value === '') await axios.post(ADMISSIONS, admissionForm.value)
    else await axios.put(ADMISSIONS + '/' + editingAdmissionId.value, admissionForm.value)
    cancelAdmission()
    loadAdmissions()
  } catch (e) { showError(e) }
}

function editAdmission(x) {
  admissionForm.value = { name: x.name, phone: x.phone, wardId: x.wardId }
  editingAdmissionId.value = x.id
}

function cancelAdmission() {
  admissionForm.value = { name: '', phone: '', wardId: '' }
  editingAdmissionId.value = ''
}

async function deleteAdmission(id) {
  error.value = ''
  try {
    await axios.delete(ADMISSIONS + '/' + id)
    loadAdmissions()
  } catch (e) { showError(e) }
}

onMounted(() => { loadWards(); loadAdmissions() })
</script>

<template>
  <h1>Ward - Admission Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Wards</h2>
  <WardForm :form="wardForm" :editing="editingWardId !== ''" @save="saveWard" @cancel="cancelWard" />
  <div class="box">
    <input v-model="keyword" placeholder="search wardName" />
    <button @click="showGet(WARDS + '/search', { keyword })">Search</button>
    <input v-model="minchargePerDay" type="number" placeholder="min chargePerDay" />
    <button @click="showGet(WARDS + '/filter', { minchargePerDay })">Filter</button>
    <button @click="showGet(WARDS + '/sorted')">Sort by chargePerDay</button>
    <button @click="showGet(WARDS + '/available')">Available</button>
    <button @click="showGet(WARDS + '/stats')">Stats</button>
  </div>
  <WardList :items="wards" @edit="editWard" @remove="deleteWard"
    @related="(id) => showGet(WARDS + '/' + id + '/admissions')" @summary="(id) => showGet(WARDS + '/' + id + '/summary')" />

  <h2>Admissions</h2>
  <AdmissionForm :form="admissionForm" :editing="editingAdmissionId !== ''" :parents="wards" @save="saveAdmission" @cancel="cancelAdmission" />
  <div class="box">
    <select v-model="filterWardId" @change="loadAdmissions">
      <option value="">All wards</option>
      <option v-for="p in wards" :key="p.id" :value="p.id">{{ p.wardName }}</option>
    </select>
    <button @click="showGet(ADMISSIONS + '/count', { wardId: filterWardId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(ADMISSIONS + '/search', { keyword })">Search</button>
  </div>
  <AdmissionList :items="admissions" :parents="wards" @edit="editAdmission" @remove="deleteAdmission" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
