package com.example.demo.repository;

import com.example.demo.model.Admission;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AdmissionRepository extends MongoRepository<Admission, String> {
    List<Admission> findByWardId(String wardId);                    // filter by the related record
    long countByWardId(String wardId);                          // count related records
    long deleteByWardId(String wardId);                         // cascade delete
    List<Admission> findByNameContainingIgnoreCase(String keyword); // search
}
