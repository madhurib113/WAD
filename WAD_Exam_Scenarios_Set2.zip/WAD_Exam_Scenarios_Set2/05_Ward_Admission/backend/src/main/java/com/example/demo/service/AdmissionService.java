package com.example.demo.service;

import com.example.demo.model.Ward;
import com.example.demo.model.Admission;
import com.example.demo.repository.WardRepository;
import com.example.demo.repository.AdmissionRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AdmissionService {

    private final AdmissionRepository admissions;
    private final WardRepository wards;

    public AdmissionService(AdmissionRepository admissions, WardRepository wards) {
        this.admissions = admissions;
        this.wards = wards;
    }

    private void validate(Admission x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getWardId() == null || x.getWardId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "wardId is required");
    }

    // The referenced ward must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkWard(String id, boolean checkLimit) {
        Ward p = wards.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "wardId does not exist: " + id));
        if (checkLimit && admissions.countByWardId(id) >= p.getbeds())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "ward is full");
    }

    public Admission getById(String id) {
        return admissions.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Admission not found with id " + id));
    }

    public Admission create(Admission x) {
        validate(x);
        checkWard(x.getWardId(), true);
        x.setId(null);
        return admissions.save(x);
    }

    // optional filter by related record: ?wardId=...
    public List<Admission> getAll(String wardId) {
        if (wardId == null || wardId.isBlank()) return admissions.findAll();
        return admissions.findByWardId(wardId);
    }

    public List<Admission> search(String keyword) { return admissions.findByNameContainingIgnoreCase(keyword); }

    public Admission update(String id, Admission in) {
        Admission existing = getById(id);
        validate(in);
        boolean moving = !in.getWardId().equals(existing.getWardId());
        checkWard(in.getWardId(), moving);       // free-place check only when moving to another ward
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setWardId(in.getWardId());
        return admissions.save(existing);
    }

    public void delete(String id) {
        getById(id);
        admissions.deleteById(id);
    }

    public long count(String wardId) {
        if (wardId == null || wardId.isBlank()) return admissions.count();
        return admissions.countByWardId(wardId);
    }
}
