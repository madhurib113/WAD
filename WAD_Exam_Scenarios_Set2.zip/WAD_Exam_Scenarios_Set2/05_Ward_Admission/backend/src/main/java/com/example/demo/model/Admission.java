package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: admissions
// wardId stores the _id of a Ward as plain text. MongoDB has NO foreign keys,
// so AdmissionService checks that the ward exists before saving.
@Document(collection = "admissions")
public class Admission {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String wardId;    // required: reference to wards._id

    public Admission() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getWardId() { return wardId; }
    public void setWardId(String wardId) { this.wardId = wardId; }
}
