package com.example.demo.repository;

import com.example.demo.model.Ward;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface WardRepository extends MongoRepository<Ward, String> {
    List<Ward> findByWardNameContainingIgnoreCase(String keyword);        // search
    List<Ward> findBychargePerDayGreaterThanEqual(Double min);                  // filter by number
}
