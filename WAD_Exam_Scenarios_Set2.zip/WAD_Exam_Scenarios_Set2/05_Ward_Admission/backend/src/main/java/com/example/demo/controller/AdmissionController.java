package com.example.demo.controller;

import com.example.demo.model.Admission;
import com.example.demo.service.AdmissionService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admissions")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class AdmissionController {

    private final AdmissionService service;

    public AdmissionController(AdmissionService service) { this.service = service; }

    @PostMapping                                   // POST   /api/admissions   -> 201 / 400 (bad ward) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Admission create(@RequestBody Admission x) { return service.create(x); }

    @GetMapping                                    // GET    /api/admissions[?wardId=..]  (filter by related record)
    public List<Admission> getAll(@RequestParam(required = false) String wardId) { return service.getAll(wardId); }

    @GetMapping("/{id}")                           // GET    /api/admissions/{id}   -> 200 / 404
    public Admission getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/admissions/{id}
    public Admission update(@PathVariable String id, @RequestBody Admission x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/admissions/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/admissions/search?keyword=an
    public List<Admission> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/admissions/count[?wardId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String wardId) {
        return Map.of("count", service.count(wardId));
    }
}
