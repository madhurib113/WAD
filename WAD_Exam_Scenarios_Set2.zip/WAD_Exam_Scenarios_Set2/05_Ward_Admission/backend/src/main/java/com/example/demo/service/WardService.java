package com.example.demo.service;

import com.example.demo.model.Ward;
import com.example.demo.model.Admission;
import com.example.demo.repository.WardRepository;
import com.example.demo.repository.AdmissionRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class WardService {

    private final WardRepository wards;
    private final AdmissionRepository admissions;

    public WardService(WardRepository wards, AdmissionRepository admissions) {
        this.wards = wards;
        this.admissions = admissions;
    }

    private void validate(Ward x) {
        if (x.getWardName() == null || x.getWardName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "wardName is required");
        if (x.getNurse() == null || x.getNurse().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "nurse is required");
        if (x.getbeds() == null || x.getbeds() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "beds is required and must be > 0");
        if (x.getchargePerDay() == null || x.getchargePerDay() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "chargePerDay is required and must be >= 0");
    }

    public Ward getById(String id) {
        return wards.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Ward not found with id " + id));
    }

    // ---------- CRUD ----------
    public Ward create(Ward x) {
        validate(x);
        x.setId(null);
        return wards.save(x);
    }

    public List<Ward> getAll() { return wards.findAll(); }

    public Ward update(String id, Ward in) {
        Ward existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of admissions already added
        long used = admissions.countByWardId(id);
        if (in.getbeds() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "beds cannot be less than the " + used + " existing admissions");
        existing.setWardName(in.getWardName());
        existing.setNurse(in.getNurse());
        existing.setFloor(in.getFloor());
        existing.setBeds(in.getBeds());
        existing.setChargePerDay(in.getChargePerDay());
        return wards.save(existing);
    }

    // a ward that still has admissions is NOT deleted unless cascade=true (then its admissions are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = admissions.countByWardId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "ward has " + used + " admissions; delete them first or use cascade=true");
        admissions.deleteByWardId(id);
        wards.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Ward> search(String keyword) { return wards.findByWardNameContainingIgnoreCase(keyword); }

    public List<Ward> filterBychargePerDay(Double min) { return wards.findBychargePerDayGreaterThanEqual(min); }

    public List<Ward> sortedBychargePerDay() { return wards.findAll(Sort.by(Sort.Direction.DESC, "chargePerDay")); }

    // only the wards that still have a free place
    public List<Ward> available() {
        List<Ward> result = new ArrayList<>();
        for (Ward x : wards.findAll())
            if (admissions.countByWardId(x.getId()) < x.getbeds()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Admission> admissionsOf(String id) {
        getById(id);                              // 404 if the ward is missing
        return admissions.findByWardId(id);
    }

    // count + calculations across the two collections for ONE ward
    public Map<String, Object> summary(String id) {
        Ward x = getById(id);
        long count = admissions.countByWardId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("wardId", x.getId());
        m.put("name", x.getWardName());
        m.put("beds", x.getbeds());
        m.put("admissionCount", count);
        m.put("placesLeft", x.getbeds() - count);
        m.put("chargePerDay", x.getchargePerDay());
        m.put("totalAmount", count * x.getchargePerDay());
        return m;
    }

    // totals across ALL wards
    public Map<String, Object> stats() {
        long totalAdmission = 0;
        double totalAmount = 0;
        List<Ward> all = wards.findAll();
        for (Ward x : all) {
            long c = admissions.countByWardId(x.getId());
            totalAdmission += c;
            totalAmount += c * x.getchargePerDay();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalWards", all.size());
        m.put("totalAdmissions", totalAdmission);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
