package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: wards
@Document(collection = "wards")
public class Ward {

    @Id
    private String id;

    private String wardName;
    private String nurse;
    private String floor;
    private Integer beds;
    private Double chargePerDay;

    public Ward() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getWardName() { return wardName; }
    public void setWardName(String wardName) { this.wardName = wardName; }
    public String getNurse() { return nurse; }
    public void setNurse(String nurse) { this.nurse = nurse; }
    public String getFloor() { return floor; }
    public void setFloor(String floor) { this.floor = floor; }
    public Integer getBeds() { return beds; }
    public void setBeds(Integer beds) { this.beds = beds; }
    public Double getChargePerDay() { return chargePerDay; }
    public void setChargePerDay(Double chargePerDay) { this.chargePerDay = chargePerDay; }
}
