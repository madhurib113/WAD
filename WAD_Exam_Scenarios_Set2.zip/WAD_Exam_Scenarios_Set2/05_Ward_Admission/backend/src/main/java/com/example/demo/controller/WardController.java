package com.example.demo.controller;

import com.example.demo.model.Ward;
import com.example.demo.model.Admission;
import com.example.demo.service.WardService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/wards")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class WardController {

    private final WardService service;

    public WardController(WardService service) { this.service = service; }

    @PostMapping                                   // POST   /api/wards                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Ward create(@RequestBody Ward x) { return service.create(x); }

    @GetMapping                                    // GET    /api/wards
    public List<Ward> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/wards/{id}            -> 200 / 404
    public Ward getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/wards/{id}            -> 200 / 400 / 404 / 409
    public Ward update(@PathVariable String id, @RequestBody Ward x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/wards/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/wards/search?keyword=ab
    public List<Ward> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/wards/filter?minchargePerDay=500
    public List<Ward> filter(@RequestParam Double minchargePerDay) { return service.filterBychargePerDay(minchargePerDay); }

    @GetMapping("/sorted")                         // GET    /api/wards/sorted          (chargePerDay high -> low)
    public List<Ward> sorted() { return service.sortedBychargePerDay(); }

    @GetMapping("/available")                      // GET    /api/wards/available       (still have free places)
    public List<Ward> available() { return service.available(); }

    @GetMapping("/{id}/admissions")                    // GET    /api/wards/{id}/admissions     (related records)
    public List<Admission> related(@PathVariable String id) { return service.admissionsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/wards/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/wards/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
