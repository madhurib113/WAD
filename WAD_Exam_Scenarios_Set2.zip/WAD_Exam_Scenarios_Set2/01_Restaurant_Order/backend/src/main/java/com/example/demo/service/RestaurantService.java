package com.example.demo.service;

import com.example.demo.model.Restaurant;
import com.example.demo.model.Order;
import com.example.demo.repository.RestaurantRepository;
import com.example.demo.repository.OrderRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class RestaurantService {

    private final RestaurantRepository restaurants;
    private final OrderRepository orders;

    public RestaurantService(RestaurantRepository restaurants, OrderRepository orders) {
        this.restaurants = restaurants;
        this.orders = orders;
    }

    private void validate(Restaurant x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getCuisine() == null || x.getCuisine().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "cuisine is required");
        if (x.getmaxOrders() == null || x.getmaxOrders() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "maxOrders is required and must be > 0");
        if (x.getavgOrderValue() == null || x.getavgOrderValue() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "avgOrderValue is required and must be >= 0");
    }

    public Restaurant getById(String id) {
        return restaurants.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Restaurant not found with id " + id));
    }

    // ---------- CRUD ----------
    public Restaurant create(Restaurant x) {
        validate(x);
        x.setId(null);
        return restaurants.save(x);
    }

    public List<Restaurant> getAll() { return restaurants.findAll(); }

    public Restaurant update(String id, Restaurant in) {
        Restaurant existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of orders already added
        long used = orders.countByRestaurantId(id);
        if (in.getmaxOrders() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "maxOrders cannot be less than the " + used + " existing orders");
        existing.setName(in.getName());
        existing.setCuisine(in.getCuisine());
        existing.setCity(in.getCity());
        existing.setMaxOrders(in.getMaxOrders());
        existing.setAvgOrderValue(in.getAvgOrderValue());
        return restaurants.save(existing);
    }

    // a restaurant that still has orders is NOT deleted unless cascade=true (then its orders are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = orders.countByRestaurantId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "restaurant has " + used + " orders; delete them first or use cascade=true");
        orders.deleteByRestaurantId(id);
        restaurants.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Restaurant> search(String keyword) { return restaurants.findByNameContainingIgnoreCase(keyword); }

    public List<Restaurant> filterByavgOrderValue(Double min) { return restaurants.findByavgOrderValueGreaterThanEqual(min); }

    public List<Restaurant> sortedByavgOrderValue() { return restaurants.findAll(Sort.by(Sort.Direction.DESC, "avgOrderValue")); }

    // only the restaurants that still have a free place
    public List<Restaurant> available() {
        List<Restaurant> result = new ArrayList<>();
        for (Restaurant x : restaurants.findAll())
            if (orders.countByRestaurantId(x.getId()) < x.getmaxOrders()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Order> ordersOf(String id) {
        getById(id);                              // 404 if the restaurant is missing
        return orders.findByRestaurantId(id);
    }

    // count + calculations across the two collections for ONE restaurant
    public Map<String, Object> summary(String id) {
        Restaurant x = getById(id);
        long count = orders.countByRestaurantId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("restaurantId", x.getId());
        m.put("name", x.getName());
        m.put("maxOrders", x.getmaxOrders());
        m.put("orderCount", count);
        m.put("placesLeft", x.getmaxOrders() - count);
        m.put("avgOrderValue", x.getavgOrderValue());
        m.put("totalAmount", count * x.getavgOrderValue());
        return m;
    }

    // totals across ALL restaurants
    public Map<String, Object> stats() {
        long totalOrder = 0;
        double totalAmount = 0;
        List<Restaurant> all = restaurants.findAll();
        for (Restaurant x : all) {
            long c = orders.countByRestaurantId(x.getId());
            totalOrder += c;
            totalAmount += c * x.getavgOrderValue();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalRestaurants", all.size());
        m.put("totalOrders", totalOrder);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
