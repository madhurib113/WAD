package com.example.demo.controller;

import com.example.demo.model.Order;
import com.example.demo.service.OrderService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class OrderController {

    private final OrderService service;

    public OrderController(OrderService service) { this.service = service; }

    @PostMapping                                   // POST   /api/orders   -> 201 / 400 (bad restaurant) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Order create(@RequestBody Order x) { return service.create(x); }

    @GetMapping                                    // GET    /api/orders[?restaurantId=..]  (filter by related record)
    public List<Order> getAll(@RequestParam(required = false) String restaurantId) { return service.getAll(restaurantId); }

    @GetMapping("/{id}")                           // GET    /api/orders/{id}   -> 200 / 404
    public Order getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/orders/{id}
    public Order update(@PathVariable String id, @RequestBody Order x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/orders/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/orders/search?keyword=an
    public List<Order> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/orders/count[?restaurantId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String restaurantId) {
        return Map.of("count", service.count(restaurantId));
    }
}
