package com.example.demo.controller;

import com.example.demo.model.Restaurant;
import com.example.demo.model.Order;
import com.example.demo.service.RestaurantService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/restaurants")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class RestaurantController {

    private final RestaurantService service;

    public RestaurantController(RestaurantService service) { this.service = service; }

    @PostMapping                                   // POST   /api/restaurants                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Restaurant create(@RequestBody Restaurant x) { return service.create(x); }

    @GetMapping                                    // GET    /api/restaurants
    public List<Restaurant> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/restaurants/{id}            -> 200 / 404
    public Restaurant getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/restaurants/{id}            -> 200 / 400 / 404 / 409
    public Restaurant update(@PathVariable String id, @RequestBody Restaurant x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/restaurants/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/restaurants/search?keyword=ab
    public List<Restaurant> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/restaurants/filter?minavgOrderValue=500
    public List<Restaurant> filter(@RequestParam Double minavgOrderValue) { return service.filterByavgOrderValue(minavgOrderValue); }

    @GetMapping("/sorted")                         // GET    /api/restaurants/sorted          (avgOrderValue high -> low)
    public List<Restaurant> sorted() { return service.sortedByavgOrderValue(); }

    @GetMapping("/available")                      // GET    /api/restaurants/available       (still have free places)
    public List<Restaurant> available() { return service.available(); }

    @GetMapping("/{id}/orders")                    // GET    /api/restaurants/{id}/orders     (related records)
    public List<Order> related(@PathVariable String id) { return service.ordersOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/restaurants/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/restaurants/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
