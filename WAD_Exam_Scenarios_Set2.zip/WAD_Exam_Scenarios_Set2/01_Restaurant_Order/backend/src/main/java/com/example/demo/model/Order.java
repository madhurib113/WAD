package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: orders
// restaurantId stores the _id of a Restaurant as plain text. MongoDB has NO foreign keys,
// so OrderService checks that the restaurant exists before saving.
@Document(collection = "orders")
public class Order {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String restaurantId;    // required: reference to restaurants._id

    public Order() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getRestaurantId() { return restaurantId; }
    public void setRestaurantId(String restaurantId) { this.restaurantId = restaurantId; }
}
