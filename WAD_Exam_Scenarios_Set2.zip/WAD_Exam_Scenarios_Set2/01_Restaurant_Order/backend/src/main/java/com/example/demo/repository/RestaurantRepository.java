package com.example.demo.repository;

import com.example.demo.model.Restaurant;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RestaurantRepository extends MongoRepository<Restaurant, String> {
    List<Restaurant> findByNameContainingIgnoreCase(String keyword);        // search
    List<Restaurant> findByavgOrderValueGreaterThanEqual(Double min);                  // filter by number
}
