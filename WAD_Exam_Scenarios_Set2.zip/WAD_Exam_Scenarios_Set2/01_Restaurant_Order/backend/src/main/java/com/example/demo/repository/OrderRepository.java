package com.example.demo.repository;

import com.example.demo.model.Order;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface OrderRepository extends MongoRepository<Order, String> {
    List<Order> findByRestaurantId(String restaurantId);                    // filter by the related record
    long countByRestaurantId(String restaurantId);                          // count related records
    long deleteByRestaurantId(String restaurantId);                         // cascade delete
    List<Order> findByNameContainingIgnoreCase(String keyword); // search
}
