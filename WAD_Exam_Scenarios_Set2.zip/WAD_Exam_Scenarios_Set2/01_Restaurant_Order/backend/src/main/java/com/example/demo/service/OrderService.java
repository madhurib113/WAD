package com.example.demo.service;

import com.example.demo.model.Restaurant;
import com.example.demo.model.Order;
import com.example.demo.repository.RestaurantRepository;
import com.example.demo.repository.OrderRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class OrderService {

    private final OrderRepository orders;
    private final RestaurantRepository restaurants;

    public OrderService(OrderRepository orders, RestaurantRepository restaurants) {
        this.orders = orders;
        this.restaurants = restaurants;
    }

    private void validate(Order x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getRestaurantId() == null || x.getRestaurantId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "restaurantId is required");
    }

    // The referenced restaurant must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkRestaurant(String id, boolean checkLimit) {
        Restaurant p = restaurants.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "restaurantId does not exist: " + id));
        if (checkLimit && orders.countByRestaurantId(id) >= p.getmaxOrders())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "restaurant is full");
    }

    public Order getById(String id) {
        return orders.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found with id " + id));
    }

    public Order create(Order x) {
        validate(x);
        checkRestaurant(x.getRestaurantId(), true);
        x.setId(null);
        return orders.save(x);
    }

    // optional filter by related record: ?restaurantId=...
    public List<Order> getAll(String restaurantId) {
        if (restaurantId == null || restaurantId.isBlank()) return orders.findAll();
        return orders.findByRestaurantId(restaurantId);
    }

    public List<Order> search(String keyword) { return orders.findByNameContainingIgnoreCase(keyword); }

    public Order update(String id, Order in) {
        Order existing = getById(id);
        validate(in);
        boolean moving = !in.getRestaurantId().equals(existing.getRestaurantId());
        checkRestaurant(in.getRestaurantId(), moving);       // free-place check only when moving to another restaurant
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setRestaurantId(in.getRestaurantId());
        return orders.save(existing);
    }

    public void delete(String id) {
        getById(id);
        orders.deleteById(id);
    }

    public long count(String restaurantId) {
        if (restaurantId == null || restaurantId.isBlank()) return orders.count();
        return orders.countByRestaurantId(restaurantId);
    }
}
