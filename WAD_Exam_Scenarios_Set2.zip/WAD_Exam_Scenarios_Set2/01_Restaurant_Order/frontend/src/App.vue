<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import RestaurantForm from './components/RestaurantForm.vue'
import RestaurantList from './components/RestaurantList.vue'
import OrderForm from './components/OrderForm.vue'
import OrderList from './components/OrderList.vue'
import ResultBox from './components/ResultBox.vue'

const RESTAURANTS = 'http://localhost:8080/api/restaurants'
const ORDERS = 'http://localhost:8080/api/orders'

const restaurants = ref([])
const orders = ref([])
const restaurantForm = ref({ name: '', cuisine: '', city: '', maxOrders: '', avgOrderValue: '' })
const editingRestaurantId = ref('')
const orderForm = ref({ name: '', phone: '', restaurantId: '' })
const editingOrderId = ref('')
const filterRestaurantId = ref('')
const keyword = ref('')
const minavgOrderValue = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Restaurant ----------
async function loadRestaurants() {
  try { restaurants.value = (await axios.get(RESTAURANTS)).data } catch (e) { showError(e) }
}

async function saveRestaurant() {
  error.value = ''
  const body = { ...restaurantForm.value, maxOrders: num(restaurantForm.value.maxOrders), avgOrderValue: num(restaurantForm.value.avgOrderValue) }
  try {
    if (editingRestaurantId.value === '') await axios.post(RESTAURANTS, body)
    else await axios.put(RESTAURANTS + '/' + editingRestaurantId.value, body)
    cancelRestaurant()
    loadRestaurants()
  } catch (e) { showError(e) }
}

function editRestaurant(x) {
  restaurantForm.value = { ...x }
  editingRestaurantId.value = x.id
}

function cancelRestaurant() {
  restaurantForm.value = { name: '', cuisine: '', city: '', maxOrders: '', avgOrderValue: '' }
  editingRestaurantId.value = ''
}

// cascade = true also deletes the orders; false -> error 409 if there are orders
async function deleteRestaurant(id, cascade) {
  error.value = ''
  try {
    await axios.delete(RESTAURANTS + '/' + id, { params: { cascade } })
    loadRestaurants()
    loadOrders()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Order ----------
async function loadOrders() {
  try { orders.value = (await axios.get(ORDERS, { params: { restaurantId: filterRestaurantId.value } })).data } catch (e) { showError(e) }
}

async function saveOrder() {
  error.value = ''
  try {
    if (editingOrderId.value === '') await axios.post(ORDERS, orderForm.value)
    else await axios.put(ORDERS + '/' + editingOrderId.value, orderForm.value)
    cancelOrder()
    loadOrders()
  } catch (e) { showError(e) }
}

function editOrder(x) {
  orderForm.value = { name: x.name, phone: x.phone, restaurantId: x.restaurantId }
  editingOrderId.value = x.id
}

function cancelOrder() {
  orderForm.value = { name: '', phone: '', restaurantId: '' }
  editingOrderId.value = ''
}

async function deleteOrder(id) {
  error.value = ''
  try {
    await axios.delete(ORDERS + '/' + id)
    loadOrders()
  } catch (e) { showError(e) }
}

onMounted(() => { loadRestaurants(); loadOrders() })
</script>

<template>
  <h1>Restaurant - Order Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Restaurants</h2>
  <RestaurantForm :form="restaurantForm" :editing="editingRestaurantId !== ''" @save="saveRestaurant" @cancel="cancelRestaurant" />
  <div class="box">
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(RESTAURANTS + '/search', { keyword })">Search</button>
    <input v-model="minavgOrderValue" type="number" placeholder="min avgOrderValue" />
    <button @click="showGet(RESTAURANTS + '/filter', { minavgOrderValue })">Filter</button>
    <button @click="showGet(RESTAURANTS + '/sorted')">Sort by avgOrderValue</button>
    <button @click="showGet(RESTAURANTS + '/available')">Available</button>
    <button @click="showGet(RESTAURANTS + '/stats')">Stats</button>
  </div>
  <RestaurantList :items="restaurants" @edit="editRestaurant" @remove="deleteRestaurant"
    @related="(id) => showGet(RESTAURANTS + '/' + id + '/orders')" @summary="(id) => showGet(RESTAURANTS + '/' + id + '/summary')" />

  <h2>Orders</h2>
  <OrderForm :form="orderForm" :editing="editingOrderId !== ''" :parents="restaurants" @save="saveOrder" @cancel="cancelOrder" />
  <div class="box">
    <select v-model="filterRestaurantId" @change="loadOrders">
      <option value="">All restaurants</option>
      <option v-for="p in restaurants" :key="p.id" :value="p.id">{{ p.name }}</option>
    </select>
    <button @click="showGet(ORDERS + '/count', { restaurantId: filterRestaurantId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(ORDERS + '/search', { keyword })">Search</button>
  </div>
  <OrderList :items="orders" :parents="restaurants" @edit="editOrder" @remove="deleteOrder" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
