<script setup>
// Table of Restaurant records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'cuisine', label: 'Cuisine', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'maxOrders', label: 'Max Orders', type: 'number' },
  { key: 'avgOrderValue', label: 'Avg Order Value', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Orders</button>
          <button @click="$emit('related', x.id)">Orders</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
