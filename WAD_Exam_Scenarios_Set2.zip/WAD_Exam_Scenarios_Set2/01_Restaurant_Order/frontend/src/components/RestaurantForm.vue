<script setup>
// Form for the "ONE" side (Restaurant). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'name', label: 'Name', type: 'text' },
  { key: 'cuisine', label: 'Cuisine', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'maxOrders', label: 'Max Orders', type: 'number' },
  { key: 'avgOrderValue', label: 'Avg Order Value', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Restaurant</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
