# Restaurant - Order (2 collections: `restaurants` and `orders`)

Database `restaurant_db`. `orders.restaurantId` stores the `_id` of a restaurant (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db restaurant_db --collection restaurants --jsonArray --file sample_data/restaurants.json
mongoimport --db restaurant_db --collection orders --jsonArray --file sample_data/orders.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Restaurant**: name*, cuisine*, city, maxOrders* (> 0), avgOrderValue* (>= 0)    (* = required)
- **Order**: name*, phone*, restaurantId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/restaurants | create (Restaurant) 201 / 400 |
| GET | /api/restaurants , /api/restaurants/{id} | all / one (404) |
| PUT | /api/restaurants/{id} | update 200 / 400 / 404 / 409 (`maxOrders` below existing orders) |
| DELETE | /api/restaurants/{id}?cascade=true | 204 / 404 / 409 (has orders and no cascade) |
| GET | /api/restaurants/search?keyword= | search by name |
| GET | /api/restaurants/filter?minavgOrderValue= | avgOrderValue >= value |
| GET | /api/restaurants/sorted | sort by avgOrderValue desc |
| GET | /api/restaurants/available | restaurants that still have free places |
| GET | /api/restaurants/{id}/orders | related orders |
| GET | /api/restaurants/{id}/summary | count, placesLeft, totalAmount = count x avgOrderValue |
| GET | /api/restaurants/stats | totals over all restaurants |
| POST | /api/orders | create (Order) 201 / 400 (bad restaurantId) / 409 (full) |
| GET | /api/orders?restaurantId= | all / filter by restaurant |
| GET | /api/orders/{id} | one (404) |
| PUT | /api/orders/{id} | update (move to another restaurant: free place checked) |
| DELETE | /api/orders/{id} | 204 / 404 |
| GET | /api/orders/search?keyword= | search by name |
| GET | /api/orders/count?restaurantId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on restaurants and on orders.
3. Validation: missing field -> 400, maxOrders <= 0 -> 400, avgOrderValue < 0 -> 400, unknown id -> 404.
4. Add a order only if the restaurant exists (400) and is not full (409).
5. Update restaurant: maxOrders cannot be lower than current number of orders (409).
6. Delete restaurant: blocked if it has orders (409); `cascade=true` deletes its orders too.
7. List orders of one restaurant; count orders of one restaurant.
8. Search by text, filter by number, sort descending, list available restaurants.
9. Calculation: totalAmount for one restaurant, and totals over all restaurants (stats).
10. Move a order from one restaurant to another.
