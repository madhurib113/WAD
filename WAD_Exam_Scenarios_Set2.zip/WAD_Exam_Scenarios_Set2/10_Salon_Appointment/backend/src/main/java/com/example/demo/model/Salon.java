package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: salons
@Document(collection = "salons")
public class Salon {

    @Id
    private String id;

    private String salonName;
    private String owner;
    private String city;
    private Integer maxAppointments;
    private Double serviceCharge;

    public Salon() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getSalonName() { return salonName; }
    public void setSalonName(String salonName) { this.salonName = salonName; }
    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public Integer getMaxAppointments() { return maxAppointments; }
    public void setMaxAppointments(Integer maxAppointments) { this.maxAppointments = maxAppointments; }
    public Double getServiceCharge() { return serviceCharge; }
    public void setServiceCharge(Double serviceCharge) { this.serviceCharge = serviceCharge; }
}
