package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: appointments
// salonId stores the _id of a Salon as plain text. MongoDB has NO foreign keys,
// so AppointmentService checks that the salon exists before saving.
@Document(collection = "appointments")
public class Appointment {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String salonId;    // required: reference to salons._id

    public Appointment() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getSalonId() { return salonId; }
    public void setSalonId(String salonId) { this.salonId = salonId; }
}
