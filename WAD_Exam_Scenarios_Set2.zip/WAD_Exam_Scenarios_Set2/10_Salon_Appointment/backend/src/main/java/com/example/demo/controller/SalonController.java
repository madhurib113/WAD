package com.example.demo.controller;

import com.example.demo.model.Salon;
import com.example.demo.model.Appointment;
import com.example.demo.service.SalonService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/salons")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class SalonController {

    private final SalonService service;

    public SalonController(SalonService service) { this.service = service; }

    @PostMapping                                   // POST   /api/salons                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Salon create(@RequestBody Salon x) { return service.create(x); }

    @GetMapping                                    // GET    /api/salons
    public List<Salon> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/salons/{id}            -> 200 / 404
    public Salon getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/salons/{id}            -> 200 / 400 / 404 / 409
    public Salon update(@PathVariable String id, @RequestBody Salon x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/salons/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/salons/search?keyword=ab
    public List<Salon> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/salons/filter?minserviceCharge=500
    public List<Salon> filter(@RequestParam Double minserviceCharge) { return service.filterByserviceCharge(minserviceCharge); }

    @GetMapping("/sorted")                         // GET    /api/salons/sorted          (serviceCharge high -> low)
    public List<Salon> sorted() { return service.sortedByserviceCharge(); }

    @GetMapping("/available")                      // GET    /api/salons/available       (still have free places)
    public List<Salon> available() { return service.available(); }

    @GetMapping("/{id}/appointments")                    // GET    /api/salons/{id}/appointments     (related records)
    public List<Appointment> related(@PathVariable String id) { return service.appointmentsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/salons/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/salons/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
