package com.example.demo.service;

import com.example.demo.model.Salon;
import com.example.demo.model.Appointment;
import com.example.demo.repository.SalonRepository;
import com.example.demo.repository.AppointmentRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class SalonService {

    private final SalonRepository salons;
    private final AppointmentRepository appointments;

    public SalonService(SalonRepository salons, AppointmentRepository appointments) {
        this.salons = salons;
        this.appointments = appointments;
    }

    private void validate(Salon x) {
        if (x.getSalonName() == null || x.getSalonName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "salonName is required");
        if (x.getOwner() == null || x.getOwner().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "owner is required");
        if (x.getmaxAppointments() == null || x.getmaxAppointments() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "maxAppointments is required and must be > 0");
        if (x.getserviceCharge() == null || x.getserviceCharge() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "serviceCharge is required and must be >= 0");
    }

    public Salon getById(String id) {
        return salons.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Salon not found with id " + id));
    }

    // ---------- CRUD ----------
    public Salon create(Salon x) {
        validate(x);
        x.setId(null);
        return salons.save(x);
    }

    public List<Salon> getAll() { return salons.findAll(); }

    public Salon update(String id, Salon in) {
        Salon existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of appointments already added
        long used = appointments.countBySalonId(id);
        if (in.getmaxAppointments() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "maxAppointments cannot be less than the " + used + " existing appointments");
        existing.setSalonName(in.getSalonName());
        existing.setOwner(in.getOwner());
        existing.setCity(in.getCity());
        existing.setMaxAppointments(in.getMaxAppointments());
        existing.setServiceCharge(in.getServiceCharge());
        return salons.save(existing);
    }

    // a salon that still has appointments is NOT deleted unless cascade=true (then its appointments are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = appointments.countBySalonId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "salon has " + used + " appointments; delete them first or use cascade=true");
        appointments.deleteBySalonId(id);
        salons.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Salon> search(String keyword) { return salons.findBySalonNameContainingIgnoreCase(keyword); }

    public List<Salon> filterByserviceCharge(Double min) { return salons.findByserviceChargeGreaterThanEqual(min); }

    public List<Salon> sortedByserviceCharge() { return salons.findAll(Sort.by(Sort.Direction.DESC, "serviceCharge")); }

    // only the salons that still have a free place
    public List<Salon> available() {
        List<Salon> result = new ArrayList<>();
        for (Salon x : salons.findAll())
            if (appointments.countBySalonId(x.getId()) < x.getmaxAppointments()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Appointment> appointmentsOf(String id) {
        getById(id);                              // 404 if the salon is missing
        return appointments.findBySalonId(id);
    }

    // count + calculations across the two collections for ONE salon
    public Map<String, Object> summary(String id) {
        Salon x = getById(id);
        long count = appointments.countBySalonId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("salonId", x.getId());
        m.put("name", x.getSalonName());
        m.put("maxAppointments", x.getmaxAppointments());
        m.put("appointmentCount", count);
        m.put("placesLeft", x.getmaxAppointments() - count);
        m.put("serviceCharge", x.getserviceCharge());
        m.put("totalAmount", count * x.getserviceCharge());
        return m;
    }

    // totals across ALL salons
    public Map<String, Object> stats() {
        long totalAppointment = 0;
        double totalAmount = 0;
        List<Salon> all = salons.findAll();
        for (Salon x : all) {
            long c = appointments.countBySalonId(x.getId());
            totalAppointment += c;
            totalAmount += c * x.getserviceCharge();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalSalons", all.size());
        m.put("totalAppointments", totalAppointment);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
