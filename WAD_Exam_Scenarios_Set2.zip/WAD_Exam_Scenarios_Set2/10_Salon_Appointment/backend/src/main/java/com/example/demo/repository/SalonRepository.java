package com.example.demo.repository;

import com.example.demo.model.Salon;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SalonRepository extends MongoRepository<Salon, String> {
    List<Salon> findBySalonNameContainingIgnoreCase(String keyword);        // search
    List<Salon> findByserviceChargeGreaterThanEqual(Double min);                  // filter by number
}
