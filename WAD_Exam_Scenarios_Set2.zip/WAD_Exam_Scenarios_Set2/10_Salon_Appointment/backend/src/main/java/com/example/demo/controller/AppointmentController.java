package com.example.demo.controller;

import com.example.demo.model.Appointment;
import com.example.demo.service.AppointmentService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class AppointmentController {

    private final AppointmentService service;

    public AppointmentController(AppointmentService service) { this.service = service; }

    @PostMapping                                   // POST   /api/appointments   -> 201 / 400 (bad salon) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Appointment create(@RequestBody Appointment x) { return service.create(x); }

    @GetMapping                                    // GET    /api/appointments[?salonId=..]  (filter by related record)
    public List<Appointment> getAll(@RequestParam(required = false) String salonId) { return service.getAll(salonId); }

    @GetMapping("/{id}")                           // GET    /api/appointments/{id}   -> 200 / 404
    public Appointment getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/appointments/{id}
    public Appointment update(@PathVariable String id, @RequestBody Appointment x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/appointments/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/appointments/search?keyword=an
    public List<Appointment> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/appointments/count[?salonId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String salonId) {
        return Map.of("count", service.count(salonId));
    }
}
