package com.example.demo.service;

import com.example.demo.model.Salon;
import com.example.demo.model.Appointment;
import com.example.demo.repository.SalonRepository;
import com.example.demo.repository.AppointmentRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AppointmentService {

    private final AppointmentRepository appointments;
    private final SalonRepository salons;

    public AppointmentService(AppointmentRepository appointments, SalonRepository salons) {
        this.appointments = appointments;
        this.salons = salons;
    }

    private void validate(Appointment x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getSalonId() == null || x.getSalonId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "salonId is required");
    }

    // The referenced salon must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkSalon(String id, boolean checkLimit) {
        Salon p = salons.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "salonId does not exist: " + id));
        if (checkLimit && appointments.countBySalonId(id) >= p.getmaxAppointments())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "salon is full");
    }

    public Appointment getById(String id) {
        return appointments.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Appointment not found with id " + id));
    }

    public Appointment create(Appointment x) {
        validate(x);
        checkSalon(x.getSalonId(), true);
        x.setId(null);
        return appointments.save(x);
    }

    // optional filter by related record: ?salonId=...
    public List<Appointment> getAll(String salonId) {
        if (salonId == null || salonId.isBlank()) return appointments.findAll();
        return appointments.findBySalonId(salonId);
    }

    public List<Appointment> search(String keyword) { return appointments.findByNameContainingIgnoreCase(keyword); }

    public Appointment update(String id, Appointment in) {
        Appointment existing = getById(id);
        validate(in);
        boolean moving = !in.getSalonId().equals(existing.getSalonId());
        checkSalon(in.getSalonId(), moving);       // free-place check only when moving to another salon
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setSalonId(in.getSalonId());
        return appointments.save(existing);
    }

    public void delete(String id) {
        getById(id);
        appointments.deleteById(id);
    }

    public long count(String salonId) {
        if (salonId == null || salonId.isBlank()) return appointments.count();
        return appointments.countBySalonId(salonId);
    }
}
