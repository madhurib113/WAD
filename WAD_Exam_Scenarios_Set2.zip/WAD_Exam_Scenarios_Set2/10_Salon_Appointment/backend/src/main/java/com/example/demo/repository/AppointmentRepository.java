package com.example.demo.repository;

import com.example.demo.model.Appointment;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AppointmentRepository extends MongoRepository<Appointment, String> {
    List<Appointment> findBySalonId(String salonId);                    // filter by the related record
    long countBySalonId(String salonId);                          // count related records
    long deleteBySalonId(String salonId);                         // cascade delete
    List<Appointment> findByNameContainingIgnoreCase(String keyword); // search
}
