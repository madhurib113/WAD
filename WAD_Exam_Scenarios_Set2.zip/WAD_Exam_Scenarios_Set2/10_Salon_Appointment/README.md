# Salon - Appointment (2 collections: `salons` and `appointments`)

Database `salon_db`. `appointments.salonId` stores the `_id` of a salon (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db salon_db --collection salons --jsonArray --file sample_data/salons.json
mongoimport --db salon_db --collection appointments --jsonArray --file sample_data/appointments.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Salon**: salonName*, owner*, city, maxAppointments* (> 0), serviceCharge* (>= 0)    (* = required)
- **Appointment**: name*, phone*, salonId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/salons | create (Salon) 201 / 400 |
| GET | /api/salons , /api/salons/{id} | all / one (404) |
| PUT | /api/salons/{id} | update 200 / 400 / 404 / 409 (`maxAppointments` below existing appointments) |
| DELETE | /api/salons/{id}?cascade=true | 204 / 404 / 409 (has appointments and no cascade) |
| GET | /api/salons/search?keyword= | search by salonName |
| GET | /api/salons/filter?minserviceCharge= | serviceCharge >= value |
| GET | /api/salons/sorted | sort by serviceCharge desc |
| GET | /api/salons/available | salons that still have free places |
| GET | /api/salons/{id}/appointments | related appointments |
| GET | /api/salons/{id}/summary | count, placesLeft, totalAmount = count x serviceCharge |
| GET | /api/salons/stats | totals over all salons |
| POST | /api/appointments | create (Appointment) 201 / 400 (bad salonId) / 409 (full) |
| GET | /api/appointments?salonId= | all / filter by salon |
| GET | /api/appointments/{id} | one (404) |
| PUT | /api/appointments/{id} | update (move to another salon: free place checked) |
| DELETE | /api/appointments/{id} | 204 / 404 |
| GET | /api/appointments/search?keyword= | search by name |
| GET | /api/appointments/count?salonId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on salons and on appointments.
3. Validation: missing field -> 400, maxAppointments <= 0 -> 400, serviceCharge < 0 -> 400, unknown id -> 404.
4. Add a appointment only if the salon exists (400) and is not full (409).
5. Update salon: maxAppointments cannot be lower than current number of appointments (409).
6. Delete salon: blocked if it has appointments (409); `cascade=true` deletes its appointments too.
7. List appointments of one salon; count appointments of one salon.
8. Search by text, filter by number, sort descending, list available salons.
9. Calculation: totalAmount for one salon, and totals over all salons (stats).
10. Move a appointment from one salon to another.
