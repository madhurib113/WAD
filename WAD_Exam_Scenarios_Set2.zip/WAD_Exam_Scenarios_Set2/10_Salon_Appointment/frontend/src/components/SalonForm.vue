<script setup>
// Form for the "ONE" side (Salon). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'salonName', label: 'Salon Name', type: 'text' },
  { key: 'owner', label: 'Owner', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'maxAppointments', label: 'Max Appointments', type: 'number' },
  { key: 'serviceCharge', label: 'Service Charge', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Salon</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
