<script setup>
// Form for the "MANY" side (Appointment). The salon is chosen from a dropdown.
defineProps({ form: Object, editing: Boolean, parents: Array })
defineEmits(['save', 'cancel'])
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Appointment</h3>
    <input v-model="form.name" placeholder="Name" />
    <input v-model="form.phone" placeholder="Phone" />
    <select v-model="form.salonId">
      <option value="">-- select salon --</option>
      <option v-for="p in parents" :key="p.id" :value="p.id">{{ p.salonName }}</option>
    </select>
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
