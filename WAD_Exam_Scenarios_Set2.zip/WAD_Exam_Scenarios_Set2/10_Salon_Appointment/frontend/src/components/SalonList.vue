<script setup>
// Table of Salon records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'salonName', label: 'Salon Name', type: 'text' },
  { key: 'owner', label: 'Owner', type: 'text' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'maxAppointments', label: 'Max Appointments', type: 'number' },
  { key: 'serviceCharge', label: 'Service Charge', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Appointments</button>
          <button @click="$emit('related', x.id)">Appointments</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
