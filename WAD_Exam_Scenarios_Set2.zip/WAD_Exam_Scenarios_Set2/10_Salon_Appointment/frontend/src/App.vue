<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import SalonForm from './components/SalonForm.vue'
import SalonList from './components/SalonList.vue'
import AppointmentForm from './components/AppointmentForm.vue'
import AppointmentList from './components/AppointmentList.vue'
import ResultBox from './components/ResultBox.vue'

const SALONS = 'http://localhost:8080/api/salons'
const APPOINTMENTS = 'http://localhost:8080/api/appointments'

const salons = ref([])
const appointments = ref([])
const salonForm = ref({ salonName: '', owner: '', city: '', maxAppointments: '', serviceCharge: '' })
const editingSalonId = ref('')
const appointmentForm = ref({ name: '', phone: '', salonId: '' })
const editingAppointmentId = ref('')
const filterSalonId = ref('')
const keyword = ref('')
const minserviceCharge = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Salon ----------
async function loadSalons() {
  try { salons.value = (await axios.get(SALONS)).data } catch (e) { showError(e) }
}

async function saveSalon() {
  error.value = ''
  const body = { ...salonForm.value, maxAppointments: num(salonForm.value.maxAppointments), serviceCharge: num(salonForm.value.serviceCharge) }
  try {
    if (editingSalonId.value === '') await axios.post(SALONS, body)
    else await axios.put(SALONS + '/' + editingSalonId.value, body)
    cancelSalon()
    loadSalons()
  } catch (e) { showError(e) }
}

function editSalon(x) {
  salonForm.value = { ...x }
  editingSalonId.value = x.id
}

function cancelSalon() {
  salonForm.value = { salonName: '', owner: '', city: '', maxAppointments: '', serviceCharge: '' }
  editingSalonId.value = ''
}

// cascade = true also deletes the appointments; false -> error 409 if there are appointments
async function deleteSalon(id, cascade) {
  error.value = ''
  try {
    await axios.delete(SALONS + '/' + id, { params: { cascade } })
    loadSalons()
    loadAppointments()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Appointment ----------
async function loadAppointments() {
  try { appointments.value = (await axios.get(APPOINTMENTS, { params: { salonId: filterSalonId.value } })).data } catch (e) { showError(e) }
}

async function saveAppointment() {
  error.value = ''
  try {
    if (editingAppointmentId.value === '') await axios.post(APPOINTMENTS, appointmentForm.value)
    else await axios.put(APPOINTMENTS + '/' + editingAppointmentId.value, appointmentForm.value)
    cancelAppointment()
    loadAppointments()
  } catch (e) { showError(e) }
}

function editAppointment(x) {
  appointmentForm.value = { name: x.name, phone: x.phone, salonId: x.salonId }
  editingAppointmentId.value = x.id
}

function cancelAppointment() {
  appointmentForm.value = { name: '', phone: '', salonId: '' }
  editingAppointmentId.value = ''
}

async function deleteAppointment(id) {
  error.value = ''
  try {
    await axios.delete(APPOINTMENTS + '/' + id)
    loadAppointments()
  } catch (e) { showError(e) }
}

onMounted(() => { loadSalons(); loadAppointments() })
</script>

<template>
  <h1>Salon - Appointment Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Salons</h2>
  <SalonForm :form="salonForm" :editing="editingSalonId !== ''" @save="saveSalon" @cancel="cancelSalon" />
  <div class="box">
    <input v-model="keyword" placeholder="search salonName" />
    <button @click="showGet(SALONS + '/search', { keyword })">Search</button>
    <input v-model="minserviceCharge" type="number" placeholder="min serviceCharge" />
    <button @click="showGet(SALONS + '/filter', { minserviceCharge })">Filter</button>
    <button @click="showGet(SALONS + '/sorted')">Sort by serviceCharge</button>
    <button @click="showGet(SALONS + '/available')">Available</button>
    <button @click="showGet(SALONS + '/stats')">Stats</button>
  </div>
  <SalonList :items="salons" @edit="editSalon" @remove="deleteSalon"
    @related="(id) => showGet(SALONS + '/' + id + '/appointments')" @summary="(id) => showGet(SALONS + '/' + id + '/summary')" />

  <h2>Appointments</h2>
  <AppointmentForm :form="appointmentForm" :editing="editingAppointmentId !== ''" :parents="salons" @save="saveAppointment" @cancel="cancelAppointment" />
  <div class="box">
    <select v-model="filterSalonId" @change="loadAppointments">
      <option value="">All salons</option>
      <option v-for="p in salons" :key="p.id" :value="p.id">{{ p.salonName }}</option>
    </select>
    <button @click="showGet(APPOINTMENTS + '/count', { salonId: filterSalonId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(APPOINTMENTS + '/search', { keyword })">Search</button>
  </div>
  <AppointmentList :items="appointments" :parents="salons" @edit="editAppointment" @remove="deleteAppointment" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
