# ParkingLot - Vehicle (2 collections: `parkingLots` and `vehicles`)

Database `parkingLot_db`. `vehicles.parkingLotId` stores the `_id` of a parkingLot (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db parkingLot_db --collection parkingLots --jsonArray --file sample_data/parkingLots.json
mongoimport --db parkingLot_db --collection vehicles --jsonArray --file sample_data/vehicles.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **ParkingLot**: lotName*, location*, owner, slots* (> 0), feePerHour* (>= 0)    (* = required)
- **Vehicle**: number*, owner*, parkingLotId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/parkingLots | create (ParkingLot) 201 / 400 |
| GET | /api/parkingLots , /api/parkingLots/{id} | all / one (404) |
| PUT | /api/parkingLots/{id} | update 200 / 400 / 404 / 409 (`slots` below existing vehicles) |
| DELETE | /api/parkingLots/{id}?cascade=true | 204 / 404 / 409 (has vehicles and no cascade) |
| GET | /api/parkingLots/search?keyword= | search by lotName |
| GET | /api/parkingLots/filter?minfeePerHour= | feePerHour >= value |
| GET | /api/parkingLots/sorted | sort by feePerHour desc |
| GET | /api/parkingLots/available | parkingLots that still have free places |
| GET | /api/parkingLots/{id}/vehicles | related vehicles |
| GET | /api/parkingLots/{id}/summary | count, placesLeft, totalAmount = count x feePerHour |
| GET | /api/parkingLots/stats | totals over all parkingLots |
| POST | /api/vehicles | create (Vehicle) 201 / 400 (bad parkingLotId) / 409 (full) |
| GET | /api/vehicles?parkingLotId= | all / filter by parkingLot |
| GET | /api/vehicles/{id} | one (404) |
| PUT | /api/vehicles/{id} | update (move to another parkingLot: free place checked) |
| DELETE | /api/vehicles/{id} | 204 / 404 |
| GET | /api/vehicles/search?keyword= | search by number |
| GET | /api/vehicles/count?parkingLotId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on parkingLots and on vehicles.
3. Validation: missing field -> 400, slots <= 0 -> 400, feePerHour < 0 -> 400, unknown id -> 404.
4. Add a vehicle only if the parkingLot exists (400) and is not full (409).
5. Update parkingLot: slots cannot be lower than current number of vehicles (409).
6. Delete parkingLot: blocked if it has vehicles (409); `cascade=true` deletes its vehicles too.
7. List vehicles of one parkingLot; count vehicles of one parkingLot.
8. Search by text, filter by number, sort descending, list available parkingLots.
9. Calculation: totalAmount for one parkingLot, and totals over all parkingLots (stats).
10. Move a vehicle from one parkingLot to another.
