package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: parkingLots
@Document(collection = "parkingLots")
public class ParkingLot {

    @Id
    private String id;

    private String lotName;
    private String location;
    private String owner;
    private Integer slots;
    private Double feePerHour;

    public ParkingLot() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getLotName() { return lotName; }
    public void setLotName(String lotName) { this.lotName = lotName; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }
    public Integer getSlots() { return slots; }
    public void setSlots(Integer slots) { this.slots = slots; }
    public Double getFeePerHour() { return feePerHour; }
    public void setFeePerHour(Double feePerHour) { this.feePerHour = feePerHour; }
}
