package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: vehicles
// parkingLotId stores the _id of a ParkingLot as plain text. MongoDB has NO foreign keys,
// so VehicleService checks that the parkingLot exists before saving.
@Document(collection = "vehicles")
public class Vehicle {

    @Id
    private String id;

    private String number;     // required
    private String owner;     // required
    private String parkingLotId;    // required: reference to parkingLots._id

    public Vehicle() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }
    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }
    public String getParkingLotId() { return parkingLotId; }
    public void setParkingLotId(String parkingLotId) { this.parkingLotId = parkingLotId; }
}
