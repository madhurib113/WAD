package com.example.demo.repository;

import com.example.demo.model.Vehicle;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface VehicleRepository extends MongoRepository<Vehicle, String> {
    List<Vehicle> findByParkingLotId(String parkingLotId);                    // filter by the related record
    long countByParkingLotId(String parkingLotId);                          // count related records
    long deleteByParkingLotId(String parkingLotId);                         // cascade delete
    List<Vehicle> findByNumberContainingIgnoreCase(String keyword); // search
}
