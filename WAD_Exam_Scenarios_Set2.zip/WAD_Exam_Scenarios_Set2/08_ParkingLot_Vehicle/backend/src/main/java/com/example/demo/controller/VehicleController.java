package com.example.demo.controller;

import com.example.demo.model.Vehicle;
import com.example.demo.service.VehicleService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/vehicles")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class VehicleController {

    private final VehicleService service;

    public VehicleController(VehicleService service) { this.service = service; }

    @PostMapping                                   // POST   /api/vehicles   -> 201 / 400 (bad parkingLot) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Vehicle create(@RequestBody Vehicle x) { return service.create(x); }

    @GetMapping                                    // GET    /api/vehicles[?parkingLotId=..]  (filter by related record)
    public List<Vehicle> getAll(@RequestParam(required = false) String parkingLotId) { return service.getAll(parkingLotId); }

    @GetMapping("/{id}")                           // GET    /api/vehicles/{id}   -> 200 / 404
    public Vehicle getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/vehicles/{id}
    public Vehicle update(@PathVariable String id, @RequestBody Vehicle x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/vehicles/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/vehicles/search?keyword=an
    public List<Vehicle> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/vehicles/count[?parkingLotId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String parkingLotId) {
        return Map.of("count", service.count(parkingLotId));
    }
}
