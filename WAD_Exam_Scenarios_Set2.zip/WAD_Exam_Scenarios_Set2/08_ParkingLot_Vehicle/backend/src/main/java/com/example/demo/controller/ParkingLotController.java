package com.example.demo.controller;

import com.example.demo.model.ParkingLot;
import com.example.demo.model.Vehicle;
import com.example.demo.service.ParkingLotService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/parkingLots")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class ParkingLotController {

    private final ParkingLotService service;

    public ParkingLotController(ParkingLotService service) { this.service = service; }

    @PostMapping                                   // POST   /api/parkingLots                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public ParkingLot create(@RequestBody ParkingLot x) { return service.create(x); }

    @GetMapping                                    // GET    /api/parkingLots
    public List<ParkingLot> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/parkingLots/{id}            -> 200 / 404
    public ParkingLot getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/parkingLots/{id}            -> 200 / 400 / 404 / 409
    public ParkingLot update(@PathVariable String id, @RequestBody ParkingLot x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/parkingLots/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/parkingLots/search?keyword=ab
    public List<ParkingLot> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/parkingLots/filter?minfeePerHour=500
    public List<ParkingLot> filter(@RequestParam Double minfeePerHour) { return service.filterByfeePerHour(minfeePerHour); }

    @GetMapping("/sorted")                         // GET    /api/parkingLots/sorted          (feePerHour high -> low)
    public List<ParkingLot> sorted() { return service.sortedByfeePerHour(); }

    @GetMapping("/available")                      // GET    /api/parkingLots/available       (still have free places)
    public List<ParkingLot> available() { return service.available(); }

    @GetMapping("/{id}/vehicles")                    // GET    /api/parkingLots/{id}/vehicles     (related records)
    public List<Vehicle> related(@PathVariable String id) { return service.vehiclesOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/parkingLots/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/parkingLots/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
