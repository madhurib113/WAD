package com.example.demo.service;

import com.example.demo.model.ParkingLot;
import com.example.demo.model.Vehicle;
import com.example.demo.repository.ParkingLotRepository;
import com.example.demo.repository.VehicleRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ParkingLotService {

    private final ParkingLotRepository parkingLots;
    private final VehicleRepository vehicles;

    public ParkingLotService(ParkingLotRepository parkingLots, VehicleRepository vehicles) {
        this.parkingLots = parkingLots;
        this.vehicles = vehicles;
    }

    private void validate(ParkingLot x) {
        if (x.getLotName() == null || x.getLotName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "lotName is required");
        if (x.getLocation() == null || x.getLocation().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "location is required");
        if (x.getslots() == null || x.getslots() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "slots is required and must be > 0");
        if (x.getfeePerHour() == null || x.getfeePerHour() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "feePerHour is required and must be >= 0");
    }

    public ParkingLot getById(String id) {
        return parkingLots.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "ParkingLot not found with id " + id));
    }

    // ---------- CRUD ----------
    public ParkingLot create(ParkingLot x) {
        validate(x);
        x.setId(null);
        return parkingLots.save(x);
    }

    public List<ParkingLot> getAll() { return parkingLots.findAll(); }

    public ParkingLot update(String id, ParkingLot in) {
        ParkingLot existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of vehicles already added
        long used = vehicles.countByParkingLotId(id);
        if (in.getslots() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "slots cannot be less than the " + used + " existing vehicles");
        existing.setLotName(in.getLotName());
        existing.setLocation(in.getLocation());
        existing.setOwner(in.getOwner());
        existing.setSlots(in.getSlots());
        existing.setFeePerHour(in.getFeePerHour());
        return parkingLots.save(existing);
    }

    // a parkingLot that still has vehicles is NOT deleted unless cascade=true (then its vehicles are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = vehicles.countByParkingLotId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "parkingLot has " + used + " vehicles; delete them first or use cascade=true");
        vehicles.deleteByParkingLotId(id);
        parkingLots.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<ParkingLot> search(String keyword) { return parkingLots.findByLotNameContainingIgnoreCase(keyword); }

    public List<ParkingLot> filterByfeePerHour(Double min) { return parkingLots.findByfeePerHourGreaterThanEqual(min); }

    public List<ParkingLot> sortedByfeePerHour() { return parkingLots.findAll(Sort.by(Sort.Direction.DESC, "feePerHour")); }

    // only the parkingLots that still have a free place
    public List<ParkingLot> available() {
        List<ParkingLot> result = new ArrayList<>();
        for (ParkingLot x : parkingLots.findAll())
            if (vehicles.countByParkingLotId(x.getId()) < x.getslots()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Vehicle> vehiclesOf(String id) {
        getById(id);                              // 404 if the parkingLot is missing
        return vehicles.findByParkingLotId(id);
    }

    // count + calculations across the two collections for ONE parkingLot
    public Map<String, Object> summary(String id) {
        ParkingLot x = getById(id);
        long count = vehicles.countByParkingLotId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("parkingLotId", x.getId());
        m.put("name", x.getLotName());
        m.put("slots", x.getslots());
        m.put("vehicleCount", count);
        m.put("placesLeft", x.getslots() - count);
        m.put("feePerHour", x.getfeePerHour());
        m.put("totalAmount", count * x.getfeePerHour());
        return m;
    }

    // totals across ALL parkingLots
    public Map<String, Object> stats() {
        long totalVehicle = 0;
        double totalAmount = 0;
        List<ParkingLot> all = parkingLots.findAll();
        for (ParkingLot x : all) {
            long c = vehicles.countByParkingLotId(x.getId());
            totalVehicle += c;
            totalAmount += c * x.getfeePerHour();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalParkingLots", all.size());
        m.put("totalVehicles", totalVehicle);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
