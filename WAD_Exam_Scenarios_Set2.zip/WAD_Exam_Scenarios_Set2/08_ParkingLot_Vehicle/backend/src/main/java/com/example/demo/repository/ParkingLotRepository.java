package com.example.demo.repository;

import com.example.demo.model.ParkingLot;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ParkingLotRepository extends MongoRepository<ParkingLot, String> {
    List<ParkingLot> findByLotNameContainingIgnoreCase(String keyword);        // search
    List<ParkingLot> findByfeePerHourGreaterThanEqual(Double min);                  // filter by number
}
