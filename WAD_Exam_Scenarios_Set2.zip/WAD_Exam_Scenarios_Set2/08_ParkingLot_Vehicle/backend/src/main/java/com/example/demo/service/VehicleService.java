package com.example.demo.service;

import com.example.demo.model.ParkingLot;
import com.example.demo.model.Vehicle;
import com.example.demo.repository.ParkingLotRepository;
import com.example.demo.repository.VehicleRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class VehicleService {

    private final VehicleRepository vehicles;
    private final ParkingLotRepository parkingLots;

    public VehicleService(VehicleRepository vehicles, ParkingLotRepository parkingLots) {
        this.vehicles = vehicles;
        this.parkingLots = parkingLots;
    }

    private void validate(Vehicle x) {
        if (x.getNumber() == null || x.getNumber().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "number is required");
        if (x.getOwner() == null || x.getOwner().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "owner is required");
        if (x.getParkingLotId() == null || x.getParkingLotId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "parkingLotId is required");
    }

    // The referenced parkingLot must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkParkingLot(String id, boolean checkLimit) {
        ParkingLot p = parkingLots.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "parkingLotId does not exist: " + id));
        if (checkLimit && vehicles.countByParkingLotId(id) >= p.getslots())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "parkingLot is full");
    }

    public Vehicle getById(String id) {
        return vehicles.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vehicle not found with id " + id));
    }

    public Vehicle create(Vehicle x) {
        validate(x);
        checkParkingLot(x.getParkingLotId(), true);
        x.setId(null);
        return vehicles.save(x);
    }

    // optional filter by related record: ?parkingLotId=...
    public List<Vehicle> getAll(String parkingLotId) {
        if (parkingLotId == null || parkingLotId.isBlank()) return vehicles.findAll();
        return vehicles.findByParkingLotId(parkingLotId);
    }

    public List<Vehicle> search(String keyword) { return vehicles.findByNumberContainingIgnoreCase(keyword); }

    public Vehicle update(String id, Vehicle in) {
        Vehicle existing = getById(id);
        validate(in);
        boolean moving = !in.getParkingLotId().equals(existing.getParkingLotId());
        checkParkingLot(in.getParkingLotId(), moving);       // free-place check only when moving to another parkingLot
        existing.setNumber(in.getNumber());
        existing.setOwner(in.getOwner());
        existing.setParkingLotId(in.getParkingLotId());
        return vehicles.save(existing);
    }

    public void delete(String id) {
        getById(id);
        vehicles.deleteById(id);
    }

    public long count(String parkingLotId) {
        if (parkingLotId == null || parkingLotId.isBlank()) return vehicles.count();
        return vehicles.countByParkingLotId(parkingLotId);
    }
}
