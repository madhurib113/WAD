<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import ParkingLotForm from './components/ParkingLotForm.vue'
import ParkingLotList from './components/ParkingLotList.vue'
import VehicleForm from './components/VehicleForm.vue'
import VehicleList from './components/VehicleList.vue'
import ResultBox from './components/ResultBox.vue'

const PARKINGLOTS = 'http://localhost:8080/api/parkingLots'
const VEHICLES = 'http://localhost:8080/api/vehicles'

const parkingLots = ref([])
const vehicles = ref([])
const parkingLotForm = ref({ lotName: '', location: '', owner: '', slots: '', feePerHour: '' })
const editingParkingLotId = ref('')
const vehicleForm = ref({ number: '', owner: '', parkingLotId: '' })
const editingVehicleId = ref('')
const filterParkingLotId = ref('')
const keyword = ref('')
const minfeePerHour = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- ParkingLot ----------
async function loadParkingLots() {
  try { parkingLots.value = (await axios.get(PARKINGLOTS)).data } catch (e) { showError(e) }
}

async function saveParkingLot() {
  error.value = ''
  const body = { ...parkingLotForm.value, slots: num(parkingLotForm.value.slots), feePerHour: num(parkingLotForm.value.feePerHour) }
  try {
    if (editingParkingLotId.value === '') await axios.post(PARKINGLOTS, body)
    else await axios.put(PARKINGLOTS + '/' + editingParkingLotId.value, body)
    cancelParkingLot()
    loadParkingLots()
  } catch (e) { showError(e) }
}

function editParkingLot(x) {
  parkingLotForm.value = { ...x }
  editingParkingLotId.value = x.id
}

function cancelParkingLot() {
  parkingLotForm.value = { lotName: '', location: '', owner: '', slots: '', feePerHour: '' }
  editingParkingLotId.value = ''
}

// cascade = true also deletes the vehicles; false -> error 409 if there are vehicles
async function deleteParkingLot(id, cascade) {
  error.value = ''
  try {
    await axios.delete(PARKINGLOTS + '/' + id, { params: { cascade } })
    loadParkingLots()
    loadVehicles()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Vehicle ----------
async function loadVehicles() {
  try { vehicles.value = (await axios.get(VEHICLES, { params: { parkingLotId: filterParkingLotId.value } })).data } catch (e) { showError(e) }
}

async function saveVehicle() {
  error.value = ''
  try {
    if (editingVehicleId.value === '') await axios.post(VEHICLES, vehicleForm.value)
    else await axios.put(VEHICLES + '/' + editingVehicleId.value, vehicleForm.value)
    cancelVehicle()
    loadVehicles()
  } catch (e) { showError(e) }
}

function editVehicle(x) {
  vehicleForm.value = { number: x.number, owner: x.owner, parkingLotId: x.parkingLotId }
  editingVehicleId.value = x.id
}

function cancelVehicle() {
  vehicleForm.value = { number: '', owner: '', parkingLotId: '' }
  editingVehicleId.value = ''
}

async function deleteVehicle(id) {
  error.value = ''
  try {
    await axios.delete(VEHICLES + '/' + id)
    loadVehicles()
  } catch (e) { showError(e) }
}

onMounted(() => { loadParkingLots(); loadVehicles() })
</script>

<template>
  <h1>ParkingLot - Vehicle Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>ParkingLots</h2>
  <ParkingLotForm :form="parkingLotForm" :editing="editingParkingLotId !== ''" @save="saveParkingLot" @cancel="cancelParkingLot" />
  <div class="box">
    <input v-model="keyword" placeholder="search lotName" />
    <button @click="showGet(PARKINGLOTS + '/search', { keyword })">Search</button>
    <input v-model="minfeePerHour" type="number" placeholder="min feePerHour" />
    <button @click="showGet(PARKINGLOTS + '/filter', { minfeePerHour })">Filter</button>
    <button @click="showGet(PARKINGLOTS + '/sorted')">Sort by feePerHour</button>
    <button @click="showGet(PARKINGLOTS + '/available')">Available</button>
    <button @click="showGet(PARKINGLOTS + '/stats')">Stats</button>
  </div>
  <ParkingLotList :items="parkingLots" @edit="editParkingLot" @remove="deleteParkingLot"
    @related="(id) => showGet(PARKINGLOTS + '/' + id + '/vehicles')" @summary="(id) => showGet(PARKINGLOTS + '/' + id + '/summary')" />

  <h2>Vehicles</h2>
  <VehicleForm :form="vehicleForm" :editing="editingVehicleId !== ''" :parents="parkingLots" @save="saveVehicle" @cancel="cancelVehicle" />
  <div class="box">
    <select v-model="filterParkingLotId" @change="loadVehicles">
      <option value="">All parkingLots</option>
      <option v-for="p in parkingLots" :key="p.id" :value="p.id">{{ p.lotName }}</option>
    </select>
    <button @click="showGet(VEHICLES + '/count', { parkingLotId: filterParkingLotId })">Count</button>
    <input v-model="keyword" placeholder="search number" />
    <button @click="showGet(VEHICLES + '/search', { keyword })">Search</button>
  </div>
  <VehicleList :items="vehicles" :parents="parkingLots" @edit="editVehicle" @remove="deleteVehicle" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
