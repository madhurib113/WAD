<script setup>
// Form for the "MANY" side (Vehicle). The parkingLot is chosen from a dropdown.
defineProps({ form: Object, editing: Boolean, parents: Array })
defineEmits(['save', 'cancel'])
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Vehicle</h3>
    <input v-model="form.number" placeholder="Number" />
    <input v-model="form.owner" placeholder="Owner" />
    <select v-model="form.parkingLotId">
      <option value="">-- select parkingLot --</option>
      <option v-for="p in parents" :key="p.id" :value="p.id">{{ p.lotName }}</option>
    </select>
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
