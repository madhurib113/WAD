<script setup>
// Table of ParkingLot records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'lotName', label: 'Lot Name', type: 'text' },
  { key: 'location', label: 'Location', type: 'text' },
  { key: 'owner', label: 'Owner', type: 'text' },
  { key: 'slots', label: 'Slots', type: 'number' },
  { key: 'feePerHour', label: 'Fee Per Hour', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Vehicles</button>
          <button @click="$emit('related', x.id)">Vehicles</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
