<script setup>
// Table of Vehicle records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the parkingLot name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Number</th><th>Owner</th><th>ParkingLot</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.number }}</td>
        <td>{{ x.owner }}</td>
        <td>{{ (parents.find(p => p.id === x.parkingLotId) || {}).lotName || x.parkingLotId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
