<script setup>
// Form for the "ONE" side (ParkingLot). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'lotName', label: 'Lot Name', type: 'text' },
  { key: 'location', label: 'Location', type: 'text' },
  { key: 'owner', label: 'Owner', type: 'text' },
  { key: 'slots', label: 'Slots', type: 'number' },
  { key: 'feePerHour', label: 'Fee Per Hour', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} ParkingLot</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
