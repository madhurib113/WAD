# Train - Ticket (2 collections: `trains` and `tickets`)

Database `train_db`. `tickets.trainId` stores the `_id` of a train (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db train_db --collection trains --jsonArray --file sample_data/trains.json
mongoimport --db train_db --collection tickets --jsonArray --file sample_data/tickets.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Train**: trainName*, source*, destination, berths* (> 0), fare* (>= 0)    (* = required)
- **Ticket**: name*, phone*, trainId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/trains | create (Train) 201 / 400 |
| GET | /api/trains , /api/trains/{id} | all / one (404) |
| PUT | /api/trains/{id} | update 200 / 400 / 404 / 409 (`berths` below existing tickets) |
| DELETE | /api/trains/{id}?cascade=true | 204 / 404 / 409 (has tickets and no cascade) |
| GET | /api/trains/search?keyword= | search by trainName |
| GET | /api/trains/filter?minfare= | fare >= value |
| GET | /api/trains/sorted | sort by fare desc |
| GET | /api/trains/available | trains that still have free places |
| GET | /api/trains/{id}/tickets | related tickets |
| GET | /api/trains/{id}/summary | count, placesLeft, totalAmount = count x fare |
| GET | /api/trains/stats | totals over all trains |
| POST | /api/tickets | create (Ticket) 201 / 400 (bad trainId) / 409 (full) |
| GET | /api/tickets?trainId= | all / filter by train |
| GET | /api/tickets/{id} | one (404) |
| PUT | /api/tickets/{id} | update (move to another train: free place checked) |
| DELETE | /api/tickets/{id} | 204 / 404 |
| GET | /api/tickets/search?keyword= | search by name |
| GET | /api/tickets/count?trainId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on trains and on tickets.
3. Validation: missing field -> 400, berths <= 0 -> 400, fare < 0 -> 400, unknown id -> 404.
4. Add a ticket only if the train exists (400) and is not full (409).
5. Update train: berths cannot be lower than current number of tickets (409).
6. Delete train: blocked if it has tickets (409); `cascade=true` deletes its tickets too.
7. List tickets of one train; count tickets of one train.
8. Search by text, filter by number, sort descending, list available trains.
9. Calculation: totalAmount for one train, and totals over all trains (stats).
10. Move a ticket from one train to another.
