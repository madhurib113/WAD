<script setup>
// Form for the "ONE" side (Train). Used for both Add and Edit.
defineProps({ form: Object, editing: Boolean })
defineEmits(['save', 'cancel'])

const fields = [
  { key: 'trainName', label: 'Train Name', type: 'text' },
  { key: 'source', label: 'Source', type: 'text' },
  { key: 'destination', label: 'Destination', type: 'text' },
  { key: 'berths', label: 'Berths', type: 'number' },
  { key: 'fare', label: 'Fare', type: 'number' }
]
</script>

<template>
  <div class="box">
    <h3>{{ editing ? 'Edit' : 'Add' }} Train</h3>
    <input v-for="f in fields" :key="f.key" v-model="form[f.key]" :type="f.type" :placeholder="f.label" />
    <button @click="$emit('save')">{{ editing ? 'Update' : 'Add' }}</button>
    <button v-if="editing" @click="$emit('cancel')">Cancel</button>
  </div>
</template>
