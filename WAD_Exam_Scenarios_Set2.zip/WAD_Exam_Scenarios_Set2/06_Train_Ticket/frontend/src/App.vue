<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import TrainForm from './components/TrainForm.vue'
import TrainList from './components/TrainList.vue'
import TicketForm from './components/TicketForm.vue'
import TicketList from './components/TicketList.vue'
import ResultBox from './components/ResultBox.vue'

const TRAINS = 'http://localhost:8080/api/trains'
const TICKETS = 'http://localhost:8080/api/tickets'

const trains = ref([])
const tickets = ref([])
const trainForm = ref({ trainName: '', source: '', destination: '', berths: '', fare: '' })
const editingTrainId = ref('')
const ticketForm = ref({ name: '', phone: '', trainId: '' })
const editingTicketId = ref('')
const filterTrainId = ref('')
const keyword = ref('')
const minfare = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Train ----------
async function loadTrains() {
  try { trains.value = (await axios.get(TRAINS)).data } catch (e) { showError(e) }
}

async function saveTrain() {
  error.value = ''
  const body = { ...trainForm.value, berths: num(trainForm.value.berths), fare: num(trainForm.value.fare) }
  try {
    if (editingTrainId.value === '') await axios.post(TRAINS, body)
    else await axios.put(TRAINS + '/' + editingTrainId.value, body)
    cancelTrain()
    loadTrains()
  } catch (e) { showError(e) }
}

function editTrain(x) {
  trainForm.value = { ...x }
  editingTrainId.value = x.id
}

function cancelTrain() {
  trainForm.value = { trainName: '', source: '', destination: '', berths: '', fare: '' }
  editingTrainId.value = ''
}

// cascade = true also deletes the tickets; false -> error 409 if there are tickets
async function deleteTrain(id, cascade) {
  error.value = ''
  try {
    await axios.delete(TRAINS + '/' + id, { params: { cascade } })
    loadTrains()
    loadTickets()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Ticket ----------
async function loadTickets() {
  try { tickets.value = (await axios.get(TICKETS, { params: { trainId: filterTrainId.value } })).data } catch (e) { showError(e) }
}

async function saveTicket() {
  error.value = ''
  try {
    if (editingTicketId.value === '') await axios.post(TICKETS, ticketForm.value)
    else await axios.put(TICKETS + '/' + editingTicketId.value, ticketForm.value)
    cancelTicket()
    loadTickets()
  } catch (e) { showError(e) }
}

function editTicket(x) {
  ticketForm.value = { name: x.name, phone: x.phone, trainId: x.trainId }
  editingTicketId.value = x.id
}

function cancelTicket() {
  ticketForm.value = { name: '', phone: '', trainId: '' }
  editingTicketId.value = ''
}

async function deleteTicket(id) {
  error.value = ''
  try {
    await axios.delete(TICKETS + '/' + id)
    loadTickets()
  } catch (e) { showError(e) }
}

onMounted(() => { loadTrains(); loadTickets() })
</script>

<template>
  <h1>Train - Ticket Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Trains</h2>
  <TrainForm :form="trainForm" :editing="editingTrainId !== ''" @save="saveTrain" @cancel="cancelTrain" />
  <div class="box">
    <input v-model="keyword" placeholder="search trainName" />
    <button @click="showGet(TRAINS + '/search', { keyword })">Search</button>
    <input v-model="minfare" type="number" placeholder="min fare" />
    <button @click="showGet(TRAINS + '/filter', { minfare })">Filter</button>
    <button @click="showGet(TRAINS + '/sorted')">Sort by fare</button>
    <button @click="showGet(TRAINS + '/available')">Available</button>
    <button @click="showGet(TRAINS + '/stats')">Stats</button>
  </div>
  <TrainList :items="trains" @edit="editTrain" @remove="deleteTrain"
    @related="(id) => showGet(TRAINS + '/' + id + '/tickets')" @summary="(id) => showGet(TRAINS + '/' + id + '/summary')" />

  <h2>Tickets</h2>
  <TicketForm :form="ticketForm" :editing="editingTicketId !== ''" :parents="trains" @save="saveTicket" @cancel="cancelTicket" />
  <div class="box">
    <select v-model="filterTrainId" @change="loadTickets">
      <option value="">All trains</option>
      <option v-for="p in trains" :key="p.id" :value="p.id">{{ p.trainName }}</option>
    </select>
    <button @click="showGet(TICKETS + '/count', { trainId: filterTrainId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(TICKETS + '/search', { keyword })">Search</button>
  </div>
  <TicketList :items="tickets" :parents="trains" @edit="editTicket" @remove="deleteTicket" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
