package com.example.demo.service;

import com.example.demo.model.Train;
import com.example.demo.model.Ticket;
import com.example.demo.repository.TrainRepository;
import com.example.demo.repository.TicketRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class TrainService {

    private final TrainRepository trains;
    private final TicketRepository tickets;

    public TrainService(TrainRepository trains, TicketRepository tickets) {
        this.trains = trains;
        this.tickets = tickets;
    }

    private void validate(Train x) {
        if (x.getTrainName() == null || x.getTrainName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "trainName is required");
        if (x.getSource() == null || x.getSource().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "source is required");
        if (x.getberths() == null || x.getberths() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "berths is required and must be > 0");
        if (x.getfare() == null || x.getfare() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "fare is required and must be >= 0");
    }

    public Train getById(String id) {
        return trains.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found with id " + id));
    }

    // ---------- CRUD ----------
    public Train create(Train x) {
        validate(x);
        x.setId(null);
        return trains.save(x);
    }

    public List<Train> getAll() { return trains.findAll(); }

    public Train update(String id, Train in) {
        Train existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of tickets already added
        long used = tickets.countByTrainId(id);
        if (in.getberths() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "berths cannot be less than the " + used + " existing tickets");
        existing.setTrainName(in.getTrainName());
        existing.setSource(in.getSource());
        existing.setDestination(in.getDestination());
        existing.setBerths(in.getBerths());
        existing.setFare(in.getFare());
        return trains.save(existing);
    }

    // a train that still has tickets is NOT deleted unless cascade=true (then its tickets are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = tickets.countByTrainId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "train has " + used + " tickets; delete them first or use cascade=true");
        tickets.deleteByTrainId(id);
        trains.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Train> search(String keyword) { return trains.findByTrainNameContainingIgnoreCase(keyword); }

    public List<Train> filterByfare(Double min) { return trains.findByfareGreaterThanEqual(min); }

    public List<Train> sortedByfare() { return trains.findAll(Sort.by(Sort.Direction.DESC, "fare")); }

    // only the trains that still have a free place
    public List<Train> available() {
        List<Train> result = new ArrayList<>();
        for (Train x : trains.findAll())
            if (tickets.countByTrainId(x.getId()) < x.getberths()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Ticket> ticketsOf(String id) {
        getById(id);                              // 404 if the train is missing
        return tickets.findByTrainId(id);
    }

    // count + calculations across the two collections for ONE train
    public Map<String, Object> summary(String id) {
        Train x = getById(id);
        long count = tickets.countByTrainId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("trainId", x.getId());
        m.put("name", x.getTrainName());
        m.put("berths", x.getberths());
        m.put("ticketCount", count);
        m.put("placesLeft", x.getberths() - count);
        m.put("fare", x.getfare());
        m.put("totalAmount", count * x.getfare());
        return m;
    }

    // totals across ALL trains
    public Map<String, Object> stats() {
        long totalTicket = 0;
        double totalAmount = 0;
        List<Train> all = trains.findAll();
        for (Train x : all) {
            long c = tickets.countByTrainId(x.getId());
            totalTicket += c;
            totalAmount += c * x.getfare();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalTrains", all.size());
        m.put("totalTickets", totalTicket);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
