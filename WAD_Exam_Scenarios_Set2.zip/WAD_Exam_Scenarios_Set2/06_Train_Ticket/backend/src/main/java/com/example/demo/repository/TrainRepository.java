package com.example.demo.repository;

import com.example.demo.model.Train;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TrainRepository extends MongoRepository<Train, String> {
    List<Train> findByTrainNameContainingIgnoreCase(String keyword);        // search
    List<Train> findByfareGreaterThanEqual(Double min);                  // filter by number
}
