package com.example.demo.service;

import com.example.demo.model.Train;
import com.example.demo.model.Ticket;
import com.example.demo.repository.TrainRepository;
import com.example.demo.repository.TicketRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class TicketService {

    private final TicketRepository tickets;
    private final TrainRepository trains;

    public TicketService(TicketRepository tickets, TrainRepository trains) {
        this.tickets = tickets;
        this.trains = trains;
    }

    private void validate(Ticket x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getPhone() == null || x.getPhone().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "phone is required");
        if (x.getTrainId() == null || x.getTrainId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "trainId is required");
    }

    // The referenced train must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkTrain(String id, boolean checkLimit) {
        Train p = trains.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "trainId does not exist: " + id));
        if (checkLimit && tickets.countByTrainId(id) >= p.getberths())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "train is full");
    }

    public Ticket getById(String id) {
        return tickets.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Ticket not found with id " + id));
    }

    public Ticket create(Ticket x) {
        validate(x);
        checkTrain(x.getTrainId(), true);
        x.setId(null);
        return tickets.save(x);
    }

    // optional filter by related record: ?trainId=...
    public List<Ticket> getAll(String trainId) {
        if (trainId == null || trainId.isBlank()) return tickets.findAll();
        return tickets.findByTrainId(trainId);
    }

    public List<Ticket> search(String keyword) { return tickets.findByNameContainingIgnoreCase(keyword); }

    public Ticket update(String id, Ticket in) {
        Ticket existing = getById(id);
        validate(in);
        boolean moving = !in.getTrainId().equals(existing.getTrainId());
        checkTrain(in.getTrainId(), moving);       // free-place check only when moving to another train
        existing.setName(in.getName());
        existing.setPhone(in.getPhone());
        existing.setTrainId(in.getTrainId());
        return tickets.save(existing);
    }

    public void delete(String id) {
        getById(id);
        tickets.deleteById(id);
    }

    public long count(String trainId) {
        if (trainId == null || trainId.isBlank()) return tickets.count();
        return tickets.countByTrainId(trainId);
    }
}
