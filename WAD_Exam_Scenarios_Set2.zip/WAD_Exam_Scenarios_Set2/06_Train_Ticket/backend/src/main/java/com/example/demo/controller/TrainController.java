package com.example.demo.controller;

import com.example.demo.model.Train;
import com.example.demo.model.Ticket;
import com.example.demo.service.TrainService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/trains")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class TrainController {

    private final TrainService service;

    public TrainController(TrainService service) { this.service = service; }

    @PostMapping                                   // POST   /api/trains                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Train create(@RequestBody Train x) { return service.create(x); }

    @GetMapping                                    // GET    /api/trains
    public List<Train> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/trains/{id}            -> 200 / 404
    public Train getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/trains/{id}            -> 200 / 400 / 404 / 409
    public Train update(@PathVariable String id, @RequestBody Train x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/trains/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/trains/search?keyword=ab
    public List<Train> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/trains/filter?minfare=500
    public List<Train> filter(@RequestParam Double minfare) { return service.filterByfare(minfare); }

    @GetMapping("/sorted")                         // GET    /api/trains/sorted          (fare high -> low)
    public List<Train> sorted() { return service.sortedByfare(); }

    @GetMapping("/available")                      // GET    /api/trains/available       (still have free places)
    public List<Train> available() { return service.available(); }

    @GetMapping("/{id}/tickets")                    // GET    /api/trains/{id}/tickets     (related records)
    public List<Ticket> related(@PathVariable String id) { return service.ticketsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/trains/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/trains/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
