package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "ONE" side. Collection: trains
@Document(collection = "trains")
public class Train {

    @Id
    private String id;

    private String trainName;
    private String source;
    private String destination;
    private Integer berths;
    private Double fare;

    public Train() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTrainName() { return trainName; }
    public void setTrainName(String trainName) { this.trainName = trainName; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public Integer getBerths() { return berths; }
    public void setBerths(Integer berths) { this.berths = berths; }
    public Double getFare() { return fare; }
    public void setFare(Double fare) { this.fare = fare; }
}
