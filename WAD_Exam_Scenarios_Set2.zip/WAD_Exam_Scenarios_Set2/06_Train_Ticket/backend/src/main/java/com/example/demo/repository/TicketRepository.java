package com.example.demo.repository;

import com.example.demo.model.Ticket;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TicketRepository extends MongoRepository<Ticket, String> {
    List<Ticket> findByTrainId(String trainId);                    // filter by the related record
    long countByTrainId(String trainId);                          // count related records
    long deleteByTrainId(String trainId);                         // cascade delete
    List<Ticket> findByNameContainingIgnoreCase(String keyword); // search
}
