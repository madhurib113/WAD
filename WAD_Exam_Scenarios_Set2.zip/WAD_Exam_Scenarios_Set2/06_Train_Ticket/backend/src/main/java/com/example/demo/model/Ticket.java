package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: tickets
// trainId stores the _id of a Train as plain text. MongoDB has NO foreign keys,
// so TicketService checks that the train exists before saving.
@Document(collection = "tickets")
public class Ticket {

    @Id
    private String id;

    private String name;     // required
    private String phone;     // required
    private String trainId;    // required: reference to trains._id

    public Ticket() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getTrainId() { return trainId; }
    public void setTrainId(String trainId) { this.trainId = trainId; }
}
