package com.example.demo.controller;

import com.example.demo.model.Ticket;
import com.example.demo.service.TicketService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tickets")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class TicketController {

    private final TicketService service;

    public TicketController(TicketService service) { this.service = service; }

    @PostMapping                                   // POST   /api/tickets   -> 201 / 400 (bad train) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Ticket create(@RequestBody Ticket x) { return service.create(x); }

    @GetMapping                                    // GET    /api/tickets[?trainId=..]  (filter by related record)
    public List<Ticket> getAll(@RequestParam(required = false) String trainId) { return service.getAll(trainId); }

    @GetMapping("/{id}")                           // GET    /api/tickets/{id}   -> 200 / 404
    public Ticket getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/tickets/{id}
    public Ticket update(@PathVariable String id, @RequestBody Ticket x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/tickets/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/tickets/search?keyword=an
    public List<Ticket> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/tickets/count[?trainId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String trainId) {
        return Map.of("count", service.count(trainId));
    }
}
