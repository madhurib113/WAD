# WAD Exam Scenarios (10 x 2-collection Spring Boot + MongoDB + Vue)

Every scenario has the SAME structure (same pom.xml, Boot 4.1.1, Java 17, same package layout, same endpoints,
same Vue components). Only the names/fields change. No tests / MockMvc.

| # | Folder | Collection 1 (ONE) | Collection 2 (MANY) | Database |
|---|---|---|---|---|
| 1 | 01_Restaurant_Order | restaurants | orders | restaurant_db |
| 2 | 02_Branch_Account | branchs | accounts | branch_db |
| 3 | 03_ClassRoom_Student | classRooms | students | classRoom_db |
| 4 | 04_Category_Product | categorys | products | category_db |
| 5 | 05_Ward_Admission | wards | admissions | ward_db |
| 6 | 06_Train_Ticket | trains | tickets | train_db |
| 7 | 07_Job_Applicant | jobs | applicants | job_db |
| 8 | 08_ParkingLot_Vehicle | parkingLots | vehicles | parkingLot_db |
| 9 | 09_Warehouse_Item | warehouses | items | warehouse_db |
| 10 | 10_Salon_Appointment | salons | appointments | salon_db |

## Run any scenario
1. Start MongoDB, import `sample_data/*.json` with `mongoimport` (commands are in each scenario README).
2. Backend: `cd backend && ./mvnw spring-boot:run` (port 8080)
3. Frontend: `cd frontend && npm install && npm run dev` (port 5173)

## Folder layout (same in all)
```
backend/src/main/java/com/example/demo/{model,repository,service,controller,exception}
frontend/src/App.vue + components/{Parent}Form, {Parent}List, {Child}Form, {Child}List, ResultBox
```
Each scenario README lists all endpoints and the typical exam questions covered.
