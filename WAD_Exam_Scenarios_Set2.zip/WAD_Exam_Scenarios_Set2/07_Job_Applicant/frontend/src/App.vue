<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import JobForm from './components/JobForm.vue'
import JobList from './components/JobList.vue'
import ApplicantForm from './components/ApplicantForm.vue'
import ApplicantList from './components/ApplicantList.vue'
import ResultBox from './components/ResultBox.vue'

const JOBS = 'http://localhost:8080/api/jobs'
const APPLICANTS = 'http://localhost:8080/api/applicants'

const jobs = ref([])
const applicants = ref([])
const jobForm = ref({ title: '', company: '', location: '', vacancies: '', salary: '' })
const editingJobId = ref('')
const applicantForm = ref({ name: '', email: '', jobId: '' })
const editingApplicantId = ref('')
const filterJobId = ref('')
const keyword = ref('')
const minsalary = ref('')
const result = ref('')
const error = ref('')

function showError(e) { error.value = e.response?.data?.error || e.message }
function show(data) { result.value = JSON.stringify(data, null, 2) }
const num = (v) => (v === '' ? null : Number(v))

// ---------- Job ----------
async function loadJobs() {
  try { jobs.value = (await axios.get(JOBS)).data } catch (e) { showError(e) }
}

async function saveJob() {
  error.value = ''
  const body = { ...jobForm.value, vacancies: num(jobForm.value.vacancies), salary: num(jobForm.value.salary) }
  try {
    if (editingJobId.value === '') await axios.post(JOBS, body)
    else await axios.put(JOBS + '/' + editingJobId.value, body)
    cancelJob()
    loadJobs()
  } catch (e) { showError(e) }
}

function editJob(x) {
  jobForm.value = { ...x }
  editingJobId.value = x.id
}

function cancelJob() {
  jobForm.value = { title: '', company: '', location: '', vacancies: '', salary: '' }
  editingJobId.value = ''
}

// cascade = true also deletes the applicants; false -> error 409 if there are applicants
async function deleteJob(id, cascade) {
  error.value = ''
  try {
    await axios.delete(JOBS + '/' + id, { params: { cascade } })
    loadJobs()
    loadApplicants()
  } catch (e) { showError(e) }
}

// generic GET that prints the JSON result (related, summary, stats, filter, sorted, available, search)
async function showGet(url, params) {
  error.value = ''
  try { show((await axios.get(url, { params })).data) } catch (e) { showError(e) }
}

// ---------- Applicant ----------
async function loadApplicants() {
  try { applicants.value = (await axios.get(APPLICANTS, { params: { jobId: filterJobId.value } })).data } catch (e) { showError(e) }
}

async function saveApplicant() {
  error.value = ''
  try {
    if (editingApplicantId.value === '') await axios.post(APPLICANTS, applicantForm.value)
    else await axios.put(APPLICANTS + '/' + editingApplicantId.value, applicantForm.value)
    cancelApplicant()
    loadApplicants()
  } catch (e) { showError(e) }
}

function editApplicant(x) {
  applicantForm.value = { name: x.name, email: x.email, jobId: x.jobId }
  editingApplicantId.value = x.id
}

function cancelApplicant() {
  applicantForm.value = { name: '', email: '', jobId: '' }
  editingApplicantId.value = ''
}

async function deleteApplicant(id) {
  error.value = ''
  try {
    await axios.delete(APPLICANTS + '/' + id)
    loadApplicants()
  } catch (e) { showError(e) }
}

onMounted(() => { loadJobs(); loadApplicants() })
</script>

<template>
  <h1>Job - Applicant Manager</h1>
  <p v-if="error" class="error">{{ error }}</p>

  <h2>Jobs</h2>
  <JobForm :form="jobForm" :editing="editingJobId !== ''" @save="saveJob" @cancel="cancelJob" />
  <div class="box">
    <input v-model="keyword" placeholder="search title" />
    <button @click="showGet(JOBS + '/search', { keyword })">Search</button>
    <input v-model="minsalary" type="number" placeholder="min salary" />
    <button @click="showGet(JOBS + '/filter', { minsalary })">Filter</button>
    <button @click="showGet(JOBS + '/sorted')">Sort by salary</button>
    <button @click="showGet(JOBS + '/available')">Available</button>
    <button @click="showGet(JOBS + '/stats')">Stats</button>
  </div>
  <JobList :items="jobs" @edit="editJob" @remove="deleteJob"
    @related="(id) => showGet(JOBS + '/' + id + '/applicants')" @summary="(id) => showGet(JOBS + '/' + id + '/summary')" />

  <h2>Applicants</h2>
  <ApplicantForm :form="applicantForm" :editing="editingApplicantId !== ''" :parents="jobs" @save="saveApplicant" @cancel="cancelApplicant" />
  <div class="box">
    <select v-model="filterJobId" @change="loadApplicants">
      <option value="">All jobs</option>
      <option v-for="p in jobs" :key="p.id" :value="p.id">{{ p.title }}</option>
    </select>
    <button @click="showGet(APPLICANTS + '/count', { jobId: filterJobId })">Count</button>
    <input v-model="keyword" placeholder="search name" />
    <button @click="showGet(APPLICANTS + '/search', { keyword })">Search</button>
  </div>
  <ApplicantList :items="applicants" :parents="jobs" @edit="editApplicant" @remove="deleteApplicant" />

  <h2>Result</h2>
  <ResultBox :text="result" />
</template>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.box { margin: 8px 0; }
input, select, button { margin: 2px; padding: 4px; }
table { border-collapse: collapse; margin-top: 6px; }
th, td { border: 1px solid #999; padding: 4px 8px; }
.error { color: red; font-weight: bold; }
.result { background: #f3f3f3; padding: 8px; }
</style>
