<script setup>
// Table of Job records with the action buttons.
defineProps({ items: Array })
defineEmits(['edit', 'remove', 'related', 'summary'])

const columns = [
  { key: 'title', label: 'Title', type: 'text' },
  { key: 'company', label: 'Company', type: 'text' },
  { key: 'location', label: 'Location', type: 'text' },
  { key: 'vacancies', label: 'Vacancies', type: 'number' },
  { key: 'salary', label: 'Salary', type: 'number' }
]
</script>

<template>
  <table>
    <thead>
      <tr><th v-for="c in columns" :key="c.key">{{ c.label }}</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td v-for="c in columns" :key="c.key">{{ x[c.key] }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id, false)">Delete</button>
          <button @click="$emit('remove', x.id, true)">Delete + Applicants</button>
          <button @click="$emit('related', x.id)">Applicants</button>
          <button @click="$emit('summary', x.id)">Summary</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
