<script setup>
// Table of Applicant records.
defineProps({ items: Array, parents: Array })
defineEmits(['edit', 'remove'])

// show the job name instead of its id
</script>

<template>
  <table>
    <thead><tr><th>Name</th><th>Email</th><th>Job</th><th>Actions</th></tr></thead>
    <tbody>
      <tr v-for="x in items" :key="x.id">
        <td>{{ x.name }}</td>
        <td>{{ x.email }}</td>
        <td>{{ (parents.find(p => p.id === x.jobId) || {}).title || x.jobId }}</td>
        <td>
          <button @click="$emit('edit', x)">Edit</button>
          <button @click="$emit('remove', x.id)">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
