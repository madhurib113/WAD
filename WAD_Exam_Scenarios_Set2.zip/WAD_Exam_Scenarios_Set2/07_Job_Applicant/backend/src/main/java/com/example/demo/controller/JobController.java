package com.example.demo.controller;

import com.example.demo.model.Job;
import com.example.demo.model.Applicant;
import com.example.demo.service.JobService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/jobs")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class JobController {

    private final JobService service;

    public JobController(JobService service) { this.service = service; }

    @PostMapping                                   // POST   /api/jobs                 -> 201 / 400
    @ResponseStatus(HttpStatus.CREATED)
    public Job create(@RequestBody Job x) { return service.create(x); }

    @GetMapping                                    // GET    /api/jobs
    public List<Job> getAll() { return service.getAll(); }

    @GetMapping("/{id}")                           // GET    /api/jobs/{id}            -> 200 / 404
    public Job getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/jobs/{id}            -> 200 / 400 / 404 / 409
    public Job update(@PathVariable String id, @RequestBody Job x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/jobs/{id}[?cascade=true] -> 204 / 404 / 409
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, @RequestParam(defaultValue = "false") boolean cascade) {
        service.delete(id, cascade);
    }

    @GetMapping("/search")                         // GET    /api/jobs/search?keyword=ab
    public List<Job> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/filter")                         // GET    /api/jobs/filter?minsalary=500
    public List<Job> filter(@RequestParam Double minsalary) { return service.filterBysalary(minsalary); }

    @GetMapping("/sorted")                         // GET    /api/jobs/sorted          (salary high -> low)
    public List<Job> sorted() { return service.sortedBysalary(); }

    @GetMapping("/available")                      // GET    /api/jobs/available       (still have free places)
    public List<Job> available() { return service.available(); }

    @GetMapping("/{id}/applicants")                    // GET    /api/jobs/{id}/applicants     (related records)
    public List<Applicant> related(@PathVariable String id) { return service.applicantsOf(id); }

    @GetMapping("/{id}/summary")                   // GET    /api/jobs/{id}/summary    (count, places left, amount)
    public Map<String, Object> summary(@PathVariable String id) { return service.summary(id); }

    @GetMapping("/stats")                          // GET    /api/jobs/stats           (totals over all)
    public Map<String, Object> stats() { return service.stats(); }
}
