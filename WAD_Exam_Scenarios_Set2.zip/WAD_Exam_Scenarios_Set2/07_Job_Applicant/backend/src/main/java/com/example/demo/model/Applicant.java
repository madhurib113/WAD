package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// "MANY" side. Collection: applicants
// jobId stores the _id of a Job as plain text. MongoDB has NO foreign keys,
// so ApplicantService checks that the job exists before saving.
@Document(collection = "applicants")
public class Applicant {

    @Id
    private String id;

    private String name;     // required
    private String email;     // required
    private String jobId;    // required: reference to jobs._id

    public Applicant() { }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getJobId() { return jobId; }
    public void setJobId(String jobId) { this.jobId = jobId; }
}
