package com.example.demo.service;

import com.example.demo.model.Job;
import com.example.demo.model.Applicant;
import com.example.demo.repository.JobRepository;
import com.example.demo.repository.ApplicantRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class JobService {

    private final JobRepository jobs;
    private final ApplicantRepository applicants;

    public JobService(JobRepository jobs, ApplicantRepository applicants) {
        this.jobs = jobs;
        this.applicants = applicants;
    }

    private void validate(Job x) {
        if (x.getTitle() == null || x.getTitle().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "title is required");
        if (x.getCompany() == null || x.getCompany().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "company is required");
        if (x.getvacancies() == null || x.getvacancies() <= 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "vacancies is required and must be > 0");
        if (x.getsalary() == null || x.getsalary() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "salary is required and must be >= 0");
    }

    public Job getById(String id) {
        return jobs.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Job not found with id " + id));
    }

    // ---------- CRUD ----------
    public Job create(Job x) {
        validate(x);
        x.setId(null);
        return jobs.save(x);
    }

    public List<Job> getAll() { return jobs.findAll(); }

    public Job update(String id, Job in) {
        Job existing = getById(id);
        validate(in);
        // consistency rule: limit cannot drop below the number of applicants already added
        long used = applicants.countByJobId(id);
        if (in.getvacancies() < used)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "vacancies cannot be less than the " + used + " existing applicants");
        existing.setTitle(in.getTitle());
        existing.setCompany(in.getCompany());
        existing.setLocation(in.getLocation());
        existing.setVacancies(in.getVacancies());
        existing.setSalary(in.getSalary());
        return jobs.save(existing);
    }

    // a job that still has applicants is NOT deleted unless cascade=true (then its applicants are deleted first)
    public void delete(String id, boolean cascade) {
        getById(id);
        long used = applicants.countByJobId(id);
        if (used > 0 && !cascade)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "job has " + used + " applicants; delete them first or use cascade=true");
        applicants.deleteByJobId(id);
        jobs.deleteById(id);
    }

    // ---------- search / filter / sort ----------
    public List<Job> search(String keyword) { return jobs.findByTitleContainingIgnoreCase(keyword); }

    public List<Job> filterBysalary(Double min) { return jobs.findBysalaryGreaterThanEqual(min); }

    public List<Job> sortedBysalary() { return jobs.findAll(Sort.by(Sort.Direction.DESC, "salary")); }

    // only the jobs that still have a free place
    public List<Job> available() {
        List<Job> result = new ArrayList<>();
        for (Job x : jobs.findAll())
            if (applicants.countByJobId(x.getId()) < x.getvacancies()) result.add(x);
        return result;
    }

    // ---------- related records ----------
    public List<Applicant> applicantsOf(String id) {
        getById(id);                              // 404 if the job is missing
        return applicants.findByJobId(id);
    }

    // count + calculations across the two collections for ONE job
    public Map<String, Object> summary(String id) {
        Job x = getById(id);
        long count = applicants.countByJobId(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("jobId", x.getId());
        m.put("name", x.getTitle());
        m.put("vacancies", x.getvacancies());
        m.put("applicantCount", count);
        m.put("placesLeft", x.getvacancies() - count);
        m.put("salary", x.getsalary());
        m.put("totalAmount", count * x.getsalary());
        return m;
    }

    // totals across ALL jobs
    public Map<String, Object> stats() {
        long totalApplicant = 0;
        double totalAmount = 0;
        List<Job> all = jobs.findAll();
        for (Job x : all) {
            long c = applicants.countByJobId(x.getId());
            totalApplicant += c;
            totalAmount += c * x.getsalary();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalJobs", all.size());
        m.put("totalApplicants", totalApplicant);
        m.put("totalAmount", totalAmount);
        return m;
    }
}
