package com.example.demo.repository;

import com.example.demo.model.Applicant;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ApplicantRepository extends MongoRepository<Applicant, String> {
    List<Applicant> findByJobId(String jobId);                    // filter by the related record
    long countByJobId(String jobId);                          // count related records
    long deleteByJobId(String jobId);                         // cascade delete
    List<Applicant> findByNameContainingIgnoreCase(String keyword); // search
}
