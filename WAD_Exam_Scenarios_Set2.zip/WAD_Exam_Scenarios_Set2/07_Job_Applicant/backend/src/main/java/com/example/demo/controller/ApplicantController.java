package com.example.demo.controller;

import com.example.demo.model.Applicant;
import com.example.demo.service.ApplicantService;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/applicants")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class ApplicantController {

    private final ApplicantService service;

    public ApplicantController(ApplicantService service) { this.service = service; }

    @PostMapping                                   // POST   /api/applicants   -> 201 / 400 (bad job) / 409 (full)
    @ResponseStatus(HttpStatus.CREATED)
    public Applicant create(@RequestBody Applicant x) { return service.create(x); }

    @GetMapping                                    // GET    /api/applicants[?jobId=..]  (filter by related record)
    public List<Applicant> getAll(@RequestParam(required = false) String jobId) { return service.getAll(jobId); }

    @GetMapping("/{id}")                           // GET    /api/applicants/{id}   -> 200 / 404
    public Applicant getById(@PathVariable String id) { return service.getById(id); }

    @PutMapping("/{id}")                           // PUT    /api/applicants/{id}
    public Applicant update(@PathVariable String id, @RequestBody Applicant x) { return service.update(id, x); }

    @DeleteMapping("/{id}")                        // DELETE /api/applicants/{id}   -> 204 / 404
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/search")                         // GET    /api/applicants/search?keyword=an
    public List<Applicant> search(@RequestParam String keyword) { return service.search(keyword); }

    @GetMapping("/count")                          // GET    /api/applicants/count[?jobId=..] -> {"count":n}
    public Map<String, Long> count(@RequestParam(required = false) String jobId) {
        return Map.of("count", service.count(jobId));
    }
}
