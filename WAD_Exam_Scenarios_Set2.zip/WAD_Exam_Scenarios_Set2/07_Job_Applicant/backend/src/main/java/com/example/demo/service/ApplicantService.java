package com.example.demo.service;

import com.example.demo.model.Job;
import com.example.demo.model.Applicant;
import com.example.demo.repository.JobRepository;
import com.example.demo.repository.ApplicantRepository;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ApplicantService {

    private final ApplicantRepository applicants;
    private final JobRepository jobs;

    public ApplicantService(ApplicantRepository applicants, JobRepository jobs) {
        this.applicants = applicants;
        this.jobs = jobs;
    }

    private void validate(Applicant x) {
        if (x.getName() == null || x.getName().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "name is required");
        if (x.getEmail() == null || x.getEmail().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        if (x.getJobId() == null || x.getJobId().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "jobId is required");
    }

    // The referenced job must exist (replaces the SQL foreign-key check) and must have a free place.
    private void checkJob(String id, boolean checkLimit) {
        Job p = jobs.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "jobId does not exist: " + id));
        if (checkLimit && applicants.countByJobId(id) >= p.getvacancies())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "job is full");
    }

    public Applicant getById(String id) {
        return applicants.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Applicant not found with id " + id));
    }

    public Applicant create(Applicant x) {
        validate(x);
        checkJob(x.getJobId(), true);
        x.setId(null);
        return applicants.save(x);
    }

    // optional filter by related record: ?jobId=...
    public List<Applicant> getAll(String jobId) {
        if (jobId == null || jobId.isBlank()) return applicants.findAll();
        return applicants.findByJobId(jobId);
    }

    public List<Applicant> search(String keyword) { return applicants.findByNameContainingIgnoreCase(keyword); }

    public Applicant update(String id, Applicant in) {
        Applicant existing = getById(id);
        validate(in);
        boolean moving = !in.getJobId().equals(existing.getJobId());
        checkJob(in.getJobId(), moving);       // free-place check only when moving to another job
        existing.setName(in.getName());
        existing.setEmail(in.getEmail());
        existing.setJobId(in.getJobId());
        return applicants.save(existing);
    }

    public void delete(String id) {
        getById(id);
        applicants.deleteById(id);
    }

    public long count(String jobId) {
        if (jobId == null || jobId.isBlank()) return applicants.count();
        return applicants.countByJobId(jobId);
    }
}
