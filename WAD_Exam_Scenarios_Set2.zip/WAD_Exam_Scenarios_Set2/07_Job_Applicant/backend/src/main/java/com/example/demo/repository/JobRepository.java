package com.example.demo.repository;

import com.example.demo.model.Job;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface JobRepository extends MongoRepository<Job, String> {
    List<Job> findByTitleContainingIgnoreCase(String keyword);        // search
    List<Job> findBysalaryGreaterThanEqual(Double min);                  // filter by number
}
