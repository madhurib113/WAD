# Job - Applicant (2 collections: `jobs` and `applicants`)

Database `job_db`. `applicants.jobId` stores the `_id` of a job (no foreign keys in MongoDB, so the service checks it).

## Run
```
mongoimport --db job_db --collection jobs --jsonArray --file sample_data/jobs.json
mongoimport --db job_db --collection applicants --jsonArray --file sample_data/applicants.json
cd backend  && ./mvnw spring-boot:run        # http://localhost:8080
cd frontend && npm install && npm run dev    # http://localhost:5173
```

## Fields
- **Job**: title*, company*, location, vacancies* (> 0), salary* (>= 0)    (* = required)
- **Applicant**: name*, email*, jobId* (must exist)

## Endpoints
| Method | URL | Result |
|---|---|---|
| POST | /api/jobs | create (Job) 201 / 400 |
| GET | /api/jobs , /api/jobs/{id} | all / one (404) |
| PUT | /api/jobs/{id} | update 200 / 400 / 404 / 409 (`vacancies` below existing applicants) |
| DELETE | /api/jobs/{id}?cascade=true | 204 / 404 / 409 (has applicants and no cascade) |
| GET | /api/jobs/search?keyword= | search by title |
| GET | /api/jobs/filter?minsalary= | salary >= value |
| GET | /api/jobs/sorted | sort by salary desc |
| GET | /api/jobs/available | jobs that still have free places |
| GET | /api/jobs/{id}/applicants | related applicants |
| GET | /api/jobs/{id}/summary | count, placesLeft, totalAmount = count x salary |
| GET | /api/jobs/stats | totals over all jobs |
| POST | /api/applicants | create (Applicant) 201 / 400 (bad jobId) / 409 (full) |
| GET | /api/applicants?jobId= | all / filter by job |
| GET | /api/applicants/{id} | one (404) |
| PUT | /api/applicants/{id} | update (move to another job: free place checked) |
| DELETE | /api/applicants/{id} | 204 / 404 |
| GET | /api/applicants/search?keyword= | search by name |
| GET | /api/applicants/count?jobId= | {"count": n} |

## Typical exam questions this covers
1. Create both collections and insert records (POST, sample_data).
2. CRUD on jobs and on applicants.
3. Validation: missing field -> 400, vacancies <= 0 -> 400, salary < 0 -> 400, unknown id -> 404.
4. Add a applicant only if the job exists (400) and is not full (409).
5. Update job: vacancies cannot be lower than current number of applicants (409).
6. Delete job: blocked if it has applicants (409); `cascade=true` deletes its applicants too.
7. List applicants of one job; count applicants of one job.
8. Search by text, filter by number, sort descending, list available jobs.
9. Calculation: totalAmount for one job, and totals over all jobs (stats).
10. Move a applicant from one job to another.
