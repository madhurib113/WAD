package com.example.jobapplication.repository;
import com.example.jobapplication.model.Applicant;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ApplicantRepository extends MongoRepository<Applicant, String> {}
