package com.example.jobapplication.service;
import com.example.jobapplication.model.*;
import com.example.jobapplication.repository.*;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class JobApplicationService {
    private final ApplicantRepository applicantRepo;
    private final JobRepository jobRepo;
    public JobApplicationService(ApplicantRepository applicantRepo, JobRepository jobRepo) {
        this.applicantRepo=applicantRepo; this.jobRepo=jobRepo;
    }
    public List<ApplicantView> getApplicants(String location) {
        List<ApplicantView> result = new ArrayList<>();
        for (Applicant a : applicantRepo.findAll()) {
            Job j = jobRepo.findByJobId(a.getAppliedJob());
            if (j != null && (location == null || location.isBlank() || j.getLocation().equalsIgnoreCase(location.trim()))) {
                result.add(new ApplicantView(a.getApplicantId(), a.getName(), a.getQualification(), a.getAppliedJob(), j.getJobName(), j.getCompany(), j.getLocation()));
            }
        }
        return result;
    }
    public List<Job> getJobs(){return jobRepo.findAll();}
    public Job addJob(Job job){return jobRepo.save(job);}
    public Applicant addApplicant(Applicant a) {
        if (jobRepo.findByJobId(a.getAppliedJob()) == null) throw new IllegalArgumentException("Job ID not found. Add the job first.");
        return applicantRepo.save(a);
    }
}
