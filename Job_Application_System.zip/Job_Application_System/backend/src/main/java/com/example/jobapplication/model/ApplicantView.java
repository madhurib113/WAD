package com.example.jobapplication.model;
public class ApplicantView {
    private String applicantId, name, qualification, appliedJob, jobTitle, company, location;
    public ApplicantView(String applicantId, String name, String qualification, String appliedJob, String jobTitle, String company, String location) {
        this.applicantId=applicantId; this.name=name; this.qualification=qualification; this.appliedJob=appliedJob; this.jobTitle=jobTitle; this.company=company; this.location=location;
    }
    public String getApplicantId(){return applicantId;} public String getName(){return name;}
    public String getQualification(){return qualification;} public String getAppliedJob(){return appliedJob;}
    public String getJobTitle(){return jobTitle;} public String getCompany(){return company;} public String getLocation(){return location;}
}
