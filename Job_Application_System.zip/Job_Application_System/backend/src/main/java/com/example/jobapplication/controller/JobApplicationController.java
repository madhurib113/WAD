package com.example.jobapplication.controller;
import com.example.jobapplication.model.*;
import com.example.jobapplication.service.JobApplicationService;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class JobApplicationController {
    private final JobApplicationService service;
    public JobApplicationController(JobApplicationService service){this.service=service;}
    @GetMapping("/applicants")
    public List<ApplicantView> getApplicants(@RequestParam(required=false) String location){return service.getApplicants(location);}
    @PostMapping("/applicants")
    public Applicant addApplicant(@RequestBody Applicant a){
        try{return service.addApplicant(a);} catch(IllegalArgumentException e){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());}
    }
    @GetMapping("/jobs") public List<Job> getJobs(){return service.getJobs();}
    @PostMapping("/jobs") public Job addJob(@RequestBody Job job){return service.addJob(job);}
}
