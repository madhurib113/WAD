package com.example.jobapplication.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "applicants")
public class Applicant {
    @Id private String id;
    private String applicantId;
    private String name;
    private String qualification;
    private String appliedJob; // stores the jobId
    public Applicant() {}
    public String getId(){return id;} public void setId(String id){this.id=id;}
    public String getApplicantId(){return applicantId;} public void setApplicantId(String v){this.applicantId=v;}
    public String getName(){return name;} public void setName(String v){this.name=v;}
    public String getQualification(){return qualification;} public void setQualification(String v){this.qualification=v;}
    public String getAppliedJob(){return appliedJob;} public void setAppliedJob(String v){this.appliedJob=v;}
}
