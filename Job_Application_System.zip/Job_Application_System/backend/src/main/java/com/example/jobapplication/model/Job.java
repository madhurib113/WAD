package com.example.jobapplication.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "jobs")
public class Job {
    @Id private String id;
    private String jobId;
    private String company;
    private String jobName;
    private double salary;
    private String location;
    public Job() {}
    public String getId(){return id;} public void setId(String id){this.id=id;}
    public String getJobId(){return jobId;} public void setJobId(String v){this.jobId=v;}
    public String getCompany(){return company;} public void setCompany(String v){this.company=v;}
    public String getJobName(){return jobName;} public void setJobName(String v){this.jobName=v;}
    public double getSalary(){return salary;} public void setSalary(double v){this.salary=v;}
    public String getLocation(){return location;} public void setLocation(String v){this.location=v;}
}
