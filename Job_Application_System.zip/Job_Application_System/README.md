# Job Application System (Spring Boot + MongoDB + Vue)

Two collections:
- `applicants`: `applicantId`, `name`, `qualification` (UG/PG), `appliedJob` (stores a job ID)
- `jobs`: `jobId`, `company`, `jobName`, `salary`, `location`

The backend returns applicant details with the matching job title, company and location. You can filter by location.

## Requirements
Java 17+, Maven, Node.js/npm, MongoDB running locally on port 27017.

## Run backend
Open terminal in `backend` and run:
```bash
mvn spring-boot:run
```
API base URL: `http://localhost:8082/api`
Database: `jobapplicationdb`

## Run frontend
Open a second terminal in `frontend` and run:
```bash
npm install
npm run dev
```
Open `http://localhost:5173`.

## Test with Postman
Add job first: `POST http://localhost:8082/api/jobs`
```json
{"jobId":"J101","company":"ABC Technologies","jobName":"Java Developer","salary":600000,"location":"Chennai"}
```
Add applicant: `POST http://localhost:8082/api/applicants`
```json
{"applicantId":"A101","name":"Anu","qualification":"UG","appliedJob":"J101"}
```
View all applicants: `GET http://localhost:8082/api/applicants`
Filter by location: `GET http://localhost:8082/api/applicants?location=Chennai`
View jobs: `GET http://localhost:8082/api/jobs`

Add a job before adding an applicant. The applicant's `appliedJob` must match an existing `jobId`. MongoDB creates the database/collections when data is saved.
