<template>
  <main class="container">
    <h1>Job Application System</h1>
    <p class="sub">Applicants and their applied jobs by location</p>

    <section class="card">
      <h2>Applicants</h2>
      <div class="filters">
        <input v-model="location" placeholder="Filter by location, e.g. Chennai">
        <button @click="loadApplicants">Search</button>
        <button class="secondary" @click="clearFilter">Show All</button>
      </div>
      <p>{{ message }}</p>
      <table><thead><tr><th>Applicant ID</th><th>Name</th><th>Qualification</th><th>Applied Job ID</th><th>Job Title</th><th>Company</th><th>Location</th></tr></thead>
        <tbody>
          <tr v-for="a in applicants" :key="a.applicantId"><td>{{a.applicantId}}</td><td>{{a.name}}</td><td>{{a.qualification}}</td><td>{{a.appliedJob}}</td><td>{{a.jobTitle}}</td><td>{{a.company}}</td><td>{{a.location}}</td></tr>
          <tr v-if="applicants.length===0"><td colspan="7">No applicants found.</td></tr>
        </tbody>
      </table>
    </section>

    <section class="card"><h2>Add Job</h2>
      <form @submit.prevent="addJob" class="form-grid">
        <input v-model="job.jobId" placeholder="Job ID" required>
        <input v-model="job.company" placeholder="Company" required>
        <input v-model="job.jobName" placeholder="Job Name" required>
        <input v-model.number="job.salary" type="number" min="0" placeholder="Salary" required>
        <input v-model="job.location" placeholder="Location" required>
        <button>Add Job</button>
      </form>
    </section>

    <section class="card"><h2>Add Applicant</h2>
      <form @submit.prevent="addApplicant" class="form-grid">
        <input v-model="applicant.applicantId" placeholder="Applicant ID" required>
        <input v-model="applicant.name" placeholder="Name" required>
        <select v-model="applicant.qualification" required><option disabled value="">Qualification</option><option>UG</option><option>PG</option></select>
        <select v-model="applicant.appliedJob" required><option disabled value="">Select job</option><option v-for="j in jobs" :key="j.jobId" :value="j.jobId">{{j.jobId}} - {{j.jobName}} ({{j.location}})</option></select>
        <button>Save Applicant</button>
      </form>
      <small>Add a job before adding an applicant.</small>
    </section>

    <section class="card"><h2>Jobs</h2>
      <table><thead><tr><th>Job ID</th><th>Company</th><th>Job Name</th><th>Salary</th><th>Location</th></tr></thead>
        <tbody><tr v-for="j in jobs" :key="j.jobId"><td>{{j.jobId}}</td><td>{{j.company}}</td><td>{{j.jobName}}</td><td>{{j.salary}}</td><td>{{j.location}}</td></tr><tr v-if="jobs.length===0"><td colspan="5">No jobs added yet.</td></tr></tbody>
      </table>
    </section>
  </main>
</template>
<script setup>
import { ref, onMounted } from 'vue'
const API = 'http://localhost:8082/api'
const applicants = ref([]), jobs = ref([]), location = ref(''), message = ref('')
const job = ref({jobId:'', company:'', jobName:'', salary:0, location:''})
const applicant = ref({applicantId:'', name:'', qualification:'', appliedJob:''})
async function loadJobs() {
  const r = await fetch(API + '/jobs'); if (!r.ok) throw new Error(); jobs.value = await r.json()
}
async function loadApplicants() {
  try {
    const q = location.value.trim() ? '?location=' + encodeURIComponent(location.value.trim()) : ''
    const r = await fetch(API + '/applicants' + q); if (!r.ok) throw new Error()
    applicants.value = await r.json(); message.value = ''
  } catch { message.value = 'Cannot connect to backend. Start MongoDB and Spring Boot.' }
}
async function loadData() {
  try { await loadJobs(); await loadApplicants() } catch { message.value = 'Cannot connect to backend. Start MongoDB and Spring Boot.' }
}
async function addJob() {
  try {
    const r = await fetch(API + '/jobs', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(job.value)})
    if (!r.ok) throw new Error()
    job.value = {jobId:'', company:'', jobName:'', salary:0, location:''}; message.value = 'Job added.'; await loadData()
  } catch { message.value = 'Could not add job. Check backend connection.' }
}
async function addApplicant() {
  try {
    const r = await fetch(API + '/applicants', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(applicant.value)})
    if (!r.ok) throw new Error()
    applicant.value = {applicantId:'', name:'', qualification:'', appliedJob:''}; message.value = 'Applicant saved.'; await loadData()
  } catch { message.value = 'Could not save applicant. Make sure the selected job exists.' }
}
function clearFilter(){location.value=''; loadApplicants()}
onMounted(loadData)
</script>
