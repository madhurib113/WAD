# Servlet Viva Questions and Short Answers

## Servlet basics

1. **What is a Servlet?**  
   A Java server-side component that handles client requests and generates responses.

2. **Why are Servlets used?**  
   To process HTTP requests, perform server-side logic, and return dynamic responses.

3. **What is a web server?**  
   Software that receives and responds to HTTP requests.

4. **What is Apache Tomcat?**  
   A web server and Servlet/JSP container used to run Java web applications.

5. **What is the role of `HttpServlet`?**  
   It provides methods for handling HTTP requests, such as `doGet()` and `doPost()`.

6. **What is `doGet()`?**  
   A method that handles HTTP GET requests, commonly used to display pages or retrieve data.

7. **What is `doPost()`?**  
   A method that handles HTTP POST requests, commonly used to submit form data.

8. **Difference between GET and POST?**  
   GET parameters are commonly placed in the URL; POST data is sent in the request body.

9. **What is `web.xml`?**  
   The deployment descriptor used to configure servlet mappings and other web application settings.

10. **What is a URL pattern?**  
    The path mapped to a servlet, such as `/vote`.

11. **What does `@WebServlet` do?**  
    It maps a servlet using an annotation. This project uses `web.xml` mappings instead.

12. **What is `HttpServletRequest`?**  
    It provides access to request information, including form parameters.

13. **What is `HttpServletResponse`?**  
    It is used to configure and send the response to the client.

14. **What does `request.getParameter("age")` return?**  
    The submitted parameter value as a `String`, or `null` if it is absent.

15. **Why use `Integer.parseInt()`?**  
    To convert a numeric string into an `int`.

16. **Why call `response.setContentType("text/html")`?**  
    To tell the browser that the response contains HTML.

17. **What does `response.getWriter()` do?**  
    It returns a writer used to send text to the response.

18. **What is a WAR file?**  
    A Web Application Archive containing a deployable Java web application.

19. **What is Maven used for here?**  
    It manages dependencies and builds the project into a WAR file.

20. **Why is `javax.servlet-api` marked `provided`?**  
    Tomcat supplies the Servlet API at runtime, so it should not be bundled as an application dependency.

21. **Why is Tomcat 9 used?**  
    This code uses the `javax.servlet` namespace supported by Tomcat 9.

22. **What changes with Tomcat 10?**  
    Tomcat 10 uses `jakarta.servlet`, so imports and compatible dependencies must be updated.

23. **What is the servlet lifecycle?**  
    Loading/instantiation, `init()`, request handling through `service()` and methods such as `doGet()`/`doPost()`, then `destroy()`.

24. **Does each request create a new servlet object?**  
    Usually no. The container typically uses one servlet instance to handle multiple requests concurrently.

25. **What is a session?**  
    A way to maintain user-specific state across multiple HTTP requests.

## Questions based on these programs

26. **How is voting eligibility checked?**  
    If age is at least 18, the user is eligible; otherwise, not eligible.

27. **How is average calculated?**  
    Total marks divided by the number of subjects.

28. **Why use `5.0` instead of `5` for average?**  
    It ensures floating-point division and preserves decimal values.

29. **How is the grade decided?**  
    By checking the average against grade thresholds using an `if-else` chain.

30. **What is simple interest?**  
    `SI = Principal × Rate × Time / 100`.

31. **How is total amount calculated in simple interest?**  
    Principal plus simple interest.

32. **Why does the electricity bill use conditions?**  
    To apply different sample rates to different unit ranges.

33. **What does `%` do in the even/odd program?**  
    It returns the remainder. A remainder of zero when divided by two means even.

34. **What is factorial?**  
    The product of positive integers from 1 through the given number; `0! = 1`.

35. **Why is factorial limited to 20?**  
    To keep the result within the range of Java's `long` for this example.

36. **How is the largest of three numbers found?**  
    By comparing the numbers; this program uses nested `Math.max()` calls.

37. **What is BMI?**  
    Body mass index, calculated here as weight in kilograms divided by height in metres squared.

38. **Why validate input values?**  
    To reject invalid values and avoid incorrect calculations or errors.

39. **What happens if a required number field is left blank?**  
    The browser's `required` attribute normally prevents submission, but server-side validation is also important.

40. **Why can `Integer.parseInt()` fail?**  
    It throws `NumberFormatException` if the supplied string is not a valid integer.

41. **What is `sendRedirect()`?**  
    It instructs the browser to make a new request to another URL.

42. **What is the difference between redirect and forward?**  
    A redirect makes the client issue another request; a forward transfers control on the server without a new client request.

43. **What is a context path?**  
    The application name portion of a URL, such as `/ServletPractice`.

44. **What does `mvn clean package` do?**  
    It removes previous build output, compiles the project, runs configured tests, and packages the WAR.

45. **How do you troubleshoot a 404 error?**  
    Check Tomcat is running, the WAR deployed successfully, the context path, and the servlet URL mapping.

46. **How do you troubleshoot a 500 error?**  
    Check the Tomcat logs and application stack trace for the underlying exception.

47. **Can HTML be written directly from a Servlet?**  
    Yes, using `response.getWriter()`, although JSP or templates are often easier for larger pages.

48. **What is the purpose of `required` in HTML inputs?**  
    It asks the browser to prevent submission when the field is empty.

49. **Why should server-side validation still be done?**  
    Browser validation can be bypassed, so the server must not trust client input.

50. **What is the difference between compile-time and runtime errors?**  
    Compile-time errors are detected during compilation; runtime errors occur while the program executes.


## Additional questions for the two new programs

51. **How is attendance percentage calculated?**  
    `(Classes attended / Total classes) * 100`.

52. **Why is `100.0` used in the attendance calculation?**  
    It makes the calculation use floating-point arithmetic instead of integer division.

53. **Why check whether attended classes exceed total classes?**  
    Such input is invalid and would produce an incorrect percentage.

54. **What does HRA mean?**  
    House Rent Allowance.

55. **What does DA mean?**  
    Dearness Allowance.

56. **What is gross salary?**  
    Basic salary plus allowances before deductions.

57. **What is net salary?**  
    Gross salary after deductions.

58. **Are the salary percentages fixed for every company?**  
    No. The percentages in this practice program are sample values and can be changed according to the question.
