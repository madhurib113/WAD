# \# Servlet Practice — 10 Programs

# 

# \## Programs Included

# 

# 1\. Voting Eligibility

# 2\. Marks and Grade Calculator

# 3\. Simple Interest Calculator

# 4\. Electricity Bill Calculator

# 5\. Even or Odd

# 6\. Factorial Calculator

# 7\. Largest of Three Numbers

# 8\. BMI Calculator

# 9\. Student Attendance Eligibility

# 10\. Employee Salary Calculator

# 

# \## Requirements

# 

# \- Ubuntu Linux

# \- Java JDK 17

# \- Apache Maven

# \- Apache Tomcat 9 (already installed)

# 

# \*\*Note:\*\* This project uses `javax.servlet`, so it is compatible with Tomcat 9.

# 

# \## Step 1: Check Java and Maven

# 

# Open the Ubuntu Terminal and run:

# 

# ```bash

# java --version

# mvn --version

# ```

# 

# If Java or Maven is missing, install them:

# 

# ```bash

# sudo apt update

# sudo apt install openjdk-17-jdk maven

# ```

# 

# \## Step 2: Extract the Project

# 

# Go to the Downloads folder:

# 

# ```bash

# cd \~/Downloads

# unzip Servlet\_Practice\_10\_Examples\_Ubuntu.zip

# ```

# 

# Enter the extracted project directory. Use `ls` to find the folder containing `pom.xml`.

# 

# ```bash

# ls

# cd Servlet\_Practice\_8\_Examples

# ```

# 

# If your extracted folder has a different name, use that name instead.

# 

# \## Step 3: Build the Project

# 

# Make sure you are inside the directory containing `pom.xml`.

# 

# Run:

# 

# ```bash

# mvn clean package

# ```

# 

# After a successful build, the WAR file will be created at:

# 

# ```text

# target/ServletPractice.war

# ```

# 

# \## Step 4: Check Tomcat

# 

# Check whether Tomcat is running:

# 

# ```bash

# sudo systemctl status tomcat9

# ```

# 

# If it is stopped, start it:

# 

# ```bash

# sudo systemctl start tomcat9

# ```

# 

# If your Tomcat installation uses a different service name, use the appropriate service name.

# 

# \## Step 5: Deploy the Application

# 

# For a standard Ubuntu package installation of Tomcat 9, run this command from your project directory:

# 

# ```bash

# sudo cp target/ServletPractice.war /var/lib/tomcat9/webapps/

# ```

# 

# Restart Tomcat:

# 

# ```bash

# sudo systemctl restart tomcat9

# ```

# 

# If your existing Tomcat uses a different deployment directory, copy the WAR file into its configured `webapps` directory instead.

# 

# \## Step 6: Open the Programs

# 

# Open a web browser and visit these URLs.

# 

# \*\*1. Voting Eligibility\*\*

# 

# http://localhost:8080/ServletPractice/vote

# 

# \*\*2. Marks and Grade Calculator\*\*

# 

# http://localhost:8080/ServletPractice/grade

# 

# \*\*3. Simple Interest Calculator\*\*

# 

# http://localhost:8080/ServletPractice/interest

# 

# \*\*4. Electricity Bill Calculator\*\*

# 

# http://localhost:8080/ServletPractice/electricity

# 

# \*\*5. Even or Odd\*\*

# 

# http://localhost:8080/ServletPractice/evenodd

# 

# \*\*6. Factorial Calculator\*\*

# 

# http://localhost:8080/ServletPractice/factorial

# 

# \*\*7. Largest of Three Numbers\*\*

# 

# http://localhost:8080/ServletPractice/largest

# 

# \*\*8. BMI Calculator\*\*

# 

# http://localhost:8080/ServletPractice/bmi

# 

# \*\*9. Attendance Eligibility\*\*

# 

# http://localhost:8080/ServletPractice/attendance

# 

# \*\*10. Employee Salary Calculator\*\*

# 

# http://localhost:8080/ServletPractice/salary

# 

# If Tomcat uses a port other than `8080`, replace `8080` in the URLs with your configured port.

# 

# \## Sample Calculation Rules

# 

# \- \*\*Grades:\*\* 90 and above = A, 80 and above = B, 70 and above = C, 60 and above = D, 50 and above = E, below 50 = Fail.

# \- \*\*Electricity Bill:\*\* First 100 units at Rs. 1.50 per unit, next 100 units at Rs. 2.50 per unit, remaining units at Rs. 4.00 per unit.

# \- \*\*Attendance:\*\* 75% or above is eligible.

# \- \*\*Salary:\*\* HRA = 20% of basic salary, DA = 10% of basic salary, PF deduction = 12% of basic salary.

# 

# These are sample rules for laboratory practice.

# 

# \## Troubleshooting

# 

# \### Error: `mvn: command not found`

# 

# ```bash

# sudo apt install maven

# ```

# 

# \### Error: `java: command not found`

# 

# ```bash

# sudo apt install openjdk-17-jdk

# ```

# 

# \### Error: 404 Not Found

# 

# \- Check whether Tomcat is running.

# \- Check whether `ServletPractice.war` has been deployed.

# \- Check the application name and URL mapping.

# 

# \### Error: 500 Internal Server Error

# 

# Check the Tomcat logs for the Java exception.

# 

# For standard Ubuntu package installations, logs are commonly located under:

# 

# ```bash

# /var/log/tomcat9/

# ```

# 

# \### Servlet errors involving `javax.servlet`

# 

# Confirm that you are using Tomcat 9. Tomcat 10 uses `jakarta.servlet` and requires code changes.

# 

# \## Viva Questions

# 

# Open `VIVA\_QUESTIONS.md` in the project folder for Servlet theory questions and answers based on all ten programs.



