package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InterestServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h2>Simple Interest Calculator</h2>");
        response.getWriter().println("<form method='post'>Principal: <input type='number' step='any' name='p' required><br><br>");
        response.getWriter().println("Rate (%): <input type='number' step='any' name='r' required><br><br>");
        response.getWriter().println("Time (years): <input type='number' step='any' name='t' required><br><br><button>Calculate</button></form>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        double p = Double.parseDouble(request.getParameter("p"));
        double r = Double.parseDouble(request.getParameter("r"));
        double t = Double.parseDouble(request.getParameter("t"));
        double si = p * r * t / 100;
        response.setContentType("text/html");
        response.getWriter().println("<h2>Simple Interest: " + si + "</h2>");
        response.getWriter().println("Total Amount: " + (p + si) + "<br><a href='interest'>Try again</a>");
    }
}
