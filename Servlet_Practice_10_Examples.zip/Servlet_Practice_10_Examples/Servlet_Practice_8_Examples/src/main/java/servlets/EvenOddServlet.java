package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EvenOddServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h2>Even or Odd</h2><form method='post'>");
        response.getWriter().println("Enter an integer: <input type='number' name='number' required>");
        response.getWriter().println("<button>Check</button></form>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int number = Integer.parseInt(request.getParameter("number"));
        response.setContentType("text/html");
        response.getWriter().println("<h2>" + number + " is " +
                (number % 2 == 0 ? "Even" : "Odd") + "</h2><a href='evenodd'>Try again</a>");
    }
}
