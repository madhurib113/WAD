package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FactorialServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h2>Factorial Calculator</h2><form method='post'>");
        response.getWriter().println("Enter a number (0-20): <input type='number' name='number' min='0' max='20' required>");
        response.getWriter().println("<button>Calculate</button></form>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int number = Integer.parseInt(request.getParameter("number"));
        if (number < 0 || number > 20) {
            response.setContentType("text/html");
            response.getWriter().println("Enter a number between 0 and 20. <a href='factorial'>Try again</a>");
            return;
        }
        long fact = 1;
        for (int i = 1; i <= number; i++) fact *= i;
        response.setContentType("text/html");
        response.getWriter().println("<h2>Factorial of " + number + " = " + fact
                + "</h2><a href='factorial'>Try again</a>");
    }
}
