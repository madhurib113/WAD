package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GradeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<html><body><h2>Marks and Grade Calculator</h2>");
        response.getWriter().println("<form method='post'>");
        for (int i = 1; i <= 5; i++)
            response.getWriter().println("Subject " + i + ": <input type='number' name='m" + i + "' min='0' max='100' required><br><br>");
        response.getWriter().println("<button type='submit'>Calculate</button></form></body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int total = 0;
        for (int i = 1; i <= 5; i++) {
            int mark = Integer.parseInt(request.getParameter("m" + i));
            if (mark < 0 || mark > 100) {
                response.setContentType("text/html");
                response.getWriter().println("Marks must be between 0 and 100. <a href='grade'>Try again</a>");
                return;
            }
            total += mark;
        }
        double average = total / 5.0;
        String grade;
        if (average >= 90) grade = "A";
        else if (average >= 80) grade = "B";
        else if (average >= 70) grade = "C";
        else if (average >= 60) grade = "D";
        else if (average >= 50) grade = "E";
        else grade = "Fail";

        response.setContentType("text/html");
        response.getWriter().println("<html><body><h2>Result</h2>Total: " + total
                + "<br>Average: " + average + "<br>Grade: " + grade
                + "<br><a href='grade'>Calculate again</a></body></html>");
    }
}
