package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ElectricityServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h2>Electricity Bill</h2><form method='post'>");
        response.getWriter().println("Units used: <input type='number' name='units' min='0' required>");
        response.getWriter().println("<button>Calculate bill</button></form>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int units = Integer.parseInt(request.getParameter("units"));
        double bill;
        if (units <= 100) bill = units * 1.5;
        else if (units <= 200) bill = 100 * 1.5 + (units - 100) * 2.5;
        else bill = 100 * 1.5 + 100 * 2.5 + (units - 200) * 4.0;

        response.setContentType("text/html");
        response.getWriter().println("<h2>Electricity Bill</h2>Units: " + units
                + "<br>Bill amount: Rs. " + bill + "<br><a href='electricity'>Try again</a>");
    }
}
