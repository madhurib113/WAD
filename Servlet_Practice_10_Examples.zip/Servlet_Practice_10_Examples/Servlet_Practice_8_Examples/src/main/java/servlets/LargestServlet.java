package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LargestServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h2>Find the Largest of Three Numbers</h2><form method='post'>");
        response.getWriter().println("Number 1: <input type='number' name='a' required><br><br>");
        response.getWriter().println("Number 2: <input type='number' name='b' required><br><br>");
        response.getWriter().println("Number 3: <input type='number' name='c' required><br><br>");
        response.getWriter().println("<button>Find largest</button></form>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int a = Integer.parseInt(request.getParameter("a"));
        int b = Integer.parseInt(request.getParameter("b"));
        int c = Integer.parseInt(request.getParameter("c"));
        int largest = Math.max(a, Math.max(b, c));
        response.setContentType("text/html");
        response.getWriter().println("<h2>Largest number: " + largest
                + "</h2><a href='largest'>Try again</a>");
    }
}
