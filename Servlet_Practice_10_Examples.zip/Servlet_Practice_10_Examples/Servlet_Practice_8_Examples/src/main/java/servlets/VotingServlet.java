package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VotingServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        String ageText = request.getParameter("age");
        response.getWriter().println("<html><body><h2>Voting Eligibility</h2>");
        if (ageText == null) {
            response.getWriter().println("<form method='post'>Enter age: <input type='number' name='age' required><button>Check</button></form>");
        } else {
            int age = Integer.parseInt(ageText);
            response.getWriter().println(age >= 18 ? "Eligible to vote" : "Not eligible to vote");
            response.getWriter().println("<p><a href='vote'>Try again</a></p>");
        }
        response.getWriter().println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String age = request.getParameter("age");
        response.sendRedirect("vote?age=" + age);
    }
}
