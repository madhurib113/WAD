package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SalaryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h2>Employee Salary Calculator</h2><form method='post'>");
        response.getWriter().println("Basic salary (Rs.): <input type='number' step='any' name='basic' min='0' required><br><br>");
        response.getWriter().println("<button>Calculate salary</button></form>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        double basic = Double.parseDouble(request.getParameter("basic"));
        if (basic < 0) {
            response.setContentType("text/html");
            response.getWriter().println("Salary cannot be negative. <a href='salary'>Try again</a>");
            return;
        }

        double hra = basic * 0.20;
        double da = basic * 0.10;
        double pf = basic * 0.12;
        double gross = basic + hra + da;
        double net = gross - pf;

        response.setContentType("text/html");
        response.getWriter().println("<h2>Salary Details</h2>");
        response.getWriter().println("Basic salary: Rs. " + basic + "<br>");
        response.getWriter().println("HRA (20%): Rs. " + hra + "<br>");
        response.getWriter().println("DA (10%): Rs. " + da + "<br>");
        response.getWriter().println("PF deduction (12% of basic): Rs. " + pf + "<br>");
        response.getWriter().println("Gross salary: Rs. " + gross + "<br>");
        response.getWriter().println("<b>Net salary: Rs. " + net + "</b><br>");
        response.getWriter().println("<a href='salary'>Try again</a>");
    }
}
