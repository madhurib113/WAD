package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BmiServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h2>BMI Calculator</h2><form method='post'>");
        response.getWriter().println("Weight (kg): <input type='number' step='any' name='weight' min='1' required><br><br>");
        response.getWriter().println("Height (metres): <input type='number' step='any' name='height' min='0.1' required><br><br>");
        response.getWriter().println("<button>Calculate BMI</button></form>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        double weight = Double.parseDouble(request.getParameter("weight"));
        double height = Double.parseDouble(request.getParameter("height"));
        if (weight <= 0 || height <= 0) {
            response.setContentType("text/html");
            response.getWriter().println("Weight and height must be positive. <a href='bmi'>Try again</a>");
            return;
        }
        double bmi = weight / (height * height);
        String category;
        if (bmi < 18.5) category = "Underweight";
        else if (bmi < 25) category = "Normal range";
        else if (bmi < 30) category = "Overweight";
        else category = "Obesity range";
        response.setContentType("text/html");
        response.getWriter().println("<h2>BMI: " + String.format("%.2f", bmi)
                + "</h2>Category: " + category + "<br><a href='bmi'>Try again</a>");
    }
}
