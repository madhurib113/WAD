package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AttendanceServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h2>Attendance Eligibility</h2>");
        response.getWriter().println("<form method='post'>");
        response.getWriter().println("Classes attended: <input type='number' name='attended' min='0' required><br><br>");
        response.getWriter().println("Total classes: <input type='number' name='total' min='1' required><br><br>");
        response.getWriter().println("<button>Check eligibility</button></form>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int attended = Integer.parseInt(request.getParameter("attended"));
        int total = Integer.parseInt(request.getParameter("total"));
        response.setContentType("text/html");

        if (total <= 0 || attended < 0 || attended > total) {
            response.getWriter().println("Enter valid attendance values. <a href='attendance'>Try again</a>");
            return;
        }

        double percentage = attended * 100.0 / total;
        String result = percentage >= 75 ? "Eligible for the examination" : "Not eligible for the examination";
        response.getWriter().println("<h2>Attendance Result</h2>");
        response.getWriter().println("Attendance: " + String.format("%.2f", percentage) + "%<br>");
        response.getWriter().println(result + "<br><a href='attendance'>Try again</a>");
    }
}
