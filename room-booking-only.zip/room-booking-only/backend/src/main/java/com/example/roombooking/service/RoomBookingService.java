package com.example.roombooking.service;

import com.example.roombooking.model.Booking;
import com.example.roombooking.model.Room;
import com.example.roombooking.repository.BookingRepository;
import com.example.roombooking.repository.RoomRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomBookingService {
    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;

    public RoomBookingService(RoomRepository roomRepository,
                              BookingRepository bookingRepository) {
        this.roomRepository = roomRepository;
        this.bookingRepository = bookingRepository;
    }

    // ROOM OPERATIONS

    public List<Room> getRooms() {
        return roomRepository.findAll();
    }

    public Room addRoom(Room room) {
        if (roomRepository.findByRoomNumber(room.getRoomNumber()).isPresent()) {
            throw new IllegalArgumentException("Room number already exists");
        }
        return roomRepository.save(room);
    }

    public Room updateRoom(String id, Room room) {
        room.setId(id);
        return roomRepository.save(room);
    }

    public void deleteRoom(String id) {
        roomRepository.deleteById(id);
    }

    public List<Room> getAvailableRooms() {
        return roomRepository.findByAvailableTrue();
    }

    public long countAvailableRooms() {
        return roomRepository.countByAvailableTrue();
    }

    public long countAllRooms() {
        return roomRepository.count();
    }

    // BOOKING OPERATIONS

    public List<Booking> getBookings() {
        return bookingRepository.findAll();
    }

    // A booking is accepted only if its room exists and is available.
    // roomNumber is the common field used to connect rooms and bookings.
    public Booking addBooking(Booking booking) {
        Room room = roomRepository.findByRoomNumber(booking.getRoomNumber())
                .orElseThrow(() -> new IllegalArgumentException("Room number not found"));

        if (!room.isAvailable()) {
            throw new IllegalArgumentException("Room is not available");
        }

        if (booking.getDays() < 1) {
            throw new IllegalArgumentException("Days must be at least 1");
        }

        Booking savedBooking = bookingRepository.save(booking);

        // Mark the same room as unavailable after booking is saved.
        room.setAvailable(false);
        roomRepository.save(room);

        return savedBooking;
    }

    public Booking updateBooking(String id, Booking booking) {
        booking.setId(id);
        return bookingRepository.save(booking);
    }

    public void deleteBooking(String id) {
        bookingRepository.deleteById(id);
    }

    public long countAllBookings() {
        return bookingRepository.count();
    }

    public long countBookingsForRoom(String roomNumber) {
        return bookingRepository.countByRoomNumber(roomNumber);
    }

    public List<Booking> getBookingsForRoom(String roomNumber) {
        return bookingRepository.findByRoomNumber(roomNumber);
    }

    public long countBookingsForCustomer(String customerName) {
        return bookingRepository.countByCustomerNameIgnoreCase(customerName);
    }
}
