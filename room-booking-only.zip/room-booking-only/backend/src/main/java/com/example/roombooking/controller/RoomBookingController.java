package com.example.roombooking.controller;

import com.example.roombooking.model.Booking;
import com.example.roombooking.model.Room;
import com.example.roombooking.service.RoomBookingService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class RoomBookingController {
    private final RoomBookingService service;

    public RoomBookingController(RoomBookingService service) {
        this.service = service;
    }

    // ROOM ENDPOINTS

    @GetMapping("/rooms")
    public List<Room> getRooms() {
        return service.getRooms();
    }

    @PostMapping("/rooms")
    public Room addRoom(@RequestBody Room room) {
        try {
            return service.addRoom(room);
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    @PutMapping("/rooms/{id}")
    public Room updateRoom(@PathVariable String id, @RequestBody Room room) {
        return service.updateRoom(id, room);
    }

    @DeleteMapping("/rooms/{id}")
    public void deleteRoom(@PathVariable String id) {
        service.deleteRoom(id);
    }

    @GetMapping("/rooms/available")
    public List<Room> getAvailableRooms() {
        return service.getAvailableRooms();
    }

    @GetMapping("/rooms/available/count")
    public long countAvailableRooms() {
        return service.countAvailableRooms();
    }

    @GetMapping("/rooms/count")
    public long countAllRooms() {
        return service.countAllRooms();
    }

    // BOOKING ENDPOINTS

    @GetMapping("/bookings")
    public List<Booking> getBookings() {
        return service.getBookings();
    }

    @PostMapping("/bookings")
    public Booking addBooking(@RequestBody Booking booking) {
        try {
            return service.addBooking(booking);
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    @PutMapping("/bookings/{id}")
    public Booking updateBooking(@PathVariable String id, @RequestBody Booking booking) {
        return service.updateBooking(id, booking);
    }

    @DeleteMapping("/bookings/{id}")
    public void deleteBooking(@PathVariable String id) {
        service.deleteBooking(id);
    }

    @GetMapping("/bookings/count")
    public long countAllBookings() {
        return service.countAllBookings();
    }

    @GetMapping("/bookings/room/{roomNumber}/count")
    public long countBookingsForRoom(@PathVariable String roomNumber) {
        return service.countBookingsForRoom(roomNumber);
    }

    @GetMapping("/bookings/room/{roomNumber}")
    public List<Booking> getBookingsForRoom(@PathVariable String roomNumber) {
        return service.getBookingsForRoom(roomNumber);
    }

    @GetMapping("/bookings/customer/{customerName}/count")
    public long countBookingsForCustomer(@PathVariable String customerName) {
        return service.countBookingsForCustomer(customerName);
    }
}
