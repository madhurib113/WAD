package com.example.roombooking.repository;

import com.example.roombooking.model.Booking;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface BookingRepository extends MongoRepository<Booking, String> {
    long countByRoomNumber(String roomNumber);
    List<Booking> findByRoomNumber(String roomNumber);
    long countByCustomerNameIgnoreCase(String customerName);
}
