package com.example.roombooking.repository;

import com.example.roombooking.model.Room;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;
import java.util.Optional;

public interface RoomRepository extends MongoRepository<Room, String> {
    List<Room> findByAvailableTrue();
    long countByAvailableTrue();
    Optional<Room> findByRoomNumber(String roomNumber);
}
