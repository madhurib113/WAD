<script setup>
import { computed, onMounted, reactive, ref } from 'vue'

const API = 'http://localhost:8082'
const rooms = ref([])
const bookings = ref([])
const message = ref('')
const error = ref('')
const loading = ref(false)
const activeTab = ref('rooms')

const roomForm = reactive({ roomNumber: '', roomType: 'Single', price: '', available: true })
const bookingForm = reactive({ bookingId: '', customerName: '', roomNumber: '', days: 1 })

const availableRooms = computed(() => rooms.value.filter(room => room.available))
const totalRevenue = computed(() => bookings.value.reduce((sum, booking) => {
  const room = rooms.value.find(item => item.roomNumber === booking.roomNumber)
  return sum + (Number(room?.price || 0) * Number(booking.days || 0))
}, 0))

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  })
  if (!response.ok) {
    let detail = `Request failed (${response.status})`
    try {
      const body = await response.json()
      detail = body.message || body.error || detail
    } catch {
      try { detail = (await response.text()) || detail } catch {}
    }
    throw new Error(detail)
  }
  if (response.status === 204) return null
  const text = await response.text()
  return text ? JSON.parse(text) : null
}

function showMessage(text) {
  message.value = text
  error.value = ''
  setTimeout(() => { message.value = '' }, 3500)
}
function showError(err) {
  error.value = err.message || 'Something went wrong'
  message.value = ''
}

async function loadData() {
  loading.value = true
  error.value = ''
  try {
    const [roomData, bookingData] = await Promise.all([
      request('/rooms'), request('/bookings')
    ])
    rooms.value = roomData || []
    bookings.value = bookingData || []
  } catch (err) {
    showError(err)
  } finally {
    loading.value = false
  }
}

async function addRoom() {
  try {
    await request('/rooms', {
      method: 'POST',
      body: JSON.stringify({
        roomNumber: roomForm.roomNumber.trim(),
        roomType: roomForm.roomType,
        price: Number(roomForm.price),
        available: true
      })
    })
    Object.assign(roomForm, { roomNumber: '', roomType: 'Single', price: '', available: true })
    await loadData()
    showMessage('Room added successfully.')
  } catch (err) { showError(err) }
}

async function deleteRoom(room) {
  if (!confirm(`Delete room ${room.roomNumber}?`)) return
  try {
    await request(`/rooms/${encodeURIComponent(room.id)}`, { method: 'DELETE' })
    await loadData()
    showMessage('Room deleted.')
  } catch (err) { showError(err) }
}

async function createBooking() {
  try {
    await request('/bookings', {
      method: 'POST',
      body: JSON.stringify({
        bookingId: bookingForm.bookingId.trim(),
        customerName: bookingForm.customerName.trim(),
        roomNumber: bookingForm.roomNumber,
        days: Number(bookingForm.days)
      })
    })
    Object.assign(bookingForm, { bookingId: '', customerName: '', roomNumber: '', days: 1 })
    await loadData()
    activeTab.value = 'bookings'
    showMessage('Booking created successfully.')
  } catch (err) { showError(err) }
}

async function deleteBooking(booking) {
  if (!confirm(`Delete booking ${booking.bookingId || booking.id}?`)) return
  try {
    await request(`/bookings/${encodeURIComponent(booking.id)}`, { method: 'DELETE' })
    await loadData()
    showMessage('Booking deleted. If needed, make the room available again from your backend/database.')
  } catch (err) { showError(err) }
}

onMounted(loadData)
</script>

<template>
  <main class="page-shell">
    <header class="topbar">
      <div class="brand"><div class="brand-icon">RB</div><div><p class="eyebrow">ROOM MANAGEMENT</p><h1>Room Booking</h1></div></div>
      <button class="btn btn-light" @click="loadData">↻ Refresh</button>
    </header>

    <section class="welcome">
      <div><p class="eyebrow light">WELCOME BACK</p><h2>Manage your rooms with ease.</h2><p class="subtext">Track room availability and manage customer bookings in one place.</p></div>
      <div class="welcome-art" aria-hidden="true">⌂</div>
    </section>

    <div v-if="message" class="notice success">✓ {{ message }}</div>
    <div v-if="error" class="notice danger">⚠ {{ error }} <span class="hint">Make sure the Spring Boot backend and MongoDB are running.</span></div>

    <section class="stats">
      <article class="stat-card"><span class="stat-icon blue">▦</span><div><p>Total rooms</p><strong>{{ rooms.length }}</strong></div></article>
      <article class="stat-card"><span class="stat-icon green">✓</span><div><p>Available rooms</p><strong>{{ availableRooms.length }}</strong></div></article>
      <article class="stat-card"><span class="stat-icon purple">▤</span><div><p>Total bookings</p><strong>{{ bookings.length }}</strong></div></article>
      <article class="stat-card"><span class="stat-icon orange">₹</span><div><p>Estimated booking value</p><strong>₹{{ totalRevenue.toLocaleString('en-IN') }}</strong></div></article>
    </section>

    <nav class="tabs">
      <button :class="{ active: activeTab === 'rooms' }" @click="activeTab = 'rooms'">Rooms</button>
      <button :class="{ active: activeTab === 'bookings' }" @click="activeTab = 'bookings'">Bookings</button>
      <button :class="{ active: activeTab === 'new-booking' }" @click="activeTab = 'new-booking'">＋ New booking</button>
    </nav>

    <section v-if="activeTab === 'rooms'" class="content-grid">
      <article class="panel form-panel">
        <div class="panel-heading"><div><p class="eyebrow">ROOM INVENTORY</p><h3>Add a room</h3></div><span class="round-icon">＋</span></div>
        <form @submit.prevent="addRoom" class="form">
          <label>Room number<input v-model="roomForm.roomNumber" required maxlength="30" placeholder="e.g. 101" /></label>
          <label>Room type<select v-model="roomForm.roomType"><option>Single</option><option>Double</option><option>Deluxe</option><option>Suite</option><option>Family</option></select></label>
          <label>Price per day (₹)<input v-model="roomForm.price" required type="number" min="0" step="0.01" placeholder="1500" /></label>
          <button class="btn btn-primary full" type="submit">＋ Add room</button>
        </form>
      </article>

      <article class="panel table-panel">
        <div class="panel-heading"><div><p class="eyebrow">YOUR PROPERTY</p><h3>All rooms <span class="count">{{ rooms.length }}</span></h3></div></div>
        <div v-if="loading" class="empty">Loading rooms…</div>
        <div v-else-if="rooms.length === 0" class="empty"><div class="empty-icon">▦</div><strong>No rooms yet</strong><p>Add your first room using the form.</p></div>
        <div v-else class="table-wrap"><table><thead><tr><th>ROOM</th><th>TYPE</th><th>PRICE / DAY</th><th>STATUS</th><th></th></tr></thead><tbody><tr v-for="room in rooms" :key="room.id"><td><strong>#{{ room.roomNumber }}</strong></td><td>{{ room.roomType }}</td><td>₹{{ Number(room.price).toLocaleString('en-IN') }}</td><td><span class="status" :class="room.available ? 'available' : 'occupied'">{{ room.available ? 'Available' : 'Booked' }}</span></td><td><button class="icon-button" title="Delete room" @click="deleteRoom(room)">×</button></td></tr></tbody></table></div>
      </article>
    </section>

    <section v-else-if="activeTab === 'bookings'" class="panel table-panel booking-panel">
      <div class="panel-heading"><div><p class="eyebrow">RESERVATIONS</p><h3>Customer bookings <span class="count">{{ bookings.length }}</span></h3></div><button class="btn btn-primary" @click="activeTab = 'new-booking'">＋ New booking</button></div>
      <div v-if="loading" class="empty">Loading bookings…</div>
      <div v-else-if="bookings.length === 0" class="empty"><div class="empty-icon">▤</div><strong>No bookings yet</strong><p>New reservations will appear here.</p></div>
      <div v-else class="table-wrap"><table><thead><tr><th>BOOKING ID</th><th>CUSTOMER</th><th>ROOM</th><th>DAYS</th><th></th></tr></thead><tbody><tr v-for="booking in bookings" :key="booking.id"><td><strong>{{ booking.bookingId || booking.id }}</strong></td><td>{{ booking.customerName }}</td><td>#{{ booking.roomNumber }}</td><td>{{ booking.days }}</td><td><button class="icon-button" title="Delete booking" @click="deleteBooking(booking)">×</button></td></tr></tbody></table></div>
    </section>

    <section v-else class="panel new-booking-panel">
      <div class="panel-heading"><div><p class="eyebrow">RESERVATIONS</p><h3>Create a booking</h3><p class="panel-description">Choose an available room and enter the customer details.</p></div><span class="round-icon">▤</span></div>
      <form class="form booking-form" @submit.prevent="createBooking">
        <label>Booking ID<input v-model="bookingForm.bookingId" required placeholder="e.g. BK1001" /></label>
        <label>Customer name<input v-model="bookingForm.customerName" required placeholder="Full name" /></label>
        <label>Available room<select v-model="bookingForm.roomNumber" required><option disabled value="">Select a room</option><option v-for="room in availableRooms" :key="room.id" :value="room.roomNumber">Room {{ room.roomNumber }} · {{ room.roomType }} · ₹{{ room.price }}/day</option></select><small v-if="availableRooms.length === 0">No rooms are currently available. Add a room first.</small></label>
        <label>Number of days<input v-model="bookingForm.days" required type="number" min="1" step="1" /></label>
        <div class="form-actions"><button class="btn btn-light" type="button" @click="activeTab = 'rooms'">Cancel</button><button class="btn btn-primary" type="submit" :disabled="availableRooms.length === 0">Confirm booking →</button></div>
      </form>
    </section>

    <footer>Room Booking System <span>•</span> Vue + Spring Boot + MongoDB</footer>
  </main>
</template>
