# Room Booking System (only)

This ZIP contains only the Room Booking application: Spring Boot + MongoDB backend and Vue 3 + Vite frontend.

## Requirements
- Java 17+
- Maven
- Node.js and npm
- MongoDB running locally at `mongodb://localhost:27017`

## Run backend (terminal 1)
```bash
cd backend
mvn spring-boot:run
```
Backend runs at `http://localhost:8082` and uses MongoDB database `roombookingdb`.

## Run frontend (terminal 2)
```bash
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173`.

The frontend calls the backend endpoints `/rooms` and `/bookings`. The original backend logic and model fields from the supplied project are retained.
